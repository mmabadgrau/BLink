#ifndef __ResultsTable_h__
#define __ResultsTable_h__

namespace BIOS {

	class ResultsTable{
		private:

		public:
		//! Table rows
		int rows;
		//! Table cols
		int cols;
		//! Result values (the sum if there are more than one sample)
		double **values;
		//! String with the row caption
		std::vector<string> rowCaptions;
		//! String with the column caption separated by tabs
		string colCaptions;

		//! Number of samples use. That is, repeats
		int nSamples;

		ResultsTable();
		~ResultsTable();
		ResultsTable(int rows, int cols);

	};

	ostream& operator<<(ostream& out, ResultsTable& l);
}

#endif
