#ifndef __TDTMeasure_cpp__
#define __TDTMeasure_cpp__




/*_____________________________________________________________*/

void print(BIOS::TDTMeasure *t){
	cout << *t << endl;
}


/*_____________________________________________________________*/


namespace BIOS {		





/*_____________________________________________________________*/


TDTMeasure::TDTMeasure(TUCounts* tuCounts, double minFreq, bool permutations, bool left):Chi2TDTMeasure (tuCounts, minFreq, permutations, left)
{

		};

/*___________________________________________________________________________________*/


TDTMeasure::TDTMeasure(double minFreq, bool permutations, bool left):Chi2TDTMeasure (minFreq, permutations, left)
{

		};

/*___________________________________________________________________________________*/


		TDTMeasure::~TDTMeasure(){
		 zap(tdtTable);
			}
			
	/*___________________________________________________________________________________*/
 
 
 string TDTMeasure::getName()
 {
 string result=string("mTDT");
 if (minFreq!=0) result=result+string("_minFreq")+tos(minFreq);
 if (permutations) result=result+addPermutationsInName();
 return result;
 };
/*___________________________________________________________________________________*/


TDTMeasure*		TDTMeasure::clone(){
return new TDTMeasure(*this);
			}

/*___________________________________________________________________________________*/


TDTMeasure*		TDTMeasure::getNewMeasure(TUCounts* tuCounts, TUCounts** training, TUCounts** test){
return new TDTMeasure(tuCounts, minFreq, permutations);
			}




	
};

#endif
