#ifndef __ScoreTDTMeasure_h__
#define __ScoreTDTMeasure_h__

namespace BIOS {
	
  /**
     @memo ScoreTDTMeasure
     @doc
     Definition:
	Table to store T/U frecuencies for the TDT algorithm

     @author María del Mar Abad Grau
     @version 1.0
	
	*/	
class ScoreTDTMeasure: public Chi2TDTMeasure {
    
    private:
    

    




    
    private:
    
    void setMatrices();

protected:

    dv2d* marginalDiscrepancies;

dv2d* marginalDiscrepanciesTranspose;
    bool HWE;

    dv2d* covMatrix;
    
		dv2d* invOfCovMatrix;
    
		public:
	

		/**
		*	Constructor
		*/		
	//	ScoreTDTMeasure();

		/**
		*	Destructor
		*/		
	virtual	~ScoreTDTMeasure();

ScoreTDTMeasure* clone();

		/**
		*	Constructor 
		*	@param minFreq Min number of counts in an haplotype to be used
		*/		
		ScoreTDTMeasure(TUCounts* tuCounts, bool HWE=false, double minFreq=10, bool left=true);

	ScoreTDTMeasure(ScoreTDTMeasure& other);

		ScoreTDTMeasure(bool HWE=false, double minFreq=10, bool left=true);

// stringList* getFreqsResults();

		/**
		*	Calculate statistic from the tables 
		*/


ScoreTDTMeasure* getNewMeasure(TUCounts* tuCounts, TUCounts** training=NULL, TUCounts** test=NULL);
ScoreTDTMeasure* inferMeasure(TUCounts* tuCounts);

//virtual stringList*  getHeadFile();

		void Chi2Print(ostream& out);
				void thisPrint(ostream& out);
						void basicPrint(ostream& out);

virtual string getName();//{return string("mTDT");};

double getStatistic();
void print(ostream&);
//friend ostream& operator<<(ostream& out, ScoreTDTMeasure& l);


	};





};

#endif
