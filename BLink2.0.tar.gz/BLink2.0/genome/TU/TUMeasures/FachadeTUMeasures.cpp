#ifndef __FachadeTUMeasures_cpp__ 
#define __FachadeTUMeasures_cpp__ 



#include "TDTMeasure.cpp"
#include "CompositeTUMeasure.cpp"
#include "SimpleTUMeasure.cpp"
#include "GroupBasedTDTMeasure.cpp"
#include "Chi2TDTMeasure.cpp"
#include "EntropyTDTMeasure.cpp"
#include "TUMeasure.cpp"
#include "G2Measure.cpp"
#include "TDTPMeasure.cpp"
#include "TDT1Measure.cpp"
//#include "TDT1TMeasure.cpp"
//#include "TDT1UMeasure.cpp"
#include "YateTDTMeasure.cpp"
#include "LaplaceTDTMeasure.cpp"
#include "TreeDTMeasure.cpp"
//#include "TreeDTMeasureK.cpp"
#include "TreeDTSimpleMeasure.cpp"
//#include "TreeDTCompositeMeasure.cpp"
#include "TDTbranchSimpleMeasure.cpp"
#include "TDTbranchMeasure.cpp"
#include "TDTbranchCompositeMeasure.cpp"
#include "LengthContrastMeasure.cpp"
#include "SignedRankMeasure.cpp"
#include "ScoreTDTMeasure.cpp"
#include "ScoreTDTPMeasure.cpp"
#include "HWEMeasure.cpp"
#include "WeightedTDTMeasure.cpp"
#endif
