
/* File: RepeatedGenomaSample.h */




#ifndef __RepeatedGenomaSample_h__
#define __RepeatedGenomaSample_h__


#include "RepeatedGenotypeSample.h"


      
        



namespace BIOS {


         class RepeatedGenomaSample: public RepeatedGenotypeSample, public PhenotypeSample
 {
	 
       //  public:


    /** @name Implementation of class RepeatedGenomaSample
        @memo Private part.
    */




  private:

 

/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:



 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		RepeatedGenomaSample(char* filename, bool  ExistPhen=true);

	    void PrintOrderedUnrepeatedGenoma (char* filename, bool PrintPhenotypes=true);



};  // End of class RepeatedGenomaSample

};  // Fin del Namespace

#endif

/* Fin Fichero: RepeatedGenomaSample.h */
