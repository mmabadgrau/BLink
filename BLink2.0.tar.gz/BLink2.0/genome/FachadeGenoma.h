#ifndef __FachadeGenoma_h__ 
#define __FachadeGenoma_h__ 


#include "../commonc++/Fachade.h"


#include "Exceptions.h"
#include "SNP.h"
#include "SNPAfter.h"
#include "VirtualPositions.h"
#include "Positions.h"
#include "SNPAfter.h"
#include "Haplotype.h"
#include "LongHaplotype.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "PairGenotype.h"
#include "GenotypeSample.h"
#include "GenotypeArray.h"
#include "Phenotype.h"
#include "GenotypeCounters.h"
#include "PhenotypeSample.h"
#include "Genoma.h"
#include "../ML/sample/GenericSample.h"
#include "GenomaSample.h"
#include "CoupleGenotype.h"
#include "MultiallelicPairwiseMeasure.h"
#include "MonolociMeasure.h"
#include "PairwiseMeasuresResults.h"
#include "PairwiseCI.h"
#include "Block.h"
#include "BlockList.h"
#include "blockCI.h"
//#include "PairSNPGenotype.h"
//#include "CoupleSNPGenotype.h"
#include "ImportFormat.h"
#include "RandomizationDistribution.h"
#include "../ML/sample/GenericMLTest.h"
#include "GenomeMLTest.h"
#include "HaplotypesForEachIndividual.h"
#include "InferredHaplotypes.h"
#include "HapCounters.h"

#include "TU/FachadeTU.h"

#include "CommandLineParser.h"
#include "CommandLineParserWindows.h"
#include "CommandLineParserGWAS.h"
#include "ResultsTable.h"
#include "../ML/classifier/TestModeClass.h"
#include "GWAS.h"

#endif
