#ifndef __FachadeClassifierknn_h__ 
#define __FachadeClassifierknn_h__ 



#include "KElement.h"
#include "KNN.h"
#endif
