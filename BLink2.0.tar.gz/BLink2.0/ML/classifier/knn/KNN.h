/* File: KNN.h */

#ifndef __KNN_h__
#define __KNN_h__



//using namespace UTILS;


namespace BIOS {



class KNN: public Classifier
{
public:

int k;
DistanceMethodClass* distanceMethodClass;
bool weight;

//floatList* weightsVector;
//void set(floatList* parameters);

  void set(floatList* parameterList=NULL, DistanceMethodClass* distanceMethodClass=NULL);


public:

KNN(floatList* parameterList=NULL, DistanceMethodClass* distanceMethodClass=NULL);


KNN(char* filename, floatList* parameterList, DistanceMethodClass* distanceMethodClass=NULL);

KNN(floatMLSample* sample, int att, floatList* parameterList=NULL, DistanceMethodClass* distanceMethodClass=NULL, VerbosityClass *verbosity=NULL, LossFunction* lossFunction=NULL);

	
~KNN();

double* getClassFrequencies(floatList* targetInputPattern);

double* getFrequencies(KElementVector* kList);


char* print();
};



ostream& operator<<(ostream& out, KNN& knn)
       {

out << (Classifier&)knn;
out <<"k is " << knn.k << "\n";
out <<"weight is " << knn.weight <<"\n";
out <<*knn.distanceMethodClass;
};









};  // Fin del Namespace

#endif

//#include "KNN.cpp"
/* Fin Fichero: KNN.h */
