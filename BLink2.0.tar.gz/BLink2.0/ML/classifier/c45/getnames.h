#ifndef __getnames_h__
#define __getnames_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//
#include <cstring>//

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "extern.h"//
//#include "buildex.i"//




namespace BIOS {
/*************************************************************************/// 
/*									 */// 
/*	Get names of classes, attributes and attribute values		 */// 
/*	-----------------------------------------------------		 */// 
/*									 */// 
/*************************************************************************/// 
#define  Space(s)	(s == ' ' || s == '\n' || s == '\t')// 
#define  SkipComment	while ( ( c = getc(f) ) != '\n' )// 
char	Delimiter;// 
String  CopyString(char*);// 
// 
Boolean ReadName(FILE *f, String s); 

   void Error(short n, String s1, String s2);

    void GetNames();

int Which(String Val, String List[], short First, short Last);

String CopyString(String x);

}
#endif
