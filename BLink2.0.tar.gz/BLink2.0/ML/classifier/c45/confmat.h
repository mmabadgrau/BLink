#ifndef __confmat_h__
#define __confmat_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "c4.5.h"//




namespace BIOS {
/*************************************************************************/ //
/*								  	 */ //
/*	Routine for printing confusion matrices				 */ //
/*	---------------------------------------				 */ //
/*								  	 */ //
/*************************************************************************/ //
 //
 //
 //
    void PrintConfusionMatrix(ItemNo *ConfusionMat);

}
#endif
