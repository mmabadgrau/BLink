#ifndef __c45_h__
#define __c45_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//


namespace BIOS {
/*************************************************************************/// 
/*									 */// 
/*	Main routine, c4.5						 */// 
/*	------------------						 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
// 
// 
    /*  External data, described in extern.i  */// 
// 
short		MaxAtt, MaxClass, MaxDiscrVal = 2;// 
// 
ItemNo		MaxItem;// 
// 
Description	*Item;// 
// 
DiscrValue	*MaxAttVal;// 
// 
char		*SpecialStatus;// 
// 
String		*ClassName,// 
		*AttName,// 
                **AttValName;// 
char FileName[256];// = "DF";// 
// 
short		VERBOSITY = 0,// 
		TRIALS    = 10;// 
// 
Boolean         GAINRATIO  = true,// 
		SUBSET     = false,// 
		BATCH      = true,// 
		UNSEENS    = false,// 
		PROBTHRESH = false;// 
// 
ItemNo		MINOBJS   = 2,// 
		WINDOW    = 0,// 
		INCREMENT = 0;// 
// 
float		CF = 0.25;// 
// 
//TreeC45		*Pruned;// 
// 
Boolean	AllKnown = true;// 


// 
}
#endif
