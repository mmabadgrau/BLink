/* File: discr.h */


#ifndef __discr_h__
#define __discr_h__

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "extern.h"//

#include "subset.cpp"//


namespace BIOS {

/*************************************************************************/// 
/*									 */// 
/*	Evaluation of a test on a discrete valued attribute		 */// 
/*      ---------------------------------------------------		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
// 
/*************************************************************************/// 
/*									 */// 
/*  Compute frequency tables Freq[][] and ValFreq[] for attribute	 */// 
/*  Att from items Fp to Lp, and set the UnknownRate for Att		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
 void ComputeFrequencies(AttributeC45 Att, ItemNo Fp, ItemNo Lp);

// 
 void EvalDiscreteAtt(AttributeC45 Att, ItemNo Fp, ItemNo Lp, ItemCount Items,
 short int criterio);

// 
float DiscrKnownBaseInfo(ItemCount KnownItems, DiscrValue MaxVal);

// 
    void DiscreteTest(TreeC45 Node, AttributeC45 Att);

}
#endif

