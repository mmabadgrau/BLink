/* file C45.cpp */

#ifndef __C45_cpp__
#define __C45_cpp__


#include "C45.h"//


//using namespace UTILS;


namespace BIOS
{

  /************************/
  /* C45 DEFINITION */
  /************************/


  /**
          @memo C45 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
	
		LocalEntropiaPuntosRiesgo=-5,
	LocalRiesgoPuntosEntropia=-4,	
	LocalEntropiaPuntosEntropia=-3, //C45
	LocalRiesgoPuntosRiesgo=-2,
    LocalMitadEntropia=-1,
	LocalMitadRiesgo=0,
	
  */



  /**********************************/
  /* DEFINITIONS OF THE FUNCTIONS */
  /**********************************/


  /*____________________________________________________________________________________ */

  void C45::set(char filename[256], int currentClassPosition, int criterion)
  {//
       // criterio es 1 si no hay que discretizar porque ya lo est  o son todo atributos discretos,
    // si no, tiene el criterio a usar para discretizar
// si prediscretizado, fichero name
// si continuo o todos eran discretos, fichero original, names
// si selecci��1/2, fichero nam2
    char filetraining[256], filenames[256], filetree[256];
changeExtension(filename, filetraining, "ttt");
changeExtension(filetraining, filenames, "name");
OpenOutput(filetraining, &OutputFile);
discretized=true;
if (criterion!=1) discretized=false;
stringMLSample* stringSample;
//cout <<"Discr is:" << discretized;
/*
if (discretized) 
{
intMLSample *discSample=sample->getDiscreteSample();
stringSample=discSample->convertToStringWithClassAtTheEnd(currentClassPosition);
zap(discSample);
}
else 
*/

stringSample=sample->convertToStringWithClassAtTheEnd(currentClassPosition);
stringSample->sample->setOutputSeparatorForInternalContainers(',');
stringSample->sample->setDelimitersForInternalContainers('\0', '\0');
stringSample->sample->setDelimiters('\0', '\0');
stringSample->sample->setOutputSeparator('\n');
OutputFile << *stringSample->sample;// <<"\n\n";
OutputFile.close();
sample->listOfAttributes->CrearFicheroNombres (filenames, currentClassPosition, discretized, true);
//free(Weight);


zap(stringSample);

     short Best;//
       strcpy(FileName, filenames);

     GetNames(); //

    GetData(filetraining);// getdata.h
TRIALS=1;//
       OneTree(criterion); //   en besttree.h//

Best=0;//
     SaveTree (Pruned[Best], (char*)".tree");//
    if (verbosity->verbosityR.structure)
    PrintTree (Pruned[Best]);

//end();

  }//
/*____________________________________________________________________________________ */

C45::C45(floatMLSample* sample, int currentClassPosition, floatList* parameterList, VerbosityClass* verbosity, LossFunction* lossFunction):Classifier(sample, currentClassPosition, parameterList, verbosity, lossFunction)
  {
classPosition=sample->listOfAttributes->size()-1;
    // discretizado vale '0' si no est��1/2discretizado ya
    // para eliminar la poda, quitar lneas 44 y 237 de besttree.h

    //discreto vale 0 si no est  prediscretizado, 1 si s lo estan
    // criterio es 1 si no hay que discretizar porque ya lo est  o son todo atributos discretos,
    // si no, tiene el criterio a usar para discretizar
set(sample->filename, currentClassPosition, 1);
  }//
/*____________________________________________________________________________________ */

C45::C45(floatMLSample* sample, int currentClassPosition, floatList* parameterList,  DiscMode discMod, VerbosityClass *verbosity, LossFunction* lossFunction):Classifier(sample, currentClassPosition, parameterList, verbosity, lossFunction)
  {//
classPosition=sample->listOfAttributes->size()-1;
    // discretizado vale '0' si no est��1/2discretizado ya
    // para eliminar la poda, quitar lneas 44 y 237 de besttree.h

    //discreto vale 0 si no est  prediscretizado, 1 si s lo estan
    // criterio es 1 si no hay que discretizar porque ya lo est  o son todo atributos discretos,
    // si no, tiene el criterio a usar para discretizar
 

set(sample->filename, currentClassPosition, (int)discMod);


  }//
/*____________________________________________________________________________________ */
/*
C45::C45(floatMLSample* sample, ClassAttribute* classAttribute, ListOfAttributes* listOfAttributes):Classifier(sample, classAttribute, listOfAttributes)
  {//
    // discretizado vale '0' si no est��1/2discretizado ya
    // para eliminar la poda, quitar lneas 44 y 237 de besttree.h

    //discreto vale 0 si no est  prediscretizado, 1 si s lo estan
    // criterio es 1 si no hay que discretizar porque ya lo est  o son todo atributos discretos,
    // si no, tiene el criterio a usar para discretizar

writeFiles();

  }//
  /*____________________________________________________________________________________ */

  C45::~C45()
{
int i, v;

ForEach(i, 0, MaxAtt)
{
ForEach(v, 1, MaxAttVal[i])
{ 
free(AttValName[i][v]);// = (char *) malloc(Length);// 
AttValName[i][v]=NULL;
}

free (AttValName[i]);
AttValName[i]=NULL;
}

free (AttValName);
AttValName=NULL;

//cout <<"MaxItem:" << MaxItem  <<"\n";


ForEach(i, 0, MaxItem) 
{
free(Item[i]);
Item[i]=NULL;
}
free(Item);
Item=NULL;


free(Tested);//	= (char *) calloc(MaxAtt+1, sizeof(char));// 
Tested=NULL;
free(Gain);//	= (float *) calloc(MaxAtt+1, sizeof(float));// 
Gain=NULL;    
free(Info);//	= (float *) calloc(MaxAtt+1, sizeof(float));// 
Info=NULL;
free(Bar);//		= (float *) calloc(MaxAtt+1, sizeof(float));// 
Bar=NULL;
free(EmpRisk);//     = (float *) calloc(MaxAtt+1, sizeof(float));// 
EmpRisk=NULL;
free(Subsets);// (short *) calloc(MaxAtt+1, sizeof(short));
Subsets=NULL;
free(SplitGain);// = (float *) calloc(MaxItem+1, sizeof(float));//
SplitGain=NULL;
free(SplitInfo);// = (float *) calloc(MaxItem+1, sizeof(float));//
SplitInfo=NULL;
free(SplitEmpRisk);// = (float *) calloc(MaxItem+1, sizeof(float));//
SplitEmpRisk=NULL;
free(Weight);// = (ItemCount *) calloc(MaxItem+1, sizeof(ItemCount));//
Weight=NULL;
ForEach(i, 0, MaxAtt)// 
{
if ( MaxAttVal[i] )//   si es un atributo discreto
{
 ForEach(v, 0, MaxAttVal[i])// 
 { 
 free(Subset[i][v]);// = (Set) malloc((MaxAttVal[a]>>3) + 1);// 
 Subset[i][v]=NULL;
 }
free(Subset[i]);//  = (Set *) calloc(MaxDiscrVal+1, sizeof(Set));// 
Subset[i]=NULL;
}
}

free(Subset);// = (Set **) calloc(MaxAtt+1, sizeof(Set *));// 
Subset=NULL;
free(ValFreq);// = (ItemCount *) calloc(MaxDiscrVal+1, sizeof(ItemCount));// 
ValFreq=NULL;
free(ClassFreq);// = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));//
ClassFreq=NULL;
free(ContFreq);// = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));// 
ContFreq=NULL;
free(Slice1);// = (ItemCount *) calloc(MaxClass+2, sizeof(ItemCount));// 
Slice1=NULL;  
free(Slice2);// = (ItemCount *) calloc(MaxClass+2, sizeof(ItemCount));// 
Slice2=NULL;
free(UnknownRate);// = (float *) calloc(MaxAtt+1, sizeof(float));// 
UnknownRate=NULL;
free(PossibleValues);
PossibleValues=NULL;
free(TargetClassFreq);
TargetClassFreq=NULL;
free(ClassName);
ClassName=NULL;
free (AttName);
AttName=NULL;
free(SpecialStatus);
SpecialStatus=NULL;


ForEach(v, 0, MaxDiscrVal)// 
{
free(Freq[v]);//  = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));// 
Freq[v]=NULL;
}
   
free(Freq);//  = (ItemCount **) calloc(MaxDiscrVal+1, sizeof(ItemCount *));// 


Freq=NULL;
free(ClassSum);
ClassSum=NULL;
free(MaxAttVal);
MaxAttVal=NULL;

freeNode(Raw[0]);
Raw[0]=NULL;

freeNode(Pruned[0]);
Pruned[0]=NULL;
free(Raw);
Raw=NULL;
free(Pruned);
Pruned=NULL;

}
/*____________________________________________________________________________________ */

void C45::freeNode(TreeC45 Node)
{

int i;

  


if (Node->NodeType)
{

ForEach(i, 0, Node->Forks)// 
{
//if (Node->Subset[i]!=NULL) free(Node->Subset[i]);
//Node->Subset[i]=NULL;
if (Node->Branch[i]!=NULL) freeNode(Node->Branch[i]);
Node->Branch[i]=NULL;
}


free(Node->Branch);
Node->Branch=NULL;
}

free(Node->Subset);
Node->Subset=NULL;
free(Node->ClassDist);
Node->ClassDist=NULL;
Node=NULL;
free(Node);
Node=NULL;
}


/*____________________________________________________________________________________ */
/*
void C45::writeFiles()
{
char filename[256], filemas[256], filenames[256];
time_t t=time(NULL);
sprintf(filename, "t%l.ttt", t); 
sample->HardCopy(filename);
ChangeExtension(filename, filemas, "mas");
ChangeExtension(filename, filenames, "names");

listOfAttributes->CrearFicheroMas (filemas);
listOfAttributes->CrearFicheroNombres (filenames);
set(filename);

}
  /*___________________________________________________________ */

  double* C45::getClassFrequencies(floatList* inputPattern)
  {
//return 0;
floatList* inputPattern2=NULL;
intList* discretePos=NULL;

//cout <<"Discr is:" << discretized;

if (discretized) 
{
//throw NonImplemented("C45::getClassFrequencies");
discretePos=this->sample->listOfAttributes->getDiscretePositions(inputPattern);
inputPattern2=discretePos->getFloatList();
zap(discretePos);
}
else inputPattern2=new floatList(*inputPattern);

    long int cont=0;
    floatList::iterator p=inputPattern2->getFirst();
    ListOfAttributes::iterator pA=this->sample->listOfAttributes->getFirst();
    Attribute * attribute;
    AttributeC45 Att;
    char name[500], *endname=NULL;
    int Dv;
    float Cv;
    Description Dvec;
    Dvec = (Description) calloc(MaxAtt+2, sizeof(AttValue));

    ForEach(Att, 0, MaxAtt-1)
    {
      attribute=this->sample->listOfAttributes->getElement(pA);
      strcpy(name, attribute->getStringValue(inputPattern2->getElement(p)).c_str());
      if ( SpecialStatus[Att] == IGNORE )    //  Skip this value   //
        DVal(Dvec, Att) = 0;
      else
        if ( MaxAttVal[Att] || SpecialStatus[Att] == DISCRETE )
        {          //  Discrete value    //
          if ( ! ( strcmp(name, "?") ) )
            Dv = 0;
          else
          {
            Dv = Which(name, AttValName[Att], 1, MaxAttVal[Att]);
            if ( ! Dv )
              if ( SpecialStatus[Att] == DISCRETE )
              {   //  Add value to list   //
                //
                Dv = ++MaxAttVal[Att];
                if ( Dv > atoi(AttValName[Att][0]) )
                {
                  printf("\nToo many values for %s (max %d)\n",
                         AttName[Att], atoi(AttValName[Att][0]));
  			free (Dvec);
                  exit(0);
                }
                AttValName[Att][Dv] = CopyString(name);
              }
              else Error(4, AttName[Att], name);
          }
          DVal(Dvec, Att) = Dv;
        }
        else
        { // Continuous value   //
          if ( ! ( strcmp(name, "?") ) ) Cv = Unknown;
          else
          {
            Cv = strtod(name, &endname);
            if ( endname == name || *endname != '\0' )
              Error(4, AttName[Att], name);
  //          zap(endname);
          }
          CVal(Dvec, Att) = Cv;

        }

      p=inputPattern2->getNext(p);
      pA=this->sample->listOfAttributes->getNext(pA);
    }

//   MaxItem = 1;
  //  ClassNo PrunedClass=Category(Dvec, Pruned[0]); //0: only one trial


 double* classFrequencies=getClassFrequenciesInC45(Dvec, Pruned[0]);
 free (Dvec);
 zap(inputPattern2);
 return classFrequencies;//


//return 0;
  }
  /*___________________________________________________________ */




}
;  // Fin del Namespace

#endif

/* Fin Fichero: C45.h */
