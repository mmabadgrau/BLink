#ifndef __contin_h__
#define __contin_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

#include "sort.cpp"// C4.5//
//#include "types.h"//
//#include "extern.h"//




namespace BIOS {
/* File: contin.h */




/*************************************************************************///
/*                                                                	 *///
/*	Evaluation of a test on a continuous valued attribute	  	 */// 
/*	-----------------------------------------------------	  	 */// 
/*								  	 */// 
/*************************************************************************/// 
// 
// 
// 
// 
float// 
	*SplitGain,	/* SplitGain[i] = gain with att value of item i as threshold */// 
        *SplitInfo,     /* SplitInfo[i] = potential info ditto */// 
        *SplitEmpRisk;       /* SplitEmpRisk[i] = empirical risk *///
//
// 
// 
/*************************************************************************/// 
/*								  	 */// 
/*  Continuous attributes are treated as if they have possible values	 */// 
/*	0 (unknown), 1 (less than cut), 2(greater than cut)	  	 */// 
/*  This routine finds the best cut for items Fp through Lp and sets	 */// 
/*  Info[], Gain[] and Bar[]						 */// 
/*								  	 */// 
/*************************************************************************/// 
// 
// 
 void   EvalContinuousAtt(AttributeC45 Att, ItemNo Fp, ItemNo Lp, short int criterium);

  void  ContinTest(TreeC45 Node, AttributeC45 Att);

float GreatestValueBelow(AttributeC45 Att, float t);

}
#endif

