/* File: EMGenotypes.h */

#ifndef __EMGenotypes_h__
#define __EMGenotypes_h__



//using namespace UTILS;


namespace BIOS {


// it assume HWE so it uses haplotypes to compute genotype frequencies

class EMGenotypes: public DiscreteEM
{
private:




private:


void setMLEstimations();
double* getFrequencies();
virtual void setExpectation();
virtual void maximize();

void set ();

public:

EMGenotypes();


//EMGenotypes(char* filename, floatList* parameterList);

EMGenotypes(floatMLSample* sample, int att, floatList* parameterList, VerbosityClass verbosity, LossFunction* lossFunction, int iterations);

	
~EMGenotypes();

double* GetClassFrequencies(floatList* targetInputPattern);




char* print();
};
};  // Fin del Namespace

#endif

//#include "EMGenotypes.cpp"
/* Fin Fichero: EMGenotypes.h */
