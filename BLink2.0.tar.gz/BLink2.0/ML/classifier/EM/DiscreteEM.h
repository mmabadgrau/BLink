/* File: DiscreteEM.h */

#ifndef __DiscreteEM_h__
#define __DiscreteEM_h__



//using namespace UTILS;


namespace BIOS {



class DiscreteEM: public EM
{
private:

ProbabilityTable * frequencyTable; // it computes the expectation of the sufficient statistics given the incomplete sample and the current MLEstimations

VarsTable<double> * MLEstimations; // it computes the MLE given the expectations

//int* positionsOfCurrentPattern;




private:


void setMLEstimations();
double* getFrequencies();
virtual void setExpectation();
virtual void maximize();

void set ();

public:

DiscreteEM();


//DiscreteEM(char* filename, floatList* parameterList);

DiscreteEM(floatMLSample* sample, int att, floatList* parameterList, VerbosityClass verbosity, LossFunction* lossFunction, int iterations);

	
~DiscreteEM();

double* GetClassFrequencies(floatList* targetInputPattern);




char* print();
};
};  // Fin del Namespace

#endif

//#include "DiscreteEM.cpp"
/* Fin Fichero: DiscreteEM.h */
