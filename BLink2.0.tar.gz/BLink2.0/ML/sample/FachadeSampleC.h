#ifndef __FachadeSampleC_h__ 
#define __FachadeSampleC_h__ 



#include "GenericSample.cpp"
#include "GenericMLTest.cpp"
#include "MLSample.cpp"
#include "selection/Selection.cpp"

#endif
