#ifndef __FachadeSelectionC_h__ 
#define __FachadeSelectionC_h__ 





#include "Selection.cpp"

#endif
