#ifndef EntropyAttributeDiscretization_h //
#define EntropyAttributeDiscretization_h //



//using namespace UTILS;


namespace BIOS {

class EntropyAttributeDiscretization: public IterativeDiscretization
{
public:

EntropyAttributeDiscretization(floatMLSample* sample, bool half, bool puntos, bool parada, int minNumberOfInstancesPerInterval=-1);

 double getMargen2(intMLSample* currentSample, int position);

 double getMargen1(intMLSample* currentSample);

void discretization(floatSample::iterator first, floatSample::iterator last) {IterativeDiscretization::discretization(first, last);};

//Sample<float>::iterator getCutPair(Sample<float>::iterator first, Sample<float>::iterator last){IterativeDiscretization::getCutPair(first, last);};

 ~EntropyAttributeDiscretization();

};
}


#endif
//#include "EntropyAttributeDiscretization.cpp"

