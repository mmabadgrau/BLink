#ifndef AttributeDiscretization_h //
#define AttributeDiscretization_h //

//////

//using namespace UTILS;


namespace BIOS  {





  class AttributeDiscretization
  {
  protected:

     Valores * intervals; 
     floatMLSample* sample;
int minNumberOfInstancesPerInterval;
 
  public:

    //       AttributeDiscretization(Classifier<float>* classifier, bool half, bool puntos, bool parada);

    //	AttributeDiscretization (){}; //
    AttributeDiscretization (floatMLSample* sample, int minNumberOfInstancesPerInterval=-1); //
    floatList* GetIntervals();
    
    ~AttributeDiscretization(); //
    virtual void discretization(floatSample::iterator first, floatSample::iterator last)=0;
    int getTotalPatterns(floatSample::iterator first, floatSample::iterator last);
    int getTotalLeftPatterns(floatSample::iterator first, floatSample::iterator last, floatSample::iterator between);
    int getTotalRightPatterns(floatSample::iterator first, floatSample::iterator last, floatSample::iterator between);

  };


}
#endif

//#include "AttributeDiscretization.cpp"
