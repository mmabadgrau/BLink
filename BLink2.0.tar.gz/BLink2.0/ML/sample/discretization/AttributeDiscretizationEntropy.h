#ifndef EntropyAttributeDiscretization_h //
#define EntropyAttributeDiscretizationEntropy_h //

#include<cstdio>//
#include<cstdlib>//
#include<cmath>//
#include<iostream>//
#include<iomanip>//
#include<fstream>//
#include "IterativeDiscretization.h"
//////

//using namespace UTILS;


namespace BIOS {

class EntropyIterativeDiscretization: public IterativeDiscretization

{
};



/*____________________________________________________________________________________________*/

double AttributeDiscretization::getEntropy(Sample<float>::iterator first, Sample<float>::iterator last)
{
Modalidades *classModalidades=classifier->GetClassAttributePointer()->GetModalidades();
floatList::iterator p=classModalidades->getFirst();
AttPattern* attPattern;
int cont=0, abs, total=classifier->GetSampleSize();
double entropy=0, frec;
prob * frec;
while (p!=classModalidades->getNext(classModalidades->GetLast()))
{
attPattern=new AttPattern(1, classModalidades->getElement(p), classModalidades->getElement(p));
abs=classifier->GetAbsoluteFrequency(attPattern);
frec=new prob(abs, total);
cont++;
entropy=entropy-frec.log2()*frec.convert();//
entropy=entropy-frec*log(frec);
p=classModalidades->getNext(p);
delete attPattern;
}//
return entropy;
/*____________________________________________________________________________________________*/

void AttributeDiscretization::getMeasure(bool half, bool puntos, bool parada, bool entropy, Pair<float>::iterator first, Pair<float>::iterator last)
{
double measure;
if (entropy) measure=getEntropy(first, last);

return measure;
}
/*____________________________________________________________________________________________*/

void AttributeDiscretization::getMargen2(bool half, bool puntos, bool parada, bool entropy, Pair<float>::iterator first, Pair<float>::iterator last, Pair<float>::iterator p)
{
double margen;
double N=(double)classifier->GetSample()->GetPos(last)+1;

if (entropy)
{
double EL=getEntropy(first, p);
double ER=getEntropy(p->Next, last);
double NL=(double)classifier->GetSample()->GetPos(p)+1;
double NR=(double)N-NL;
double jointEntropy=(EL*NL+ER*NR)/N;
//double Margen0=E0*(1+E0*totalClasses)/N-log2(N-1)/N;
double margen=jointEntropy+
  		        log_2(pow((double)3,(double)getTotalClasses(first, last)-(double)2))/(double)N+
			((double)getTotalClasses(first, p)*EL)/(double)N+
			((double)getTotalClasses(p, last)*ER)/(double)N; //

}
return margen;
}
/*____________________________________________________________________________________________*/

void AttributeDiscretization::getMargen1(bool half, bool puntos, bool parada, bool entropy, Pair<float>::iterator first, Pair<float>::iterator last, double measure)
{
double margen;
double N=(double)classifier->GetSample()->GetPos(last)+1;

if (entropy)
{
real numreal;
double E=measure;//
double margen=E+getTotalClasses(first, las)*E/(double)N-
log_2(N-1)/(double)(N);
}
return margen;
}


#endif
