#ifndef __SelSubmodeClass_h__
#define __SelSubmodeClass_h__


namespace BIOS {

typedef enum SelSubmode {
	rows=1,
	rowsStartingAt0=2,
	blocks=3
};

class SelSubmodeClass {



public:

SelSubmode selSubmode;

char selectionFile[256];

SelSubmodeClass()
{
  strcpy(this->selectionFile,"");
}
 	
SelSubmodeClass(SelSubmode selSubmode, char* selectionFile)
{
 this->selSubmode=selSubmode;
 strcpy(this->selectionFile,selectionFile);
}

~SelSubmodeClass() {};


 /*____________________________________________________________________________________________*/

intList*  rowExtraction(int i)
{
if (strcmp(selectionFile,"")==0) 
{
cout <<"Error in SelSubmodeClass.rowExtraction";
end();
}
intSample* kernels=new intSample(selectionFile);
intList* currentKernel;
if (i>kernels->size()) // class is not included in filter file
{
cout << "Error 2 in SelSubmodeClass::rowExtraction, i=" << i << " is greater than " << kernels->size();
cout << "\nKernels: " << *kernels; 
end();
}
if (i==kernels->size()) // class is not included in filter file
{
currentKernel=new intList();
if (selSubmode==rows) currentKernel->insertElement(i+1);
else currentKernel->insertElement(i);
}
else currentKernel=new intList(*kernels->getElement(i));
//if (hasClass) currentKernel->insertElementAtPos(totalAttributes-1,0);
zap(kernels);
return (currentKernel);
}
 /*____________________________________________________________________________________________*/

intList*  rowExtractionStartingAt1(int i)
{
intList *currentKernel=rowExtraction(i), *selection;
selection=(intList*)currentKernel->substract(1);
zap(currentKernel);
return selection;
}
/*____________________________________________________________________________________________*/

intList*  blockExtraction(int i)
{
if (strcmp(selectionFile,"")==0) 
{
cout <<"Error in SelSubmodeClass.rowExtraction";
end();
}
intSample* blocks=NULL;
intSample::iterator p;
bool found=false;
intList* selectionFinal=new intList(), *selection;
//if (hasClass) selectionFinal->insertElement(totalAttributes-1);
blocks=new intSample(selectionFile);
//if (i==47)
//cout <<"blocks:" << *blocks;
p=blocks->getFirst();
while (p!=NULL && !found)
{
selectionFinal=blocks->getElement(p);
//cout <<"\n" << *selectionFinal;
if (selectionFinal->findElement(i+1)!=NULL)
found=true;
p=blocks->getNext(p);
}
if (!found)
{
//cout << "Error in  MissingImputation::runSelected. Att " << i << " was not found";
//end();
selection=new intList();
selection->insertElement(i);
}
else selection=(intList*)selectionFinal->substract(1);

zap(blocks);
return selection;
}
};

ostream& operator<<(ostream& out, SelSubmodeClass& p)
  {
if (strcmp(p.selectionFile,"")==0)
{
cout <<"Error in SelSubmodeClass.<<";
end();
}
out << "\nMode for selection from file " << p.selectionFile <<":\t\t";
	switch (p.selSubmode)
	{
	case rows: out << "Rows"; break;
	case rowsStartingAt0: out << "Rows starting at 0"; break;
	case blocks:  out <<  "Blocks"; break;
	default: out <<"Invalid selection algorithm subtype code " << p.selSubmode; end(); break;
	}

}






}

#endif
