#ifndef __FachadeGraphsC_h__ 
#define __FachadeGraphsC_h__ 


#include "Graph.cpp"
#include "Clique.cpp"

#include "UTree.cpp"
#include "CompleteGraph.cpp"
#include "Separator.cpp"

#include "SeparatorContent.cpp"
#include "DirectedArc.cpp"
#include "Tree.cpp"
#include "SingleAncestorGraph.cpp"
//#include "TriangulatedUG.cpp"

// end namespace

//#include "Front.cpp"
#endif
