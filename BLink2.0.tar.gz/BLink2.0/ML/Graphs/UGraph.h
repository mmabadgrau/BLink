/* File: UGraph.h */


#ifndef __UGraph_h__
#define __UGraph_h__






//using namespace UTILS;


namespace BIOS
{


  /************************/
  /* DAG DEFINITION */
  /************************/


  /**
          @memo DAG 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
   
  A DAG is a DG without directed loops
  */

	
// We wanted to use:
//template <class T>  typedef typename CompleteGraph<UndirectedArc, T> CompleteUG<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U>
  struct UGraph
  {
    typedef Graph<UndirectedArc, T, U> Class;
  };

typedef UGraph<Node*, void>::Class SimpleUGraph;
  };  // Fin del Namespace

#endif

/* Fin Fichero: DAG.h */
