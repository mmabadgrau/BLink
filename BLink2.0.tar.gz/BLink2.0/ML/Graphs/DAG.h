/* File: DAG.h */


#ifndef __DAG_h__
#define __DAG_h__






//using namespace UTILS;


namespace BIOS
{


  /************************/
  /* DAG DEFINITION */
  /************************/


  /**
          @memo DAG 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
   
  A DAG is a DG without directed loops
  */

	
// We wanted to use:
//template <class T>  typedef typename CompleteGraph<UndirectedArc, T> CompleteUG<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U=int>
  struct DAG
  {
    typedef AcyclicGraph<DirectedArc, T, U> Class;
  };

typedef DAG<Node*>::Class SimpleDAG;
  }
;  // Fin del Namespace

#endif

/* Fin Fichero: DAG.h */
