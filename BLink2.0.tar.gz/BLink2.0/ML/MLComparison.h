/***************************************************************************
 *   Copyright (C) 2005 by M. Mar Abad Grau 				   *
 *   mabad@ugr.es  						           *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/* File: ClassClassAttribute.cpp */


#ifndef __MLComparison_h__
#define __MLComparison_h__


#include "FachadeML.h"

//#include "classifier/ClassifierTest.cpp"


//using namespace UTILS;

namespace BIOS {

class MLComparison {

InputTUI* inputTUI;

unsigned int haplotypes, salida;
//int foldbase;


void lectura_argumentos(int argc, char *argv[]);


list<unsigned int>* GetSelected(char* filename, unsigned int cm, unsigned int totalmuestras);

public:

MLComparison(int argc, char *argv[]);

bool isAModifier(char* c);

void printHelp(char* programName);

bool isAValue(char* c);

bool isHelp(char* c);

};



}


#endif





