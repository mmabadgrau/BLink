/* File: EstimatorTypeClass.h */

#ifndef __EstimatorTypeClass_h__
#define __EstimatorTypeClass_h__



//using namespace UTILS;


namespace BIOS {

typedef enum EstType {
	MLE=0, 
	UniformBayes=1
}


class EstimatorTypeClass {



public:
 	



///////
char* print (EstType estType)
{
  switch (estType) //
  { //
   case MLE: cout <<"\n MLE \n"; break;  //
   case UniformBayes: cout <<"\n Uniform Bayesian estimator \n"; break; //
  
   } //
}
};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
