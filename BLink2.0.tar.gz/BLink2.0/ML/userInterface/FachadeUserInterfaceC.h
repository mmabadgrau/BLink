#ifndef __FachadeuserInterfaceC_h__ 
#define __FachadeUserInterfaceC_h__ 




#include "InputTUI.cpp"



//#include "sample/FachadeSample.h"
//#include "BN/FachadeBN.h"
// end namespace

//#include "Front.cpp"
#endif
