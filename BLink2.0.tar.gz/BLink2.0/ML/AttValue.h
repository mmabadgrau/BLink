#ifndef AttValue_h//
#define AttValue_h//

#include "../commonc++/list.h"

namespace BIOS {



/************************/
/* ListOfLists DEFINITION */
/************************/


/**
        @memo AttValue 

	@doc

    @author Maria M. Abad
	@version 1.0
*/

template <class T> class AttValue {

private:

struct 
{
 int pos;
 T minValue;
 T maxValue;
} AttValue;

public:

AttValue()
{
AttValue.pos=-1;
}


AttValue(int position, T val)
{
AttValue.pos=position;
AttValue.value=val;
}

AttValue(AttValue<T> *ap)
{
AttValue.pos=ap->GetPos();
AttValue.value=ap->GetValue();
}


int GetPos()
{
return AttValue.pos;
}

T GetMinValue()
{
return AttValue.minValue;
}

T GetMaxValue()
{
return AttValue.maxValue;
}


};
}// end namespace
#endif
