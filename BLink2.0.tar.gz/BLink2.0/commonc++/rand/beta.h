#include <iostream>
//#include <ostream>
//#include <fstream>
#include <string>
#include <math.h>


#ifndef __beta_h__
#define __beta_h__

/*********************************************************************
   Returns the beta distribution
   From "NUmerical recipes in c"        
*********************************************************************/
namespace BIOS {

double beta(double z, double w);

}
#endif
