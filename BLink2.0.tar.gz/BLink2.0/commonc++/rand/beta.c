
      #include <math.h>


#ifndef __beta_cpp__
#define __beta_cpp__

/*********************************************************************
   Returns the beta distribution
   From "Numerical recipes in c"        
*********************************************************************/
namespace BIOS {

double beta(double z, double w) 
//  Returns the value of the beta function B(z, w).
{
return exp(gammln(z)+gammln(w)-gammln(z+w));	
};
};

#endif
