double cdfHalfNormal(const double x, double sd)
{
return erf(x/(sqrt(2)*sd));
}

/*________________________________________*/

double getPValHalfNormal(const double x)
{
return 1-cdfHalfNormal(x);
}

