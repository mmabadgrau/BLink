/* File: HeteroPair.h */


#ifndef __HeteroPair_h__
#define __HeteroPair_h__



using namespace std;

namespace BIOS {


// is a pair of lists
template < class P, class Q> class HeteroPair
  {
public:
           P First;
           Q Second;
           HeteroPair(P f, Q s) ;
           HeteroPair(HeteroPair<P, Q>& p) ;
           HeteroPair() ;
           ~HeteroPair() ;
											void empty();
	   bool operator>(const HeteroPair<P, Q>& p) ;
	   bool operator<(const HeteroPair<P, Q>&p) ;
	   bool operator==(HeteroPair<P, Q>p) ;
           void setValues(P f, Q s) ;
	   P first();
	   Q second();
     static HeteroPair* fromString(string s);
    HeteroPair* clone(); 
  };

/*
	template<class T> bool compare( const HeteroPair<T>& arg1, const HeteroPair<T>& arg2)
	{
return arg1>arg2;
}
*/
/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>& HeteroPair);



}//end namespace
#endif
