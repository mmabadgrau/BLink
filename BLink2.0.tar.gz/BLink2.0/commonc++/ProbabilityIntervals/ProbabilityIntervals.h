#ifndef ProbabilityIntervals_h//
#define ProbabilityIntervals_h//



namespace BIOS 
{




class ProbabilityIntervals: public Container<vector<ProbabilityInterval*>, ProbabilityInterval*>
{ 
   
public:

//ProbabilityIntervals():Set<ProbabilityInterval, list>(){};
Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* getMaxEntropy();
Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* getVertexSet();
void getMaxEntropy(Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* maxEntropyDistribution, Container<vector<ProbabilityInterval*>, ProbabilityInterval*>*resultDistribution, intList* positions);
double sumLower(Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* maxEntropyDistribution);
int minLower(Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* maxEntropyDistribution, intList* positions);
int totalMin(Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* maxEntropyDistribution, intList* positions);
int secondMinLower(Container<vector<ProbabilityInterval*>, ProbabilityInterval*>* maxEntropyDistribution, int pos, intList* positions);
Prob min(Prob a, Prob b, Prob c);
Prob min(Prob a, Prob b);
double getEntropy();

};//


} // end namespace

#endif
