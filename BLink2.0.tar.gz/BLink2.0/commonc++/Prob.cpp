/* File: Prob.cpp */


#ifndef __Prob_cpp__
#define __Prob_cpp__

                                                   
#include "Prob.h"//

using namespace std;

namespace BIOS {

//////////////
Prob::Prob (const Prob & origen):Quotient<double>(origen)
{
}
/////////////////
/*
void Prob::operator= (Prob & rat2)
{
Quotient<double>::operator=(rat2);
}
*/
/*
Prob::Prob(double num=0.0, double den=1.0):Quotient<double>(num, den)
{
if (num!=0.0 && den!=0.0)
if ((num>den) || (num*den<0))
{
	cout <<"\nError in Prob::new, non a Probability, num:" << num <<", den:" << den;
	end();
}
}
*/
/////////////////
/*
bool Prob::operator< (Prob & rat2)
{
return (this->convert()< rat2.convert());
}

/////////////////
bool Prob::operator<= (Prob & rat2)
{
return (this->convert()<= rat2.convert());
}
*/
/*_________________________________________________________________________________________*/

void Prob::setNumerator(double numerator)
{
if (numerator>this->denominator)
{
cout <<"\nError in Prob::getNumerator, non a Probability, num:" << numerator <<", den:" << this->denominator;
end();
}
this->numerator=numerator;
}	

/////////////
/*
Prob::Prob(double num, double den, float alpha, double size):Quotient<double>(num, den)
{
//if (num!=0.0 && den!=0.0)

addAlpha(alpha, size, 1);
if ((numerator>denominator) || (numerator*denominator<0))
{
	cout <<"\nError in Prob1::new, non a Probability, num:" << numerator <<", den:" << denominator <<" size: " << size;
	end();
}
}
*/

/////////////
Prob::Prob(double num, double den, Quotient<double> alphaNumerator, float alphaDenominator) throw (NonProb) :Quotient<double>(num, den) 
{
addAlpha(alphaNumerator, alphaDenominator);
if (alphaNumerator.getNumerator()!=alphaDenominator)
{
cout <<"error prob";
end();
}

if (numerator>denominator) throw NonProb("Prob(double num, double den, Prob alphaNumerator, float alphaDenominator)", numerator);
//if ((numerator-denominator)>zero || (numerator-denominator)>0)
/*
{
	cout <<"\nError in Prob_3::new, non a Probability, num:" << numerator <<", den:" << denominator <<" alphaNumerator: " << alphaNumerator.convert() << ", alphaDenominator: " << alphaDenominator;
printf("\nnum:%0.20f, den: %0.20f, alphanum:%0.20f, alphaden: %0.20f", numerator, denominator, alphaNumerator.convert(), alphaDenominator);
cout <<"\noriginal values were ";
printf("\nnum:%0.20f, den: %0.20f", num, den);
	end();
}
*/
}
/////////////
Prob::Prob(double num, double den, float alphaNumerator, float alphaDenominator)  throw (NonProb) :Quotient<double>(num, den) 
{
//if (num!=0.0 && den!=0.0)
if (alphaNumerator>alphaDenominator)
{
cout <<"Error 1 in Prob()";
end();
}
addAlpha(alphaNumerator, alphaDenominator);
double dif=denominator-numerator;
double dif2=numerator-denominator;
if (numerator>denominator) 
if ((numerator-denominator)<zero)
numerator=denominator;
else
throw NonProb(string("Prob(double num, double den, float alphaNumerator, float alphaDenominator): prob is "+tos(numerator)+"--"+ tos(denominator)), numerator);
/*
if (numerator>denominator)
//if ((numerator-denominator)>zero || (numerator-denominator)>0)
{
	cout <<"\nError in Prob_2::new, non a Probability, num:" << numerator <<", den:" << denominator <<" alphaNumerator: " << alphaNumerator << ", alphaDenominator: " << alphaDenominator;
printf("\nnum:%0.20f, den: %0.20f, alphanum:%0.20f, alphaden: %0.20f", numerator, denominator, alphaNumerator, alphaDenominator);
cout <<"\noriginal values were ";
printf("\nnum:%0.20f, den: %0.20f", num, den);
	end();
}
*/
//else
{
//printf("\nnum:%0.20f, den: %0.20f", numerator, denominator);
//numerator=denominator;
}


}
/////////////////
Prob Prob::operator/ (Prob  rat2)
{
Prob result(0.0,0.0);
result.numerator=this->numerator*rat2.denominator;
result.denominator=this->denominator*rat2.numerator;


if ((int)result.numerator>(int)result.denominator)
{
	cout <<"\nError in Prob::operator/, non a Probability " << print() <<" divided by " << rat2.print() <<" gives result " << result.print() <<" which has numerator " << result.numerator <<" larger than denominator " << result.denominator;
	end();
}
Quotient<double> r=Quotient<double>(this->numerator, this->denominator), r2=Quotient<double>(rat2.numerator, rat2.denominator), r3=r/r2;

result=Prob(r3.getNumerator(), r3.getDenominator());
return result;
}
/////////////////
Prob Prob::operator+ (Prob  rat2)
{
Quotient<double> r=Quotient<double>(numerator, denominator), r2=Quotient<double>(rat2.numerator, rat2.denominator), r3=r+r2;

return Prob(r3.getNumerator(), r3.getDenominator());
}
/////////////////
Prob Prob::operator- (Prob  rat2)
{
Quotient<double> r=Quotient<double>(numerator, denominator), r2=Quotient<double>(rat2.numerator, rat2.denominator), r3=r-r2;

return Prob(r3.getNumerator(), r3.getDenominator());
}
/////////////////
Prob Prob::operator* (Prob  rat2)
{
Quotient<double> r=Quotient<double>(numerator, denominator), r2=Quotient<double>(rat2.numerator, rat2.denominator), r3=r*r2;

return Prob(r3.getNumerator(), r3.getDenominator());
}


/////////////////
/*
void Prob::addAlpha (float alpha, double numeratorSize, double denominatorSize)
{
numerator=numerator+alpha/numeratorSize;
denominator=denominator+alpha/denominatorSize;
};
*/
/*_______________________________________________________________________________________________*/

/////////////////
void Prob::addAlpha (float alphaNumerator, float alphaDenominator)
{
//Prob alpha=Prob(alphaNumerator, alphaDenominator);
numerator=numerator+alphaNumerator;
denominator=denominator+alphaDenominator;
};

/*_______________________________________________________________________________________________*/

void Prob::addAlpha (Quotient<double> alphaNumerator, float alphaDenominator)
{
//Prob alpha=Prob(alphaNumerator, alphaDenominator);
//cout <<"\ninalphaNum:" << alphaNumerator.print() <<"den:" << alphaDenominator;
if (alphaNumerator.getNumerator()!=0 || alphaDenominator!=0)
{
//cout <<"\ncondinalphaNum:" << alphaNumerator.print() <<"den:" << alphaDenominator;

numerator=numerator*alphaNumerator.getDenominator()+alphaNumerator.getNumerator();
denominator=(denominator+alphaDenominator)*alphaNumerator.getDenominator();
}
};

 ostream& operator<<(ostream& out, Prob& e)
{
out << e.print();
return out;
};

/////////////////


//////////////////
/*
ostream& Prob::operator<<(ostream& out)
{
out << this->print();
return out;
}
*/
}//end namespace
#endif
