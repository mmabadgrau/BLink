/* File: AmbiguousArray.h */
//prr

#ifndef __AmbiguousArray_h__
#define __AmbiguousArray_h__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  class AmbiguousArray: public MultidimensionalEmptyTable<int> //
  {//
 


// Used names for arguments, methods, etc.:
// variable: for each dimension in the AmbiguousArray
// pos: for each value of a variable in the AmbiguousArray
// knownPos: those positions whose values can be solved
// conf: for each configuration in the AmbiguousArray (i.e., a composition of pos for all the variables)
// confArr: for configurations stored in an array
// binaryKnownConf: a configuration with only binary values meaning the way to solve the phase
// solvedPos: for each value of a variable in the solvedArray
// solvedConf: for each known (non-ambiguous) configuration in the solvedArray



//the total number of ambiguous pos for each variable (obtained with getTotalPos(total) is computed as solvedPos^2+(combinations(tsolvedPos, 2)
// as an example with two solvedPos (as A, C in DNA), it would be 5: AA, AC, CA, CC, A/C 



  public:



    AmbiguousArray();
    AmbiguousArray(intList* dimensionList);
      AmbiguousArray(AmbiguousArray &source);
    ~AmbiguousArray();
 long long int  changePhase(long long int conf);
 long long  int  getTotalSolvedConfs(long long int conf);
 long long int  getTotalSolvedConfs(int* confArr);
int  getTotalSolvedPos (int variable);
bool  isAKnownPosition (int pos, int variable);
static bool  isAKnownPos (int pos, int totalValuesAtCurrentPos);
bool  isAPositionWithDifferentValues (int pos, int variable);
bool  hasSameValues (long long int conf);
int  getAmbiguousPosition (int knownPos1, int knownPos2, int variable);
static int  getAmbiguousPos (int knownPos1, int knownPos2, int totalValuesAtCurrentPos);
long long int getSolvedConf(int* confArr, long long int knownConf, bool left, MultidimensionalEmptyTable<int>* solvedArray);
long long int  getSolvedConf(long long int conf, long long int knownConf, bool left, MultidimensionalEmptyTable<int>* solvedArray);
long long int getPartnerSolvedConf(long long int partnerKnownConf, long long int conf, long long int partnerConf, bool left, MultidimensionalEmptyTable<int>* solvedArray);
int  getKnownValue (int pos, int variable, bool left);
int  inferValue (int pos, int variable, bool left);
int  getUnknownPosition (int knownPos1, int knownPos2, int variable);
static int  getUnknownPos (int knownPos1, int knownPos2, int totalValuesAtCurrentPos);
int getTotalKnownPositions (int variable);
static int getTotalPos (int totalKnownPos);
static int  getTotalUnknownPos (int totalKnownPos);
//double getTotalFreq (double totalCounts, int totalSolvedConfs, long long int ambiguousConfPos, MultidimensionalTable<double> * ambiguousCounts, MultidimensionalTable<double>* currentEstimation, MultidimensionalTable<double>* secondCurrentEstimation, MultidimensionalTable<double>* newEstimation, MultidimensionalTable<double>* newEstimation2, bool together, bool compatibilityPairs, longLongList *partnerPointer, int genotypeInd, double pAcc, MultidimensionalEmptyTable<int>* solvedArray, BayesType Bayes=MLE, float distance=0, float alpha=0);
double getTotalFreq (double totalCounts, int totalSolvedConfs, long long int ambiguousConfPos, MultidimensionalTable<double> * ambiguousCounts, MultidimensionalTable<double>* currentEstimation, MultidimensionalTable<double>* newEstimation, bool compatibilityPairs, longLongList *partnerPointer, int genotypeInd, double pAcc, MultidimensionalEmptyTable<int>* solvedArray, BayesType Bayes=MLE, float distance=0, float alpha=0);

//void  estimateMLE (MultidimensionalTable<double>*& currentEstimation, MultidimensionalTable<double> * ambiguousCounts, MultidimensionalTable<longLongList*> * ambiguousPartnerPointers, double totalCounts, int it, MultidimensionalTable<double>*& secondCurrentEstimation, MultidimensionalTable<double>*& thirdCurrentEstimation, MultidimensionalTable<double>*& fourthCurrentEstimation, MultidimensionalEmptyTable<int>* solvedArray, BayesType Bayes=MLE, float distance=0, float alpha=0);
void  estimateMLE (MultidimensionalTable<double>*& currentEstimation, MultidimensionalTable<double> * ambiguousCounts, MultidimensionalTable<longLongList*> * ambiguousPartnerPointers, double totalCounts, int it, MultidimensionalEmptyTable<int>* solvedArray, BayesType Bayes=MLE, float distance=0, float alpha=0);
}; // end class
   


  

}
#endif
