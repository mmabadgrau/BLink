/* File: HeteroPair.h */


#ifndef __HeteroPair_cpp__
#define __HeteroPair_cpp__



using namespace std;

namespace BIOS {


           template < class P, class Q> HeteroPair<P,Q>::HeteroPair(P f, Q s) {First=BIOS::clone(f); Second=BIOS::clone(s);};
           //template < class P, class Q> HeteroPair<P,Q>::HeteroPair(HeteroPair<P, Q>* p) {First=p->First; Second=p->Second;};
           template < class P, class Q> HeteroPair<P,Q>::HeteroPair(HeteroPair<P, Q>& p) {First=BIOS::clone(p.First); Second=BIOS::clone(p.Second);}
           template < class P, class Q> HeteroPair<P,Q>::HeteroPair() {};
           template < class P, class Q> HeteroPair<P,Q>::~HeteroPair() {zap(First); zap(Second);};
											template < class P, class Q> void 	HeteroPair<P,Q>::empty() {zap (First); zap(Second);};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator>(const HeteroPair<P, Q>& p) {if (First>p.First || First==p.First && Second>p.Second) return true; else return false;};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator<(const HeteroPair<P, Q>&p) {if (First<p.First|| First==p.First && Second<p.Second) return true; else return false;};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator==(HeteroPair<P, Q>p) {if (First==p.First && Second==p.Second) return true; else return false;};
           template < class P, class Q> void HeteroPair<P,Q>::setValues(P f, Q s) {First=f; Second=s;};
	   template < class P, class Q> P HeteroPair<P,Q>::first(){return First;};
	   template < class P, class Q> Q HeteroPair<P,Q>::second(){return Second;};
     template < class P, class Q> HeteroPair<P,Q>* HeteroPair<P,Q>::clone(){return new HeteroPair<P,Q>(*this);};
/*______________________________________________________*/

 template <class T, class U> HeteroPair<T, U>* HeteroPair<T, U>::fromString(string s)
{
throw NonImplemented("static HeteroPair* fromString(string s)");
}
/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>*& heteroPair)
{
 
out << "(" << heteroPair->First <<", " << heteroPair->Second <<")";

return out;
  }

/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T*&, U*&>*& heteroPair)
{
 
out << "(" << *heteroPair->First <<", " << *heteroPair->Second <<")";

return out;
  }

/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>& heteroPair)
{
 
out << "(" << heteroPair.First <<", " << heteroPair.Second <<")";

return out;
  }



}//end namespace
#endif
