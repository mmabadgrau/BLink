/* File: DiagonalTable.h */


#ifndef __DiagonalTable_h__
#define __DiagonalTable_h__



using namespace std;

namespace BIOS {

/////////////////////////////////////////
template <class T> class DiagonalTable //
{//
// it is a 2D table with only the element at one side of a diagonal plus the diagonal
private:
int sizeX, sizeY;
T* table;
int size;
public:
DiagonalTable(int sizeX, int sizeY=0) ;
~DiagonalTable();
void setValue(int posX, int posY, T value);
int getFirstPosInSameRow(int posX);
int getPos(int posX, int PosY) ;
T getValue(int posX, int posY);
void initialize(T value);
int getSizeX();
int getSizeY();
 
};//

 template <class T> ostream& operator<<(ostream& out, DiagonalTable<T>& p);
//#include "DiagonalTable.cpp"
}
#endif
