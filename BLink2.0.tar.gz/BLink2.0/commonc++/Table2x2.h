/* File: Tables2x2.h */


#ifndef __Table2x2_h__
#define __Table2x2_h__




using namespace std;

namespace BIOS {



class Table2x2

	{


	public:


    //	void DistributeLDMax (sfrequencies hap, sfrequencies hap2, sfrequencies hap3);

	//	void DistributeLDMin (sfrequencies hap, sfrequencies hap2, sfrequencies hap3);

		double GetDPrime(double fAB, double fA, double fB);

		double GetMaxD (double fAB, double fA, double fB);

		double GetPositiveMaxD (double fAB, double fA, double fB);

		double GetNegativeMaxD (double fAB, double fA, double fB);

		double GetD(double fAB, double fA, double fB);

 	double getCompositeLD(double fAB, double fA_B, double fA, double fB);

	 double getMaxCompositeLD(double fAB, double fA_B, double fA, double fB, double fAA, double fAa, double faa, double fBB, double fBb, double fbb);

  double getStandardizedCompositeLD(double fAB, double fA_B, double fA, double fB, double fAA, double faa, double fAa, double fBB, double fBb, double fbb);

		double GetR2(double fAB, double fA, double fB);

		double GetQ(double fAB,  double fA, double fB);

		double GetRho(double fAB,  double fA, double fB);

		double EstimateMLE (double fAB, double nHH, double nABKnown, double total, double fA, double fB, int it);

		double EstimateMLE (int nAB, int nAb, int naB, int nab, int nHH, int it);

		Pair<double> GetQuantilesDPrime (double alpha, double fA, double fB, double fAB, double nAB, double nAb, double naB, double nab, double nHH, bool Print=false);

		double GetMaxDPrime(double fA, double fB, double nAB, double nAb, double naB, double nab, double nHH);

		struct FreqAndVal* GetDDistribution(double fA, double fB, double nAB, double nAb, double naB, double nab, double nHH);

		struct FreqAndVal* GetDPrimeDistribution(double fA, double fB, double nAB, double nAb, double naB, double nab, double nHH);

		struct FreqAndVal* GetAbsDPrimeDistribution(double fA, double fB, double nAB, double nAb, double naB, double nab, double nHH);


	}; //end of class Table2x2

};  // Fin del Namespace

#endif

/* Fin Fichero: Tables2x2.h */
