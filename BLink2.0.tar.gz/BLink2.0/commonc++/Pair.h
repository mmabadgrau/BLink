/* File: Pair.h */


#ifndef __Pair_h__
#define __Pair_h__



using namespace std;

namespace BIOS {



template < class P> class Pair
  {
public:
           P First;
           P Second;
           Pair(P f, P s);
           Pair(Pair<P>* p) ;
           Pair() ;
           ~Pair() ;
           void empty();
	   bool operator>(const Pair<P>& p) ;
	   bool operator<(const Pair<P>&p) ;
	   bool operator==(Pair<P>p) ;
           void setValues(P f, P s) ;
	   P& getFirst();
	   P& getSecond();
     static Pair* fromString(string s);
     Pair* clone();
  };

/*
	template<class T> bool compare( const Pair<T>& arg1, const Pair<T>& arg2)
	{
return arg1>arg2;
}
*/
/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Pair<T>& pair);

}//end namespace
#endif
