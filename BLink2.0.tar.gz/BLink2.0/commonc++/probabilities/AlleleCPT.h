/* File: AlleleCPT.h */


#ifndef __AlleleCPT_h__
#define __AlleleCPT_h__




using namespace std;


namespace BIOS
{

//extern class PriorTable;
 class AlleleCPT: public CPT
  {//
public:
    AlleleCPT(intSample*  sample, intList *varList, intList *conditionalVarList, intList* dimensionList, BayesType bayesType, float alpha, ListOfAttributes* listOfAttributes);
   AlleleCPT(intList *conditionalVarList, PriorTable *priorTable):CPT(conditionalVarList, priorTable){};
~AlleleCPT();
void empty();
};

}
#endif

