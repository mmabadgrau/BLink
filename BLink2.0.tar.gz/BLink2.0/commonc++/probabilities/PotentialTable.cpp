/* File: PotentialTable.h */


#ifndef __PotentialTable_cpp__
#define __PotentialTable_cpp__


using namespace std;


namespace BIOS
{



   template<> VarsTable<double>* VarsTable<double>::operator*(CPT* source)
  {
    // product is false when division
 VarsTable<double>* cp=source->convertToPotential(); 
 VarsTable<double>* cp2= *this*cp;
zap(cp);
return cp2;
  };

/*______________________________________________________*/

  template<>  void VarsTable<double>::setProductValue(int pos, double first, double second, bool product)
  {
    if (product) this->table[pos]=first*second;
    else if (second==0 && first!=0) 
     {
//cout << "Error in PotentialTable::setProductValue, division by zero, vars " << *varList;
//end();
this->table[pos]=0;//first;
}
else if (first==0 && second==0) this->table[pos]=0;
else this->table[pos]=first/second;
  };


 /*______________________________________________________*/

  template<> void VarsTable<double>::set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes) throw (OutOfRange<long long int>) //, intSample::NodePointer first, intSample::NodePointer last)
  {

  VarsTable<int>* pT=new VarsTable<int>(sample, varList, dimensionList, listOfAttributes);

//MultidimensionalTable::set(dimensionList);
  totalSample=pT->totalSample;

  set(varList, pT->totalSample);

//cout <<"size is" << this->getSize();
 for (int i=0;i<this->getSize();i++)
{
//cout <<"\nval for pos " << i <<" is " << pT->getValue(i);
 this->setValue(i, (pT->getValue(i)/(double)this->getSize()));
//cout <<"\nval for pos " << i <<" is " << this->getValue(i);

}
//end();
    zap(pT);


    //  cout <<"totalcounts" << this->getTotalCounts();
  }

 






}
#endif
