#ifndef __FachadeProbabilitiesC_h__ 
#define __FachadeProbabilitiesC_h__ 





#include "AlleleProbabilityTable.cpp"

#include "SampleTable.cpp"
#include "VarsTable.cpp"
#include "ProbabilityTable.cpp"
//#include "PriorTable.cpp"
#include "CPT.cpp"


#include "PotentialTable.cpp"
#include "PotentialList.cpp"
#include "BidimensionalVarsTable.cpp"





#include "AlleleCPT.cpp"

#include "ContingencyTable.cpp"


#endif
