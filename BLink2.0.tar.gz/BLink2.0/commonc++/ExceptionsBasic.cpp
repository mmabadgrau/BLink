
#ifndef __ExcepBasicpp__
#define __ExcepBasicpp__




using namespace std;

namespace BIOS
{


//	NullValue nv;

	NoWindow nw;
	
	NoMemory NM, nm;


	MissingValue mv;

OutOfBounds ob;	


	OutOfRange<double> wm;
	
	OutOfRange<int> ori;

AlreadyOpen ao;

        BadSize bs;
        
NoEOL nl;

//        ErrorFile NoFile, eF;

NonImplemented ni;


 EmptyFile EFile;









        BadFormat bF;


	
	ZeroValue zv;



	
	NonProb n, np;


	

} // end namespace
#endif
