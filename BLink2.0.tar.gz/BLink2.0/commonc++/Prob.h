/* File: Prob.h */


#ifndef __Prob_h__
#define __Prob_h__




using namespace std;

namespace BIOS {



/////////////////////////////////

class Prob: public Quotient<double> //
{//
public://
 Prob(const Prob &other); // constructor
// Prob(double numerator, double denominator); // constructor
// Prob(double numerator, double denominator, float alpha, double size); // constructor
 Prob(double numerator=0, double denominator=0, float alphaNumerator=0, float alphaDenominator=0) throw (NonProb);
 Prob(double numerator, double denominator, Quotient<double> alphaNumerator, float alphaDenominator) throw (NonProb);  //
 Prob operator/ (Prob  origen);
 Prob operator* (Prob  origen);
 Prob operator+ (Prob  origen);
 Prob operator- (Prob  origen);
//bool operator< (Prob & rat2);
//bool operator<= (Prob & rat2);
// bool operator< (Prob & rat2);
 void addAlpha (float alphaNumerator, float alphaDenominator);
 void addAlpha (Quotient<double> alphaNumerator, float alphaDenominator);
 void setNumerator(double numerator);
	
//void operator= (Prob & rat2);
 //ostream& operator<<(ostream& out);
};//


 ostream& operator<<(ostream& out, Prob& e);


}//end namespace
#endif
