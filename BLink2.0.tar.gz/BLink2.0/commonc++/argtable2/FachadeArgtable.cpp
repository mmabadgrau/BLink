#ifndef __Argtable_c__ 
#define __Argtable_c__ 





//#include "myprog.c"
#include "getopt.c"
#include "getopt1.c"
#include "argtable2.c"
#include "arg_str.c"
#include "arg_rex.c"
#include "arg_rem.c"
#include "arg_lit.c"
#include "arg_int.c"
#include "arg_file.c"
#include "arg_end.c"
#include "arg_dbl.c"
#include "arg_date.c"
#endif
