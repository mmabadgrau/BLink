#ifndef __FachadeC_h__ 
#define __FachadeC_h__ 



/*
#include<sstream>
#include <sys/stat.h>  

#include <cassert>
#include <cstdlib>
#include <memory>
#include <vector>
#include <set>
#include <cstdio>
#include <typeinfo>
#include <cstring>

#include <string>
#include <values.h>//
#include <cmath>
#include <math.h>//
//#include <stdio.h>//
#include <vector>//
#include <set>//
#include <map>//
#include <boost/pool/singleton_pool.hpp>//
#include <boost/pool/pool_alloc.hpp>//

#include <iostream>
#include <fstream>
*/
#include "ExceptionsBasic.cpp"

#include "basic.cpp"


#include "mathMatrix/FachadeMatrix.cpp"

#include "rand/FachadeRand.cpp"
#include "Quotient.cpp"
#include "Prob.cpp"

#include "Integer.cpp"
#include "Pair.cpp"
#include "HeteroPair.cpp"
#include "Container.cpp"

//#include "AssociateContainer.cpp"
#include "HeteroListPair.cpp"
#include "Basic2.cpp"
#include "TextFile.cpp"
#include "Table2x2.cpp"
#include "attributes/FachadeAttributes.cpp"
#include "Sample.cpp"
#include "Set.cpp"
#include "Partition.cpp"
//#include "SampleOfSets.cpp"
//#include "ficheros.cpp"
#include "MultidimensionalTable.cpp"
#include "MultidimensionalEmptyTable.cpp"
#include "AmbiguousArray.cpp"
#include "BidimensionalTable.cpp"
//#include "BinaryMultidimensionalTable.cpp"
#include "Matrix.cpp"
#include "SquaredMatrix.cpp"
#include "DiagonalTable.cpp"
#include "Sampling.cpp"
#include "AttPattern.cpp"
#include "measure/FachadeMeasureC.h"
#include "probabilities/FachadeProbabilities.cpp"
#include "ProbabilityIntervals/FachadeProbabilityIntervals.cpp"

#include "argtable2/FachadeArgtable.cpp"

#include "SlidingWindows.cpp"


#endif
