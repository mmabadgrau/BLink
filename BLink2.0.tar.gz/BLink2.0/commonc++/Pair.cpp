/* File: Pair.h */


#ifndef __Pair_cpp__
#define __Pair_cpp__

#include "Pair.h"

using namespace std;

namespace BIOS {

    template < class P> Pair<P>::Pair(P f, P s) {First=BIOS::clone(f); Second=BIOS::clone(s);};
    template < class P> Pair<P>::Pair(Pair<P>* p) {First=BIOS::clone(p.First); Second=BIOS::clone(p.Second);};
    template < class P> Pair<P>::Pair() {};
    template < class P> Pair<P>::~Pair() {empty();};
    template < class P> void Pair<P>::empty() {zap(First); zap(Second);};

	   template < class P> bool Pair<P>::operator>(const Pair<P>& p) {if (First>p.First || First==p.First && Second>p.Second) return true; else return false;};
	   template < class P> bool Pair<P>::operator<(const Pair<P>&p) {if (First<p.First|| First==p.First && Second<p.Second) return true; else return false;};
	   template < class P> bool Pair<P>::operator==(Pair<P>p) {if (First==p.First && Second==p.Second) return true; else return false;};
    template < class P> void Pair<P>::setValues(P f, P s) {First=f; Second=s;};
	   template < class P> P& Pair<P>::getFirst(){return First;};
	   template < class P> P& Pair<P>::getSecond(){return Second;};
	       template < class P> Pair<P>* Pair<P>::clone(){return new Pair<P>(*this);};
    template < class P> Pair<P>* Pair<P>::fromString(string s)
{
throw NonImplemented("static Pair* fromString(string s)");
}

/*
	template<class T> bool compare( const Pair<T>& arg1, const Pair<T>& arg2)
	{
return arg1>arg2;
}
*/
/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Pair<T>& pair)
{
 
out << "(" << pair.First <<", " << pair.Second <<")";

return out;
  }

}//end namespace
#endif
