#ifndef Ddvector_HPP
#define Ddvector_HPP 1




#include <stdio.h>

namespace BIOS {
class dvector:public doublevec{
int offset; // if starts at non-zero index
public:
dvector(int l,int h):doublevec(h-l+1) {offset=l;}
~dvector() {;}
double& operator[](int i) {return v[i-offset];}
double* vec(void){return v;}
};




extern int (*dvec_error)(const char*);

extern int default_vec_error(const char *s);
extern int (*vec_error)(const char*);
extern "C" {
extern int comp_row(void const *,void const *);
}
}

#endif

