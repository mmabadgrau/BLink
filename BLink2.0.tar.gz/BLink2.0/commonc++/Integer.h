/* File: Integer.h */


#ifndef __Integer_h__
#define __Integer_h__




using namespace std;


namespace BIOS
{


  /************************/
  /* Integer DEFINITION */
  /************************/


  /**
          @memo Integer 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


  class Integer
  {

  protected:

 
  public:

     int position;

    Integer(){};

    void set (int position){this->position=position;};
    Integer(int position) {set(position);};
    Integer(Integer & a) {set(a.position);};
    ~Integer(){};
    static Integer* fromString(string s){return new Integer(atoi(s.c_str()));};
    int getValue(){return this->position;};
    Integer* clone(){return new Integer(*this);};

    void setValue(int position){this->position=position;};

    Integer & operator=(const Integer & node){throw NonImplemented("Integer & operator=(const Integer & node)");};

    bool operator==(const Integer & node)
    {
     return node.position==position;
    };

    bool operator!=(const Integer & node)
    {
     return node.position!=position;
    };
 
    bool operator<(const Integer & node)
    {
     return position<node.position;
    };

    bool operator>(const Integer & node)
    {
      return position>node.position;
    };
    /*____________________________________________________________________________________ */

    string print()
    {
    string result;
      char line[50];
      sprintf(line, "%d\0", this->position);
      result=string(line);
      return result;
    }

int size()
{
//cout <<"no sense";
return 0;
}
};// End of class Integer
/*______________________________________________________*/

   ostream& operator<<(ostream& out, Integer& i);




}
;  // Fin del Namespace

#endif

/* Fin Fichero: Integer.h */
