#ifndef MLEst_h//
#define MLEst_h//



namespace BIOS 
{


//////

template <class T> class MLEst: public DependenceMeasure<T>

{ 
	
   
public:

virtual bool better(double m1, double m2);
double getMeasure(CPT *s1, CPT* priors=NULL);
MLEst(BayesType bayesType, float alpha);

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, MLEst<T>& lista);

  
} // end namespace
#endif
