#ifndef Entropy_cpp//
#define Entropy_cpp//



namespace BIOS 
{

/*______________________________________________________*/

template <class T> Entropy<T>::Entropy(BayesType bayesType, float alpha): MLEst<T>(bayesType, alpha)
{
//if (alpha==0) alpha=1;
//this->bayesType=bayesType;
}


/*______________________________________________________*/

template <class T> double Entropy<T>::getMeasure(CPT *s1, CPT* s2)
{
cout <<"Entropy<T>::getMeasure not defined yet";
end();
}


/*______________________________________________________*/

template<> double Entropy<int>::getMeasure(CPT *s1, CPT* priors)
{
//It is used to compute entropy of s1 E(x) versus entropy of s1 given y E(x|y)
// If s1->getConditionals() has not values, we compute entropy of x (s1->getProbabilityTable())
//if not, we compute entropy of x given y
// it always true that E(x|y)<=E(x)
// E(x)=-\sum_i p(x_i)log p(x_i)
// E(x|y)=-\sum_j p(y_j) \sum_i p(x_i|y_j) log p(x_i|y_j) 
// MDL is recommended for a tradeoff between complexity and training accuracy (empirical error)
return -MLEst<int>::getMeasure(s1,priors); //2;
/*
if (bayesType!=MLE) s1->addPrior(*priors);
ProbabilityTable* pt=s1->getProbabilityTable();
int xTotalMods=pt->dimensionList->GetElement(0);
double entropy=0, w=1;
Prob p;
int* pos=NULL;
for (int j=0;j<pt->getSize()/xTotalMods;j++)
 {
  pos=pt->getPositions(j);
  if (s1->getConditionals()!=NULL) 
  w=Prob(s1->getValue(pos).getDenominator(), s1->getTotalSample()).convert();
//cout <<"\np" << w;
 for (int k=0;k<xTotalMods;k++)
{
    pos[0]=k;
    p=pt->getValue(pos);
//cout <<"inside p:" << p;
if (w>0 && p.convert()>0)
    entropy=entropy-w*p.convert()*log2(p.convert());
//cout <<"parent:" << entropy;
}
zap(pos);
}
return entropy;
*/
 }
 
 /*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Entropy<T>& lista)
{
 
//out << *lista.sample;

return out;
  }

  
} // end namespace
#endif
