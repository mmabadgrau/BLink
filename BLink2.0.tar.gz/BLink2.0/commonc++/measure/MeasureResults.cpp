/* File: MeasureResults.h */

#ifndef __MeasureResults_cpp__
#define __MeasureResults_cpp__



//using namespace UTILS;


namespace BIOS
{

 
    MeasureResults::MeasureResults()
    {
         };
/*________________________________________________________________________*/

    MeasureResults::~MeasureResults()
    {
}

/*________________________________________________________________________*/

   MeasureResults*  MeasureResults::emptyClone()
    {
    MeasureResults* result=this->clone();
    result->empty();
    return result;
}

/*________________________________________________________________________*/

   double MeasureResults::getTotalMultiTest()
    {
    return 0;
}


/*________________________________________________________________________*/

MeasureResults* MeasureResults::getAverage (MeasureResults** array, int size)
{
MeasureResults* result=array[0]->emptyClone();
for (int i=0;i<size;i++)
result->addResult(array[i], size);
return result;
};
    

};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
