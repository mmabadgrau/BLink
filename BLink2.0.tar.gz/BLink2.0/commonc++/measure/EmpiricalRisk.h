#ifndef EmpiricalRisk_h//
#define EmpiricalRisk_h//



namespace BIOS 
{


//////

template <class T> class EmpiricalRisk: public DependenceMeasure<T>

{ 
	
   
public:

EmpiricalRisk(BayesType bayesType=MLE, float alpha=0);
double getMeasure(CPT *s1, CPT* priors=NULL);
bool better(double m1, double m2);
    EmpiricalRisk();

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, EmpiricalRisk<T>& lista);
  
} // end namespace
#endif
