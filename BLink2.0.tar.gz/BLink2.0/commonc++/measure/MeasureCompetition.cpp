#ifndef MeasureCompetition_cpp//
#define MeasureCompetition_cpp//



namespace BIOS 
{


/*______________________________________________________*/

template <template <class T> class M, class U>   MeasureCompetition<M, U>::MeasureCompetition(Container<vector<Pair<intList*>*>, Pair<intList*>* >* listOfParticipants, BayesType bayesType, float alpha) 
{
this->alpha=alpha;
this->bayesType=bayesType;
this->listOfParticipants=listOfParticipants; 
results=NULL;
}
/*______________________________________________________*/

template <template <class T> class M, class U>  void MeasureCompetition<M, U>::makeRound(struct VectorSample<U>::Class* sample, ListOfAttributes* listOfAttributes) 
{
throw NonImplemented("MeasureCompetition::makeRound");
}
/*
M<U>* measure;
results=new Container<vector, HeteroPair<float, int> >();
int i=0;
for (Container<vector, Pair<intList*>* >::iterator it=listOfParticipants->begin(); it<listOfParticipants->end(); it++)
{
measure= new M<U>(this->bayesType, this->alpha);
results->insertElement(HeteroPair<float, int>(measure->getMeasure(sample, listOfAttributes, listOfParticipants->getElement(i)->getFirst(), listOfParticipants->getElement(i)->getSecond()), i));
i++;
zap(measure);
  }

results->order(false, measure->betterPair());// descendant
}
/*______________________________________________________*/

template <template <class T> class M, class U>  HeteroPair<float, int>* MeasureCompetition<M, U>::getWinner() 
{
return results->getFirstElement();
}
/*______________________________________________________*/

template <template <class T> class M, class U>  ostream& operator<<(ostream& out, MeasureCompetition<M, U>& lista)
{
 
out << *lista.sample;

return out;
  }
  
} // end namespace
#endif
