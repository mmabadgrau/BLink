/* File: MeasureResults.h */

#ifndef __MeasureResults_h__
#define __MeasureResults_h__



//using namespace UTILS;


namespace BIOS
{

  class MeasureResults
  {
  public: 

  
    MeasureResults();

    virtual ~MeasureResults();

virtual void set()=0;
virtual void addResult(MeasureResults*m, int size)=0;
MeasureResults* getAverage (MeasureResults** array, int size);  
MeasureResults* emptyClone();  
virtual MeasureResults* clone()=0;  
virtual double getMainResult()=0;
virtual void print(ostream& out, bool verticalPrint=true)=0;
virtual void printHeading(ostream& out)=0;
virtual void printHeadingPlus(string s, ostream& out){};
virtual void empty()=0;
friend ostream& operator<<(ostream& out, MeasureResults& mr){mr.print(out); return out;};
virtual double getTotalMultiTest();
};

};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
