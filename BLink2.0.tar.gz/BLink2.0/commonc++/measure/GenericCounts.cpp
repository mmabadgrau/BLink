/* File: PhylogeneticDistance.h */

#ifndef __GenericCounts_cpp__
#define __GenericCounts_cpp__

//using namespace stats;

namespace BIOS {

/*_________________________________________________________________*/
/*
GenericCounts::GenericCounts(char* filename, TestModeClass* testModeClass)
{
fileName=filename;
this->testModeClass=testModeClass;

};


/*_________________________________________________________________*/

 GenericCounts::~GenericCounts()
 {
 };
 


/*_________________________________________________________________*/
 


};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




