#ifndef SymmetricalUncertainty_h//
#define SymmetricalUncertainty_h//



namespace BIOS 
{


//////

template <class T> class SymmetricalUncertainty: public Entropy<T>

{ 
	
   
public:


  //  SymmetricalUncertainty();
SymmetricalUncertainty(BayesType bayesType=MLE, float alpha=0);
bool better(double m1, double m2);
double getMeasure(CPT *s1, CPT* priors=NULL);
//double getMeasure(MLSample<T>* sample, intList* varList, intList* conditionalVarList);

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, SymmetricalUncertainty<T>& lista);

  
} // end namespace
#endif
