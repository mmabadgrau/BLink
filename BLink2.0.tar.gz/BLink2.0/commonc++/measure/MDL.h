#ifndef MDL_h//
#define MDL_h//



namespace BIOS 
{


//////

template <class T> class MDL: public MLEst<T>

{ 
	
   
public:

//virtual bool better(double m1, double m2);
double getMeasure(CPT *s1, CPT* priors=NULL);
MDL(BayesType bayesType=MLE, float alpha=0);
    MDL();

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, MDL<T>& lista);

  
} // end namespace
#endif
