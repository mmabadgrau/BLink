#ifndef __GenericMeasure_cpp__
#define __GenericMeasure_cpp__

namespace BIOS {
	
		GenericMeasure::GenericMeasure()
		{
		};
		
		/*___________________________________________________________ */
		
				GenericMeasure::~GenericMeasure()
		{
		};

 /*_________________________________________________________________*/
/*
	 GenericMeasure* GenericMeasure::getNewGenericMeasure(GenericCounts* tuCounts2)
	{
	
 return getNewGenericMeasure(tuCounts2, positions, length);
	}
 /*_________________________________________________________________*/



};

#endif
