#ifndef TextFile_cpp//
#define TextFile_cpp//





/**
 *
 * @author mabad
 */

namespace BIOS {


/*_______________________________________________________________________________________*/

TextFile::TextFile(char fileName[256], bool input, int filePos)
		{

this->input=input;
		 strcpy(this->fileName,fileName);
  		
if (input)
{
 OpenInput(fileName, &InputFile);
if (filePos!=0)
InputFile.seekg (filePos, ifstream::beg);
}
else
 OpenOutput();

        };

/*_______________________________________________________________________________________*/

 void TextFile::OpenOutput() 
 {
  BIOS::OpenOutput(fileName, &OutputFile);
 };



/*_______________________________________________________________________________________*/

int TextFile::getTotalLines() 
{
totalLines=BIOS::getTotalLines(fileName);
 return totalLines;
};
    /*_______________________________________________________________________________________*/

   stringVector* TextFile::readLine(const char* tokensSource) 
   {
	   if (eof()) throw EOFile(fileName, "stringVector* TextFile::readLine(const char* tokensSource)");

	     	char* genotypebuf=NULL;
		genotypebuf=CaptureLine(&InputFile);

string s=string(genotypebuf);

      stringVector* line=getStringVector (genotypebuf, tokensSource);
        zaparr(genotypebuf);
 
if (line==NULL) return NULL;

	if (line->size()>0)	  
        return line;
	else 
{
zap(line);
return NULL;
}

};
      /*_______________________________________________________________________________________*/

   bool TextFile::eof() 
   {
//if (!InputFile.eof()) cout <<"\nnext elemnt is: " << InputFile.peek() <<"END";
	   return InputFile.eof();// || (InputFile.peek()=='\n' && (*(char*)(&InputFile+InputFile.tellg()+2))==EOF) 
//|| ((InputFile.peek()=='\n' || InputFile.peek()=='\r')  && ((*(char*)(&InputFile+InputFile.tellg()+2))=='\n' || (*(char*)(&InputFile+InputFile.tellg()+2))=='\r') && (*(char*)(&InputFile+InputFile.tellg()+3))==EOF)
;//it detects also empty last line
   }
   /*_______________________________________________________________________________________*/
   /*
     list<string>* getWordsInLine(int lineNumber, char* separators){
        
          ArrayList aL=null;
             TextLine *tLine;// =new TextLine(bufferendReader, separators);
        int total=0;
        try
        {
            BufferedReader bufferedReader=new BufferedReader(new FileReader(fileName));
          
     
        while (total<lineNumber && bufferedReader!=null)
        {
            total++;
            bufferedReader.readLine();
        };
           
        if (total==lineNumber)
        {
         tLine=new TextLine(bufferedReader, separators);
         aL= tLine.getWordsInLine();
      //     JOptionPane.showMessageDialog(null,"total:"+aL.size());
        }
      
              }
        catch (IOException exception){
            JOptionPane.showMessageDialog(null,"Error when reading file "+fileName+".");
                                   
        }  ;   
        return aL;
};
*/
    
} // end namespace
#endif
