#ifndef __DistanceMethodClass_cpp__
#define __DistanceMethodClass_cpp__


namespace BIOS {




 /*______________________________________________________*/

  ostream& operator<<(ostream& out, DistanceMethodClass& d)
  {

	out << "\nNumercal attributes distance method:\t\t";
	switch (d.numericalAttributeDistanceMethod)
	{
	case absoluteDifference: out << "Absolute difference"; break;
	case normalizedAbsoluteDifference: out << "Normalized absolute difference"; break;
	case squareDifference:  out << "Square Difference"; break;
	}
	out << "\nDistance method:\t\t";
	switch (d.distanceMethod)
	{
	case SqRoot: out << "Square root of the sum"; break;
	case Sum:  out << "Plain sum"; break;
	}
	// Hamming distance is obtained when all attributes are categorical and DistanceMethod is Sum
// Euclidean distances is obtained when all attributes are numerical with squareDifference as the NumericalAttributeDistanceMethod and SqRoot as the DistanceMethod
// Manhattan distance is obtained when all attributes are numerical with absoluteDifference as the NumericalAttributeDistanceMethod and Sum as the DistanceMethod

       if (d.distanceMethod==Sum)
	{
       out << "\nit will be the Hamming distances if all attributes are categorical";
       if (d.numericalAttributeDistanceMethod==absoluteDifference)
      out << "\nit will be the Manhattan distances if all attributes are numerical";
}
       if (d.distanceMethod==SqRoot)
       if (d.numericalAttributeDistanceMethod==squareDifference)
      out << "\nit will be the Euclidean distances if all attributes are numerical";
      
 return out;
  }






}

#endif
