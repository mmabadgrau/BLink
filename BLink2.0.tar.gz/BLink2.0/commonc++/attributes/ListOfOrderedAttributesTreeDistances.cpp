/* File: ListOfOrderedAttributesTreeDistances.cpp */


#ifndef __ListOfOrderedAttributesTreeDistances_cpp__
#define __ListOfOrderedAttributesTreeDistances_cpp__




//using namespace UTILS;


namespace BIOS
{



  /**********************************/
  /* DEFINITIONS OF THE FUNCTIONS */
  /**********************************/


ListOfOrderedAttributesTreeDistances* ListOfOrderedAttributesTreeDistances::clone()
  {
return new ListOfOrderedAttributesTreeDistances(*this);
  };

/*___________________________________________________________*/


 ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(int totalAtts, int totalMods,floatList* positionsVector, intList* positionsVectorToComputeDistances):ListOfOrderedAttributes(totalAtts, totalMods, positionsVector)
{
this->positionsVectorToComputeDistances=NULL;
if (positionsVectorToComputeDistances!=NULL) this->positionsVectorToComputeDistances=new intList (*positionsVectorToComputeDistances);
}
/*___________________________________________________________*/

 ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(floatList* positionsVector, intList* positionsVectorToComputeDistances):ListOfOrderedAttributes(positionsVector)
  {
this->positionsVectorToComputeDistances=NULL;
if (positionsVectorToComputeDistances!=NULL) this->positionsVectorToComputeDistances=new intList (*positionsVectorToComputeDistances);
  };
/*___________________________________________________________*/
/*
  ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(ListOfAttributes & vectorOfOrderedAttributes)
  {
cout <<"It should not be implemented ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(ListOfAttributes & vectorOfOrderedAttributes, intList* verbosity)";
end();
}
  /*___________________________________________________________*/

  ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(ListOfOrderedAttributesTreeDistances & vectorOfOrderedAttributes):ListOfOrderedAttributes(vectorOfOrderedAttributes)
  {
this->positionsVectorToComputeDistances=NULL;
if (vectorOfOrderedAttributes.positionsVectorToComputeDistances!=NULL)
 this->positionsVectorToComputeDistances=new intList(*vectorOfOrderedAttributes.positionsVectorToComputeDistances);
};

 

  /*___________________________________________________________ */

  ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances(char* texto):ListOfOrderedAttributes(texto)
  {
//cout <<"  ListOfOrderedAttributesTreeDistances::ListOfOrderedAttributesTreeDistances finished";
  }



  
  /*___________________________________________________________ */

  ListOfOrderedAttributesTreeDistances::~ListOfOrderedAttributesTreeDistances()
  {
zap(positionsVectorToComputeDistances);
  };

  /*___________________________________________________________ */

  void ListOfOrderedAttributesTreeDistances::setPositionsVectorToComputeDistances(intList* positionsVectorToComputeDistances)
{
if (positionsVectorToComputeDistances!=NULL)
{
zap(this->positionsVectorToComputeDistances);
 this->positionsVectorToComputeDistances=new intList(*positionsVectorToComputeDistances);
}

}
  
  	/*___________________________________________________________ */
	
		float ListOfOrderedAttributesTreeDistances::getDistance(Container<vector<float>, float> * pattern1, Container<vector<float>, float> * pattern2, bool useMissing, bool noclass, DistanceMethodClass * distanceMethodClass, int classPosition, doubleList* weights)
		{
      if (weights!=NULL) throw BadFormat("ListOfOrderedAttributesTreeDistances::getDistance");
		if (distanceMethodClass->distanceMethod==SqRoot) throw BadFormat("2. ListOfOrderedAttributesTreeDistances::getDistance");
			if (size()!=(pattern1->size()+noclass)) {cout <<"error 1 in ListOfOrderedAttributesTreeDistances::getDistance for pattern: " << *pattern1; exit(0);};
			if (pattern1->size()!=pattern2->size()) {cout <<"error 2 in ListOfOrderedAttributesTreeDistances::getDistance"; exit(0);};
			iterator p=getFirst();
			Attribute *attribute;
			if (positionsVectorToComputeDistances==NULL) throw BadFormat("3. ListOfOrderedAttributesTreeDistances::getDistance");
      intList::iterator pos2=positionsVectorToComputeDistances->begin();
try
{
intList* cleanPattern1=new intList(), *cleanPattern2=new intList();
//cout <<"patterns to be compared are:" << *pattern1 <<" and " <<*pattern2 <<"\n";
//cout <<"positionsvectoris:" << *positionsVectorToComputeDistances<< "\n";
	for (intList::iterator pos=this->positionsVectorToComputeDistances->begin(); pos<this->positionsVectorToComputeDistances->end(); pos++)
				if (!noclass || classPosition!=*pos)
	{
				attribute=this->getElement(*pos);
				if (attribute->isSelected())
					if (!attribute->isMissing(pattern1->getElement(*pos2)))
						if (!attribute->isMissing(pattern2->getElement(*pos2)))
		{
		cleanPattern1->insertElement((int)pattern1->getElement(*pos2)+1);
		cleanPattern2->insertElement((int)pattern2->getElement(*pos2)+1);
}
pos2++;
}
int* posArray=positionsVectorToComputeDistances->toArray();
int* array1=cleanPattern1->toArray(), *array2=cleanPattern2->toArray();
Haplotype* hap1=new Haplotype((base*)array1, cleanPattern1->size()), *hap2=new Haplotype((base*)array2, cleanPattern2->size()), *hap1B=hap1->filter(posArray, positionsVectorToComputeDistances->size()), *hap2B=
hap2->filter(posArray, positionsVectorToComputeDistances->size());
float distance=hap1B->getDistance(hap2B);
zap(hap2);
zap(hap1);
zap(hap2B);
zap(hap1B);
zaparr(array1);
zaparr(array2);
zaparr(posArray);
zap(cleanPattern1);
zap(cleanPattern2);
		return distance;  //  return (-1);
}
catch (OutOfRange<int>& ore){ore.addMessage("\ncalled from ListOfAttributes::getDistance"); throw;}
//cout <<"distance is:" << distance<<"\n";

	
		};

/*______________________________________________________*/

ostream& operator<<(ostream& out, ListOfOrderedAttributesTreeDistances& vectora)
{
   out << (ListOfAttributes&)vectora<<"\n";
   if (vectora.positionsVectorToComputeDistances!=NULL) out << "Relative positions to compute distances are:\n" << *vectora.positionsVectorToComputeDistances;
   
   return out;
}

 
};  // Fin del Namespace

#endif

/* Fin Fichero: ListOfOrderedAttributesTreeDistances.h */
