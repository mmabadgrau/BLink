#ifndef AttPattern_cpp//
#define AttPattern_cpp//



using namespace std;


namespace BIOS {



/************************/
/* ListOfLists DEFINITION */
/************************/


/**
        @memo AttPattern 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/


/*______________________________________________________*/

   ostream& operator<<(ostream& out, AttPattern& attPattern)
  {

         out << attPattern.print() <<"\n";
    return out;
  }



}// end namespace
#endif
