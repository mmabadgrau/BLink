/* File: Sampling.h */


#ifndef __Sampling_h__
#define __Sampling_h__



namespace BIOS {


/************************/
/* Sampling STATISTIC*/
/************************/


/**
        @memo Sampling

	@doc
        Definition:
        An array Pos of Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Sampling  {


protected:
    /** @name Implementation of class Sampling
        @memo Private part.
    */


  intList* positionsList;
  






/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

  int  * Pos;
 int Size;

Sampling(int size, bool repetition=false, int finalSize=-1);
~Sampling();
int* getPositionsTable();
void setPositionsList();
intList* getPositionsList();
int getPos(int pos);
friend ostream& operator<<(ostream& out, Sampling& pm);

};  // End of class Sampling





};  // End of Namespace

#endif

/* End of file: Sampling.h */




