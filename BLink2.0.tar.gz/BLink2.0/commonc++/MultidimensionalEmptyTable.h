/* File: MultidimensionalEmptyTable.h */


#ifndef __MultidimensionalEmptyTable_h__
#define __MultidimensionalEmptyTable_h__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{
class AmbiguousArray;
  /////////////////////////////////////////
  template <class T> class MultidimensionalEmptyTable //
  {//
    // it is an empty xD table with position numbers first in deep vars. Example: 2x2 table. Configuration numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
// It is empty as there will not be any array. The class is used only to convert from configuration numbers to an array of positions at each variable


protected:
    
long long int size; // array size
int totalDimensions; // total number of variables (dimensions)

  public:

        intList *dimensionList;


    MultidimensionalEmptyTable();
    MultidimensionalEmptyTable(intList* dimensionList);
    MultidimensionalEmptyTable(MultidimensionalEmptyTable &source);
void set(intList *dimensionList) ;
        long long int getSubtableSize(int dim);
      long long int getPos(int *pos); 
    void setSize(); 
       int* getPositions(long long int pos);


void initialize();
void set();
void empty();
intList* getPosList(long long int pos);
T GetMax();
int getDimension();
intList* getAmbiguousDimList ();
AmbiguousArray* getAmbiguousTable ();
       int getIndexPositionOfIndexVar(int pos, int var);
    ~MultidimensionalEmptyTable();
  string print();
       int getSize() ;
         bool inferredFrequency(int pos);
   }; // end class
   
   template <class T> ostream& operator<<(ostream& out, MultidimensionalEmptyTable<T>& p);
  
   /*______________________________________________________*/
/*
  template <class T> ostream& operator<<(ostream& out, MultidimensionalEmptyTable<T>& p)
  {
    out << p.print();
    return out;
  };
   */
  

}
#endif
