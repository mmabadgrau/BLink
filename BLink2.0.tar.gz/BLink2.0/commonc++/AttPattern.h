#ifndef AttPattern_h//
#define AttPattern_h//



using namespace std;


namespace BIOS {



/************************/
/* ListOfLists DEFINITION */
/************************/


/**
        @memo AttPattern 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/

class AttPattern {

private:

char line[256];

struct 
{
 int pos;
 float minValue;
 float maxValue;
} attPattern;

public:

AttPattern()
{
attPattern.pos=-1;
}


AttPattern(int position, float minVal, float maxVal)
{
attPattern.pos=position;
attPattern.minValue=minVal;
attPattern.maxValue=maxVal;
}

AttPattern(AttPattern *ap)
{
attPattern.pos=ap->GetPos();
attPattern.minValue=ap->GetMinValue();
attPattern.maxValue=ap->GetMaxValue();
}

AttPattern* clone()
{
return new AttPattern(*this);
}

AttPattern & operator=(AttPattern & ap)
{
/*AttPattern * attPattern;
attPattern=new AttPattern(&ap);
return *attPattern;*/
 if (&ap!=NULL)
    if (this!=&ap)
     this->attPattern=ap.attPattern;
return *this;
}

virtual bool operator>(AttPattern & e){cout <<"Not implemented"; exit(0);};

virtual bool operator<(AttPattern & e){cout <<"Not implemented"; exit(0);};

bool operator==(AttPattern& target)
{
return target.attPattern.pos==attPattern.pos && target.attPattern.minValue==attPattern.minValue && target.attPattern.maxValue==attPattern.maxValue;
};

virtual bool operator!=(const AttPattern & e){cout <<"Not implemented"; exit(0);};

int GetPos()
{
return attPattern.pos;
}

float GetMinValue()
{
return attPattern.minValue;
}

float GetMaxValue()
{
return attPattern.maxValue;
}

string print()
{
char line[50];
sprintf(line, "%d, %0.8f, %0.8f", attPattern.pos, attPattern.minValue, attPattern.maxValue);
return string(line);
}

int size()
{
//cout <<"no sense";
return 0;
}


AttPattern* fromString (string source)
{
throw NonImplemented("AttPattern::fromString (string source)");
 };

};// end class

typedef Vector<AttPattern*>::Class AttPatternVector;

/*______________________________________________________*/

   ostream& operator<<(ostream& out, AttPattern& attPattern);



}// end namespace
#endif
