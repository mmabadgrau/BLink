#ifndef __Fachade_h__ 
#define __Fachade_h__ 

#include<sstream>
#include <sys/stat.h>  
#include <sys/time.h>  
#include <cassert>
#include <cstdlib>
#include <memory>
#include <vector>
#include <set>
#include <cstdio>
#include <typeinfo>
#include <cstring>
#include <string>
#ifdef _CMP_MAC_
#include <float.h>
#else
#include <values.h>//
#endif
#include <cmath>
#include <math.h>//
//#include <stdio.h>//
#include <iostream>
#include <algorithm>
#include <vector>//
#include <set>//
#include <map>//
//#include <boost/pool/singleton_pool.hpp>//
//#include <boost/pool/pool_alloc.hpp>//


#include <fstream>
#include <sstream>
#include<iomanip>
#include "ExceptionsBasic.h"
#include "Pair.h"
#include "float.h"
#include "basic.h"

#include "mathMatrix/FachadeMatrix.h"
#include "Integer.h"
#include "HeteroPair.h"
#include "Container.h"
#include "Sampling.h"
#include "Set.h"
#include "Sample.h"
#include "Partition.h"


//#include "GenericContainer.h"
//#include "AssociateContainer.h"
#include "rand/FachadeRand.h"
#include "HeteroListPair.h"



#include "Quotient.h"
#include "Prob.h"

#include "MultidimensionalEmptyTable.h"
#include "MultidimensionalTable.h"


#include "AttPattern.h"

#include "attributes/FachadeAttributes.h"


//#include "BinaryMultidimensionalTable.h"
#include "BidimensionalTable.h"
#include "AmbiguousArray.h"





#include "SlidingWindows.h"





#include "AttPattern.h"



#include "NonZero.h"



//#include "SampleOfSets.h"
#include "TextFile.h"
#include "DiagonalTable.h"
#include "Table2x2.h"
#include "Basic2.h"
//#include "ficheros.h"


#include "Matrix.h"
#include "SquaredMatrix.h"
#include "probabilities/FachadeProbabilities.h"



#include "measure/FachadeMeasure.h"

#include "ProbabilityIntervals/FachadeProbabilityIntervals.h"
//#include "probabilities/FachadeProbabilitiesC.h"

#include "argtable2/FachadeArgtable.h"

#include "../ML/Graphs/Node.h"

#include "tree.hh"
#include "tree_util.hh"


#endif
