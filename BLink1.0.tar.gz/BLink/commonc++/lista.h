/* File: lista.h */


#ifndef __lista_h__
#define __lista_h__


#include "Exceptions.h"
#include "base.h"


/************************/
/* lista DEFINITION */
/************************/


/**
        @memo lista 

	@doc
        Definition:
        A set of lista's features 

        Memory space: O(SizeP), which SizeP being the number of elements in the lista

    @author Maria M. Abad
	@version 1.0
*/

typedef int Pos;	
	
template <class T> class lista {

public:	
		
typedef struct node
{
 T element;
 struct node* Next;
};


typedef node * NodePointer;

protected:		
NodePointer List;




/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

/////////////////////////////////////////////
void destroy(NodePointer e);

void copy(NodePointer & target, const NodePointer source);

void ReadInfo (ifstream * is, Pos size);


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


      /**
         @memo Destructor
	 @doc
           Deallocate memory used by lista.
           Time complexity O(1).

      */
      ~lista ();
//////////////////////////////////////////////




      /** @name Operations on lista 
        @memo Operations on a lista 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
      lista();
  /////////////////////////////////////////////
      /**
         @memo Copy constructor
         @param target: lista where will be copy
         @param origen: lista to copy
         @doc
           Make a copy of lista
           Time complexity in time O(1).
        */

  	  
	  lista (lista &source, Pos *Sampling, Pos size);



///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: lista to copy.
         @return Reference to the receptor lista.
	 @doc
           Copy the lista in the receptor lista.
           Time complexity O(1).

      */
      lista & operator=(const lista & e);
////////////////////////////////////////////////////
 
      bool operator==(const lista & e);
      /**
         @memo Is different
         @param g: lista to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const lista & e);



	  	        /**
         @memo Obtain the element pointed by the nodepointer.
         @return return a pointer to the first lista in the lista
         Time complexity O(1)

      */
	  T GetElement(NodePointer e);

	  T GetElement(Pos k);

	        /**
         @memo Obtain the first lista in the lista.
         @return return a pointer to the first lista in the lista
         Time complexity O(1)

      */
	  inline NodePointer GetFirst () {return List;};

      /**
         @memo Obtain the Next lista in the lista.
         @param The pointer to the current lista
         @return return a pointer to the Next lista in the lista
         Time complexity O(1)

      */
       inline NodePointer GetNext (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Next;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};

   /**
         @memo Obtain the element at pos k in the lista.
         @param The pointer to the current lista
         @return return a pointer to the Next lista in the lista
         Time complexity O(1)

      */
      inline  NodePointer GetNode (Pos k)
		{
		NodePointer i=List;
		try {
		for (int c=0;c<k;c++)
		 if ((i=i->Next)==NULL) throw NullValue();
			}
		catch (NullValue null) {null.PrintMessage();}
		return i;};             

	 
      /**
         @memo Obtain the lista SizeP.
         @return the size of a lista
         @doc Return the number of lists in the lista. This value
         is in the variable SizeP.
         Time complexity O(1)

      */
        Pos GetSize ();         
		
		Pos GetPos(NodePointer p);

		  /**
         @memo Add an element to the lista.
         @param Position: Position of this element in the lista
         Time complexity O(1)

      */
	  void insertElement (T & element);

		  /**
         @memo Remove the element at pos n from the lista.
         @param Position: Position of this element in the lista
         Time complexity O(1)

      */
	//  void RemoveElement (NodePointer e);

NodePointer RemoveElement (NodePointer Pointer)
{
	NodePointer Pointer2=List, PointerPre=NULL;
	
try
{

		if (Pointer2==NULL || Pointer==NULL)
		//throw NullValue("when removing an element");
		   throw NullValue();


	while ((Pointer2!=Pointer) && (Pointer2!=NULL))
	{
     PointerPre=Pointer2;
     Pointer2=GetNext(Pointer2);
	}

	if (Pointer2==NULL)
		//throw NullValue("when removing an element");
		  throw NullValue();

	else 
	{
     if (PointerPre!=NULL) // it is not the first element		 
	 {
	  PointerPre->Next=Pointer->Next;
	  delete Pointer;
	  return PointerPre->Next;
	 }
	 else 
	 {
	  List=Pointer->Next;
	  delete Pointer;
	  return List;
	}
	}
}
catch (NullValue null) {
    null.PrintMessage("when removing an element");
    }

} ;


	  void Order(Pos* NewOrder, Pos size);

	  void Order(int funcioncomparar (const void *arg1, const void *arg2));

  	  void Remove(bool* RemovePos);

	  void ReplaceNode(NodePointer p, T & NewElement);

	  bool IsEmpty();


};  // End of class lista

//	  void lista<name>::insertElement (name element);

/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/////////////////////////////////////////////
template <class T>  void lista<T>::destroy(lista::NodePointer e)
{

       		if(e!= NULL)
			 destroy (e->Next);
			delete e;
            
}
//////////////////////////////////////////

template <class T>  void lista<T>::copy (lista<T>::NodePointer & Target, const lista<T>::NodePointer Source)
{
	try
	{

	  if ((Target=new node)==NULL)
            throw NoMemory();
 
	     Target->element=Source->element;
        	 
         if (Source->Next!=NULL)
           copy(Target->Next,Source->Next);     
		 else Target->Next=NULL;

	}
	catch (NoMemory wm) 
{
 wm.PrintMessage();
}        

}

///////////////////
//// public ////////
///////////////////

template <class T> lista<T>::lista()
{

  List=NULL; 
}

/*____________________________________________________________ */

template <class T>  lista<T>::lista (lista<T> &source, Pos *Sampling=NULL, Pos SizeP=0)
{
// copy elements with pos in Sampling, they can be repeated

Pos cont=0;
List=NULL;

if (Sampling!=NULL)
{
  while (cont<SizeP)
  {
  insertElement(source.GetElement(Sampling[cont]));
  cont++;
  };
}
else
 copy (List, source.List);

}


/*____________________________________________________________ */

template <class T>  lista<T>::~lista ()
{
	if (List!=NULL) destroy(List);
}
 /*____________________________________________________________ */

template <class T> T lista<T>::GetElement(lista<T>::NodePointer e)
{
	try
	{
  if (e==NULL) 
   // throw NullValue(" in GetElement");
   throw NullValue();
  else return e->element;
	}

   catch (NullValue nv) {
                nv.PrintMessage();}
}
 /*____________________________________________________________ */

template <class T> T lista<T>::GetElement(Pos k)
{
return GetElement(GetNode(k));
}



/*____________________________________________________________ */

template <class T>  void lista<T>::ReplaceNode(lista<T>::NodePointer p, T & NewElement)
{
  try {
  if (p==NULL)
   throw NullValue();

  p->element=NewElement;
      
  }
  catch (NullValue null) {
    null.PrintMessage();
    }
}
/*____________________________________________________________ */

template <class T> Pos lista<T>::GetPos(lista<T>::NodePointer p)
{
  Pos k=0;
  NodePointer i=List;
  
	  while (i!=NULL)
	  {
		if (i==p) return k;
		k++;
		i=i->Next;
	  }
  
  return k;
}
/*____________________________________________________________ */


template <class T>  Pos lista<T>::GetSize()
{
	Pos Size=0;

	NodePointer i=List;

     while (i!=NULL)
	 {
		 i=i->Next;
		 Size++;
	 }

	 return Size;
}
/*____________________________________________________________ */

template <class T>  lista<T>& lista<T>::operator=(const lista<T> & Source)
{
  if (this!=&Source)  
  {
  destroy(List);
  copy (List, Source.List);
  }
  return *this;
}
/*____________________________________________________________ */

template <class T>  void lista<T>::insertElement (T & element)
{
	
	NodePointer OldPointer=NULL, Pointer=GetFirst();

	while (Pointer!=NULL) 
	{
		OldPointer=Pointer;
		Pointer=GetNext(Pointer);
	}

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	Pointer->element=element;      	      
	Pointer->Next=NULL;
	if (OldPointer!=NULL) OldPointer->Next=Pointer; else List=Pointer;
	
}


/*____________________________________________________________ */
/*
template <class T>  void lista<T>::RemoveElement (lista<T>::NodePointer Pointer)
{

try
{
	NodePointer Pointer2=List;

	while ((Pointer2->Next!=Pointer) && (Pointer!=NULL))
     Pointer2=GetNext(Pointer2);

	if (Pointer==NULL)
		//throw NullValue("when removing an element");
		   throw NullValue();

	else 
	{
		delete Pointer;
		if (Pointer2!=NULL)
		 Pointer2->Next=Pointer->Next;
		else // Pointer is the first element, lista will be empty
         List=NULL;
	}
}
catch (NullValue null) {
    null.PrintMessage();
    }

} 
*/
/*____________________________________________________________ */

template <class T>  void lista<T>::Order(Pos* NewOrder, Pos size)
{
 	 Pos Size=GetSize(), pos;
	
	 lista<T> *List2;
	 try
	 {
	 if (Size!=size)
		 throw NoMemory();
 	if ((List2=new lista<T>())==NULL)
		throw NoMemory();
	 }

	 catch (NoMemory NM ) {
      NM.PrintMessage();
	}
	exit(0);


	for (Pos i=0;i<Size;i++)
	{
      pos=NewOrder[i];
	  List2->insertElement(GetElement(GetNode(pos)));  
	 }

	destroy(List);
	NodePointer p=List2->GetFirst();
    while (p!=NULL) 
	{
	  insertElement(GetElement(p));  
	  p=List2->GetNext(p);
	}

	

  cout <<"Sorting has finished\n";
}
/*____________________________________________________________ */

template <class T>  void lista<T>::Order(int funcioncomparar (const void *arg1, const void *arg2))
{
 
 NodePointer IndPosition=GetFirst();

 int size=GetSize(), i=0;

 T *List;
 if ((List=new T[size])==NULL)
  throw NoMemory();

 while (IndPosition!=NULL)
 {
  List[i]=IndPosition->element;
  IndPosition=GetNext(IndPosition);
  i++;
 }
 qsort ((void*)List, size, sizeof (T), funcioncomparar);

IndPosition=GetFirst();
i=0;
while (IndPosition!=NULL)
{
 IndPosition->element=List[i];
 IndPosition=GetNext(IndPosition);               
 i++;
}

delete List;
	
}

/*____________________________________________________________ */

template <class T>  bool lista<T>::IsEmpty()
{
	return List==NULL;
}
/*____________________________________________________________ */

template <class T>  void lista<T>::Remove(bool* PosList)
{
	// PosList contains true in positions to be removed

 	 Pos Size=GetSize(), pos, i=0;
	
	 try
	 {
	 if (Size!=sizeof(*PosList))
		 throw NoMemory();
	 }

	 catch (NoMemory NM ) {NM.PrintMessage();
	}

	NodePointer p=GetFirst(), oldp;
	
	while (p!=NULL)
	{
    oldp=p;
    p=GetNext(p);
	if (PosList[i]==true)
	  RemoveElement(oldp);  
	}  
	

  cout <<"Sorting has finished\n";
}
/* _____________________________________________________*/


#endif

/* Fin Fichero: lista.h */
