/* File: ListOfPointers.h */


#ifndef __ListOfPointers_h__
#define __ListOfPointers_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.cpp"
#include "list.cpp"
//#include "ListOfPointers.h"

//#include "Diplotype.h"


/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A set of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */



  template <class T> class ListOfPointers: public list<T*>
  {

public:

/*
   typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;
      ~node() {delete &element; Next=NULL; Previous=NULL;};
    };
*/

   //Node::~Node() {delete &element; Next=NULL; Previous=NULL;};

public:

 //  typedef node * NodePointer2;

   protected:  void copy(const typename ListOfPointers<T>::NodePointer source);

 
   
    /////////////////////////



    /* PUBLIC FUNCTIONS (INTERFACE) */

  public:


    ~ListOfPointers ();

    ListOfPointers();

    ListOfPointers(ListOfPointers &source, list<int> *Sampling);

    ListOfPointers(char* filename, char* tokens=NULL);

    ListOfPointers & cloneSecond(const ListOfPointers & e);
    
    ListOfPointers & operator=(const ListOfPointers & e);

 
    void Order(bool ascendent=true);
    
    T* GetExtremeElement(bool max);

typename ListOfPointers<T>::NodePointer findElement(T* element);

  
  typename ListOfPointers<T>::NodePointer GetClosestGreaterPointerToElement(T* argument, bool checkOrder);

      bool isOrdered(bool ascendent);

    char* print(bool* seleccionados=NULL);

   // T GetElement(typename ListOfPointers<T>::NodePointer e);

    //void InsertHardElement (T & element);

 //   void insertElement (T* element);

  void insertElement (T * element);

  //  void softEmpty();

   // void softDestroy(typename ListOfPointers<T>::NodePointer e);

 void deleteElement (T * element);
 
  assignElement (typename ListOfPointers<T>::NodePointer p, T* element);
 
 
/*
   void ReadInfo (ifstream * is, char* tokens)
{//list<T*>::ReadInfo(is, tokens);

   // insertElement(
   this->ReadElement(is, tokens);//);
   // cout <<"bbb";
//exit(0);
    
    if (is->peek()!=EOF) // && is->peek()>='0' && is->peek()<='?')

      ReadInfo(is, tokens);

};
/*
    void GetInfo(char *FileName, char* tokens){
//list<T*>::GetInfo(FileName, tokens);
    ifstream  InputFile;

    try
    {
      if (!ExistFile(FileName))
        throw ErrorFile();
      InputFile.open (FileName, ifstream::in);
      if (InputFile.peek()==EOF)
        throw EmptyFile();
    }
  catch (ErrorFile NoFile) {NoFile.PrintMessage(FileName);}
    catch (EmptyFile EFile) {EFile.PrintMessage(FileName);}


    ReadInfo (&InputFile, tokens);
    //exit(0);

    InputFile.close();
    //cout <<"Elements reading has finished\n";
  };
*/
 //T& ListOfPointers<T>::GetElement(typename ListOfPointers<T>::NodePointer e);
   

  //  T* GetPointerToElement(typename ListOfPointers<T>::NodePointer e);
  
  //  T* GetPointerToElement(int k);

    ListOfPointers<T>* ExtractList(long int indexVector[], int size);

    typename ListOfPointers<T>::NodePointer removeNode(typename ListOfPointers<T>::NodePointer Pointer);

    void moveElement(int oldPos, int newPos);
     
     void copyPaste (ListOfPointers<T>* otherList);




};


}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
