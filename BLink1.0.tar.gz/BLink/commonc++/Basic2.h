
#ifndef __Basic2_h__
#define __Basic2_h__


using namespace std;

namespace BIOS
{


//void print(char* filename);

  template <class T> bool empty(list<T>* lista);
  template <class T> T GetMean (Pair<T>* values, int size, bool first=true);
  stringList*  getList (char * genotypebuf, char* tokensSource);
  intList* getNumbers (char* input);
   template <class T> Container<T, list>* createList(T* array, int length);

 /*______________________________________________________*/

  template <class T> void print(T val)
  {
    cout << val;
  };
 /*______________________________________________________*/

   template <>  void print(Prob val)
  {
    cout << val.print();
  };
}
// end namespace

//#include "basic.cpp"
#endif


