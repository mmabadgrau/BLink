/* File: CoupleTable.h */


#ifndef __CoupleTable_h__
#define __CoupleTable_h__

// a diagonal 2 dim table

namespace BIOS {


template <class T> class CoupleTable 
{
protected:

 unsigned long int x;
 T **table;
 unsigned long int Width;

public:

	CoupleTable();
	CoupleTable(unsigned long int a, unsigned long int width);
	~CoupleTable();
	void Initialization(T value);
	void CheckCoordinates(unsigned long int i, unsigned long int j);
	void SetValue(unsigned long int i, unsigned long int j, T value);
	T GetValue(unsigned long int i, unsigned long int j);


};
/*___________________________________________________*/

template <class T> CoupleTable<T>::CoupleTable()//
{//
}
/*___________________________________________________*/

template <class T> CoupleTable<T>::CoupleTable(unsigned long int a, unsigned long int width=0)//
{//
x=a;
if (width==0) Width=a;
else Width=width;
if ((table=new T*[x-1])==NULL)
  throw NoMemory();

for (long unsigned int i=0; i<(x-1) ;i++)
 if ((table[i]=new T[mini((x-i-1),Width)])==NULL)
  throw NoMemory();
}
/*___________________________________________________*/

template <class T> CoupleTable<T>::~CoupleTable<T>()//
{//

 //for (long unsigned int i=0; i<x;i++)
 //delete (table[i]);

//zaparr (table);

}
/*___________________________________________________*/

template <class T> void CoupleTable<T>::Initialization (T value)
{
for (long unsigned int i=0; i<x;i++)
{
 unsigned long int last=mini((x-i-1),Width);
 for (long unsigned int i2=0; i2<last;i2++)
  table[i][i2]=value;
}
}
/*___________________________________________________*/

template <class T> void CoupleTable<T>::CheckCoordinates (unsigned long int i, unsigned long int j)
{
if (i>j) change (i,j);
char line[100];
sprintf(line, " CoupleTable::SetValue, values %d-%d", i,j);
try
{
	if (i>=x || j>=mini(x, Width+i))
		throw NullValue();
}
catch (NullValue nv) {nv.PrintMessage(line);}; 

}
/*___________________________________________________*/

template <class T> void CoupleTable<T>::SetValue (unsigned long int i, unsigned long int j, T value)
{

	CheckCoordinates (i,j);

table[i][j-i-1]=value;
}
/*___________________________________________________*/

template <class T> T CoupleTable<T>::GetValue (unsigned long int i, unsigned long int j)
{

	CheckCoordinates (i,j);

	return table[i][j-i-1];
}

}//                      // End of Namespace

#endif

/* End of file: CoupleTable.h */


