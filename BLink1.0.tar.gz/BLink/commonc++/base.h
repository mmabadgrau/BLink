#ifndef __base_h__
#define __base_h__


#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
// mensajes email en c++
#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>                                                       
#include <math.h>
#include <cassert>
#include "Exceptions.h"

#define  maxint  32767//
#define maxreal  1.7E+38//
#define zero 0.1E-10 //


const bool temporal=true;
const unsigned short int old=0;
const unsigned short int nuevo=2;
const unsigned short int actual=1;

char urli[]="/cgi-bin/vivegranada/vivegranada.shtml";
char urlb[]="/index-esp.html";
char urlbe[]="/index-ingles.html";
char urlbm[]="Volver a la p&aacute;gina de inicio\0";
char urlbem[]="Back to the main page\0";
char urlw[]="mailto://mabad@vivegranada.com\0";
char urlwm[]="Contacte con el webmaster\0";
char urlwem[]="Contact to the webmaster\0";
char urlv[]="/index.html";
char urlvm[]="Volver a la p&aacute;gina de vivegranada\0";
char urlvg[]="http://www.vivegranada.com/cgi-bin/\0";
char cgiseg[]="https://eurus.safe-order.net/vivegranada/cgi-bin/\0";
char cdatos[]="/home/vivegranada/datos/\0";
char csistema[]="/home/vivegranada/www/cgi-bin/\0";
char ccookies[]="/home/vivegranada/cookies/\0";
char urlba[]="/abentur/index-esp.html";
char urlbea[]="/abentur/index-ingles.html";
char urlbma[]="Volver a la p&aacute;gina de inicio\0";
char urlva[]="/abentur/index.html";
char urlvma[]="Volver a la p&aacute;gina de aBenTur\0";
char nomfich[128];

char *rango[4]={"Enero a Marzo", "Abril a Junio", "Julio a Septiembre", "Octubre a Diciembre"};
char *rangoeng[4]={"January to March", "April to June", "July to September", "October to December"};
const unsigned short int datos=0;
const unsigned short int sistema=1;

/*---------------------------------------------------------------*/

/////////////////////////
	typedef enum {
		vivegranada=0, 
		infovive=1, 
		vivespain=2,
        viverent=3 
		} WebType; 


/////////////////////////
void actualizar_modos (char publica[2], char privada[2], char intranet[2]);
void enviarcorreoerror (unsigned short int error, int procedimiento, char* nomfich=NULL);
bool ExistFile (char* namefile);


///////////////////////////////77
char* BoolToChar(bool valor)
{
	if (valor==true) return("1\0");
	else return("0\0");
}
///////////////////////
unsigned short int incluidoidioma (unsigned short int idioma)
{
unsigned short int incluido=0;
switch (idioma)
{
case 1:
case 6:
incluido=1;
break;
}
return (incluido);
}
///////////////////////////

void iniciopagina(char textoesp[100], char textoeng[100], char textoal[100], unsigned short int idioma, WebType web =vivegranada, unsigned short int code=0);
void splitword (char * out, char *in, char stop)
{
int i, j,k;
for (i=0; in[i] && (in[i]!=stop); i++)
 out[i]=in[i];

out[i]='\0'; //terminar
if (in[i])
 ++i;

//printf("lenin:%d", strlen(in));
//printf("lenout:%d", strlen(out));
k=strlen(in)-strlen(out);
//printf("k:%d", k);

//exit(0);

for (j=0; (in[j]&&(j<k));) // desplazar el resto de in
//if (j<k)
// if (j<(strlen(in)-strlen(out)))
{
 in [j++]=in[i++];
//printf("%d", j);
// if ((in[j-1]) && (in[j-1]!='\0'))
// printf("%c", in[j-1]);
}
in[j]='\0';
}
/////////////////////////////

char x2c (char *x)
{
 register char c;
// nota: (x & 0xdf) pone en mayÃÂºscula a x 
c= (x[0] >= 'A' ?  ((x[0] & 0xff) - 'A')+ 10: (x[0] - '0'));
c*=16;
c+= (x[1] >= 'A' ? ((x[1] & 0xdf) - 'A') + 10: (x[1]-'0'));
return(c);
}
///////////////////////////////
void unescape_url (char *url)
{
register int i,j;
for (i=0, j=0; url[j]; ++i,++j)
{
 if ((url[i]=url[j]) == '%')
 {
 url[i]=x2c(&url[j+1]);
 j += 2;
 }
else if (url[i] == '+')
 url[i] = ' ';
 }
url[i]='\0'; //terminar en la nueva longitud
}        
///////////////
char valorlectura[10000];
//////////////////
char* LeerValor(char* query_string, int &error)
{
error=0;
strcpy(valorlectura, "\0");
char *nombre;
if ((nombre=new char[100])==NULL)
 cerr <<"Error en LeerValor";
strcpy(nombre, "\0");
splitword(valorlectura, query_string, '&');
unescape_url(valorlectura);       
splitword(nombre, valorlectura, '=');
if (strlen(valorlectura)==0)
{
error=1;
//printf("<br>%s", query_string);
}
delete nombre;
return(valorlectura);
}
//////////////////////////////
unsigned int buscarcadena (FILE* ftemp, char* cadena, unsigned int tam, char* cadena2)
{
unsigned short int error=0, encontrado=0;
int desp=0;
char cadena3[tam];
//printf ("cadena:%s", cadena);
fread (cadena3, 1, tam, ftemp);
cadena3[tam]='\0';
//printf ("lon1:%d, long2:%d, tam:%d", strlen(cadena), strlen(cadena3), tam);
do
{
//printf ("cad3:%s", cadena3);
if (strncmp(cadena, cadena3, tam)==0) encontrado=1;
fseek(ftemp, ftell(ftemp)-tam+1,0);
fread (cadena3, 1, tam, ftemp);
cadena3[tam]='\0';
}
while ((encontrado==0) && (!feof(ftemp)));
if (encontrado==0)
{
printf ("No encontrada la cadena %s", cadena);
exit(0);
}
desp=ftell(ftemp)+3;
fseek (ftemp, desp, 0);
fread (cadena2, 200, 1, ftemp);
fseek (ftemp, desp, 0);
return (desp);
}
//////////////////////////////
unsigned int buscarcadena2 (FILE* ftemp, char* cadena, unsigned int tam, char* cadena2)
{
unsigned short int error=0, encontrado=0;
int desp=0;
char cadena3[tam];
//printf ("cadena:%s", cadena);
fread (cadena3, 1, tam, ftemp);
cadena3[tam]='\0';
//printf ("lon1:%d, long2:%d, tam:%d", strlen(cadena), strlen(cadena3), tam);
do
{
//printf ("cad3:%s", cadena3);
if (strncmp(cadena, cadena3, tam)==0) encontrado=1;
fseek(ftemp, ftell(ftemp)-tam+1,0);
fread (cadena3, 1, tam, ftemp);
cadena3[tam]='\0';
}
while ((encontrado==0) && (!feof(ftemp)));
if (encontrado==0)
{
printf ("No encontrada la cadena %s", cadena);
exit(0);
}
desp=ftell(ftemp);
//fseek (ftemp, desp, 0);
fread (cadena2, 200, 1, ftemp);
fseek (ftemp, desp, 0);
return (desp);
}
//////////////////////////////
int buscarcadena3 (char* filename, char* cadena, unsigned int tam)
{
FILE* file;
if  ((file=fopen(filename, "r"))==NULL) 
return -1;


unsigned short int error=0, encontrado=0;
int desp=0;
char cadena3[tam];
//printf ("cadena:%s", cadena);
fread (cadena3, 1, tam, file);
cadena3[tam]='\0';
//printf ("lon1:%d, long2:%d, tam:%d", strlen(cadena), strlen(cadena3), tam);
do
{
//printf ("cad3:%s", cadena3);
if (strncmp(cadena, cadena3, tam)==0) encontrado=1;
fseek(file, ftell(file)-tam+1,0);
fread (cadena3, 1, tam, file);
cadena3[tam]='\0';
}
while ((encontrado==0) && (!feof(file)));
if (encontrado==0)
desp=-1;
else
desp=ftell(file);
fclose(file);
return (desp);
}
/////////////////////////////////
void imprimir_texto (char  mensajeesp[100], char  mensajeeng[100], char mensajeale[100], unsigned int idioma, WebType web=vivegranada)
{
// iniciopagina("Error", "", "", 1, web);
 switch(idioma)
 {
 case 1:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeesp);
 break;
 case 6:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeeng);
 break;
 case 7:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeale);
 break;
 }
}
/////////////////////////////////
void print (char  mensajeesp[100], char  mensajeeng[100], char mensajeale[100], unsigned int idioma, WebType web=vivegranada)
{
// iniciopagina("Error", "", "", 1, web);
 switch(idioma)
 {
 case 1:
 printf(mensajeesp);
 break;
 case 6:
 printf(mensajeeng);
 break;
 case 7:
 printf(mensajeale);
 break;
 }
}
/////////////////////////////////
void imprimir_error (char  mensajeesp[100], char  mensajeeng[100], char mensajeale[100], unsigned int idioma, WebType web=vivegranada)
{
// iniciopagina("Error", "", "", 1, web);
 switch(idioma)
 {
 case 1:
 printf("<p> <center> <Font color=navy> ERROR: %s </center></font>\n", mensajeesp);
 break;
 case 6:
 printf("<p> <center> <Font color=navy> ERROR: %s </center></font>\n", mensajeeng);
 break;
 case 7:
 printf("<p> <center> <Font color=navy> ERROR: %s </center></font>\n", mensajeale);
 break;
 }
}
/////////////////////////////////
void imprimir_error2 (char  mensajeesp[100], char  mensajeeng[100], char mensajeale[100], unsigned int idioma, WebType web=vivegranada)
{
 iniciopagina("Error", "", "", 1, web);
 switch(idioma)
 {
 case 1:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeesp);
 break;
 case 6:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeeng);
 break;
 case 7:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeale);
 break;
 }
}
/////////////////////////////////
void imprimir2 (char  mensajeesp[200], char  mensajeeng[200], char mensajeale[200], unsigned int idioma)
{
 switch(idioma)
 {
 case 1:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeesp);
 break;
 case 6:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeeng);
 break;
 case 7:
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensajeale);
 break;
 }
}
//////////
/*
///////////////
void copiarfichero (FILE* forigen, FILE* fdestino, unsigned int inicio, unsigned int tam)
{
char a;
fseek(forigen, inicio,0);
for (int i=0; i<tam;i++)
{
fread (&a, 1, 1, forigen);
fwrite (&a, 1, 1, fdestino);
}
}
*/
///////////////
void copiarfichero (FILE* forigen, FILE* fdestino, unsigned int inicio, unsigned int tam)
{
char a;
fseek(forigen, inicio,0);
fseek(fdestino, 0 ,0);

//cout <<"tam:" << tam;
//cout <<"TRANSC:";
if (tam<100000000)
for (int i=0; i<tam;i++)
{
fread (&a, 1, 1, forigen);
fwrite (&a, 1, 1, fdestino);
//cout <<a;
}
else
{
printf ("error en tamfich");
exit(0);
}
}
///////////////
long int obtenertamfichtexto (char* nomfich)
{
FILE* fichero;
char a;
int tam=0;
if  ((fichero=fopen(nomfich, "r"))==NULL) 
return -1;

fread (&a, 1, 1, fichero);

while (!feof(fichero))
{
fread (&a, 1, 1, fichero);
tam++;
}
fclose (fichero);
return tam;
}
///////////////
char* obtenertexto (char* nomfich)
{
FILE* fichero;
long int i=1, tam=obtenertamfichtexto(nomfich);
char *buffer;
buffer=new char [tam];

if  ((fichero=fopen(nomfich, "r"))==NULL) 
exit (0);

fread (&buffer[0], 1, 1, fichero);

while (!feof(fichero))
{
fread (&buffer[i], 1, 1, fichero);
i++;
};
buffer[strlen(buffer)-2]='\0';
fclose (fichero);
return buffer;
}
////////////////////////////
///////////////
unsigned short int almacenarbuffer (char* nombre, char* query_string)
{
nombre=new char[strlen(query_string)];
strcpy(nombre, query_string);
return (0);
}
//////////////////////
char* obtener_limite()
{

char *content_type, *content_type2, *limite;
int rc;
limite=(char*) malloc(100);
limite[0]='\0';
content_type=(char*) malloc(1000);
content_type2=(char*) malloc(1000);
content_type=getenv("CONTENT_TYPE");
// comprobar validez consulta
strncpy(content_type2, content_type, 19);
if (strcmp(content_type2,"multipart/form-data")==0) 
{
 sprintf(limite, "%s", strstr(content_type, "boundary="));
 limite=limite+9;
}
return(limite);
}

////////////////////////////

/////////////////////////////
void cargarestilosvg()
{
printf ("<style type=\"text/css\">\n");
printf("  BODY\n");
printf("  { \n");
//printf("    background-color : rgb(100\%,100\%,100\%);\n");
//printf("    color        : rgb(10\%,10\%,30\%);\n");
//printf("    margin-top   : 10px ;\n");
//printf("    margin-left  : 10px ;\n");
//printf("    margin-right : 10px ;\n");
printf("    font-family  : verdana, sans-serif ;\n");
printf("    font-size    : 9px ;\n");
printf("  }\n");

printf("div.centered \n");
printf ("{\n");
printf ("text-align: center;\n");
printf ("}\n");

printf ("div.centered table \n");
printf ("{\n");
printf ("margin: 0 auto; \n");
printf ("text-align: left;\n");
printf ("}\n");
printf("  table\n");
printf("  {\n");
//printf("    margin  : 10px ;\n");
//printf("    border  (outset or inset) : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    width   : 80\% ;\n");
//printf("    left   : 10\% ;\n");
//printf("    margin-left  : auto ;\n");
//printf("    margin-right  : auto ;\n");
printf("    border: outset  3px ;\n");
//printf("    border-width   : 10pt ;\n");
printf("    font-family  : verdana, sans-serif ;\n");
printf("    font-size    : 9px ;\n");
//printf ("     text-align : left;\n"); 
//printf("    border-spacing  : 10pt 10pt ;\n"); //      /** CSS 2.0 --> equivale a atributo 'cellspacing' de html **/\n");
printf("    border-collapse : separate ; // /** CSS 2.0 --> permite bordes distintos en cada celda    **/\n");
printf("    border-color   : #8db8b4 ;\n");
printf("    background-color   : #8db8b4 ;\n");
printf("    color   : navy ;\n");
printf("  }\n");

printf("  table th\n");
printf("  {\n");
printf("    text-align   : center ;\n");
printf("    background-color   : #8db8b4;\n");
printf("    font-size      : 9px ;\n");

printf("  }\n");


printf("  table td\n");
printf("  {\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    border-spacing : 0px ;\n");
printf("    font-size      : 9px ;\n");
//printf("    align      : center ;\n");
printf("  }\n");

printf("  table table\n");
printf("  {\n");
//printf("    border-spacing     : 0px ;\n"); //  /** distancia entre bordes de celdas **/\n");
printf("    background-color   : #929cfe;\n");
//printf("    border-width       : 2px ;\n");
//printf("    border-style       : solid ;\n");
//printf("    border-color       : #929cfe;\n");
printf("  }\n");


printf (".campo\n");
printf ("{\n");
printf ("font-size:10px;margin:0px;color:#333333;font-family: verdana,sans-serif;");
printf ("background-color:#ffffff;align: right}\n");


printf("  table table.oscuro tr\n");
printf("  {\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    border-spacing : 0px ;\n");
//printf("    font-size      : 9pt ;\n");
printf("    background-color    : #c5d1fe;\n");
printf("  }\n");

printf("  table td table th\n");
printf("  {\n");
//printf("    background-color    : rgb(80\%,80\%,80\%) ;\n");
//printf("    border-color        : rgb(0\%,0\%,30\%);\n");
//printf("    margin-width        : 0px ;\n");
//printf("    padding             : 2px 8px 2px 8px ;\n");
//printf("    border-width        : 0px 0px 1px 0px ;\n");
//printf("    border-style        : solid ;\n");
//printf("    font-weight         : bold ;\n");
//printf("    text-align          : center ;\n");
//printf("    vertical-align      : top ;\n");
printf("  }\n");

//printf("  table td table td \n");
//printf("  {\n");
//printf("    margin-width       : 0px ;\n");
//printf("    padding            : 8px 8px 0px 8px ;\n");
//printf("    border-style       : solid ;\n");
//printf("    vertical-align     : top ;\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//(printf("    border-spacing : 0px ;\n");
printf("    font-size      : 9px ;\n");
//printf("    align      : left ;\n");
//printf("  }\n");


printf("  DIV.foot\n");
printf("  {\n");
printf("    font-size   : 9px ;\n");
printf("  }\n");

//printf("  A,\n");
//printf("  A:visited,\n");
//printf("  A:active\n");
//printf("  {\n");
//printf("     text-decoration : none ;\n");
//printf("     color : rgb(0\%,0\%,60\%) ;\n");
//printf("  }\n");


printf("  .centro\n");
printf("  {\n");
printf("    align : center ;\n");
printf("  }\n");


cout <<".formularios {\n";
cout <<"	font-family: Verdana, Arial, Helvetica, sans-serif;\n";
cout <<"	font-size: 11px;\n";
cout <<"	font-style: normal;\n";
cout <<"	line-height: normal;\n";
cout <<"	font-weight: bold;\n";
cout <<"	color: #666666;\n";
cout <<"}\n";

cout <<" .smallcentro {\n";
cout <<" 	font-family: Verdana, Arial, Helvetica, sans-serif;\n";
cout <<" 	font-size: 10px;\n";
cout <<" 	font-weight: normal;\n";
cout <<" 	text-align: center;\n";
//cout <<" 	align: center;\n";
cout <<" 	color: navy;\n";
cout <<" }\n";


cout <<" .subgris {\n";
cout <<" 	font-family: Verdana, Arial, Helvetica, sans-serif;\n";
cout <<" 	font-size: 10px;\n";
cout <<" 	font-weight: normal;\n";
cout <<" 	text-align: center;\n";
//cout <<" 	align: center;\n";
cout <<" 	color: navy;\n";
cout <<" }\n";
printf(" </style>\n");
}
///////////////////
/////////////////////////////
void cargarestilosviverent()
{
printf ("<style type=\"text/css\">\n");
printf("  BODY\n");
printf("  { \n");
//printf("    background-color : rgb(100\%,100\%,100\%);\n");
//printf("    color        : rgb(10\%,10\%,30\%);\n");
//printf("    margin-top   : 10px ;\n");
//printf("    margin-left  : 10px ;\n");
//printf("    margin-right : 10px ;\n");
printf("    font-family  : verdana, sans-serif ;\n");
printf("    font-size    : 9px ;\n");
printf("  }\n");

printf("div.centered \n");
printf ("{\n");
printf ("text-align: center;\n");
printf ("}\n");

printf ("div.centered table \n");
printf ("{\n");
printf ("margin: 0 auto; \n");
printf ("text-align: left;\n");
printf ("}\n");
printf("  table\n");
printf("  {\n");
//printf("    margin  : 10px ;\n");
//printf("    border  (outset or inset) : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    width   : 80\% ;\n");
//printf("    left   : 10\% ;\n");
//printf("    margin-left  : auto ;\n");
//printf("    margin-right  : auto ;\n");
printf("    border: outset  3px ;\n");
//printf("    border-width   : 10pt ;\n");
printf("    font-family  : verdana, sans-serif ;\n");
printf("    font-size    : 9px ;\n");
//printf ("     text-align : left;\n"); 
//printf("    border-spacing  : 10pt 10pt ;\n"); //      /** CSS 2.0 --> equivale a atributo 'cellspacing' de html **/\n");
printf("    border-collapse : separate ; // /** CSS 2.0 --> permite bordes distintos en cada celda    **/\n");
printf("    border-color   : #8db8b4 ;\n");
printf("    background-color   : #8db8b4 ;\n");
printf("    color   : navy ;\n");
printf("  }\n");

printf("  table th\n");
printf("  {\n");
printf("    text-align   : center ;\n");
printf("    background-color   : #8db8b4;\n");
printf("    font-size      : 9px ;\n");

printf("  }\n");


printf("  table td\n");
printf("  {\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    border-spacing : 0px ;\n");
printf("    font-size      : 9px ;\n");
//printf("    align      : center ;\n");
printf("  }\n");

printf("  table table\n");
printf("  {\n");
//printf("    border-spacing     : 0px ;\n"); //  /** distancia entre bordes de celdas **/\n");
printf("    background-color   : #929cfe;\n");
//printf("    border-width       : 2px ;\n");
//printf("    border-style       : solid ;\n");
//printf("    border-color       : #929cfe;\n");
printf("  }\n");


printf (".campo\n");
printf ("{\n");
printf ("font-size:10px;margin:0px;color:#333333;font-family: verdana,sans-serif;");
printf ("background-color:#ffffff;align: right}\n");


printf("  table table.oscuro tr\n");
printf("  {\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//printf("    border-spacing : 0px ;\n");
//printf("    font-size      : 9pt ;\n");
printf("    background-color    : #c5d1fe;\n");
printf("  }\n");

printf("  table td table th\n");
printf("  {\n");
//printf("    background-color    : rgb(80\%,80\%,80\%) ;\n");
//printf("    border-color        : rgb(0\%,0\%,30\%);\n");
//printf("    margin-width        : 0px ;\n");
//printf("    padding             : 2px 8px 2px 8px ;\n");
//printf("    border-width        : 0px 0px 1px 0px ;\n");
//printf("    border-style        : solid ;\n");
//printf("    font-weight         : bold ;\n");
//printf("    text-align          : center ;\n");
//printf("    vertical-align      : top ;\n");
printf("  }\n");

//printf("  table td table td \n");
//printf("  {\n");
//printf("    margin-width       : 0px ;\n");
//printf("    padding            : 8px 8px 0px 8px ;\n");
//printf("    border-style       : solid ;\n");
//printf("    vertical-align     : top ;\n");
//printf("    margin  : 5px ;\n");
//printf("    border  : 0px ;\n");
//printf("    padding : 0px ;\n");
//(printf("    border-spacing : 0px ;\n");
printf("    font-size      : 9px ;\n");
//printf("    align      : left ;\n");
//printf("  }\n");


printf("  DIV.foot\n");
printf("  {\n");
printf("    font-size   : 9px ;\n");
printf("  }\n");

//printf("  A,\n");
//printf("  A:visited,\n");
//printf("  A:active\n");
//printf("  {\n");
//printf("     text-decoration : none ;\n");
//printf("     color : rgb(0\%,0\%,60\%) ;\n");
//printf("  }\n");


printf("  .centro\n");
printf("  {\n");
printf("    align : center ;\n");
printf("  }\n");

printf(" </style>\n");
}
/////////////////////777
const unsigned short int FormOcupacion=0;
const unsigned short int Ocupacion=1;
const unsigned short int Todos=2;
const unsigned short int Casa=3;




/////////////
void volver (unsigned int idioma)
{
switch(idioma)
{
case 1:
printf("<p><center><font color=\"navy\">");
printf ("<a href=\"javascript:history.back()\">Volver</a></font></center></p>\n");
break;
case 6:
printf("<p><center><font color=\"navy\">");
printf ("<a href=\"javascript:history.back()\">Back</a> ");
printf ("</font></center></p>\n");
break;
default:
printf("<p><center><font color=\"navy\">");
printf ("<a href=\"javascript:history.back()\">Back</a> ");
printf ("</font></center></p>\n");
break;
}
}

//////
void cargarjs (WebType web=vivegranada)
{
if (web==vivegranada)
{
printf("\n <script languaje=\"javascript\">\n");
printf ("\nfunction openPop(url,x,y)\n");
printf ("\n        {\n");
printf ("\n                  window.open(url, \"info\", width=\"+x+\",height=\"+y+\",");
printf (" location=no,toolbar=no,directories=no,menubar=no,resizable=yes, scrollbars=yes);\n");
printf ("\n                        }\n");
printf("\n   </script>\n");
};
if (web==vivespain)
{
cout <<"\n	<script language=\"JavaScript\" type=\"text/JavaScript\">;";

/*
cout <<"\n function mmLoadMenus() {";
cout <<"\n  if (window.mm_menu_0217003322_0) return;";
cout <<"\n  window.mm_menu_0217003322_0 = new Menu(\"root\",196,18,\"Verdana, Arial, Helvetica, sans-serif\",12,\"#FF9900\",\"#666666\",\"#FFFFFF\",\"#FFFFFF\",\"center\",\"middle\",3,0,1000,-5,7,true,true,false,0,true,true);";
cout <<"\n  mm_menu_0217003322_0.addMenuItem(\"Search�Box\",\"location='adv_search.cgi'\");";
cout <<"\n    mm_menu_0217003322_0.addMenuItem(\"Apartments�Directory\",\"location='apart_directory.html'\")";
cout <<"\n    mm_menu_0217003322_0.addMenuItem(\"Recommended�Apartments\",\"location='recommended.html'\");";
cout <<"\n    mm_menu_0217003322_0.addMenuItem(\"List�All�Apartments\");";
cout <<"\n     mm_menu_0217003322_0.fontWeight=\"bold\";";
cout <<"\n     mm_menu_0217003322_0.hideOnMouseOut=true;";
cout <<"\n     mm_menu_0217003322_0.bgColor='#555555';";
cout <<"\n     mm_menu_0217003322_0.menuBorder=1;";
cout <<"\n     mm_menu_0217003322_0.menuLiteBgColor='#FFFFFF';";
cout <<"\n     mm_menu_0217003322_0.menuBorderBgColor='#777777';";
cout <<"\n  window.mm_menu_0217003917_0 = new Menu(\"root\",186,18,\"Verdana, Arial, Helvetica, sans-serif\",12,\"#FF9900\",\"#666666\",\"#FFFFFF\",\"#FFFFFF\",\"center\",\"middle\",3,0,1000,-5,7,true,true,false,0,true,true);";
cout <<"\n    mm_menu_0217003917_0.addMenuItem(\"Show&nbsp;my&nbsp;Selection\");";
cout <<"\n    mm_menu_0217003917_0.addMenuItem(\"Clear&nbsp;my&nbsp;Selection\");";
cout <<"\n    mm_menu_0217003917_0.addMenuItem(\"Save&nbsp;my&nbsp;Selection&nbsp;for&nbsp;later\");";
cout <<"\n     mm_menu_0217003917_0.fontWeight=\"bold\";";
cout <<"\n     mm_menu_0217003917_0.hideOnMouseOut=true;";
cout <<"\n     mm_menu_0217003917_0.bgColor='#555555';";
cout <<"\n     mm_menu_0217003917_0.menuBorder=1;";
cout <<"\n     mm_menu_0217003917_0.menuLiteBgColor='#FFFFFF';";
cout <<"\n     mm_menu_0217003917_0.menuBorderBgColor='#777777';";

cout <<"\n      window.mm_menu_0217004004_0 = new Menu(\"root\",169,18,\"Verdana, Arial, Helvetica, sans-serif\",12,\"#FF9900\",\"#666666\",\"#FFFFFF\",\"#FFFFFF\",\"center\",\"middle\",3,0,1000,-5,7,true,true,false,0,true,true);";
cout <<"\n    mm_menu_0217004004_0.addMenuItem(\"Our&nbsp;Additional&nbsp;Services\",\"location='adi_services.html'\");";
cout <<"\n    mm_menu_0217004004_0.addMenuItem(\"Our&nbsp;Advice\");";
cout <<"\n     mm_menu_0217004004_0.fontWeight=\"bold\";";
cout <<"\n     mm_menu_0217004004_0.hideOnMouseOut=true;";
cout <<"\n     mm_menu_0217004004_0.bgColor='#555555';";
cout <<"\n     mm_menu_0217004004_0.menuBorder=1;";
cout <<"\n   mm_menu_0217004004_0.menuLiteBgColor='#FFFFFF';";
cout <<"\n     mm_menu_0217004004_0.menuBorderBgColor='#777777';";
cout <<"\n      window.mm_menu_0217004038_0 = new Menu(\"root\",230,18,\"Verdana, Arial, Helvetica, sans-serif\",12,\"#FF9900\",\"#666666\",\"#FFFFFF\",\"#FFFFFF\",\"center\",\"middle\",3,0,1000,-5,7,true,true,false,0,true,true);";
cout <<"\n    mm_menu_0217004038_0.addMenuItem(\"Granada:&nbsp;Recommended&nbsp;Program\",\"location='program.html'\");";
cout <<"\n    mm_menu_0217004038_0.addMenuItem(\"Granada:&nbsp;All&nbsp;Interesting&nbsp;Places\");";
cout <<"\n   mm_menu_0217004038_0.addMenuItem(\"Others&nbsp;Destinations\");";
cout <<"\n    mm_menu_0217004038_0.fontWeight=\"bold\";";
cout <<"\n    mm_menu_0217004038_0.hideOnMouseOut=true;";
cout <<"\n    mm_menu_0217004038_0.bgColor='#555555';";
cout <<"\n    mm_menu_0217004038_0.menuBorder=1;";
cout <<"\n    mm_menu_0217004038_0.menuLiteBgColor='#FFFFFF';";
cout <<"\n    mm_menu_0217004038_0.menuBorderBgColor='#777777';";
cout <<"\n window.mm_menu_0217004115_0 = new Menu(\"root\",118,18,\"Verdana, Arial, Helvetica, sans-serif\",12,\"#FF9900\",\"#666666\",\"#FFFFFF\",\"#FFFFFF\",\"center\",\"middle\",3,0,1000,-5,7,true,true,false,0,true,true);";
cout <<"\n   mm_menu_0217004115_0.addMenuItem(\"Our&nbsp;Mission\",\"location='our_mission.html'\");";
cout <<"\n   mm_menu_0217004115_0.addMenuItem(\"Contact&nbsp;Us\",\"location='contac.html'\");";
cout <<"\n   mm_menu_0217004115_0.addMenuItem(\"Job&nbsp;and&nbsp;Career\");";
cout <<"\n   mm_menu_0217004115_0.addMenuItem(\"FAQ\");";
cout <<"\n    mm_menu_0217004115_0.fontWeight=\"bold\";";
cout <<"\n    mm_menu_0217004115_0.hideOnMouseOut=true;",
cout <<"\n    mm_menu_0217004115_0.bgColor='#555555';";
cout <<"\n    mm_menu_0217004115_0.menuBorder=1;";
cout <<"\n    mm_menu_0217004115_0.menuLiteBgColor='#FFFFFF';";
cout <<"\n    mm_menu_0217004115_0.menuBorderBgColor='#777777';";
cout <<"\n mm_menu_0217004115_0.writeMenus();";
cout <<"\n}"; // mmLoadMenus()
*/
//cout <<"</script>";
//cout <<"<script language=\"JavaScript\" src=\"mm_menu.js\"></script>";

cout << "\nfunction MM_swapImgRestore() {";
cout <<"\nvar i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;";
cout <<"\n}";

cout <<"\n function MM_findObj(n, d) {";
cout <<"\n   var p,i,x;  if(!d) d=document; if((p=n.indexOf(\"?\"))>0&&parent.frames.length) {";
cout <<"     d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}";
cout <<"\n   if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];";
cout <<"\n   for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);";
cout <<"\n   if(!x && d.getElementById) x=d.getElementById(n); return x;";
cout <<"\n }";

cout <<"\n function MM_swapImage() {";
cout <<"\n   var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)";
cout <<"\n    if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}";
cout <<"\n }";
cout <<"\n </script>";
}
}
/////////////////////////////
void cargarvarios(WebType web=vivespain, unsigned short int idioma=6)
{
if (web==vivespain)
{
//if (codepage==0)
if (idioma==1)
printf("\n<meta name=\"Keywords\" content=\"alojamientos, apartamentos, rurales, casas, Granada, Spain, Barcelona, Madrid, Valencia, Andalucia, Albaicin, Albayzin, capital, golf, ciudad, cuevas, Alhambra, disponibilidad, reservas\">\n");
else
printf("\n<meta name=\"Keywords\" content=\"lodging, traditional, stay, cave, self-catering, accomodations, acomodations, vacation, rentals, rent, houses, capital, Granada, city, Spain, apartment, golf, Alhambra, Andalusian, Andalucian, interbook, vacancy, vacancies, database, booking, online, available, availability online, central, reservations\">\n");
printf("\n<meta name=\"robots\" CONTENT=\"all\">\n");
if (idioma==1)
printf("\n<meta name=\"description\" content= \"Casas, apartamentos, hoteles con encanto y otros alojamientos en Espa&ntilde;a \">\n");     
else
printf("\n<meta name=\"description\" content= \"Vacation apartments, rural houses, hotels and other lodgings  in Spain\">");
cout <<" \n<STYLE TYPE=\"text/css\">";
cout <<"  \n  .barra {";
cout <<"  \n         scrollbar-3dlight-color:;";
cout <<"   \n        scrollbar-arrow-color:#FF6633;";
cout <<"   \n        scrollbar-base-color:#FF6633;";
cout <<"   \n        scrollbar-darkshadow-color:#FF6633;";
cout <<"   \n        scrollbar-face-color:#FFFFFF;";
cout <<"   \n        scrollbar-highlight-color:#FFFFFF;";
cout <<"    \n       scrollbar-shadow-color:#FFFFFF;";
cout <<"    \n      }";
cout <<" \n </STYLE>";
cout << "\n<link href=\"../../vivespain/css/normal.css\" rel=\"stylesheet\" type=\"text/css\">";

cargarjs(vivespain);
}
}
/////////////////////////////
void cargarestilos(WebType web=vivegranada, unsigned short int idioma=1)
{
	switch (web)
	{
	case vivegranada: cargarestilosvg(); break;
	case vivespain: cargarvarios(web, idioma);break;
	case infovive: cargarestilosvg(); break;
	case viverent: cargarestilosviverent(); break;
	}
}
/////////////////////////
void iconohome (unsigned int codigo_agencia, unsigned int idioma)
{
switch (codigo_agencia)
{
case 0:
if (idioma==1)
{
printf("<center><a href=\"/index-esp.html\" name=\"home\" target=\"_top\"");
printf ("onmousedown=\"document.miVolver.src='/inicio2.gif'\"\n");
printf("onmouseout=\"document.miVolver.src='/inicio.gif'\"");
printf ("          onmouseover=\"document.miVolver.src='/inicio2.gif'\"");
printf ("               onmouseup=\"document.miVolver.src='/inicio2.gif'\"\n");
printf(" target=_self>");
printf("<IMG alt=\"\" border=0 hspace=1 name=miVolver src=\"/inicio.gif\"></a></center> \n");
}
else
{
printf("<center><a href=\"/index.html\" name=\"home\" target=\"_top\"");
printf ("onmousedown=\"document.miVolver.src='/inicio2-eng.gif'\"\n");
printf("onmouseout=\"document.miVolver.src='/inicio-eng.gif'\"");
printf ("          onmouseover=\"document.miVolver.src='/inicio2-eng.gif'\"");
printf ("               onmouseup=\"document.miVolver.src='/inicio2-eng.gif'\"\n");
printf(" target=_self>");
printf("<IMG alt=\"\" border=0 hspace=1 name=miVolver src=\"/inicio-eng.gif\"></a></center> \n");
}
break;
/*: // pagina inicio infovive
//switch (idioma)
{
case 1:
printf("<center><a href=\"http://www.infovive.com/index-esp.html\" name=\"volver\"");
break;

default:
printf("<center><a href=\"http://www.infovive.com\" name=\"volver\"");
break;
}
*/
}
}
//////////////////
int obtener_longitud_cadena_entrada (void)
{
char *content_length;
int entero_content_length;
content_length=(char*) malloc(7);
content_length=getenv("CONTENT_LENGTH");
if (content_length==NULL)
{
;// imprimir_error("","Content_length is undefined\0", "",6);
return(0);
}
else
entero_content_length=atoi(content_length);
return (entero_content_length);
}

//////////////////////
unsigned int detectar_error_entradas(char *query_string, int entero_content_length)
{

char *content_type, *content_type2;
int rc;
content_type=(char*) malloc(100);
content_type2=(char*) malloc(100);
content_type=getenv("CONTENT_TYPE");
// comprobar validez consulta
strncpy(content_type2, content_type, 19);

//printf("cont:%s",content_type);
//printf("cont2:%s",content_type2);
if((strcmp(content_type,"application/x-www-form-urlencoded")) &&
(strcmp(content_type2,"multipart/form-data"))) 
{
 imprimir_error("", "I don't understand the content-type\n", "",6);
 return(1);
}
else if (entero_content_length==0)
{

 imprimir_error ( "", "Content_length is zero\n","", 6);
 return(1);
}
//if ((rc=fread(query_string, 1765, 1, stdin)) != 1)
if ((rc=fread(query_string, entero_content_length, 1, stdin)) != 1)
{
 imprimir_error ("", "Cannot read the input stream. Contact the webmaster\n", "",6);
 return(1);
}
else
{
query_string[entero_content_length]='\0';
return(0);
}
}
///////////////
unsigned short int almacenarcadena (char* nombre, char* query_string, int longitud)
{
FILE *ftemp;
int tam=0, error=0;
//printf ("long:%d", longitud);
if ((ftemp=fopen(nombre,"wb"))!=NULL)
{
do
{
fprintf(ftemp, "%c", *(query_string+tam));
tam=tam+1;
if (tam<1) printf ("error, tam:%d", tam);
}
while (tam<longitud);
fclose (ftemp);
}
else error=1;
return (error);
}
//////////
char* ObtenerCaminoDatos()
{
return (cdatos);
}
//////////
char* ObtenerCaminoSistema()
{
return (csistema);
}
//////////
char* ObtenerCaminoCookies()
{
return (ccookies);
}

//////////
char* ObtenerNombreCompleto(char* nombrecorto, unsigned short int tipo)
{
if (tipo==sistema)
strcpy(nomfich,ObtenerCaminoSistema());
else
strcpy(nomfich, ObtenerCaminoDatos());
strcat(nomfich, nombrecorto);
return(nomfich);
}
////////////////////
void QuitarMarcos(char* nombrepag)
{
printf(" <script languaje=\"javascript\">\n");
printf ("onLoad=\"if(parent.frames.length!=0) top.location='%s';\"", nombrepag);
printf("</script>");
}
//////////////////
void iniciopagina (char *tituloesp, char *tituloeng, char *tituloale, unsigned short int idioma, WebType web=vivegranada, unsigned short int code=0)
{
//web: 0, vivegranada
// web: 1: infovive
// web: 2: vivespain
// web 3: inforent
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloale);
break;
default:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
cout <<"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">";

if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);

printf("</head><BODY ");
if (web==vivegranada) printf (" background=\"/fondo15.jpg\">\n");
if (web==infovive) printf (" bgcolor=\"#009966\">\n");
if (web==vivespain) cout <<" class=\"barra\" bgcolor=\"#FFFFFF\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" 
marginheight=\"0\" >";
//onLoad=\"MM_preloadImages('Imagenes/mail_2.gif','Imagenes/how_2.gif','Imagenes/reg_2.gif','Imagenes/site_2.gif','Imagenes/link_2.gif','Imagenes/menu_2_01.gif','Imagenes/menu_2_02.gif','Imagenes/menu_2_03.gif','Imagenes/menu_2_04.gif','Imagenes/menu_2_05.gif')\">";

}

//////////////////
void iniciopaginase (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloale);
break;
default:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
//printf(" <script languaje=\"javascript\">\n");
//rintf("          function preload(imgObj,imgSrc) {\n");
//printf("   eval(imgObj+' = new Image()')\n");
//printf("           eval(imgObj+'.src = \"'+imgSrc+'\"')\n");
//printf("   }
//   preload('fondo15','fondo15.jpg')\n");
//printf("   </script>\n");
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);
printf("</head><BODY ");
if (web==vivegranada) printf (" background=\"/fondo15.jpg\">\n");
if (web==infovive) printf ("bgcolor=\"#009966\" >\n");

}

///////////////
void iniciopaginai (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloale);
break;
default:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);
printf("</head><BODY><style type=\"text/css\">BODY{background-image: url  (https://eurus.safe-order.net/vivegranada/fondo5.jpg); background repeat: repeat-y; background-attachment: fixed}</style>\n");
//printf("</HEAD><BODY background=\"/fondo5.jpg\">\n");
}
///////////////
/////////////
void iniciopaginasegura (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
defaut:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);
printf("</head>");
printf("<BODY ");
if (web==vivegranada) printf (" background=\"/fondo15.jpg\">\n");
if (web==infovive) printf ("bgcolor=\"#009966\" >\n");
if (web==vivespain) printf (">");

//printf("</HEAD><BODY>\n");
}
/////////////
void iniciopaginais (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
defaut:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);

printf ("</head>");
printf("<body bgcolor=\"#006699\" text=\"#FFFFFF\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FFFFFF\">");


//printf("</HEAD><BODY>\n");
}
/////////////
void iniciopaginasegurai (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
defaut:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);
printf("</head><BODY><style type=\"text/css\">BODY{background-image: url  (https://eurus.safe-order.net/vivegranada/fondo5.jpg); background repeat: repeat-y; background-attachment: fixed}</style>\n");
//printf("</HEAD><BODY>\n");
}
/////////////
void iniciopaginasegurablanca (char *tituloesp, char *tituloeng, char *tituloale, unsigned int idioma, WebType web=vivegranada)
{
switch (idioma)
{
case 1:
printf("<HTML><HEAD><title>%s</title>\n", tituloesp);
break;
case 6:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
case 7:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
defaut:
printf("<HTML><HEAD><title>%s</title>\n", tituloeng);
break;
}
if (web!=vivespain)
{
cargarjs(web);
cargarestilos(web);
}
else
cargarvarios(web, idioma);
printf("</head>");
printf("<BODY>\n");
}
////////////////
void finpagina (WebType web)
{
if (web==(WebType)vivespain)
printf("<table><tr valign=\"bottom\"><td><img src=\"/vivespain/Imagenes/index_cabe.gif\" width=\"1024\" height=\"56\"></td></Tr></table>");
printf("</BODY></HTML>");
}
////////////////
void finpagina ()
{
printf("</BODY></HTML>");
}
////////////////
void finpagina (unsigned int cod_agencia, unsigned int idioma=6)
{
if (cod_agencia==0) iconohome(cod_agencia, idioma);
printf("</BODY></HTML>");
}


void decisionbooleana (unsigned int valor, unsigned int idioma)
{
printf("<SELECT NAME=\"decision\">  \n");
printf("<OPTION VALUE=\"0\"");
if (valor==0)
printf(" selected");
printf (">No</OPTION>");
printf("<OPTION VALUE=\"1\"");
if (valor==1)
printf(" selected");
printf (">");
switch (idioma)
{
case 1: printf("S&iacute;"); break;
case 6: printf("Yes"); break;
default: printf("Yes"); break; 
}
printf (" </OPTION>");
printf ("</SELECT></P></td>\n");
}

////////////////////////
/////////////////////////////
long int obtener_tamfich(FILE *fichero)
{
 long int posicion, taman;
 posicion=ftell(fichero);
 fseek(fichero, 0L, 2); //2: ir al final del fichero
 taman=ftell(fichero);
 fseek(fichero, posicion, 0); //0: ir al principio
 return(taman);
}
/*_________________________________________________*/

int CreateTextFile(char* nomfich)
{
FILE *fichero;

if  ((fichero=fopen(nomfich, "w"))==NULL) 
return -1;
else return 0;
}
/*____________________________________________________*/

int AddLine (char* nomfich, char* line)
{
FILE *fichero;
char line2[256];
bool found=false;

if  ((fichero=fopen(nomfich, "r+"))==NULL) 
return -1;

fgets(line2, 256, fichero);
while (!feof(fichero))
{
if (strncmp(line, line2, strlen(line))==0)
 found=true;
fgets(line2, 256, fichero);
}
if (!found) 
{
fprintf (fichero, line);
fprintf(fichero, "\n");
}

return 0;
}
/*____________________________________________________*/

int RemoveLine (char* nomfich, char* line)
{
FILE *fichero, *fichero2;
char line2[256], nomfich2[128];
bool found=false;
sprintf(nomfich2, "%s-new", nomfich);

if  ((fichero=fopen(nomfich, "r"))==NULL) 
return -1;
if  ((fichero2=fopen(nomfich2, "w"))==NULL) 
return -1;

fgets(line2, 256, fichero);
while (!feof(fichero))
{
if (strncmp(line, line2, strlen(line))!=0)
fprintf (fichero2, line2);

fgets(line2, 256, fichero);
}
fclose(fichero);
fclose(fichero2);
unlink(nomfich);
rename(nomfich2, nomfich);
return 0;
}
/*____________________________________________________*/

bool FindCookie (char* nomfich, char* line)
{
FILE *fichero;
char line2[256];
bool found=false;

if (!ExistFile(nomfich)) return false;

if  ((fichero=fopen(nomfich, "r"))==NULL) 
return false;

fgets(line2, 256, fichero);
while (!feof(fichero) && !found)
{
if (strncmp(line, line2, strlen(line))==0)
 found=true;
fgets(line2, 256, fichero);
}
return found;
}
/////////////////////////////
long int obtener_tamfich(char* nomfich)
{
 FILE *fichero;

if  ((fichero=fopen(nomfich, "rb"))==NULL) 
return -1;




 long int posicion, taman;
 posicion=ftell(fichero);
 fseek(fichero, 0L, 2); //2: ir al final del fichero
 taman=ftell(fichero);
 fseek(fichero, posicion, 0); //0: ir al principio
 fclose (fichero);
 return(taman);
}

///////////////////////
void ErrorFatal()
{
imprimir_error("System error","", "",1);
finpagina();
enviarcorreoerror(1,0,"error falta");
actualizar_modos("0\0","0\0","0\0");
exit(0);
}
/////////
template <class T> T sum (T* array, unsigned int length)
{
T total=0;
for (int i=0; i<length;i++)
 total=total+array[i];
return total;
}    
/////////
template <class T> void change (T & val1, T & val2)
{
T s;
s=val1;
val1=val2;
val2=s;
}       
/////////
/*---------------------------------------------------------------*/

template <class T>
T * Initialize(int size, T val)
{
T * x;
try
{
if ((x = new T [size])==NULL) //
 throw NoMemory();
}
catch (NoMemory NM) {
        NM.PrintMessage();  }

InitializeList(x, size, val);
return (x);
}
/*---------------------------------------------------------------*/

template <class T>
void InitializeList(T* list, int size, T val)
{
for (int i=0;i<size;i++)
 list[i]=val;
}

/*---------------------------------------------------------------*/

template <class T> bool IsOne (T value)
{
double val=(double) value;
if ((val>=(1.0-zero)) && (val<=(1.0+zero)))
return true;
else return false;
}                                                   
///////
bool ExistFile (char* namefile)
{
struct stat fs;
if (stat(namefile, &fs)==0) return (true); else return (false);
}
/*---------------------------------------------------------------*/
bool IsAZero(unsigned int column, unsigned int pos) 
{
// this function returns 0 if pos has a 0 at column or 1 if it has a 1 at column, considering
// a basis2 table with TotalColumns (i.e., 2^TotalColumns positions)
//cout <<"pos:" << pos <<", column:" << column;
	int min= (pos/(int)pow(2,column+1))*(int)pow(2,column+1);
//	cout <<"min:" << min;
	//(pos%(2^column-1));
	int max= min+(int)pow(2,column);
//	cout <<"max:" << max;
	if ((pos>=min) && (pos<max))
		return true; 
	else return false;
}
/*---------------------------------------------------------------*/

	int comparedouble(const void *arg1, const void *arg2)
	{
         if(*(double *)arg1 < *(double *)arg2) return -1;
   else if(*(double *)arg1 > *(double *)arg2) return 1;
   else return 0;
	}
/*---------------------------------------------------------------*/

	int comparechar(const void *arg1, const void *arg2)
	{
         if(*(char *)arg1 < *(char *)arg2) return -1;
   else if(*(char *)arg1 > *(char *)arg2) return 1;
   else return 0;
	}	
/*---------------------------------------------------------------*/

int compareint (const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}

/*---------------------------------------------------------------*/
unsigned int GetNumberOfColumns (char* filename)
{
ifstream InputFile; 
char * cad, * genotypebuf;

unsigned int maxN=20000;

try
{
if ((genotypebuf=new char[maxN*4])==NULL)
 throw NoMemory();
if ((cad=new char[maxN*4])==NULL)
 throw NoMemory();



 InputFile.open (filename, ifstream::in);

 if (InputFile.peek()==EOF)
  throw EmptyFile();	

 InputFile.getline (genotypebuf, maxN*4, '\n');

 InputFile.close();

}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
	EFile.PrintMessage(filename);}
catch (NoMemory NM) {
        NM.PrintMessage();  }


unsigned int Columns=0;

	cad = strtok (genotypebuf," \t");

	do
	{
     cad = strtok (NULL," \t");
	 Columns++;
	}
	 while (cad!=NULL);

	delete cad, genotypebuf;

return Columns;
}
////////
// Put an assert to check if x is NULL, this is to catch
// program "logic" errors early. Even though delete works
// fine with NULL by using assert you are actually catching
// "bad code" very early

// Defining Zap using templates
// Use zap instead of delete as this will be very clean
template <class T>
inline void zap(T & x)
{
        assert(x != NULL);
        delete x;
        x = NULL;
}
// In C++ the reason there are 2 forms of the delete operator is because
// there is no way for C++ to tell the difference between a pointer to
// an object and a pointer to an array of objects. The delete operator
// relies on the programmer using "[]" to tell the two apart.
// Hence, we need to define zaparr function below.
// To delete array of pointers
template <class T>
inline void zaparr(T & x)
{
        assert(x != NULL);
        delete [] x;
        x = NULL;
}

/*---------------------------------------------------------------*/
int median(int * ip, int  size)
{
	if ((size % 2) != 0)
		return ip[size / 2];
	else
		return (ip[size / 2 - 1] + 
				ip[size / 2]) / 2; // it is not exact, because sometimes we can have an interval and the median is undetermined
	// here we get the floor value
}
/*---------------------------------------------------------------*/
double median(double * ip, int  size)
{
int lower=size;
int upper=0;
double val=ip[size / 2];
for (int i=0;i<size;i++)
{
if ((ip[i]==val) && (lower==size))
 lower=i;
if (ip[i]==val) upper=i;
}
return ip[lower]+(ip[upper]-ip[lower])*(double)(val-lower)/(double)(upper-lower);
}
/*---------------------------------------------------------------*/

double percentile(double * ip, int  size, int perc)
{
int lower=size;
int upper=0;
double val=ip[(int) floor (size * perc/(double)100)];
for (int i=0;i<size;i++)
{
if ((ip[i]==val) && (lower==size))
 lower=i;
if (ip[i]==val) upper=i;
}
if (upper>lower)
return ip[lower]+(ip[upper]-ip[lower])*(double)(val-lower)/(double)(upper-lower);
else return ip[lower];
}

/*---------------------------------------------------------------*/
template <class T> T maxi(T a, T b)//
{//
if (a >= b)//
return (a);//
else return (b);//
}//
/*---------------------------------------------------------------*/
template <class T> T mini(T a, T b)//
{//
if (a <= b)//
return (a);//
else return (b);//
}//
/*---------------------------------------------------------------*/
template <class T> T GetExtreme(T* array, int size, bool IsMax=true)//
{//
return array[GetExtremePos(array, size, IsMax)];
}//
/*---------------------------------------------------------------*/
template <class T> int GetExtremePos(T* array, int size, bool IsMax=true)//
{//
T Extreme=array[0];
int ExtremePos=0;

for (int i=1;i<size;i++)
 if ((array[i]>Extreme && IsMax==true) || (array[i]<Extreme && IsMax==false))
 {
	 Extreme=array[i];
	 ExtremePos=i;
 }
return (ExtremePos);
}//
/*---------------------------------------------------------------*/
template <class T> int GetMax(T* array, int size)//
{
	return GetExtreme(array, size, true);
}
/*---------------------------------------------------------------*/
template <class T> int GetMin(T* array, int size)//
{
	return GetExtreme(array, size, false);
}
/*---------------------------------------------------------------*/
template <class T> int GetMaxPos(T* array, int size)//
{
	return GetExtremePos(array, size, true);
}
/*---------------------------------------------------------------*/
template <class T> int GetMinPos(T* array, int size)//
{
	return GetExtremePos(array, size, false);
}
/*---------------------------------------------------------------*/
void ChangeExtension (char* FileSource, char*FileTarget, char* Extension)
{
         strcpy (FileTarget, FileSource);
		 FileTarget=strtok(FileTarget+2, ".")-2;
         strcat (FileTarget, ".\0");
		 strcat (FileTarget, Extension);
		 strcat (FileTarget, "\0");
}
/*---------------------------------------------------------------*/
bool HasThisExtension (char* FileSource, char* Extension, unsigned short int ExtensionLength)
{
 int pos;
 for (int i=0;i<strlen(FileSource);i++)
	 if (FileSource[i]=='.')
		 pos=i;
char * p=&FileSource[pos+1];
if (strncmp(p, Extension, ExtensionLength)==0) return true; else return false;

}
/*---------------------------------------------------------------*/
void CaptureLine (ifstream * source, char* genotypebuf, int & size)
{/*
	if (size>100)
	while (source->peek()!=EOF) 
	{
source->getline (genotypebuf, size, '\n');
cout << genotypebuf <<"\n";
	}
	else
	*/
source->getline (genotypebuf, size, '\n');


}
/*---------------------------------------------------------------*/
int GetLineLength (char * FileName)
{
ifstream  InputFile;
cout <<"Filename: " << FileName;
try
{
 if (!ExistFile(FileName))
	 throw ErrorFile();
 InputFile.open (FileName, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(FileName);
   }
	char c; 
	int i=0;
	do
	{
	 InputFile.get (c);
	 i++;
	} 
	while (c!='\n' && c!=EOF);

	InputFile.close();
	return i;
}
/*____________________________________________________________ */

void OpenOutput(char* filename, ofstream* OutputFile)
{
  try
{
	  OutputFile->open (filename, ifstream::out);
	 if (!*OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
}

///////////////////////////////
long int redondear (float numero)
{
float resto;

{
resto=fabs(numero)-(int) fabs(numero);
if (fabs(resto)<0.5)
return ((long int) numero);
else 
if (numero<0)
return (-(long int) ceil (fabs(numero)));
else
return ((long int) ceil (numero));
}
}
/////////////////////////////////
void imprimir (char  mensaje[100], char url[],char mensajeurl[])
{
 printf("<p> <center> <Font color=navy> %s </center></font>\n", mensaje);
 printf("<p> <center> <Font color=red><a href=\"");
 printf("%s\">", url);
 printf("%s", mensajeurl);
 printf("</a> </center></font></p>\n");
} 

///////////////////
char* may(char* cadena, unsigned int longitud)
{
unsigned int i;
char *cadenamay;
cadenamay = new char[longitud+1];
for(i=0; i<longitud; i++)
cadenamay[i]=toupper(cadena[i]);
cadenamay[longitud]='\0';
return(cadenamay);
}
///////////////////
char* minusc(char* cadena, unsigned int longitud)
{
unsigned int i;
//char* cadenaminus;
//cadenaminus= new char[longitud+1];
char *cadenaminus;
cadenaminus=new char[longitud+1];
for(i=0; i<longitud; i++)
cadenaminus[i]=tolower(cadena[i]);
cadenaminus[longitud]='\0';
return(cadenaminus);
}
///////////////////////
char nombreidioma[20];

char* ObtenerNombreIdioma (unsigned short int idioma, unsigned short int idiomanombre)
{
switch (idioma)
{
case 1:
switch(idiomanombre)
{
case 1:
strcpy(nombreidioma, "espa&ntilde;ol\0");
break;
case 6:
strcpy (nombreidioma, "Spanish\0");
break;
}
break;
case 6:
switch(idiomanombre)
{
case 1:
strcpy(nombreidioma, "ingl&eacute;s\0");
break;
case 6:
strcpy (nombreidioma, "English\0");
break;
}
break;
case 7:
switch(idiomanombre)
{
case 1:
strcpy(nombreidioma, "alem&aacute;n\0");
break;
case 6:
strcpy (nombreidioma, "Germany\0");
break;
}
break;
}
return(nombreidioma);
}
///////
bool existefichero (char* nomfich)
{
struct stat fs;
if (stat(nomfich, &fs)==0) return (true); else return (false);
}
///////
bool existeficheroesperando (char* nomfich)
{
struct stat fs;
register int i=0;

while ((stat(nomfich, &fs)!=0) && (i<50))
{
//for(i=0; ((i<50)&&(stat(nomfich, &fs)==0));i++)
 sleep(1);
 i++;
}
if (i==50) return (false); else return(true);
}
///////////
void iconoayuda (char* pagina, int ancho, int largo, bool privada)
{
printf ("<a href=\"javascript:openPop('%s',%d,%d)\">", pagina, ancho, largo);
if (privada)
printf ("<img src=\"https://eurus.safe-order.net/vivegranada/info2.gif\" border=0></a>");
else
printf ("<img src=\"/info2.gif\" border=0></a>");
}
/////////////
void iconovolver (unsigned int idioma=1, unsigned int pagina=0)
{
switch (pagina)
{
case 0:
printf("<center><a href=\"javascript:history.back()\" name=\"volver\"");
break;
case 1: // pagina inicio vivegranada
switch (idioma)
{
case 1:
printf("<center><a href=\"http://www.vivegranada.com/index-esp.html\" name=\"volver\"");
break;
default:
printf("<center><a href=\"http://www.vivegranada.com\" name=\"volver\"");
break;
}
}
printf ("onmousedown=\"document.miVolver.src='http://www.vivegranada.com/volver2.gif'\"\n");
printf("onmouseout=\"document.miVolver.src='http://www.vivegranada.com/volver1.gif'\"");
printf ("          onmouseover=\"document.miVolver.src='http://www.vivegranada.com/volver2.gif'\"");
printf ("               onmouseup=\"document.miVolver.src='http://www.vivegranada.com/volver2.gif'\"\n");
printf(" target=_self>");
printf("<IMG alt=\"\" border=0 hspace=16 name=miVolver src=\"http://www.vivegranada.com/volver1.gif\"></a></center> \n");
}
/////////////

//////

int posicionfichero (FILE* fichero, unsigned int tam)
{
return (ftell(fichero)/tam-1);
}
	///////////////////////////////////////////////////
bool SaltaAlarma(FILE* temp, FILE* actual)
{
bool salta=false;
if (obtener_tamfich(temp)< obtener_tamfich(actual))
{
 imprimir_error("1. Consulte con el Webmaster", "Consult webmaster", "", 1);
 enviarcorreoerror(0, 0, "SaltaAlarma");
 fclose(temp);
 fclose (actual);
 actualizar_modos("0\0","0\0","0\0");
 salta=true;
}
return(salta);
}
//////////
#endif
