#ifndef Sample_cpp//
#define Sample_cpp//

#include "Sample.h"

namespace BIOS 
{
/*
 template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
Container<T,Cont>* Sample<T, Cont, SuperCont>::getElement(typename Sample<T, Cont, SuperCont>::NodePointer p)
{
  try
    {
      if (p==NULL)
        // throw NullValue(" in GetElement");
        throw NullValue();
    }

    catch (NullValue nv)
    {
      nv.PrintMessage("in GetElement");
    }

    return (Container<T,Cont>*) p->element;
}
/*____________________________________________________________________________________________*/
/*
   template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  
int Sample<T, Cont, SuperCont>::getTotalPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last)
  {
 return GetPos(last)-GetPos(first)+1;
}
 /*____________________________________________________________________________________________*/
/*
   template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  int Sample<T, Cont, SuperCont>::getTotalLeftPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last, typename Sample<T, list, ListOfPointers>::NodePointer between)
  {
return GetPos(between)-GetPos(first)+1;
}
 /*____________________________________________________________________________________________*/
/*
  template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  int Sample<T, Cont, SuperCont>::getTotalRightPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last, typename Sample<T, list, ListOfPointers>::NodePointer between)
  {
return GetPos(last)-GetPos(between);

}

/*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
 Sample<T, Cont, SuperCont>* Sample<T, Cont, SuperCont>::copyColumns(intList* posList, bool orderedByThis)//
  {
Sample<T, Cont, SuperCont>* sample2=new Sample();
typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst();
Container<T, Cont>* pattern, *sourcePattern;
 while (p!=NULL)
{
sourcePattern=this->GetElement(p);
pattern=sourcePattern->copyElementsWithPositionsIn(posList, orderedByThis);
sample2->insertElement(pattern);
zap(pattern);
p=this->GetNext(p);
}
return sample2;
  };
  /*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
  intList* Sample<T, Cont, SuperCont>::getOptimalBlanket (Container<T, Cont>* otherSet)
  {
  Sample<T, Cont, SuperCont>* temporal=Sample<T, Cont, SuperCont>(*this);
  typename Sample<T, Cont, SuperCont>::NodePointer p;
  Container<T, Cont>* newSet, *temporalArgument=new Container<T, Cont>(*otherSet), *foundElements;
  int max;
  intList* result=new intList();
  while (temporalArgument->GetSize()>0)
  {
  max=temporal->getOptimalSingleBlanket(temporalArgument);
  result->insertElement(max);
  foundElements=temporalArgument->copyElementsIn(temporal->GetElement(max));
  temporalArgument->removeElementsIn(temporal->GetElement(max));
  p==this->GetFirst();
  while (p!=NULL)
  {
   temporal->GetElement(p)->removeElementsIn(foundElements);
   p=this->GetNext(p);
  }
  zap(foundElements);
  }
  zap(temporalArgument);
  zap(temporal);
  return result;
  }
  /*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
  int Sample<T, Cont, SuperCont>::getOptimalSingleBlanket (Container<T, Cont>* otherSet)
  {
  typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst();
  int max, i=0;
  Container<T, Cont>* newSet, *currentMaxSet;
 
  while (p!=NULL)
  {
   newSet=this->GetElement(p)->copyElementsIn(otherSet);
   if (newSet->GetSize()>currentMaxSet->GetSize() || (newSet->GetSize()==currentMaxSet->GetSize() && this->GetElement(p)->GetSize()<this->GetElement(max)->GetSize()))
    {
    max=i;
    zap(currentMaxSet);
    currentMaxSet=new Set<T, ListOfPointers>(*newSet);
    }
   zap(newSet);
   p=this->GetNext(p);
   i++;
  }
  zap(currentMaxSet);
  return i;
  }

/*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
 Container<T, Cont>* Sample<T, Cont, SuperCont>::getColumn(int pos)//
  {
Container<T,Cont>* result=new Container<T,Cont>();
typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst();
Container<T, Cont>* pattern;
int i=0;
 while (p!=NULL)
{
pattern=this->GetElement(p);
if (pattern->GetSize()<=pos)
{
cout <<"Error, row " << i <<" has only " << pattern->GetSize() <<" elements and should have at least" << pos+1;
}
result->insertElement(pattern->GetElement(pos));
p=this->GetNext(p);
i++;
}

return result;

  };
/*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
 Sample<T, Cont, SuperCont>* Sample<T, Cont, SuperCont>::transpose()//
  {
Sample<T, Cont, SuperCont>* result=new Sample<T, Cont, SuperCont>();
int totalColumns=this->GetFirstElement()->GetSize();
Container<T, Cont>* column, *reverseColumn;
int totalRows=this->GetSize();
for (int i=0;i<totalColumns;i++)
{
column=this->getColumn(i);
if (column->GetSize()!=totalRows)
{
cout <<"Error, column " << i <<" has only " << column->GetSize() <<" and should have " << totalRows;
}
reverseColumn=column->reverse();
 result->insertElement(reverseColumn);
delete column;
delete reverseColumn;
}
return result;

  };


/*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
 Sample<T, Cont, SuperCont>* Sample<T, Cont, SuperCont>::extractRowsWithPositionsIn(intList* posList)//
  {
  return (Sample<T, Cont, SuperCont>*)this->extractElementsWithPositionsIn(posList);
  };

/*___________________________________________________________________________________*/
/*
  template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
 Sample<T, Cont, SuperCont>* Sample<T, Cont, SuperCont>::extractRowsWithPositionsIn(intList* posList)//
  {
  return (Sample<T, Cont, SuperCont>*)this->extractElementsWithPositionsIn(posList);
  };
/*___________________________________________________________________________________*/

  template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  long int Sample<T, Cont, SuperCont>::GetAbsoluteFrequency(Set<AttPattern, ListOfPointers>* attList) throw (OutOfBounds)
  {
    // Given a list of AttPatterns (Attribute position and range) and optional filtering it returns the number of members which values in the same range for the list of attribute positions

    long int frequency=0;
    typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst();
    typename Set<AttPattern, ListOfPointers>::NodePointer pA;
    Container<T, Cont>* pattern;
    bool inconsistent;
    int position;
    T minValue, maxValue, value;
    AttPattern* attPattern;
    bool continuous;
      while(p!=NULL)
    {
      pattern=(Container<T, Cont>*)GetElement(p);
      pA=attList->GetFirst();
      inconsistent=false;
       while(pA!=NULL && !inconsistent)
      {
        attPattern=attList->GetElement(pA);
	if (attPattern->GetPos()>=pattern->GetSize())
throw OutOfBounds(attPattern->GetPos(), pattern->GetSize());
	
        value=pattern->GetElement(attPattern->GetPos());
        if (attPattern->GetMinValue()==attPattern->GetMaxValue())
        {
         if (value!=attPattern->GetMinValue()) inconsistent=true;
        } 
       else
        if (attPattern->GetMinValue()>=value || attPattern->GetMaxValue()<value)
          inconsistent=true;
        pA=attList->GetNext(pA);
       }
      if (!inconsistent) frequency++;
      p=GetNext(p);
    }
    return frequency;
  };
  /*___________________________________________________________________________________*/
/*
  template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  double Sample<T, Cont, SuperCont>::GetRelativeFrequency(Set<AttPattern, ListOfPointers>* values, typename Sample<T, Cont, SuperCont>::NodePointer first=NULL, typename Sample<T, Cont, SuperCont>::NodePointer last=NULL)
  {
    return GetAbsoluteFrequency(values, first, last)/this->GetSize();
  };


  /*___________________________________________________________________________________*/
/*
  template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  Prob Sample<T, Cont, SuperCont>::GetConditionalFrequency(Set<AttPattern, ListOfPointers>* independents, Set<AttPattern, ListOfPointers>* conditioners, typename Sample<T, Cont, SuperCont>::NodePointer first=NULL, typename Sample<T, Cont, SuperCont>::NodePointer last=NULL)
  {

    Set<AttPattern, ListOfPointers>* joint;
    joint=new Set<AttPattern, ListOfPointers>(*independents);

    AttPattern* attPattern; 
    typename Set<AttPattern, ListOfPointers>::NodePointer pC=conditioners->GetFirst();
   
    while (pC!=NULL)
    {
    attPattern=new AttPattern(conditioners->GetElement(pC));
      joint->insertElement(attPattern);
      zap(attPattern);
      pC=conditioners->GetNext(pC);
    }

    ///// Now, compute frequencies for the joint and the marginal
    Prob r=Prob(GetAbsoluteFrequency(joint, first, last), GetAbsoluteFrequency(conditioners, first, last));

    zap(joint);

    return r;
  };
 /*___________________________________________________________________________________*/
/*
  template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  
typename Container<T, Cont>::NodePointer Sample<T, Cont, SuperCont>::findFinalElement(T element)//
  {
typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst();
typename T::NodePointer pp;

while (p!=NULL)
{
pp=GetElement(p)->findElement(element);
if (pp!=NULL) return p;
p=this->GetNext(p);
}
return NULL;

  };
 
/*___________________________________________________________________________________*/

template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  Sample<T, Cont, SuperCont>*  Sample<T, Cont, SuperCont>::moveColumn(int oldPos, int newPos)
{
Sample<T, Cont, SuperCont>* sample2=new Sample<T, Cont, SuperCont>(*this);

if (oldPos!=newPos)
{
Container<T, Cont>* pattern;
typename Sample<T, Cont, SuperCont>::NodePointer p=sample2->GetFirst();
while (p!=NULL)
{
pattern=sample2->GetElement(p);
pattern->moveElement(oldPos, newPos);
p=sample2->GetNext(p);
}
}
return sample2;
};

/*____________________________________________________________ */
/*
 template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  Sample<T, Cont, SuperCont>*  Sample<T, Cont, SuperCont>::mergeWithUsingColumn(Sample<T, Cont, SuperCont>* secondList, int column)
  {

   Sample<T, Cont, SuperCont>* result=new  Sample<T, Cont, SuperCont>();
   typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst(), p2=secondList->GetFirst();
   while (p!=NULL || p2!=NULL)
 {
 while (p!=NULL && 
(p2!=NULL && this->GetElement(p)>=secondList->GetElement(p2)) || p2==NULL)
{
  result->insertElement(GetElement(p));
  p=this->GetNext(p);
}
 while (p2!=NULL && 
(p!=NULL && this->GetElement(p)<secondList->GetElement(p2)) || p==NULL)
{
  result->insertElement(secondList->GetElement(p2));
  p2=secondList->GetNext(p2);
}
 }
return result;
  }
/*____________________________________________________________ */

 template<class T, template <class T> class Cont,template <class Cont> class SuperCont>  Sample<T, Cont, SuperCont>*  Sample<T, Cont, SuperCont>::mergeWith(Sample<T, Cont, SuperCont>* secondList)
  {
   Sample<T, Cont, SuperCont>* result=new  Sample<T, Cont, SuperCont>();
   typename Sample<T, Cont, SuperCont>::NodePointer p=this->GetFirst(), p2=secondList->GetFirst();
//Container<T,Cont>* newList=NULL;
   while (p!=NULL || p2!=NULL)
 {
 while (p!=NULL && 
(p2!=NULL && this->GetElement(p)>=secondList->GetElement(p2)) || (p2==NULL && p!=NULL))
{
 // newList=new Container<T,Cont>(*GetElement(p));
 if (result->GetSize()==0 || !(result->GetLastElement()==GetElement(p)))
   result->insertElement(GetElement(p));
  p=this->GetNext(p);
}
 while (p2!=NULL && 
(p!=NULL && this->GetElement(p)<secondList->GetElement(p2)) || (p==NULL && p2!=NULL))
{
//newList=new Container<T,Cont>(*secondList->GetElement(p2));
 if (result->GetSize()==0 || !(result->GetLastElement()==secondList->GetElement(p2)))
  result->insertElement(secondList->GetElement(p2));
  p2=secondList->GetNext(p2);
}

// p=this->GetNext(p);
//p2=secondList->GetNext(p2);
 }
return result;
  }
/*___________________________________________________________________________________*/

/*
template<class T, template <class T> class Cont,template <class Cont> class SuperCont>   
Container<T, Cont>* Sample<T, Cont, SuperCont>::ReadElement(ifstream * source, char* tokensSource)
{
cout <<"Sample:ReadElement, not implemented";
end();
};
  /* _____________________________________________________*/

template <> Container<int,list>*  Sample<int, list, ListOfPointers>::ReadElement(ifstream * source, char* tokensSource)
  {
  char * genotypebuf=CaptureLine(source);
  

  stringList* l=getList(genotypebuf, tokensSource);
zap(genotypebuf);
//return NULL;
if (l==NULL) return NULL;
  intList* lline;
    lline=new intList();
stringList::NodePointer p=l->GetFirst();
string s;
    while (p!=NULL)
    {
    s=l->GetElement(p);
      if (isAnInteger(s.c_str()))
      lline->insertElement(atoi(s.c_str()));
      else
      {
      cout <<"Error in Sample<int>::ReadElement, " << s <<" is not an integer";
      end();
      }
      p=l->GetNext(p);
      }
      zap(l);
           return lline;
  };
 /* _____________________________________________________*/

  template <> floatList*  floatSample::ReadElement (ifstream * source, char* tokensSource)
  {
  char * genotypebuf=CaptureLine(source);

stringList* l=getList (genotypebuf, tokensSource);
 zap(genotypebuf);
if (l==NULL) return NULL;

   floatList* lline;
    lline=new floatList();
list<string>::NodePointer p=l->GetFirst();
string s;


    while (p!=NULL)
    {
    s=l->GetElement(p);
      if (strcmp(s.c_str(), "?")==0) lline->insertElement(maxreal);
      else 
      if (isANumber(s.c_str()))
      lline->insertElement(atof(s.c_str()));
      else
      {
      cout <<"Error in Sample<float>::ReadElement" << s;
      end();
      }
      p=l->GetNext(p);
      }
        zap(l);
     

       return lline;
  };

   /* _____________________________________________________*/

 template<> stringList*  stringSample::ReadElement (ifstream * source, char* tokensSource)
  {
 // char tokens[7];
 //  if (tokensSource==NULL) strcpy(tokens, "\t, /\n\r");
 //  else strcpy(tokens, tokensSource);
char * genotypebuf=CaptureLine(source);

//cout <<genotypebuf;
//return NULL;
stringList* lline=getList(genotypebuf, tokensSource); 

zap(genotypebuf);

if (lline==NULL) return NULL;
else
if (lline->GetSize()==0) 
{
zap(lline);
return NULL;
}
else return lline;
  };
 
  /* _____________________________________________________*/

template<> int  stringSample::getTotalMissingValues ()
{
int totalMissing=0;
NodePointer p=GetFirst();
stringList* row, *newRow, *pattern=new stringList(); pattern->insertElement(string("?"));

while (p!=NULL)
{
row=GetElement(p);
newRow=row->copyElementsIn(pattern);
totalMissing=totalMissing+newRow->GetSize();
zap(newRow);
p=GetNext(p);
};

return totalMissing;

}
   
} // end namespace
#endif
