  /**
    * @file MergeFiles.cpp
    * @brief Program to merge text files when value at some column is the same
    *
    */

#include "Fachade.h"
/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file1> " << "<input file2>" << " <output file> " << "0: as strings, 1: as integers(default is 0)>\n";
        exit(0);
        }
     char filename[128], filename2[128], filename3[128];
int column;
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

	 strcpy(filename3, argv[3]);

bool asInteger=false;
if (argc==5)
asInteger=atoi(argv[4]);



if (strcmp(filename, filename2)==0 || strcmp(filename, filename3)==0 || strcmp(filename3, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}
//if (argc==5) 
//column=atoi(argv[4]);


ofstream OutputFile;
OpenOutput(filename3, &OutputFile);
//cout <<"filename" << filename;

if (!asInteger)
{
Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename), * l2=new Sample<string, list, ListOfPointers>(filename2), *result;

l->Order();
l2->Order();
result=l->mergeWith(l2);
zap(l);
zap(l2);
result->Order();
OutputFile << *result;
}
else
{
Sample<int, list, ListOfPointers> * lb=new Sample<int, list, ListOfPointers>(filename), * l2b=new Sample<int, list, ListOfPointers>(filename2), *resultb;

lb->Order();
l2b->Order();
resultb=lb->mergeWith(l2b);
zap(lb);
zap(l2b);
resultb->Order();
OutputFile << *resultb;
}
OutputFile.close();

cout <<"\nResults have been saved in file " << filename3 <<"\n";

//zap(result);


}










