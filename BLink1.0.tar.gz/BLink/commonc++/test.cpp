

#include "Fachade.h"

using namespace BIOS;

int
main(int argc, char **argv)
{
double val[2], expe[2];
val[0]=46;
val[1]=28;
expe[0]=37;
expe[1]=37;

cout <<"p val is:";
printf("%3.5f",chiTest(val, expe, 1));

printf("\n%3.5f",std::pow(2,(double)1/2));

printf("\n%3.5f",pdfTestChiSquare(4,4));

    return 0;
}
