#include <iostream.h>

template <class T> class Object
{
public:
	Object* ExtractList(int indexVector[], int size);

}

/*___________________________________________________________________________________*/
	
	template <class T> Object* container<T>::ExtractList(int indexVector[], int size)//
	{
		Object* newList=new Object(*this);
                newList->selectElements(indexVector, size);
                return newList;
	};