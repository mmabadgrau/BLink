#ifndef __Fachade_h__ 
#define __Fachade_h__ 


#include<sstream>
#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
#include <string>
#include <iostream>
#include <cmath>
#include <math.h>//
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "gamma.h"
#include "basic.h"
#include "Sampling.cpp"
#include "Binomial.cpp"
#include "Multinomial.cpp"
#include "list.h"
#include "chiSquare.h"
 

#include "basic.cpp"

#include "AttPattern.h"
#include "list.cpp"

#include "Pair.h"

#include "Integer.h"
#include "SoftListOfPointers.cpp"
#include "ListOfPointers.cpp"

#include "Container.h"
#include "Prob.cpp"
#include "Basic2.h"
#include "TextFile.h"
#include "Basic2.cpp"
#include "ProbabilityInterval.h"


#include "Set.h"

#include "NonZero.h"
#include "ListOfLists.h"
#include "Sample.cpp"
#include "SampleOfSets.h"
#include "SampleOfSets.cpp"
#include "MultidimensionalTable.h"
#include "BidimensionalTable.h"
#include "ficheros.cpp"

#include "Container.cpp"
#include "DiagonalTable.h"
#include "Tables2x2.h"
#include "Tables2x2.cpp"
//#include "dcdflib.c"
#endif
