  /**
    * @file SelectRowsForColumnEqualTo.cpp
    * @brief Program to select rows when some column matches a given value
    *
    */


#include "Fachade.h"


/* This program select rows which match some column value. Result is a file with the selected row numbers, starting by 0*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

bool exact=true;

int main(int argc, char*argv[]) {
   
     if(argc<5)
     {
        cerr << "Error: you have to specify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<column to be matched>" <<"<key value>" <<"<exact match (1, yes, default; 0, no)> ";
        exit(0);
        }
     char filename[128], filename2[128], keyValue[128];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

         int column=atoi(argv[3]);

         strcpy(keyValue, argv[4]);

         if (argc>5) exact=atoi(argv[5]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}

stringList* currentLine=NULL;

ofstream OutputFile;
OpenOutput(filename2, &OutputFile);

TextFile* tf=new TextFile(filename);
currentLine=tf->readLine();
string value;
while (!tf->eof())
{

value= currentLine->GetElement(column);
if ((exact && strcmp(value.c_str(), keyValue)==0) ||
(!exact && strstr(value.c_str(), keyValue)!=NULL))
OutputFile << *currentLine <<"\n";
zap(currentLine);
currentLine=tf->readLine();
}

zap(currentLine);
OutputFile.close();

zap(tf);

cout <<"\nResults have been saved in file " << filename2 <<"\n";

}










