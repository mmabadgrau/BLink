  /**
    * @file ManageRows.cpp
    * @brief Program to resolve phase
    *
    */


#include "Fachade.h"


/* This program select rows which match some column value. Result is a file with the selected row numbers, starting by 0. Both the input file and the one used for selection have rows ordered by the field used for selection*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<5)
     {
        cerr << "Error: you have to specify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<column to be matched> " <<"<key file>" <<" ";
        exit(0);
        }
     char filename[128], filename2[128], filename3[128];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

         int column=atoi(argv[3]);

         strcpy(filename3, argv[4]);


if (strcmp(filename, filename2)==0 || strcmp(filename, filename3)==0 ||strcmp(filename3, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}



Container<string, list>* queryPositions=new Container<string, list>(&filename3[0]);


stringList* currentLine=NULL;

int i=0, total=queryPositions->GetSize();
cout <<"\nThere are " << total <<" values to be found\n";

ofstream OutputFile;
OpenOutput(filename2, &OutputFile);


TextFile* tf=new TextFile(filename);
currentLine=tf->readLine();//heading
currentLine=tf->readLine();
string value;
Container<string, list>::NodePointer p=queryPositions->GetFirst();
while (p!=NULL)
{
//cout <<"\nSearching matches for value " << queryPositions->GetElement(p);
//cout <<"\nvalue is " <<currentLine->GetElement(column);

while (!tf->eof() && atoi(queryPositions->GetElement(p).c_str())>atoi(currentLine->GetElement(column).c_str()))
{
if (i%100000==0)
{
cout <<"\nline " << i <<" has been processed";
cout <<"\nvalue is " <<currentLine->GetElement(column);
}
if (1==2)
if (atoi(currentLine->GetElement(column).c_str())==15021674  || atoi(currentLine->GetElement(5).c_str())==15021674)
{
cout <<"found";
end();
} 
zap(currentLine);
currentLine=tf->readLine();
i++;
}
while (!tf->eof() && queryPositions->GetElement(p)==currentLine->GetElement(column))
{
if (i%100000==0)
cout <<"\nline " << i <<" has been processed and value " << column << " was found in column " << column;
if (1==2)
if (atoi(currentLine->GetElement(column).c_str())==15021674 || atoi(currentLine->GetElement(5).c_str())==15021674)
{
cout <<"foundb";
end();
}

OutputFile << *currentLine <<"\n";
zap(currentLine);
currentLine=tf->readLine();
i++;
}
p=queryPositions->GetNext(p);
}

zap(queryPositions);


OutputFile.close();

cout <<"\nResults have been saved in file " << filename2 <<"\n";

}










