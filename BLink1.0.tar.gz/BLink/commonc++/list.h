/* File: list.h */


#ifndef __list_h__
#define __list_h__





/**
    @memo Declaration of a list (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{
 template <class T, template <class T> class Cont> class Container;

  /************************/
  /* list DEFINITION */
  /************************/


  /**
          @memo list 
   
  	@doc
          Definition:
          A set of list's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the list
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
/*
 template <class T> typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;

    };
*/


typedef enum  {
	equal=0,
	lower=-1, 
	greater=1
	
} ComparisonType;



  template <class T> class list
  {

  public:

    typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;
      ~node() {Next=NULL; Previous=NULL;};
      node() {Next=NULL; Previous=NULL;};
      node* getNext() {return Next;};
      node* getPrevious() {return Previous;};
    };
    
public:

    typedef node * NodePointer;
    



  protected:
    NodePointer List, Last;

    int Size;

  






    /*********************************************************************/
    /***     ASSOCIATED FUNCTIONS     ***/
    /*********************************************************************/

    /* Head */

    /////////////////////////////////////////////

  protected:



    virtual void copy(NodePointer source, NodePointer last=NULL);
    
    void copySecond(NodePointer source);

  
    //T ReadElement (ifstream * is, int size) {cout <<"ggg";};

    //virtual template <class T> T list<T>::ReadElement(ifstream * is);

    void setPreviousPointers (NodePointer & Target);

    void UnlinkElement(NodePointer Pointer);

    void init();

	void createWithSampling (list<T> &source, Sampling* sampling);

void getIntersection(list<T> * Source);
void getDifference(list<T> * Source);
 
    /////////////////////////



    /* PUBLIC FUNCTIONS (INTERFACE) */

  public:

    virtual void destroy(NodePointer e);
  
  int GetExtremePosition(bool max=true);
  
  int GetMaxPosition();

  int GetMinPosition();
 
 void paste(list<T>* otherList);


	 // void hardCopy(char filename[256]);


	  virtual void* findElement(void* element){cout <<"list::findELement not implemented"; end();};


    virtual ~list ();

    list();
    list(int i);
 virtual T ReadElement (ifstream * is, char* tokens){ cout<<"list::ReadElement not implemented yet"; exit(0);}; // if word virtual is not 
 virtual void ReadInfo (ifstream * is, char* tokens=NULL);
 virtual void GetInfo(char *FileName, char* tokens);

 
    virtual void deleteElement (T element){} ;
    
 //   list(list &source) {cout <<"list(&) not implemented yet"; end();};;

 //list(const list &source) {cout <<"list(const) not implemented yet"; end();};
  
  list(list &source, NodePointer first=NULL, NodePointer last=NULL);

list(list &source, Sampling* sampling);

    list(char* filename, char* tokens=NULL);
    

    list & cloneSecond(const list & e);
    
 list & operator=(list & e){cout << "list = not implemented yet"; end();};
    list & operator=(const list & e);

    virtual bool operator>(list & e);

    virtual bool operator<(list & e);
    
    virtual bool operator==(list & e);

    virtual bool operator!=(list & e);

    list* operator+(T value) {cout << "list = not implemented yet"; end();};

    list* operator-(T value) {cout << "list = not implemented yet"; end();};

    list* substract(T value) {cout << "list = not implemented yet"; end();};
   
    virtual bool comparison(list & e, ComparisonType type);
    
    virtual ComparisonType compareElement(T arg1, T arg2);
	
   // void filterElements(int* elements, int size);
    
   // void selectElements(int* elements, int size);

	//   void filterElements(list<int>* elements);
    
    //void selectElements(list<int>* elements);

    //list<T>* selectElementsByContents(list<int>* sourceList);

 //   template <class c> Container<T, c>* operator Container<T, c>();//{return (Container<T, Cont>*)this;};

    T* getTable();

   
      bool includes(list * e);

    T GetLastElement();

    T GetFirstElement();

    //T* GetPointerToElement(typename list<T>::NodePointer e);//  (node * e);//

   // T* GetPointerToElement(int k);
    //virtual
    //  T ReadElement (ifstream * is, int size, char* mark); // if word virtual is not included, end loop

   
  //included, end loop

    virtual void insertElement (T element);


  //  virtual void selectAndOrderElements(list<int>* elementList);


    virtual T GetElement(NodePointer e) throw(NullValue);

    T GetElement(int k);

    //string print(bool forward=true);


    NodePointer GetFirst () {return this->List;};

    NodePointer GetLast () {return Last;};

    NodePointer GetPrevious (const NodePointer i);

    NodePointer GetNext (const NodePointer i);

    NodePointer GetNode (int k);

    virtual NodePointer findElement(T element);


    int GetSize ();

    int GetPos(NodePointer p);

    T GetMaxElement();

    T GetMinElement();

    virtual T GetExtremeElement(bool max);


    
    void copyPaste (list<T>* otherList);

  
    //void insertElement (char* element);

    void insertElementAtPointer (T element, NodePointer  p);

    void changeElementAtPointer (T element,  NodePointer  p);

    void changeElementAtPos (T element, int position);
     
    void insertElementAtPos (T element, int position);
   
   
    virtual NodePointer removeNode(NodePointer Pointer);
     
    virtual void assignElement (NodePointer p, T element);
 

    T removeNode(int position);

    void Order(int* NewOrder, int size);

    void Order(bool ascendent);

    void Remove(bool* RemovePos);

    void ReplaceNode(NodePointer p, T NewElement);

    bool IsEmpty();

    void Empty();

    T Pop();

   // float GetDistance(list* otherList, int distanceType, list<bool>* missingPositions);
    
    void moveElement(int oldPos, int newPos);

    NodePointer GetClosestGreaterPointerToElement(T argument, bool checkOrder=true);
    
    bool isOrdered(bool ascendent);


    void hardCopy(char filename[256]);
 

    string print(bool* seleccionados, bool *integer, bool *missing);
 
  //   list<T>* ExtractList(int TotalElements);

  //  list<T>* ExtractList(int indexVector[], int size);

    T CopyColumn(int column);
    
 //  template<class U, class V> typename V::NodePointer findFinalElement(U element);//

    
  };  // End of class list

  //typedef  char s40[40];

/*______________________________________________________*/

     template<class T> ostream& operator<<(ostream& out, list<T>& l)
{
if (l.GetSize()>1) out <<"(";
typename list<T>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << p->element; 
p=l.GetNext(p); 
   if (l.GetSize()>1) if (p!=NULL) out <<","; else out <<")";
}
return out;
}

/*______________________________________________________*/
/*
     template<class T> ostream& operator<<(ostream& out, ListOfPointers<T>& l)
{
if (l.GetSize()>1) out <<"(";
typename list<T>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << *(p->element); 
p=l.GetNext(p); 
   if (l.GetSize()>1) if (p!=NULL) out <<","; else out <<")";
}
return out;
}

  /*______________________________________________________*/

//template <class T> ostream& operator<<(ostream& out, list<T>& l);

      ostream& operator<<(ostream& out, list<list<struct node*>::NodePointer>& l)
{
if (l.GetSize()>1) out <<"(";

 list<list<struct node*>::NodePointer>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {

 out << p->element->element; 
p=l.GetNext(p); 
       if (l.GetSize()>1) if (p!=NULL) out <<","; else out <<")";

}
return out;
}


  /*______________________________________________________*/

     ostream& operator<<(ostream& out, list<int>& l)
{
//if (l.GetSize()>1) out <<"(";

list<int>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << l.GetElement(p); 
p=l.GetNext(p); 
      if (l.GetSize()>1)  if (p!=NULL) out <<","; //else out <<")";

}
return out;
}
/*______________________________________________________*/

      ostream& operator<<(ostream& out, list<float>& l)
{
//if (l.GetSize()>1) out <<"(";

list<float>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << l.GetElement(p); 
p=l.GetNext(p); 
     if (l.GetSize()>1)   if (p!=NULL) out <<","; //else out <<")";

}
return out;
}
/*______________________________________________________*/

     ostream& operator<<(ostream& out, list<double>& l)
{
//if (l.GetSize()>1) out <<"(";

list<double>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << l.GetElement(p); 
p=l.GetNext(p); 
      if (l.GetSize()>1)  if (p!=NULL) out <<","; //else out <<")";

}
return out;
}
/*______________________________________________________*/

     ostream& operator<<(ostream& out, list<string>& l)
{
//if (l.GetSize()>1) out <<"(";

list<string>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << l.GetElement(p); 
p=l.GetNext(p); 
    if (l.GetSize()>1)   if (p!=NULL) out <<","; //else out <<")";

}
return out;
}

} // end namespace
#endif

//#include "list.cpp"

/* Fin Fichero: list.h */


/* Fin Fichero: list.h */
