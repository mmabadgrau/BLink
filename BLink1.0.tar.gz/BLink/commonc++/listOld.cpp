/* File: list.cpp */


#ifndef __list_cpp__
#define __list_cpp__




#include "list.h"




/**
@memo Declaration of a list (FIFO)
@doc
*/


namespace BIOS
{

  /************************/
  /* list DEFINITION */
  /************************/


  /**
  @memo list 

    @doc
    Definition:
    A set of list's features 
    
  	Memory space: O(SizeP), which SizeP being the number of elements in the list
  	
  	  @author Maria Mar Abad Grau<< "\n
  	  @version 1.0
  */



  /**********************************/
  /* DEFINITIONS OF THE FUNCTIONS */
  /**********************************/

  /////////////////////////////////////////////
  template <class T> void list<T>::destroy(NodePointer e)
  {

    if(e!= NULL)
    {
      destroy (e->Next);
      removeNode(e);
    }
  }
  //////////////////////////////////////////

  template <class T> void list<T>::setPreviousPointers (NodePointer & Target)
  {
    if (Target->Next==NULL) Last=Target;

    else
    {
      if (Target==List) Target->Previous=NULL;
      else Target->Next->Previous=Target;
      setPreviousPointers(Target->Next);
    }


  }
  //////////////////////////////////////////

  template <class T> void list<T>::copy (const NodePointer Source)
  {
    if (Source!=NULL)
    {
  //  cout <<"\nPPointer is " << Source;
   // cout <<" and element pointer is " << Source->element;
   
      insertElement(Source->element);
      copy(Source->Next);
    }
  }



  /*___________________________________________________________ */

  template <class T> void list<T>::ReadInfo (ifstream * is, char* tokens=NULL)
  {

    while (is->peek()!=EOF)
    {

      insertElement(ReadElement(is, tokens));

    }


  }

  /*____________________________________________________________ */

  template <class T> void list<T>::GetInfo(char *FileName, char* tokens)
  {
 
    ifstream  InputFile;



    OpenInput(FileName, &InputFile);
    ReadInfo(&InputFile, tokens);

    //InputFile.exceptions ( ifstream::eofbit | ifstream::failbit | ifstream::badbit );
    //try{

    //ReadElement(&InputFile, tokens);

    //}
    //catch (ifstream::failure e) {
    //   cout << "Exception reading file";
    // };


    InputFile.close();
    //cout <<"Elements reading has finished\n";
  };
  ///////////////////
  //// public ////////
  ///////////////////

  template <class T> void list<T>::init()
  {
    List=NULL;
    Last=NULL;
     Size=0;
  }

  template <class T> list<T>::list()
  {
    init();
    //  mark=new char[3];
    // strcpy(mark, "\t, ");
  }


  
   /*____________________________________________________________ */


  template <class T> list<T>::list (list<T> &source, list<int> *Sampling)
  {
init();
    
    if (&source!=NULL)
    {

      if (Sampling!=NULL)
      createWithSampling(source, Sampling);
      else
        copy (source.List);
    }
  }
       /*____________________________________________________________ */

  template <class T> void list<T>::createWithSampling (list<T> &source, list<int> *Sampling)
  {
    int cont=0;
    
   
        list<int>::NodePointer p=Sampling->GetFirst();
	typename list<T>::NodePointer p2;
       
        T e;

        while (p!=NULL)
        {
	e=source.GetElement(source.GetNode(Sampling->GetElement(p)));
	 // e=p2->element;
          insertElement(e);//source.GetElement(Sampling->GetElement(p)));
          p=Sampling->GetNext(p);
        }
    
    
  }
  /*____________________________________________________________ */

  template <class T> list<T>::list (char* filename, char* tokens)
  {
    init();
    GetInfo(filename, tokens);
  }

  /*____________________________________________________________ */

  template <class T> list<T>::~list ()
  {
    destroy(List);
   }

  /*____________________________________________________________ */

  template <class T> T list<T>::GetElement(NodePointer e)
  {
    try
    {
      if (e==NULL)
        // throw NullValue(" in GetElement");
        throw NullValue();
    }

    catch (NullValue nv)
    {
      nv.PrintMessage("in GetElement");
    }

    return e->element;
  };
  /*____________________________________________________________ */

  template <class T> T list<T>::GetElement(int k)
  {
    return GetElement(GetNode(k));
  };
  /*____________________________________________________________ */

  template <class T> typename list<T>::NodePointer list<T>::GetPrevious (const typename list<T>::NodePointer i)
  {
    try { if (i==NULL) throw NullValue();else  return i->Previous;}
  catch (NullValue nv) {nv.PrintMessage("in GetPrevious"); }
  };
  /**
  @memo Obtain the Next list in the list.
  @param The pointer to the current list
  @return return a pointer to the Next list in the list
  Time complexity O(1)

  */
  /*____________________________________________________________ */

  // template <class T> typename list<T>::Nodepointer list<T>::GetNext (const typename //list<T>::NodePointer i)
  template <class T> typename list<T>::NodePointer list<T>::GetNext (const typename list<T>::NodePointer i)
  {
    try { if (i==NULL) throw NullValue(); }
  catch (NullValue nv) {nv.PrintMessage("in GetNext"); }

    return i->Next;
  };

  /**
  @memo Obtain the element at pos k in the list.
  @param The pointer to the current list
  @return return a pointer to the Next list in the list
  Time complexity O(1)

  */
  /*____________________________________________________________ */
  template <class T> typename list<T>::NodePointer list<T>::GetNode (int k)
  //template <class T> BIOS::list<T>::node* list<T>::GetNode (int k)
  {
    NodePointer i=List;
    try
    {
      if (i==NULL) throw NullValue();
      for (int c=0;c<k;c++)
      {

        i=i->Next;
        if (i==NULL) throw NullValue();

      }
      return i;
    }
  catch (NullValue null) {null.PrintMessage("list<>::GetNode()");}

  };

  /*____________________________________________________________ */

  template <class T> T list<T>::Pop()
  {
    T last=GetElement(Last);

    // extract the last element from the list

    UnlinkElement(Last);
    return last;
  };
  /*____________________________________________________________ */

  template <class T> T list<T>::removeNode(int pos)
  {
    NodePointer p=GetNode(pos);
    T element=GetElement(pos);
    removeNode(p);
    return element;
  }
  	/*____________________________________________________________ */
	
	template <class T> void list<T>::UnlinkElement(NodePointer Pointer)
	{
		
		NodePointer Previous, Next;
		
		try
		{
			if (Size==0 || Pointer==NULL)  throw NullValue();
		}
		catch (NullValue null) {null.PrintMessage("in UnlinkElement");}
		
		
			//cout <<"h";
			Previous=Pointer->Previous;
			Next=Pointer->Next;
			if (Pointer!=List) Previous->Next=Pointer->Next;
			else List=Next;
			
			if (Pointer!=Last) Next->Previous=Previous;
			else Last=Previous;
			
			zap(Pointer);
			
			
			Size--;
			
		
	};
  /*____________________________________________________________ */

  template <class T> typename list<T>::NodePointer list<T>::removeNode(typename list<T>::NodePointer Pointer)
  {
    NodePointer Previous, Next;
    T object;
    int pos=0;
    char errorLine[100];
    try
    {
      if (Size==0)
      {
        sprintf(errorLine, "list::removeNode, list is empty");
        throw NullValue();
      }

      if (Pointer!=NULL)
      {
        Previous=Pointer->Previous;
        Next=Pointer->Next;
        if (Pointer!=List) Previous->Next=Pointer->Next;
        else List=Next;

        if (Pointer!=Last) Next->Previous=Previous;
        else Last=Previous;
		
	deleteElement(Pointer->element);
        zap(Pointer);
        Size--;
        return Next;
      }
      else
      {
        sprintf(errorLine, "list::removeNode, pointer argument is null");
        throw NullValue();
      }
    }
    catch (NullValue null)
    {
      null.PrintMessage(errorLine);
    }
  } ;

  /*____________________________________________________________ */

  template <class T> void list<T>::ReplaceNode(list<T>::NodePointer p, T NewElement)
  {
    try
    {
      if (p==NULL)
        throw NullValue();
      p->element=NewElement;
    }
    catch (NullValue null)
    {
      null.PrintMessage("in ReplaceNode");
    }
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::filterElements(int* elements, int size)
  {
// exclude those elements specified in array elements
    list<NodePointer>* listPos=new list<NodePointer>();
    for (int i=0;i<size;i++)
      listPos->insertElement(GetNode(elements[i]));



    typename list<NodePointer>::NodePointer p=listPos->GetFirst();
    while (p!=NULL)
    {
      removeNode(listPos->GetElement(p));
      p=listPos->GetNext(p);
    }

    zap(listPos);
  }
   /*____________________________________________________________ */

  template <class T> T* list<T>::getTable()
  {
	T*elements=new T[GetSize()];
  int i=0;
   NodePointer p=GetFirst();
    while (p!=NULL)
    {
      elements[i]=GetElement(p);
      p=GetNext(p);
	  i++;
    }
	return elements;
  }
  
   /*____________________________________________________________ */

  template <class T> void list<T>::filterElements(list<int>* elementList)
  {
   int* elements=elementList->getTable();
   filterElements(elements, elementList->GetSize());
   zap(elements);
  }
   /*____________________________________________________________ */

  template <class T> void list<T>::selectElements(list<int>* elementList)
  {
   int* elements=elementList->getTable();
   selectElements(elements, elementList->GetSize());
   zap(elements);
  }
  /*___________________________________________________________________________________*/

  template <class T> void list<T>::selectAndOrderElements(list<int>* elementList)//
  {
 try
 {
 if (elementList->GetSize()==0) throw NullValue();
 }
 catch (NullValue nv)
{
nv.PrintMessage ("Error in list::selectAndOrderElements");
}
typename list<int>::NodePointer p=elementList->GetFirst();
NodePointer p2=GetFirst();

int pos=0;
while (p!=NULL)
{
insertElementAtPos(GetElement(elementList->GetElement(p)+pos), pos);
//cout <<"inserting element at pos" << elementList->GetElement(p) <<"\n";//<<": " << this->GetElement(elementList->GetElement(p)).print() <<"\n";
p=elementList->GetNext(p);
pos++;
}

destroy(p2);

};
  /*____________________________________________________________ */

  template <class T> void list<T>::selectElements(int* elements, int size)
  {
// select elements whose positions are specified in array elements
    NodePointer* listPos=new NodePointer[Size];

    int oldSize=Size;
    for (int i=0;i<oldSize;i++)
      listPos[i]=GetNode(i);
     
    for (int i=0;i<size;i++)
    {
      if (elements[i]>=Size)
      {
        cout <<"Error in list<T>::selectElements, size is " << Size << " and is trying position " << elements[i];
        end();
      }
      listPos[elements[i]]=NULL;
     }

    for (int i=0;i<oldSize;i++)   
      if (listPos[i]!=NULL)
         removeNode(listPos[i]);
	
  zaparr(listPos);
  }
   /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectPositionsByContents(list<int>* sourceList)
  {
	      if (Source==NULL) 
   {
	   cout <<"Error in list::selectElementsByContents";
	   end();
   }
    list<int>::NodePointer p=sourceList->GetFirst(), p2;

   	  list<int>* newList=new list<int>();
	  while (p!=NULL)
	  {
		  if ((findElement(sourceList->GetElement(p))==NULL && type==1) ||  (findElement(sourceList->GetElement(p))!=NULL && type==0))
		  newList->insertElement(GetNode(p));
		  p=GetNext(p);
	  }
	  return newList;
  }
     /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectElementsByContents(list<T> * Source, int type)
  {
  // type=0: common, 1: different
      	  list<int>* newList=selectPositionsByContents(Source, type), result=new list<int>(*this);
	  result->selectElement(newList);
	
	  zap(newList);
	  return result;
  }
   /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectCommonElements(list<T> * Source)
  {
  return selectElementsByContents(Source, 0);
  }
  /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectDifferentElements(list<T> * Source)
  {
  return selectElementsByContents(Source, 1);
  }
    /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectPositionsWithCommonElements(list<T> * Source)
  {
  return selectPositionsByContents(Source, 0);
  }
  /*____________________________________________________________ */
/*
  template <class T> list<T>* list<T>::selectPositionsWithDifferentElements(list<T> * Source)
  {
  return selectPositionsByContents(Source, 1);
  }
  /*____________________________________________________________ */

  template <class T> int list<T>::GetPos(list<T>::NodePointer p)
  {
    try
    {
      int k=0;
      NodePointer i=List;
      //	cout <<"p" << p <<"list:" << List;
      if (p==NULL) throw NullValue();
      while (i!=NULL)
      {
        if (i==p) return k;
        k++;
        i=i->Next;
      }
      return k;
    }
    catch (NullValue null)
    {
      null.PrintMessage("in list::GetPos");
    }
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::insertElementAtPos(T element, int pos)
  {
    try
    {
      if (pos>GetSize()) throw NullValue();
      if (pos==GetSize()) insertElementAtPointer(element, NULL);
      else insertElementAtPointer(element, GetNode(pos));

    }
    catch (NullValue null)
    {
      null.PrintMessage("in list::insertElementAtPos");
    }

  }
  /*____________________________________________________________ */

  template <class T> void list<T>::moveElement(int oldPos, int newPos)
  {
    //cout <<"\n" << Size;
    T element=removeNode(oldPos);
    this->insertElementAtPos(element, newPos);
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::changeElementAtPos(T element, int pos)
  {
    NodePointer p=GetNode(pos);
    changeElementAtPointer(element, p);
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::changeElementAtPointer(T element, NodePointer p)
  {
    ReplaceNode(p, element);
  }
  /*____________________________________________________________ */


  template <class T> int list<T>::GetSize()
  {
    //   return Size;
    if (Last==NULL) return 0;
    else return GetPos(Last)+1;
  };

  /*____________________________________________________________ */

  template <class T> list<T>& list<T>::operator=(const list<T> & Source)
  {

    if (&Source!=NULL)
    {
      if (this!=&Source)
      {

        if (this->List!=NULL)
          destroy(this->List);

        copy (Source.List);

      }
    }
    return *this;
  }
  	/*---------------------------------------------------------------*/
	
       template<class T> int list<T>::compareElement(T arg1, T arg2)
	{
	//cout <<"\nfinal";
		if(arg1 < arg2) return -1;
		else if(arg1 > arg2) return 1;
		else return 0;
	}
	
   /*____________________________________________________________ */

  template <class T> bool list<T>::comparison(list<T> & Source, int type)
  {
  //cout <<"so then";
   try{
    if (&Source==NULL) throw NullValue(); 
   if (type==0)
   {
   if (this->GetSize()!=Source.GetSize()) return false;
   if (this==&Source) return true;
   }
   else if (this==&Source) return false;
 

   NodePointer p1=GetFirst(), p2=Source.GetFirst();
   while (p1!=NULL && p2!=NULL)
    {
    if (type ==0)
    { if (compareElement(GetElement(p1), Source.GetElement(p2))!=type) return false;}
    else 
    {
    if (compareElement(GetElement(p1), Source.GetElement(p2))*type==-1) return false;
    if (compareElement(GetElement(p1), Source.GetElement(p2))*type==1) return true;
    }
    p1=GetNext(p1);
    p2=Source.GetNext(p2);
   }
     switch (type)
    {
    case 0: if (this->GetSize()!=Source.GetSize()) return false; else return true; break;
    case -1: if (this->GetSize()>=Source.GetSize()) return false; else return true; break;
    case 1: if (this->GetSize()<=Source.GetSize()) return false; else return true; break;
   }
   }
catch (NullValue null)
    {
      null.PrintMessage("in list::comparison");
    }
  }
  /*____________________________________________________________ */

  template <class T> bool list<T>::operator==(list<T> & Source)
  {
  return comparison(Source, 0);
  }
  /*____________________________________________________________ */

  template <class T> bool list<T>::operator!=(list<T> & Source)
  {
  return !comparison(Source, 0);
  }
  /*____________________________________________________________ */

  template <class T> bool list<T>::operator>(list<T> & Source)
  {
 
  return comparison(Source, 1);

  }
  /*____________________________________________________________ */

  template <class T> bool list<T>::operator<(list<T> & Source)
  {
return comparison(Source, -1);

  }

  /*____________________________________________________________ */

  template <class T> bool list<T>::includes(list<T> * Source)
  {
   if (Source==NULL) 
   {
	   cout <<"Error in list::includes";
	   end();
   }
 
   if(this->GetSize()<Source->GetSize()) return false;
   NodePointer p=Source->GetFirst();
   while(p!=NULL)
   {
	   if (findElement(GetElement(p))==NULL) return false;
	   p=Source->GetNext(p);
   }
   return true;
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::assignElement (typename list<T>::NodePointer p, T element)
  {
 // p->element=new T(*element);
    p->element=element;
      }    
  /*____________________________________________________________ */

  template <class T> void list<T>::insertElement (T element)
  {
    NodePointer Pointer=NULL;
    try
    {
      if ((Pointer=new node)==NULL)
        throw NoMemory();
    }
  catch (NoMemory NM ) {NM.PrintMessage();}

    
    assignElement(Pointer, element);
    Pointer->Next=NULL;
    Pointer->Previous=Last;

    if (Size>0) Last->Next=Pointer;
    else List=Pointer;
    Last=Pointer;
    Size++;
  };

  /*____________________________________________________________ */


  template <class T> void list<T>::insertElementAtPointer (T element, NodePointer  p)
  {
    // if pointer is NULL, insert element at the end of the list
    typename list<T>::NodePointer Pointer, previous;

    if (p==NULL) insertElement(element);
    else
    {

      try
      {
        if ((Pointer=new node)==NULL)
          throw NoMemory();
      }
    catch (NoMemory NM ) {NM.PrintMessage();}

   assignElement(Pointer, element);
 
      //Pointer->element=element;
      Pointer->Next=p;

      if (p!=List)
      {
        previous=p->Previous;
        Pointer->Previous=previous;
        previous->Next=Pointer;
      }
      else
      {
        List=Pointer;
        Pointer->Previous=NULL;
      }

      p->Previous=Pointer;

      Size++;
    }

  };
  /*____________________________________________________________ */

  template <class T>  void list<T>::Order(int* NewOrder, int size)
  {
    int pos;

    list<T> *List2;
    try
    {
      if (Size!=size)
        throw NoMemory();
      if ((List2=new list<T>())==NULL)
        throw NoMemory();
    }

    catch (NoMemory NM )
    {
      NM.PrintMessage();
    }


    for (int i=0;i<Size;i++)
    {
      pos=NewOrder[i];
      List2->insertElement(GetElement(GetNode(pos)));
    }

    Empty();
    NodePointer p=List2->GetFirst();
    while (p!=NULL)
    {
      insertElement(List2->GetElement(p));
      cout <<"inserted";
      p=List2->GetNext(p);
    }

zaparr(List2);
//cout <<print() <<"\n";

    //  cout <<"Sorting has finished\n";
  }
  /*____________________________________________________________ */

  template <class T>  void list<T>::Order(bool ascendent=true)
  {
    typename list<T>::NodePointer IndPosition=GetFirst();

    int i=0, listSize=Size;
    T *List2=NULL;
    try
    {
      if ((List2=new T[listSize])==NULL)
        throw NoMemory();
    }
    catch (NoMemory NM )
    {
      NM.PrintMessage();
    }
    ;
    while (IndPosition!=NULL)
    {
      List2[i]=IndPosition->element;
      IndPosition=GetNext(IndPosition);
      i++;
    }
    if (ascendent) qsort ((void*)List2, listSize, sizeof (T), compare<T>);
    else   qsort ((void*)List2, listSize, sizeof(T), compareinv<T>);

    Empty();

    for (int i=0;i<listSize;i++)
      insertElement(List2[i]);

    zaparr(List2);
  }
  /*____________________________________________________________ */

  template <class T> bool list<T>::IsEmpty()
  {
    return List==NULL;
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::Empty()
  {
    if (List!=NULL)
    {
      destroy(List);
  //    Size=0;
    }
  }
  /*____________________________________________________________ */

  template <class T> void list<T>::Remove(bool* PosList)
  {
    // PosList contains true in positions to be removed

    int pos, i=0;

    try
    {
      if (Size!=sizeof(*PosList))
        throw NoMemory();
    }

    catch (NoMemory NM )
    {
      NM.PrintMessage();
    }

    NodePointer p=GetFirst(), oldp;

    while (p!=NULL)
    {
      if (PosList[i]==true)
      {
        oldp=p;
        p=GetNext(p);
        this->removeNode(oldp);
      }
      else p=GetNext(p);
    }


    cout <<"Sorting has finished\n";
  };
  /*____________________________________________________________________________________ */


  template<class T> bool list<T>::isOrdered(bool ascendent=true)
  {

    // it returns a pointer to the element in the list which has the closest upper value than argument
    typename list<T>::NodePointer pk=GetFirst(), pk2=NULL;
    T  NextValue, OldValue=GetElement(pk);

    if (pk!=NULL) pk=GetNext(pk);
    while (pk!=NULL)
    {
      NextValue=GetElement(pk);

      if ((ascendent && compareElement(NextValue,OldValue)==-1) || (!ascendent && compareElement(NextValue,OldValue)==1)) return false;

      OldValue=NextValue;
      pk=GetNext(pk);
    }
    return true;

  };
  /*___________________________________________________________ */

  template<class T> typename list<T>::NodePointer list<T>::GetClosestGreaterPointerToElement(T argument, bool checkOrder=true)
  {
    // it returns a pointer to the element in the list which has the closest upper value than argument, assuming elements are ordered
    if (checkOrder==true && !isOrdered())
    {
      cout <<"Error in list<T>::GetClosestGreaterPointerToElement, not ordered";
      exit(0);
    }
    NodePointer pk=GetFirst(), pk2=NULL;
    T NextValue, ClosestValue=GetElement(pk);
    while (pk!=NULL)
    {
      NextValue=GetElement(pk);

      if (compareElement(NextValue,argument)==1) return pk;

      pk=GetNext(pk);
    }
  };
  /*___________________________________________________________ */

  template<class T> T list<T>::GetMaxElement()
  {
    return GetExtremeElement(true);
  };
  /*___________________________________________________________ */

  template<class T> T list<T>::GetMinElement()
  {
    return GetExtremeElement(false);
  };
  /*___________________________________________________________ */

  template<class T> T list<T>::GetExtremeElement(bool max=true)
  {
    // it returns a pointer to the element in the list which has the closest upper value than argument

    typename list<T>::NodePointer p=GetFirst();

    T maxElement;
    if (p!=NULL) maxElement=GetElement(p);

    while (p!=NULL)
    {
      if ((compareElement(GetElement(p), maxElement)==1 && max)  || (compareElement(GetElement(p),maxElement)==-1 && max==false)) maxElement=GetElement(p);
      p=GetNext(p);
    }
    return maxElement;
  };
  /*___________________________________________________________ */

  template<class T> typename list<T>::NodePointer list<T>::findElement(T element)
  {
    // it returns a pointer to the first element in the list equal to the argument
    typename list<T>::NodePointer p=GetFirst();

    while (p!=NULL)
    {
       if (compareElement(GetElement(p),element)==0) return p;
      p=GetNext(p);
    }
    return NULL;
  };

   /*___________________________________________________________________________________*/
/*
  template <class T>  void list<T>::hardCopy(char filename[256])
  {

	  
    ofstream  OutputFile;
    OpenOutput(filename, &OutputFile);

	filename >> print();

	 OutputFile.close();
  }
  /*___________________________________________________________ */

  template<class T> void list<T>::copyPaste(list<T>* otherList)
  {
	  try{

		  if (otherList==NULL) throw NullValue();
    typename list<T>::NodePointer p=otherList->GetFirst();


    while (p!=NULL)
    {
      insertElement(otherList->GetElement(p));
      p=otherList->GetNext(p);
    }
	  }
	    catch (NullValue null)
    {
      null.PrintMessage("in list::copyPaste");
    }

  }
 
/*______________________________________________________*/

     template<class T> ostream& operator<<(ostream& out, const list<T>& p)
{
	out << p.print();
	return out;
}
  /*___________________________________________________________________________________*/

  template <>  string list<string>::print(bool forward)
  {
   char line[maxline];
    string pattern;
    list<string>::NodePointer p;
	if (forward) p=GetFirst(); else p=GetLast();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
        pattern=GetElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%s", pattern.c_str());
        else sprintf(line, "%s, %s", line, pattern.c_str());
        if (forward) p=GetNext(p); else p=GetPrevious(p);
    }
return string(line);
  }
   /*___________________________________________________________________________________*/

  template <>  string list<float>::print(bool forward)
  {
  string result;
    char line[maxline];
    float pattern;
    list<float>::NodePointer p;
	if (forward) p=GetFirst(); else p=GetLast();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
          pattern=GetElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%0.4f", pattern);
        else sprintf(line, "%s, %0.4f", line, pattern);
        if (forward) p=GetNext(p); else p=GetPrevious(p);
    }
result=string(line);
    return result;
  }
    /*___________________________________________________________________________________*/

  template <>  string list<int>::print(bool forward)
  {
    char line[maxline];
    string result;
    int pattern;
    list<int>::NodePointer p;
		if (forward) p=GetFirst(); else p=GetLast();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
          pattern=GetElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%d", pattern);
        else sprintf(line, "%s, %d", line, pattern);
        if (forward) p=GetNext(p); else p=GetPrevious(p);
    }
result=string(line);
    return result;
  }
/*___________________________________________________________________________________*/
	
	template <class T> list<T>* list<T>::ExtractList(int indexVector[], int size)//
	{
	list<T>* newList=new list<T>(*this);
        newList->selectElements(indexVector, size);
        this->filterElements(indexVector, size);
        return newList;
	};
	
	
  /*___________________________________________________________________________________*/

  template <class T> list<T>* list<T>::ExtractList(int TotalElements)//
  {
    //it randomly extracts TotalElements from the original sample and put them in a new list
    int elegido;
    NodePointer p;
    T e; 
    list<T>* newList=new list<T>();

    //cout <<"TotalPrueba:" << TotalPrueba;
    //cout <<"size:" << splittedSample.trainingSample->list<InputAttributesPattern*>::GetSize();
    for (int contador=0;contador<TotalElements;contador++)
    {
      if (GetSize()<=0)
      {
        cout <<"error for " << contador;
        exit(0);
      }
      elegido=rand() % GetSize();
      p=GetNode(elegido);
      newList->insertElement(GetElement(p));
      e=p->element;
      UnlinkElement(p);
      deleteElement(e);
 
    }
    return newList;
  }
	
  /*___________________________________________________________________________________*/

  template <class T> T list<T>::GetLastElement ()
  {
    return this->GetElement(this->GetLast());
  };
  /*___________________________________________________________________________________*/

  template <class T> T list<T>::GetFirstElement ()
  {
    return this->GetElement(this->GetFirst());
  };


  /* _____________________________________________________*/

  template<> int list<int>::ReadElement (ifstream * source, char* tokens)
  {
    char* genotypebuf=NULL;
    genotypebuf=CaptureLine(source);
    int val=atol(genotypebuf);
    zap(genotypebuf);
    return val;

  };
  /* _____________________________________________________*/

  template<> double list<double>::ReadElement (ifstream * source, char* tokens)
  {
    char* genotypebuf=NULL;
    genotypebuf=CaptureLine(source);
    float val=atof(genotypebuf);
    zap(genotypebuf);
    return val;
  };
  /* _____________________________________________________*/

  template<> string list<string>::ReadElement (ifstream * source, char* tokens)
  {
    char* genotypebuf=NULL;
    genotypebuf=CaptureLine(source);
    string val=genotypebuf;
    zap(genotypebuf);
    return val;
  };
 
  /* _____________________________________________________*/
  //  template <class U> typename T::NodePointer findFinalElement(U element);
 // template<class T, class U> typename list<U>::NodePointer list<list<U> >::findFinalElement(U element);//
/*
 template<class T, class U> typename T::NodePointer list<T >::findFinalElement(U element)//
  {
 typename list<T >::NodePointer p=this->GetFirst();
typename T::NodePointer pp;

 while (p!=NULL)
{
pp=GetElement(p)->findElement(element);
if (pp!=NULL) return p;
p=this->GetNext(p);
}
return NULL;

  };
*/


} // end namespace
#endif

/* Fin Fichero: list.cpp */
// void zap<list<float>::node*>(list<float>::node*&);


