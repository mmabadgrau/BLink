  /**
    * @file ManageTable.cpp
    * @brief Program to resolve phase
    *
    */

#include "Fachade.h"
/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<operation (default is 0: transpose)>\n";
        exit(0);
        }
     char filename[128], filename2[128];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}
int operation=0;
if (argc==4) 
operation=atoi(argv[3]);


ofstream OutputFile;
OpenOutput(filename2, &OutputFile);

Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename);	
//Sample<string, list, ListOfPointers> * result=l->transpose();	

int totalColumns=l->GetFirstElement()->GetSize();
Container<string, list>* column, *reverseColumn;
int totalRows=l->GetSize();
for (int i=0;i<totalColumns;i++)
{
column=l->getColumn(i);
if (column==NULL) {cout <<"Error"; end();}

if (column->GetSize()!=totalRows)
{
cout <<"Error, column " << i <<" has only " << column->GetSize() <<" and should have " << totalRows;
}
//reverseColumn=column->reverse();

OutputFile << column <<"\n";
delete(column);
}
/*
	if (forward) p=GetFirst(); else p=GetLast();
    strcpy(line, "\0");
  list<string>::NodePointer p=column->GetLast();

     while (p!=NULL)
    {
        pattern=GetElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%s", pattern.c_str());
        else sprintf(line, "%s, %s", line, pattern.c_str());
        if (forward) p=GetNext(p); else p=GetPrevious(p);
    }

}
*/
OutputFile.close();

cout <<"\nResults have been saved in file " << filename2 <<"\n";



}










