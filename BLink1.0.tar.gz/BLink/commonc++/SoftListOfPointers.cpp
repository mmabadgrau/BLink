/* File: ListOfPointers.cpp */


#ifndef __SoftListOfPointers_cpp__
#define __SoftListOfPointers_cpp__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.h"
#include "AttPattern.h"
#include "SoftListOfPointers.h"
//#include "SoftListOfPointers.h"
//#include "Diplotype.h"


/**
    @memo Declaration of a SoftListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* SoftListOfPointers DEFINITION */
  /************************/


  /**
          @memo SoftListOfPointers 
   
  	@doc
          Definition:
          A set of SoftListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the SoftListOfPointers
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

  
  /*___________________________________________________________ */
/*
  template<class T> typename SofListOfPointers<T>::NodePointer SofListOfPointers<T>::GetClosestGreaterPointerToElement(T* argument, bool checkOrder=true)
  {

    if (checkOrder==true && !isOrdered())
    {
      cout <<"Error in list<T>::GetClosestGreaterPointerToElement, not ordered";
      exit(0);
    }
    // it returns a pointer to the element in the list which has the closest upper value than argument
    typename SofListOfPointers<T>::NodePointer pk=SofListOfPointers<T>::GetFirst(), pk2=NULL;
    if (pk==NULL) return NULL;
    T * NextValue, *ClosestValue=GetElement(pk);

    while (pk!=NULL)
    {
      NextValue=GetElement(pk);

      if (*NextValue>*argument) return pk;

      pk=GetNext(pk);
    }
    return NULL;
  };
  /*____________________________________________________________ */
 
   template <class T>  SoftListOfPointers<T>::~SoftListOfPointers(){};
  /*____________________________________________________________ */

    template <class T>  SoftListOfPointers<T>::SoftListOfPointers():list<T*>(){};;
  /*____________________________________________________________ */

    template <class T>  SoftListOfPointers<T>::SoftListOfPointers(SoftListOfPointers &source):list<T*>(source){};
  /*____________________________________________________________ */

    template <class T>  SoftListOfPointers<T>::SoftListOfPointers(char* filename, char* tokens):list<T*>(filename, tokens){};

	/*---------------------------------------------------------------*/

//	template <class T>  SofListOfPointers<T>::SoftListOfPointers (list<T*> &source, list<int> *Sampling):list<T*>(source, Sampling)  {};
  
	/*---------------------------------------------------------------*/
	
	template <class T> ComparisonType SoftListOfPointers<T>::compareElement(T *arg1, T *arg2)
	{
		if(*arg1 < *arg2) return lower;
		else if(*arg1 > *arg2) return greater;
		else return equal;
	}

	
  /*___________________________________________________________________________________*/

  template <class T>   string SoftListOfPointers<T>::print(bool forward)
  {
/*
    char line[maxline];
    T* pattern;
    typename SoftListOfPointers<T>::NodePointer p;
	if (forward) p=this->GetFirst(); else p=this->GetLast();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
        pattern=GetElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%s\n", pattern->print().c_str());
        else sprintf(line, "%s%s\n", line, pattern->print().c_str());
        if (forward) p=this->GetNext(p); else p=this->GetPrevious(p);
    }

    return string(line);
*/
string a;
return a;
  }
    /*___________________________________________________________________________________*/
/*
  template <class T>   void SoftListOfPointers<T>::modularPrint(bool forward)
  {
    char line[maxline];
    T* pattern;
    typename SoftListOfPointers<T>::NodePointer p;
	if (forward) p=this->GetFirst(); else p=this->GetLast();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
        pattern=GetElement(p);
        cout<< "\n" << pattern->print();
        
        if (forward) p=this->GetNext(p); else p=this->GetPrevious(p);
    }

    }
  /*____________________________________________________________ */
	
	template <class T>   void SoftListOfPointers<T>::Order(bool ascendent)
	{
		
		typename SoftListOfPointers<T>::NodePointer IndPosition=this->GetFirst();
		
		int i=0, listSize=this->Size;
		T **List2=NULL;
		try
		{
			if ((List2=new T*[listSize])==NULL)
				throw NoMemory();
		}
		
		catch (NoMemory NM)
		{
			NM.PrintMessage();
		};
		while (IndPosition!=NULL)
		{
			List2[i]= new T(*this->GetElement(IndPosition));//required for qsort
			IndPosition=this->GetNext(IndPosition);
			i++;	
		}
	
		if (ascendent) qsort ((void*)&List2[0], listSize, sizeof (T*), comparePointer<T>);
		else   qsort ((void*)&List2[0], listSize, sizeof(T*), compareinvPointer<T>);	
	
		this->SoftListOfPointers<T>::Empty();	
	
		for (i=0;i<listSize;i++)
{
//if (i==0 || !(*List2[i]==*List2[i-1]))
		 this->SoftListOfPointers<T>::insertElement(List2[i]);	

//cout <<"at " << i << " is:" << *List2[i] <<" versus " << *List2[i-1];			
}
	        zaparr(List2, listSize);
				
	};

/*___________________________________________________________ */

   template <class T> typename SoftListOfPointers<T>::NodePointer SoftListOfPointers<T>::findElement(T* element)
  {
    // it returns a pointer to the first element in the list equal to the argument
    typename SoftListOfPointers<T>::NodePointer p=this->GetFirst();

    while (p!=NULL)
    {
       if (this->compareElement(this->GetElement(p),element)==0) return p;
      p=this->GetNext(p);
    }
    return NULL;
  };	
/*___________________________________________________________ */

 template <class T> void* SoftListOfPointers<T>::findElement(void* element)
  {
  try
  {
          if (element==NULL)
	  throw NullValue();
	   }
	    catch (NullValue null)
    {
      null.PrintMessage("in SoftListOfPointers::findElement");
    }
	  return this->SoftListOfPointers<T>::findElement((T*)element);
  };
    	/*___________________________________________________________________________________*/

  template <class T>   typename SoftListOfPointers<T>::NodePointer  SoftListOfPointers<T>::findFinalElement(void* element)//
  {
 typename SoftListOfPointers<T>::NodePointer p=this->GetFirst();
 T * secondContainer;
void* pp=NULL;
 while (p!=NULL)
{
	 secondContainer=GetElement(p);
     pp=(void*) secondContainer->findElement(element);
if (pp!=NULL) return p;
p=this->GetNext(p);
}
return NULL;

  };
  /*______________________________________________________*/

     template<class T> ostream& operator<<(ostream& out, SoftListOfPointers<T>& lista)
{
    T* pattern;
    typename SoftListOfPointers<T>::NodePointer p=lista.GetFirst(); 
    while (p!=NULL)
    {
        pattern=lista.GetElement(p);
        out<< "\n" << *pattern;
        p=lista.GetNext(p); 
    }
    return out;
}

} // end namespace
#endif

/* Fin Fichero: SoftListOfPointers.cpp */
