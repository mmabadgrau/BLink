/* File: DiagonalTable.h */


#ifndef __tabla_h__
#define __tabla_h__

#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"

using namespace std;

namespace BIOS {

/////////////////////////////////////////
template <class T> class DiagonalTable //
{//
// it is a 2D table with only the element at one side of a diagonal plus the diagonal
private:
int sizeX, sizeY;
T* table;
int size;
public:
DiagonalTable(int sizeX, int sizeY=0) {if (sizeY==0) this->sizeY=sizeX; else this->sizeY=sizeY; this->sizeX=sizeX; size=this->sizeX*(this->sizeY-1)/2; table=new T[size];};
~DiagonalTable(){zaparr(table);};
void setValue(int posX, int posY, T value) {table[getPos(posX, posY)]=value;};
int getFirstPosInSameRow(int posX){if (posX==0) return 0; return sizeY*posX-getGauss(posX);};
int getPos(int posX, int PosY) {return getFirstPosInSameRow(posX)+(sizeX-posX-1)-(sizeY-PosY-1);};
T getValue(int posX, int posY) {return table[getPos(posX, posY)];}
void initialize(T value){for (int i=0;i<size;i++) table[i]=value;};
int getSizeX(){return sizeX;};
int getSizeY(){return sizeY;};
 
};//

 template <class T> ostream& operator<<(ostream& out, DiagonalTable<T>& p)
  {
for (int i=0;i<p.getSizeX();i++)
{
for (int j=0;j<p.getSizeY();j++)
if (j<=i) out <<"-\t";
else out << p.getValue(i,j) <<"\t";
out <<"\n";
}
    return out;
  }
//#include "DiagonalTable.cpp"
}
#endif
