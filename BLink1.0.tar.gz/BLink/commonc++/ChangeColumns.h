/* File: ChangeColumns.h */


#ifndef __ChangeColumns_h__
#define __ChangeColumns_h__


#include <string>
#include <stdio.h>


#include "ExceptionsBasic.h"

namespace BIOS {

  /**



/************************/
/* ChangeColumns DEFINITION */
/************************/


/**
        @memo ChangeColumns for text files separated by tabs, commas or blanks or remove a column or add an id column at the first position

	@doc
        Definition:
        A set of ChangeColumns's features for each individual

        Memory space: O(SizeP), which SizeP being the number of individuals in the sample

    @author Maria M. Abad
	@version 1.0
*/
      typedef  char value[128];


class ChangeColumns {

  protected:
    /** @name Implementation of class ChangeColumns
        @memo Private part.
    */


   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
    int TotalRows;

    /**
       @memo Number of rows
       @doc  Used to declare an array of this length
    */

      unsigned int TotalColumns;


	  
    /**
       @memo if there is ChangeColumns information in the sample
       @doc  boolean, 1: yes, 0, no
    */

	int Column, NewPos;


value TextId;

   struct Row {

 value *ListOfValues;
	  
	  /**
      @memo Next
      @doc It contains a pointer to the following row
      */
Row *Next;

	  
	  /**
      @memo Next
      @doc It contains a pointer to the Previous Row 
      */
    Row *Previous;

   };  // end structure Row

 Row *TheFirstRow;

/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

////////////////////////////////////////////
void ChangeColumns::destroy(Row * ind);

void copy(Row * Target, const Row * Origen);

short int ReadRow (Row * Target, ifstream * Origen);

/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


      /**
         @memo Destructor
	 @doc
           Deallocate memory used by ChangeColumns.
           Time complexity O(1).

      */
      ~ChangeColumns ();
//////////////////////////////////////////////




      /** @name Operations on ChangeColumns 
        @memo Operations on a ChangeColumns 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
      ChangeColumns(const unsigned int TotalRows);
  /////////////////////////////////////////////
      /**
         @memo Copy constructor
         @param target: ChangeColumns where will be copy
         @param origen: ChangeColumns to copy
         @doc
           Make a copy of ChangeColumns
           Time complexity in time O(1).
        */
      ChangeColumns (const ChangeColumns & origen);


  /////////////////////////////////////////////
      /**
         @memo Constructor from input buffer
         @param file: file position in which is the ChangeColumns who will be copy
         @param origen: ChangeColumns to read
         @doc
           Read an ChangeColumns
           Time complexity in time O(1).
        */
	  ChangeColumns (char* filename, const char* filename2, const unsigned int InputTotalRows, const unsigned int TotalColumns, const int Column, const int NewPos, value TextId);

     // ChangeColumns (const ChangeColumns & origen, istream* file, const typefile tf);

///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: ChangeColumns to copy.
         @return Reference to the receptor ChangeColumns.
	 @doc
           Copy the ChangeColumns in the receptor ChangeColumns.
           Time complexity O(1).

      */
      ChangeColumns& operator=(const ChangeColumns & ind);
////////////////////////////////////////////////////
   
      /**
         @memo Is equal
         @param g: ChangeColumns to compare with.
	 @return
           Return true if the SNP is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const ChangeColumns & ind);
      /**
         @memo Is different
         @param g: ChangeColumns to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const ChangeColumns & ind);

	        /**
         @memo Obtain the first ChangeColumns in the sample.
         @return return a pointer to the first ChangeColumns in the sample
         Time complexity O(1)

      */
	  Row* GetFirst ();

      /**
         @memo Obtain the Next ChangeColumns in the sample.
         @param The pointer to the current ChangeColumns
         @return return a pointer to the Next ChangeColumns in the sample
         Time complexity O(1)

      */
        Row* GetNext (const Row* ind);


		ChangeColumns::Row* ChangeColumns::GetRow(const unsigned int k);

		 /**
         @memo Check if is a child.
         @param The pointer to the current individual's ChangeColumns
         @return return a boolean reporting if is a child
         Time complexity O(1)


      */
        Row* GetChangeColumns (unsigned int k);             

      /**
         @memo Obtain the sample SizeP.
         @return the size of a sample
         @doc Return the number of ChangeColumnss in the sample. This value
         is in the variable SizeP.
         Time complexity O(1)

   
 
      */
        unsigned int GetTotalColumns ();          

        unsigned int GetTotalRows ();          

  


		  /**
         @memo Print the ChangeColumns for an individual.
         @param Position: Position of this individual in the sample
         Time complexity O(1)

      */
	  void PrintChangedColumns (const char * filename2, short int sep);
	  void PrintChangedPosColumns (const char * filename2, short int sep);

	  	  /**
         @memo Print the sample changing columns by rows.
         @param Position: Position of this individual in the sample
         Time complexity O(1)

      */
	  void PrintInvertedMatrix (const char * filename2);


};  // End of class ChangeColumns



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/////////////////////////////////////////////
void ChangeColumns::destroy(Row * ind)
{

       		if(ind != NULL)
			{
			destroy (ind->Next);
			if (ind->ListOfValues!=NULL)
              delete ind->ListOfValues;
			delete ind;
			}
            
}
//////////////////////////////////////////

void ChangeColumns::copy(Row * Target, const Row * Origen)
{

   if ((Target->ListOfValues=new value[TotalColumns])==NULL)
    throw NoMemory();

	for (int i=0;i<TotalColumns;i++)
	 strcpy(Target->ListOfValues[i], Origen->ListOfValues[i]);
	Target->Previous=Origen->Previous;

 		 
         if (Origen->Next!=NULL)
		 {
		   if ((Target->Next=new Row)==NULL)
            throw NoMemory();
          Target->Next->Previous=Target;
          copy(Target->Next,Origen->Next);     
		 }  
		 else Target->Next=NULL;

		 TotalRows++;

}




///////////////////
short int  ChangeColumns::ReadRow (Row * target, ifstream*  origen)
{
short int sep=0;
	char *genotypebuf, *cad, *cadena;
    if ((genotypebuf=new char[TotalColumns*130])==NULL)
     throw NoMemory();
    if ((cadena=new char[128])==NULL)
     throw NoMemory();


	origen-> getline (genotypebuf, TotalColumns*130, '\n');
    if (strstr(genotypebuf, ",")!=NULL) 
		sep=1;
	else
    if (strstr(genotypebuf, "\t")!=NULL) 
		sep=2;

	for (int i=0;i<TotalColumns;i++)
	{
	if (i==0)
	cad = strtok (genotypebuf,", \t");
	else
	cad = strtok (NULL,", \t");
	sscanf (cad, "%s", cadena);
	strcpy(target->ListOfValues[i],cadena);
//	cout <<" " << target->ListOfValues[i];
	}
    

	
	assert (genotypebuf!=NULL);
	delete genotypebuf;
		
	assert (cadena!=NULL);
	delete cadena;
  
    if (origen->peek()!=EOF)
	{
	if ((target->Next=new Row)==NULL)
      throw NoMemory();
	if ((target->Next->ListOfValues=new value[128])==NULL)
      throw NoMemory();
		sep=ReadRow (target->Next, origen);
	}
	else target->Next=NULL;
    TotalRows++;

//	cout <<"\n";
return sep;
}

///////////////////
//// public ////////
///////////////////

ChangeColumns::ChangeColumns(const unsigned int TotalRows)
{
 ChangeColumns::TotalRows=TotalRows;

 try
 {
 TheFirstRow = new Row;
 }
  catch (NoMemory wm) {
                wm.PrintMessage();

 }

 try
 {
 TheFirstRow->ListOfValues = new value[TotalColumns];
 }
  catch (NoMemory wm) {
                wm.PrintMessage();

 }


  TheFirstRow=NULL;
}

/*____________________________________________________________ */

ChangeColumns::ChangeColumns (const ChangeColumns & origen)
{

	
  TotalColumns=origen.TotalColumns;
  TotalRows=0;

  if (&origen==NULL)
   TheFirstRow=NULL;
  else
  {
  try {
	   if ((TheFirstRow = new Row)==NULL)
	    throw NoMemory();
        copy (TheFirstRow, origen.TheFirstRow);
		if (TotalRows!=origen.TotalRows)
         throw BadSize();
  }
  catch (NoMemory no) {
                no.PrintMessage();
		}
catch (BadSize bs) {
                bs.PrintMessage("ChangeColumns.h");
		}
  }

}

/*____________________________________________________________ */

ChangeColumns::ChangeColumns (char* filename, const char* filename2, const unsigned int TotalRows, const unsigned int TotalColumns, const int Column, const int NewPos, value TextId=NULL)
{
	// NewPoa=-1: REMOVE COLUMN
short int sep;
ifstream InputFile; 
ChangeColumns::TotalRows=0;
ChangeColumns::Column=Column;
ChangeColumns::NewPos=NewPos;
ChangeColumns::TotalColumns=TotalColumns;
if (TextId!=NULL)
strcpy(ChangeColumns::TextId,TextId);
try
{
	InputFile.open (filename, ifstream::in);
	 if (InputFile.peek()==EOF)
		throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(filename);
   }

try {
if ((this->TheFirstRow=new Row)==NULL)
      throw NoMemory();
if ((this->TheFirstRow->ListOfValues=new value[128])==NULL)
      throw NoMemory();

//cout << "Reading Instances from " << filename <<" ...\n";
sep=ChangeColumns::ReadRow (this->TheFirstRow, &InputFile);
InputFile.close();

if (TotalRows != ChangeColumns::TotalRows)
{
	cerr << "\nThere are " << ChangeColumns::TotalRows <<" rows in the file but you have especified that the number is " << TotalRows;
}
//cout << "Writing Instances to " << filename2 <<" ...\n";

if (Column==-2) // format changing except matrix invertion
ChangeColumns::PrintChangedColumns (filename2, sep);
else
if (Column==-1) // format changing except matrix invertion
ChangeColumns::PrintInvertedMatrix(filename2);
else
ChangeColumns::PrintChangedPosColumns (filename2, sep);


}
catch (NoMemory no) {
  no.PrintMessage();
  }



/*
if (Column!=-2)
cout << "Columns have been moved ...\n";
else
cout << "An id column will be added with the text " << TextId << " ...\n";
*/
}

/*____________________________________________________________ */

ChangeColumns::~ChangeColumns ()
{
	if (TheFirstRow!=NULL)
                destroy(TheFirstRow);

}



 /*____________________________________________________________ */

ChangeColumns::Row*  ChangeColumns::GetFirst()
{

    return TheFirstRow;
  }



/*____________________________________________________________ */

ChangeColumns::Row* ChangeColumns::GetNext(const ChangeColumns::Row *i)
{

  if (i==NULL) {
    throw NullValue();
	 return 0;
  }
  else {
  return i->Next;
  }
}



/*____________________________________________________________ */

ChangeColumns::Row* ChangeColumns::GetRow(const unsigned int k)
{
  ChangeColumns::Row *i;

  i=TheFirstRow;
  try {
  for (int c=0;c<k;c++)
      i=i->Next;
  }
  catch (NullValue null) {
    null.PrintMessage();
    }

  return i;
}


/*____________________________________________________________ */


unsigned int ChangeColumns::GetTotalRows()
{
  return TotalRows;
}



/*____________________________________________________________ */

void ChangeColumns::PrintChangedColumns (const char * filename2, short int sep)
{
// Column=-2 and NewPos=-2; add an id column at the first position
// NewPos=-1; remove Column

	ofstream target;

target.open (filename2, ifstream::out);
Row* Instance=TheFirstRow;
char sepcad[3];
if (Column==-2) NewPos=-2;
 switch (sep)
 {
	case 0: strcpy(sepcad, " "); break;
	case 1: strcpy(sepcad, ", "); break;
	case 2: strcpy(sepcad, "\t "); break;
 }
for (int r=0;r<TotalRows;r++)
{
if (Column==-2)
 target << TextId << r+1 << ' ';
for (int i=0;i<TotalColumns;i++)
{
if ((i!= Column && i!=NewPos) || (Column==NewPos) || (i!=Column && NewPos==-1) || (Column==-1))
{
 target << Instance->ListOfValues[i];
 if (i!=(TotalColumns-1)) target << sepcad;
}
if (Column!=-2)
{
if (Column!=NewPos && NewPos!=-1)
if (i==NewPos)
if (Column>NewPos)
{
 target << Instance->ListOfValues[Column] << sepcad;
 target << Instance->ListOfValues[i]  << sepcad;
}
else
{
 target << Instance->ListOfValues[i] << sepcad;
 target << Instance->ListOfValues[Column]  << sepcad;
}
}
}

target << '\n';

Instance=GetNext(Instance);
}

target.close();

}
/*____________________________________________________________ */

void ChangeColumns::PrintChangedPosColumns (const char * filename2, short int sep)
{
// Column=-2 and NewPos=-2; add an id column at the first position
// NewPos=-1; remove Column

	ofstream target;

target.open (filename2, ifstream::out);
Row* Instance=TheFirstRow;
char sepcad[3];
 switch (sep)
 {
	case 0: strcpy(sepcad, " "); break;
	case 1: strcpy(sepcad, ", "); break;
	case 2: strcpy(sepcad, "\t "); break;
 }
for (int r=0;r<TotalRows;r++)
{
for (int i=0;i<TotalColumns;i++)
{
if ((i!= Column && i!=NewPos) || (Column==NewPos) || (i!=Column && NewPos==-1))
{
 target << Instance->ListOfValues[i];
 if (i!=(TotalColumns-1)) target << sepcad;
}
{
if (Column!=NewPos)
if (i==NewPos)
if (Column>NewPos)
{
 target << Instance->ListOfValues[Column] << sepcad;
 target << Instance->ListOfValues[i];
 if (i!=(TotalColumns-1)) target << sepcad;
}
else
{
 target << Instance->ListOfValues[i] << sepcad;
 target << Instance->ListOfValues[Column];
 if (i!=(TotalColumns-1)) target << sepcad;
}
}
}

target << '\n';

Instance=GetNext(Instance);
}

target.close();

}
/*____________________________________________________________ */

void ChangeColumns::PrintInvertedMatrix (const char * filename2)
{
// Column must be -1; 

	ofstream target;

target.open (filename2, ifstream::out);

Row* Instance;

for (int r=0;r<TotalColumns;r++)
{
Instance=TheFirstRow;
for (int i=0;i<TotalRows;i++)
{
 target << Instance->ListOfValues[r] << ' ';
 Instance=GetNext(Instance);
}
target << '\n';
}

target.close();

}
/*____________________________________________________________ */


};  // Fin del Namespace

#endif

/* Fin Fichero: ChangeColumns.h */
