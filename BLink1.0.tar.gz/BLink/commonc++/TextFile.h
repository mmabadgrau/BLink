#ifndef TextFile_h//
#define TextFile_h//



#include <fstream>
#include <string>
#include <stdio.h>//
#include <iostream>//
#include <cassert>//
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//
#include <ctime>//
#include <malloc.h>//
#include <fstream>//
#include <math.h>
#include "basic.cpp"
#include "list.cpp"


/**
 *
 * @author mabad
 */

namespace BIOS {

class TextFile  {
    
    char fileName[256];
    ifstream InputFile;
    ofstream OutputFile;
    int totalLines;
bool input;
    public:
		
		~TextFile(){if (input) InputFile.close(); else OutputFile.close();};
		TextFile(char fileName[256], bool input=true);
		void OpenOutput();
void print();
bool eof();
int getTotalLines();
stringList* readLine(char* tokensSource="\t ,\n\r"); 
};
/*_______________________________________________________________________________________*/

TextFile::TextFile(char fileName[256], bool input)
		{
this->input=input;
		 strcpy(this->fileName,fileName);
  		totalLines=GetTotalLines(fileName);
if (input)
 OpenInput(fileName, &InputFile);
else
 OpenOutput();

        };

/*_______________________________________________________________________________________*/

 void TextFile::OpenOutput() 
 {
  BIOS::OpenOutput(fileName, &OutputFile);
 };

/*_______________________________________________________________________________________*/

void TextFile::print() 
{
for (int i=0; i < totalLines; i++)
{
cout << *readLine() <<"\n";
};
};

/*_______________________________________________________________________________________*/

int TextFile::getTotalLines() 
{
 return totalLines;
};
    /*_______________________________________________________________________________________*/

   stringList* TextFile::readLine(char* tokensSource) 
   {
	   if (eof())
	   {
		   cout <<"Error in TextFile::readLine. End of File";
		   end();
	   }
	     	char* genotypebuf=NULL;
		genotypebuf=CaptureLine(&InputFile);

      stringList* line=getList (genotypebuf, tokensSource);
        zaparr(genotypebuf);
	if (line->GetSize()>0)	  
        return line;
	else 
{
zap(line);
return NULL;
}
};
      /*_______________________________________________________________________________________*/

   bool TextFile::eof() 
   {
	   return InputFile.eof() || InputFile.peek()==EOF;
   }
   /*_______________________________________________________________________________________*/
   /*
     list<string>* getWordsInLine(int lineNumber, char* separators){
        
          ArrayList aL=null;
             TextLine *tLine;// =new TextLine(bufferendReader, separators);
        int total=0;
        try
        {
            BufferedReader bufferedReader=new BufferedReader(new FileReader(fileName));
          
     
        while (total<lineNumber && bufferedReader!=null)
        {
            total++;
            bufferedReader.readLine();
        };
           
        if (total==lineNumber)
        {
         tLine=new TextLine(bufferedReader, separators);
         aL= tLine.getWordsInLine();
      //     JOptionPane.showMessageDialog(null,"total:"+aL.size());
        }
      
              }
        catch (IOException exception){
            JOptionPane.showMessageDialog(null,"Error when reading file "+fileName+".");
                                   
        }  ;   
        return aL;
};
*/
    
} // end namespace
#endif
