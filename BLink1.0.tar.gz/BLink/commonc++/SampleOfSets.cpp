#ifndef SampleOfSetsOfSets_cpp//
#define SampleOfSets_cpp//

#include "SampleOfSets.h"

namespace BIOS 
{
/*
 template<class T, template <class T> class Cont,template <class Cont> class SuperCont> 
Container<T,Cont>* SampleOfSets<T, Cont, SuperCont>::getElement(typename SampleOfSets<T, Cont, SuperCont>::NodePointer p)
{
  try
    {
      if (p==NULL)
        // throw NullValue(" in GetElement");
        throw NullValue();
    }

    catch (NullValue nv)
    {
      nv.PrintMessage("in GetElement");
    }

    return (Container<T,Cont>*) p->element;
}
/*___________________________________________________________________________________*/

template<class T>
  SampleOfSets<T>* SampleOfSets<T>::getCommonNodes (Set<T, ListOfPointers>* otherSet)
  {
  typename SampleOfSets<T>::NodePointer p=this->GetFirst();
  SampleOfSets<T>* result=new SampleOfSets<T>();
  Set<T, ListOfPointers> *e;
  while (p!=NULL)
  {
  e=this->GetElement(p)->getCommonNodes(otherSet);
  result->insertElement(e);
  zap(e);
  p=this->GetNext(p);
  }
  return result;
  }
  /*___________________________________________________________________________________*/

  template<class T> Set<T, ListOfPointers>* SampleOfSets<T>::jointSets ()
  {
  typename SampleOfSets<T>::NodePointer p=this->GetFirst();
  Set<T, ListOfPointers>* result=new Set<T, ListOfPointers>();
   while (p!=NULL)
  {
  result->copyPaste(this->GetElement(p));
  p=this->GetNext(p);
  }
  return result;
  }

  /*___________________________________________________________________________________*/

template<class T> intList* SampleOfSets<T>::getOptimalMaxIntersection (Set<T, ListOfPointers>* otherSet)
 // if no blanket, return NULL
  {
  SampleOfSets<T>* temporal=new SampleOfSets<T>(*this);
  typename SampleOfSets<T>::NodePointer p;
  Set<T, ListOfPointers>* newSet, *temporalArgument=new Set<T, ListOfPointers>(*otherSet);
  Container<T, ListOfPointers> *foundElements;
  int max;
  intList* result=new intList();
  while (temporalArgument->GetSize()>0)
  {
  max=temporal->getMaxIntersection(temporalArgument);
  if (max==-1)
  {
  zap(result);
  zap(temporalArgument);
  zap(temporal);
  return NULL;
  }
  result->insertElement(max);
  foundElements=temporalArgument->copyElementsIn(temporal->GetElement(max));
  temporalArgument->removeElementsIn(temporal->GetElement(max));
  p=temporal->GetFirst();
  while (p!=NULL)
  {
   temporal->GetElement(p)->removeElementsIn(foundElements);
   p=temporal->GetNext(p);
  }
  zap(foundElements);
   }
  zap(temporalArgument);
  zap(temporal);
  if (result->GetSize()==0)
  zap(result);
  return result;
  }
  /*___________________________________________________________________________________*/

  template<class T> int SampleOfSets<T>::getOptimalBlanket (Set<T, ListOfPointers>* otherSet)
// returns the position in the sample which better covers otherSet, -1 if none
  {
//cout <<"argument is " << *otherSet;
  if (otherSet==NULL || otherSet->GetSize()==0) return -1; 
  typename SampleOfSets<T>::NodePointer p=this->GetFirst();
  if (p==NULL) return -1;
  int max=0, i=0;
  Container<T, ListOfPointers>* newSet, *currentMaxSet=NULL;
  currentMaxSet=NULL;
//cout <<"\nOptimal blanket of " << *otherSet << " in " << *this;
//cout <<"FIN";
  while (p!=NULL)
  {
   newSet=this->GetElement(p)->copyElementsIn(otherSet, false);
   if ((currentMaxSet==NULL || newSet->GetSize()< currentMaxSet->GetSize()) && newSet->includes(otherSet))
    {
    max=i;
    zap(currentMaxSet);
    currentMaxSet=new Set<T, ListOfPointers>((Set<T, ListOfPointers>&)*newSet);
//cout <<"found" <<*currentMaxSet;
    }
   zap(newSet);
   p=this->GetNext(p);
   i++;  
  }
  if (currentMaxSet==NULL || currentMaxSet->GetSize()==0) max=-1;
   zap(currentMaxSet);
   return max;
  }
/*___________________________________________________________________________________*/

  template<class T> Set<T, ListOfPointers>* SampleOfSets<T>::getUnionOfIntersections ()
  {
Set<T, ListOfPointers> *result=new Set<T, ListOfPointers>(), *commonNodes;
typename SampleOfSets<T>::NodePointer p=this->GetFirst(), p2;
while (p!=NULL)
{
p2=this->GetNext(p);
while (p2!=NULL)
{
commonNodes=this->GetElement(p)->getCommonNodes(this->GetElement(p2));
 result->copyPaste(commonNodes);
zap(commonNodes);
p2=this->GetNext(p2);
}
p=this->GetNext(p);
};
return result;
}
/*___________________________________________________________________________________*/

  template<class T> intList* SampleOfSets<T>::getBlankets (Set<T, ListOfPointers>* otherSet)
// returns the position in the sample which better covers otherSet, -1 if none
  {
  intList* result;
  int i=0;
  if (otherSet==NULL || otherSet->GetSize()==0) return NULL; 
  typename SampleOfSets<T>::NodePointer p=this->GetFirst();
  if (p==NULL) return NULL;
  result=new intList();
  Container<T, ListOfPointers>* newSet;
  while (p!=NULL)
  {
   newSet=this->GetElement(p)->copyElementsIn(otherSet, false);
   if (newSet->includes(otherSet))
     result->insertElement(i);
   zap(newSet);
   p=this->GetNext(p);
   i++;  
  }
  return result;
  }
  /*___________________________________________________________________________________*/

  template<class T> int SampleOfSets<T>::getMaxIntersection (Set<T, ListOfPointers>* otherSet)
// returns the position in the sample which more elements in common with otherSet, -1 if all have empty set as intersection
  {
  typename SampleOfSets<T>::NodePointer p=this->GetFirst();
  if (p==NULL) return -1;
  int max=0, i=0;
  Container<T, ListOfPointers>* newSet, *currentMaxSet=NULL;
  currentMaxSet=this->GetElement(p)->copyElementsIn(otherSet);
  while (p!=NULL)
  {
   newSet=this->GetElement(p)->copyElementsIn(otherSet);
   if (newSet->GetSize()>currentMaxSet->GetSize() || (newSet->GetSize()==currentMaxSet->GetSize() && this->GetElement(p)->GetSize()<this->GetElement(max)->GetSize()) || currentMaxSet->GetSize()==0)
    {
    max=i;
    zap(currentMaxSet);
    currentMaxSet=new Set<T, ListOfPointers>(*newSet);
    }
   zap(newSet);
   p=this->GetNext(p);
   i++;  
  }
  if (currentMaxSet->GetSize()==0) max=-1;
   zap(currentMaxSet);
   return max;
  }
} // end namespace
#endif
