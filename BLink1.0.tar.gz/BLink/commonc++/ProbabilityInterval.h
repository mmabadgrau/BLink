/* File: ProbabilityInterval.h */


#ifndef __ProbabilityInterval_h__
#define __ProbabilityInterval_h__



using namespace std;

namespace BIOS {



 class ProbabilityInterval: public Pair<Prob>
  {
public:
           ProbabilityInterval(Prob f, Prob s):Pair<Prob>(f, s)  {if (f>s) {cout <<"\nError, not a probability interval"; end();}};
           ProbabilityInterval(ProbabilityInterval* p): Pair<Prob>(p) {First=p->First; Second=p->Second;};
 	   void setValues(Prob f, Prob s) {if (f>s) {cout <<"\nError, not a probability interval"; end();} Pair<Prob>::setValues(f,s);};
  };



}//end namespace


#endif
