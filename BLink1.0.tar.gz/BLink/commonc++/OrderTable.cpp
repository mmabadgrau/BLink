  /**
    * @file ManageTable.cpp
    * @brief Program to resolve phase
    *
    */

#include "Fachade.h"
/* This program perform task with the whole table*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file>" << "0: as strings, 1: as integers(default is 0)\n";
        exit(0);
        };
     char filename[128], filename2[128], * columns;
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

bool asInteger=false;
if (argc==4)
asInteger=atoi(argv[3]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}


ofstream OutputFile;
OpenOutput(filename2, &OutputFile);

if (!asInteger)
{
Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename);

l->Order();	
OutputFile << *l;
zap(l);
}
else

{
Sample<int, list, ListOfPointers> * l2=new Sample<int, list, ListOfPointers>(filename);	
l2->Order();	
OutputFile << *l2;
zap(l2);
}



OutputFile.close();

cout <<"\nResults have been saved in file " << filename2 <<"\n";



}











