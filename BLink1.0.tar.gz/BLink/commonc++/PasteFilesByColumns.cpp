  /**
    * @file PasteFilesByColumns.cpp
    * @brief Program to create a new file by joining each row from the sources
    *
    */

#include "Fachade.h"
/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <input file 2> " << " <output file>   \n";
        exit(0);
        }
     char filename[256], filename2[256], filename3[256];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

   	 strcpy(filename3, argv[3]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename, filename3)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename2, filename3)==0)
{
cout << "error, files must have different names";
exit(0);
}

ofstream OutputFile;
OpenOutput(filename3, &OutputFile);

Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename);	
Sample<string, list, ListOfPointers> * l2=new Sample<string, list, ListOfPointers>(filename2);	
int totalRows=l->GetSize();
if (totalRows!=l2->GetSize())
{
cout <<"Source files must have the same number of rows";
end();
}
Container<string, list>* row, *row2, *targetRow;
Sample<string, list, ListOfPointers>::NodePointer pL=l->GetFirst();
Sample<string, list, ListOfPointers>::NodePointer pL2=l2->GetFirst();
while (pL!=NULL && pL2!=NULL)
{
row=l->GetElement(pL);
row2=l2->GetElement(pL2);
targetRow=new stringList(*row);
targetRow->copyPaste(row2);
OutputFile << *targetRow <<"\n";
delete(targetRow);
pL=l->GetNext(pL);
pL2=l->GetNext(pL2);
}

OutputFile.close();

cout <<"\nResults have been saved in file " << filename3 <<"\n";



}










