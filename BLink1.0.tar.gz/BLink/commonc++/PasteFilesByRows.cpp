  /**
    * @file PasteFilesByRows.cpp
    * @brief Program to create a new file by joining each row from the sources
    *
    */

#include "Fachade.h"
/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <input file 2> " << " <output file>   \n";
        exit(0);
        }
     char filename[256], filename2[256], filename3[256];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

   	 strcpy(filename3, argv[3]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename, filename3)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename2, filename3)==0)
{
cout << "error, files must have different names";
exit(0);
}
/*
ofstream OutputFile;
OpenOutput(filename3, &OutputFile);

Sample<string, list, ListOfPointers> * l;
int totalColumns1, totalColumns2;
for (int i=0;i<2;i++)
{
if (i==0)
l=new Sample<string, list, ListOfPointers>(filename);	
else l=new Sample<string, list, ListOfPointers>(filename2);	

Container<string, list>* row;
Sample<string, list, ListOfPointers>::NodePointer pL=l->GetFirst();

if (pL!=NULL) if (i==0) totalColumns1=l->GetElement(pL)->GetSize();
else
{
totalColumns2=l->GetElement(pL)->GetSize();
if (totalColumns1!=totalColumns2)
{
cout <<"Source files must have the same number of columns";
end();
}
}
int r=0;
while (pL!=NULL)
{
cout <<"\n"<<r;
row=l->GetElement(pL);
OutputFile << *row <<"\n";
pL=l->GetNext(pL);
r++;
}
zap(l);
}
OutputFile.close();
*/
FileCopy(filename, filename3);
FileAppend(filename2, filename3);
cout <<"\nResults have been saved in file " << filename3 <<"\n";



}










