/* File: ListOfVectors.h */


#ifndef __ListOfVectors_h__
#define __ListOfVectors_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.h"
#include "AttPattern.h"
//#include "Diplotype.h"


  /**
      @memo Declaration of a ListOfVectors (FIFO)
      @doc
      */

using namespace UTILS;

namespace BIOS {

/************************/
/* ListOfVectors DEFINITION */
/************************/


/**
        @memo ListOfVectors 

	@doc
        Definition:
        A list of pointers to lists, all of them with the same size 

        Memory space: O(SizeP), which SizeP being the number of elements in the ListOfVectors

    @author Maria M. Abad
	@version 1.0
*/

	
	
template <class T> class ListOfVectors: list<list<T> > {




/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

/////////////////////////////////////////////
void destroy(NodePointer e);

void copy(NodePointer & target, const NodePointer source);

void ReadInfo (ifstream * is, int linesize);

//T ReadElement (ifstream * is, int size) {cout <<"ggg";};

//virtual template <class T> T ListOfVectors<T>::ReadElement(ifstream * is);

/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


      /**
         @memo Destructor
	 @doc
           Deallocate memory used by ListOfVectors.
           Time complexity O(1).

      */
      ~ListOfVectors ();
//////////////////////////////////////////////




      /** @name Operations on ListOfVectors 
        @memo Operations on a ListOfVectors 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
      ListOfVectors();
  /////////////////////////////////////////////
      /**
         @memo Copy constructor
         @param target: ListOfVectors where will be copy
         @param origen: ListOfVectors to copy
         @doc
           Make a copy of ListOfVectors
           Time complexity in time O(1).
        */

  	  
	 // ListOfVectors (ListOfVectors &source, int *Sampling, int size);
        ListOfVectors(ListOfVectors &source, ListOfVectors<int> *Sampling);


	  ListOfVectors(char* filename);
 
///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: ListOfVectors to copy.
         @return Reference to the receptor ListOfVectors.
	 @doc
           Copy the ListOfVectors in the receptor ListOfVectors.
           Time complexity O(1).

      */
      ListOfVectors & operator=(const ListOfVectors & e);
////////////////////////////////////////////////////
   
	void GetInfo(char *FileName);

      /**
         @memo Is equal
         @param g: ListOfVectors to compare with.
	 @return
           Return true if the SNP is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const ListOfVectors & e);
      /**
         @memo Is different
         @param g: ListOfVectors to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const ListOfVectors & e);


	  //virtual 
		  T ReadElement (ifstream * is, int size); // if word virtual is not included, end loop


	  	        /**
         @memo Obtain the element pointed by the nodepointer.
         @return return a pointer to the first ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
	  T GetElement(NodePointer e);

	  T GetElement(int k);

	        /**
         @memo Obtain the first ListOfVectors in the ListOfVectors.
         @return return a pointer to the first ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
	  NodePointer GetFirst () {return ListOfVectors;};
	        /**
         @memo Obtain the first ListOfVectors in the ListOfVectors.
         @return return a pointer to the first ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
	  NodePointer GetLast () {return Last;};

      /**
         @memo Obtain the Next ListOfVectors in the ListOfVectors.
         @param The pointer to the current ListOfVectors
         @return return a pointer to the Next ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
        NodePointer GetPrevious (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Previous;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};
      /**
         @memo Obtain the Next ListOfVectors in the ListOfVectors.
         @param The pointer to the current ListOfVectors
         @return return a pointer to the Next ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
        NodePointer GetNext (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Next;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};

   /**
         @memo Obtain the element at pos k in the ListOfVectors.
         @param The pointer to the current ListOfVectors
         @return return a pointer to the Next ListOfVectors in the ListOfVectors
         Time complexity O(1)

      */
        NodePointer GetNode (int k)
		{
		NodePointer i=ListOfVectors;
		try {
		for (int c=0;c<k;c++)
		 if ((i=i->Next)==NULL) throw NullValue();
		}
		catch (NullValue null) {null.PrintMessage();}
		return i;};             

	 
      /**
         @memo Obtain the ListOfVectors SizeP.
         @return the size of a ListOfVectors
         @doc Return the number of ListOfVectorss in the ListOfVectors. This value
         is in the variable SizeP.
         Time complexity O(1)

      */
        int GetSize ();         
		
		int GetPos(NodePointer p);

		  /**
         @memo Add an element to the ListOfVectors.
         @param Position: Position of this element in the ListOfVectors
         Time complexity O(1)

      */
	  virtual void insertElement (T element);

	  //void insertElement (char* element);

  	  void insertElementAtPointer (T element, NodePointer & p);

		  /**
         @memo Remove the element at pos n from the ListOfVectors.
         @param Position: Position of this element in the ListOfVectors
         Time complexity O(1)

      */
	 
/*____________________________________________________________ */

void RemoveElement(NodePointer Pointer)
{

NodePointer Previous, Next;

try
{
if (Size==0)  throw NullValue();		
}
catch (NullValue null) {null.PrintMessage();}

if (Pointer!=NULL)
{
 //cout <<"h";
 Previous=Pointer->Previous;
 Next=Pointer->Next;
 if (Pointer!=ListOfVectors) Previous->Next=Pointer->Next;
 else ListOfVectors=Next;

 if (Pointer!=Last) Next->Previous=Previous;
 else Last=Previous;

// Pointer=Previous;
 delete Pointer;
 Size--;
}
} ;
/*____________________________________________________________ */


	  void Order(int* NewOrder, int size);

	  void Order(int funcioncomparar (const void *arg1, const void *arg2));

  	  void Remove(bool* RemovePos);

	  void ReplaceNode(NodePointer p, T NewElement);

	  bool IsEmpty();

	  void Empty();


	  void Pop()
	  {

		// extract the last element from the ListOfVectors

       RemoveElement(Last);
	  }

	T GetDistance(ListOfVectors* otherListOfVectors);

	NodePointer GetClosestGreaterElement(T argument);

	long int GetAbsoluteFrequency(ListOfVectors<AttPattern<T> >* attListOfVectors);

	double GetRelativeFrequency(ListOfVectors<AttPattern<T> >* values);

	double GetConditionalFrequency(ListOfVectors<AttPattern<T> >* independents, ListOfVectors<AttPattern<T> >* conditioners);

	void HardCopy(char filename[128]);

	ListOfVectors<T>* ExtractListOfVectors(int TotalElements);

	ListOfVectors<T>* ExtractListOfVectors(long int[] indexVector);



};  // End of class ListOfVectors

typedef  char s40[40];

//	float ListOfVectors<float>::ReadElement (ifstream * is, int size){};


//	unsigned int ListOfVectors<unsigned int>::ReadElement (ifstream * is, int size){};


//	int ListOfVectors<int>::ReadElement (ifstream * is, int size){};


//	char* ListOfVectors<char*>::ReadElement (ifstream * is, int size){};


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/////////////////////////////////////////////
template <class T> void ListOfVectors<T>::destroy(ListOfVectors<T>::NodePointer e)
{

       		if(e!= NULL)
			 destroy (e->Next);
			delete e;
            
}
//////////////////////////////////////////

template <class T> void ListOfVectors<T>::copy (ListOfVectors<T>::NodePointer & Target, const ListOfVectors<T>::NodePointer Source)
{
	try
	{
	  if ((Target=new node)==NULL)
            throw NoMemory();

	     Target->element=Source->element;
     	 
         if (Source->Next!=NULL)
           copy(Target->Next,Source->Next);     
		 else Target->Next=NULL;

	}
	catch (NoMemory wm) 
{
 wm.PrintMessage();
}        

}
/*___________________________________________________________ */

template <class T> void ListOfVectors<T>::ReadInfo (ifstream * is, int linesize)
{
//	T* e;
//	e=new T(ReadElement(is, size));
//	if (size!=18)
//	cout << e->PrintPhenotype();
//	T e;
//	T e(ReadElement(is, size));
	insertElement(ReadElement(is, linesize));
//	Size++;
//	Last=p;
//	insertElement(e);
//if (size!=18) exit(0);
//	cout <<"val";
	if (is->peek()!=EOF) // && is->peek()>='0' && is->peek()<='?') 
	 ReadInfo(is, linesize);
}

/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::GetInfo(char *FileName)
{

//cout << "Reading elements ...\n";

int linesize=GetLineLength(FileName)*2+100; //double because there can be longer lines
//if (linesize!=18)
//exit(0);
ifstream  InputFile;

try
{
 if (!ExistFile(FileName))
	 throw ErrorFile();
  InputFile.open (FileName, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
catch (EmptyFile EFile) {EFile.PrintMessage(FileName);}
ReadInfo (&InputFile, linesize);

InputFile.close();
//cout <<"Elements reading has finished\n";
};
///////////////////
//// public ////////
///////////////////

template <class T> ListOfVectors<T>::ListOfVectors()
{
ListOfVectors=NULL;
Last=NULL;
Size=0;
}

/*____________________________________________________________ */

template <class T> ListOfVectors<T>::ListOfVectors (ListOfVectors<T> &source, ListOfVectors<int> *Sampling=NULL)
{
// copy elements with pos in Sampling, they can be repeated

int cont=0;
ListOfVectors=NULL;
Last=NULL;
Size=0;

if (Sampling!=NULL)
{
ListOfVectors<int>::NodePointer p=Sampling->GetFirst();

  while (p!=NULL)
  {
  insertElement(source.GetElement(Sampling->GetElement(p)));
  p=Sampling->GetNext(p);
  }
}
else
 copy (ListOfVectors, source.ListOfVectors);

}
/*____________________________________________________________ */

template <class T> ListOfVectors<T>::ListOfVectors (char* filename)
{
ListOfVectors=NULL;
Last=NULL;
Size=0;
GetInfo(filename);
}

/*____________________________________________________________ */

template <class T> ListOfVectors<T>::~ListOfVectors ()
{
	if (ListOfVectors!=NULL) destroy(ListOfVectors);
	ListOfVectors=NULL;
}
 /*____________________________________________________________ */

template <class T> T ListOfVectors<T>::GetElement(ListOfVectors<T>::NodePointer e)
{
	try
	{
  if (e==NULL) 
   // throw NullValue(" in GetElement");
   throw NullValue();
  else return e->element;
	}

   catch (NullValue nv) {
                nv.PrintMessage();}
}
 /*____________________________________________________________ */

template <class T> T ListOfVectors<T>::GetElement(int k)
{
return GetElement(GetNode(k));
}



/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::ReplaceNode(ListOfVectors<T>::NodePointer p, T NewElement)
{
  try {
  if (p==NULL)
   throw NullValue();

  p->element=NewElement;
      
  }
  catch (NullValue null) {
    null.PrintMessage();
    }
}
/*____________________________________________________________ */

template <class T> int ListOfVectors<T>::GetPos(ListOfVectors<T>::NodePointer p)
{
  int k=0;
  NodePointer i=ListOfVectors;
  
	  while (i!=NULL)
	  {
		if (i==p) return k;
		k++;
		i=i->Next;
	  }
  
  return k;
}
/*____________________________________________________________ */


template <class T> int ListOfVectors<T>::GetSize()
{
	 return Size;
};

/*____________________________________________________________ */

template <class T> ListOfVectors<T>& ListOfVectors<T>::operator=(const ListOfVectors<T> & Source)
{
  if (this!=&Source)  
  {
	//  cout <<"prueba";
	  if (ListOfVectors!=NULL)
  destroy(ListOfVectors);
copy (ListOfVectors, Source.ListOfVectors);
  //	  exit(0);

  }
  return *this;
}
/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::insertElement (T element)
{
//	cout <<"size:" << Size;
	NodePointer Pointer=NULL;
	
//			 if (Size==1) cout<<"\nmmmlast" << Last <<"pointer:" << Pointer << "posfirst:" << ListOfVectors <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << ListOfVectors->Previous;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
//		 if (Size==1) cout<<"\nmmmlast" << Last <<"pointer:" << Pointer << "posfirst:" << ListOfVectors <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << ListOfVectors->Previous;

	Pointer->element=element;      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;

	if (Size>0) Last->Next=Pointer; 
	else ListOfVectors=Pointer;
	Last=Pointer;
//	 if (Size==1) cout<<"\nposfirst:" << ListOfVectors <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << ListOfVectors->Previous;


	Size++;
};
/*____________________________________________________________ */
/*
void ListOfVectors<char[40]>::insertElement (char element[40])
{
	
	NodePointer Pointer;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	strcpy(Pointer->element, element);      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;
	if (Size>0) Last->Next=Pointer; 
	else ListOfVectors=Pointer;
	Last=Pointer;
	Size++;





};

/*____________________________________________________________ */

template<> void ListOfVectors<char*>::insertElement (char* element)
{
	
	NodePointer Pointer;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	strcpy(Pointer->element, element);      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;
	if (Size>0) Last->Next=Pointer; 
	else ListOfVectors=Pointer;
	Last=Pointer;
	Size++;





};


/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::insertElementAtPointer (T element, NodePointer & p)
{
	// if pointer is NULL, insert element at the end of the ListOfVectors
    NodePointer Pointer, previous;


if (p==NULL) insertElement(element);
else
{

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	

	Pointer->element=element;  
	Pointer->Next=p;

    if (p!=ListOfVectors)
	{
    previous=p->Previous;
    Pointer->Previous=previous;
	previous->Next=Pointer;
	}
	else
	{
	ListOfVectors=Pointer;
    Pointer->Previous=NULL;
	}

    p->Previous=Pointer;

	Size++;
}

};



/*____________________________________________________________ */

template <class T>  void ListOfVectors<T>::Order(int* NewOrder, int size)
{
 	 int pos;
	
	 ListOfVectors<T> *ListOfVectors2;
	 try
	 {
	 if (Size!=size)
		 throw NoMemory();
 	if ((ListOfVectors2=new ListOfVectors<T>())==NULL)
		throw NoMemory();
	 }

	 catch (NoMemory NM ) {
      NM.PrintMessage();
	}


	for (int i=0;i<Size;i++)
	{
      pos=NewOrder[i];
	  ListOfVectors2->insertElement(GetElement(GetNode(pos)));  
	 }

	destroy(ListOfVectors);
	NodePointer p=ListOfVectors2->GetFirst();
    while (p!=NULL) 
	{
	  insertElement(GetElement(p));  
	  p=ListOfVectors2->GetNext(p);
	}

	

  cout <<"Sorting has finished\n";
}
/*____________________________________________________________ */

template <class T>  void ListOfVectors<T>::Order(int funcioncomparar (const void *arg1, const void *arg2))
{
 
 NodePointer IndPosition=GetFirst();

 int i=0;

 T *ListOfVectors2;
 if ((ListOfVectors2=new T[Size])==NULL)
  throw NoMemory();

 while (IndPosition!=NULL)
 {
  ListOfVectors2[i]=IndPosition->element;
  IndPosition=GetNext(IndPosition);
  i++;
 }
 qsort ((void*)ListOfVectors2, Size, sizeof (T), funcioncomparar);

IndPosition=GetFirst();
i=0;
while (IndPosition!=NULL)
{
 IndPosition->element=ListOfVectors2[i];
 IndPosition=GetNext(IndPosition);               
 i++;
}

if (ListOfVectors2!=NULL) delete ListOfVectors2;
	
}
/*____________________________________________________________ */

template <class T> bool ListOfVectors<T>::IsEmpty()
{
	return ListOfVectors==NULL;
}
/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::Empty()
{	
	if (ListOfVectors!=NULL) 
	{
	destroy(ListOfVectors);
	ListOfVectors=NULL;
	Last=NULL;
	Size=0;
	}
}
/*____________________________________________________________ */

template <class T> void ListOfVectors<T>::Remove(bool* PosListOfVectors)
{
	// PosListOfVectors contains true in positions to be removed

 	 int pos, i=0;
	
	 try
	 {
	 if (Size!=sizeof(*PosListOfVectors))
		 throw NoMemory();
	 }

	 catch (NoMemory NM ) {NM.PrintMessage();
	}

	NodePointer p=GetFirst(), oldp;
	
	while (p!=NULL)
	{
	if (PosListOfVectors[i]==true)
	  p=RemoveElement(p);  
	else p=GetNext(p);
	}  
	

  cout <<"Sorting has finished\n";
};
/*____________________________________________________________________________________ */


template<class T> T ListOfVectors<T>::GetDistance(ListOfVectors<T>* otherListOfVectors)
{
typename ListOfVectors<T>::NodePointer otherPointer=otherListOfVectors->GetFirst(), 
thisPointer=GetFirst();
T distance=(T) 0;
 while (thisPointer!=NULL && otherPointer!=NULL)
 {
  distance=distance+(T)fabs(GetElement(thisPointer)-otherListOfVectors->GetElement(otherPointer));
  thisPointer=GetNext(thisPointer);
  otherPointer=otherListOfVectors->GetNext(otherPointer);
 }  
 return distance;
};
/*___________________________________________________________ */

template<class T> typename ListOfVectors<T>::NodePointer ListOfVectors<T>::GetClosestGreaterElement(T argument)
{
// it returns a pointer to the element in the ListOfVectors which has the closest upper value than argument  
 typename ListOfVectors<T>::NodePointer pk=GetFirst(), pk2=NULL;
 T NextValue, ClosestValue=maxreal;
   while (pk!=NULL)
   {
	NextValue=GetElement(pk);

	if (NextValue>=argument && NextValue<ClosestValue)
	{
		ClosestValue=NextValue;
		pk2=pk;
	}
	pk=GetNext(pk);
   }
return pk2;
}
/*___________________________________________________________________________________*/

template <class T>  long int ListOfVectors<T>::GetAbsoluteFrequency(ListOfVectors<AttPattern<T> >* attListOfVectors)
{
// Given a ListOfVectors of Attrribute positions and a ListOfVectors of ranges it resturns the number of members which values in the same range for the ListOfVectors of attribute positions

long int frequency=0;
typename ListOfVectors<T>::NodePointer p=GetFirst();
typename ListOfVectors<AttPattern<T> >::NodePointer pA;
ListOfVectors<T>* pattern;
bool inconsistent;
int position;
T minValue, maxValue;
AttPattern<T> attValue;
T value;
bool continuous;
while(p!=NULL)
{
pattern=GetElement(p);
pA=attListOfVectors->GetFirst();
inconsistent=false;
while(pA!=NULL && !inconsistent)
{
attValue=attListOfVectors->GetElement(pA);
value=pattern->GetElement(attValue.GetPos());
continuous=(attValue.GetMinValue()!=attValue.GetMaxValue());
if ((!continuous && value!=attValue.GetMinValue()) ||
    (continuous && (attValue.GetMinValue()>value || attValue.GetMaxValue()<=value)))
 inconsistent=true;
pA=attListOfVectors->GetNext(pA);
}
if (!inconsistent) frequency++;
p=GetNext(p);
}
return frequency;
}; 
/*___________________________________________________________________________________*/

template <class T>  double ListOfVectors<T>::GetRelativeFrequency(ListOfVectors<AttPattern<T> >* values)
{
return GetAbsoluteFrequency(values)/(double)GetSize();
} 


/*___________________________________________________________________________________*/

template <class T> double ListOfVectors<T>::GetConditionalFrequency(ListOfVectors<AttPattern<T> >* independents, ListOfVectors<AttPattern<T> >* conditioners)
{
ListOfVectors<AttPattern<T> >* joint;
*joint=*independents;// value copy 
typename ListOfVectors<AttPattern<T> >::NodePointer pC=conditioners->GetFirst();

//// First, add conditioners to compose the joint distribution
while (pC!=NULL)
{
 joint->insertElement(conditioners->GetElement(pC));
 pC=conditioners->GetNext(pC);
}

///// Now, compute frequencies for the joint and the marginal 
double pjoint=(double)GetAbsoluteFrequency(joint);
double marginal=(double)GetAbsoluteFrequency(conditioners);

delete joint;

return pjoint/marginal;
};
/*___________________________________________________________________________________*/

template <class T>  void ListOfVectors<T>::HardCopy(char filename[128])
{ 
ofstream  OutputFile;
OpenOutput(filename, &OutputFile);
ListOfVectors<T> *pattern;
typename ListOfVectors<T>::NodePointer p=GetFirst();
while (p!=NULL)
{
 pattern=GetElement(p);
 OutputFile << pattern->Print();
 p=GetNext(p);
}
OutputFile.close();
}
/*___________________________________________________________________________________*/

template <class T> ListOfVectors<T>* ListOfVectors<T>::ExtractListOfVectors(int TotalElements)//
{ 
//it reandomly extracts TotalElements from the original sample and put them in a new ListOfVectors
int elegido;
NodePointer p;

ListOfVectors<T>* newListOfVectors;

//cout <<"TotalPrueba:" << TotalPrueba;
//cout <<"size:" << splittedSample.trainingSample->ListOfVectors<InputAttributesPattern*>::GetSize();
for (int contador=0;contador<TotalPrueba;contador++)
{ 
	if (GetSize()<=0)
	{
		cout <<"error for " << contador;
		exit(0);
	}
  elegido=rand() % GetSize();
  p=GetNode(elegido);
  newListOfVectors->insertElement(GetElement(p));
  RemoveElement(p);
}
return newListOfVectors;
}
/*___________________________________________________________________________________*/

template <class T> ListOfVectors<T>* ListOfVectors<T>::ExtractColumns (long int[] indexVector)//
{ 
//it extracts elements at pos in indexVector from the original sample and put them in a new ListOfVectors
int elegido;
NodePointer p;

ListOfVectors<T>* newListOfVectors;

//cout <<"TotalPrueba:" << TotalPrueba;
//cout <<"size:" << splittedSample.trainingSample->ListOfVectors<InputAttributesPattern*>::GetSize();
for (int contador=0;contador<sizeof(*indexVector);contador++)
{ 
	if (GetSize()<=0)
	{
		cout <<"error for " << contador;
		exit(0);
	}
  p=GetNode(indexVector[contador]);
  newListOfVectors->insertElement(GetElement(p));
  RemoveElement(p);
}
return newListOfVectors;
}


} // end namespace
#endif

/* Fin Fichero: ListOfVectors.h */
