/* File: Pair.h */


#ifndef __Pair_h__
#define __Pair_h__



using namespace std;

namespace BIOS {



template < class P> class Pair
  {
public:
           P First;
           P Second;
           Pair(P f, P s) {First=f; Second=s;};
           Pair(Pair<P>* p) {First=p->First; Second=p->Second;};
           Pair() {};
           ~Pair() {};
	   bool operator>(Pair<P> p) {if (First>p.First && Second>p.Second) return true; else return false;};
	   bool operator<(Pair<P>p) {if (First<p.First && Second<p.Second) return true; else return false;};
	   bool operator==(Pair<P>p) {if (First==p.First && Second==p.Second) return true; else return false;};
           void setValues(P f, P s) {First=f; Second=s;};
	   P getFirst(){return First;};
	   P getSecond(){return Second;};
  };


/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Pair<T>& pair)
{
 
out << "(" << pair.First <<", " << pair.Second <<")\n";

return out;
  }

}//end namespace
#endif
