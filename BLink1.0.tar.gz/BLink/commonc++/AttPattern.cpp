#ifndef AttPattern_cpp//
#define AttPattern_cpp//

#include "AttPattern.h"

namespace BIOS {



/************************/
/* ListOfLists DEFINIfloatION */
/************************/


/**
        @memo AttPattern 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/


AttPattern::AttPattern()
{
attPattern.pos=-1;
};


AttPattern::AttPattern(int position, float minVal, float maxVal)
{
attPattern.pos=position;
attPattern.minValue=minVal;
attPattern.maxValue=maxVal;
};

AttPattern::AttPattern(AttPattern *ap)
{
attPattern.pos=ap->GetPos();
attPattern.minValue=ap->GetMinValue();
attPattern.maxValue=ap->GetMaxValue();
};


int AttPattern::GetPos()
{
return attPattern.pos;
};

float AttPattern::GetMinValue()
{
return attPattern.minValue;
};

float AttPattern::GetMaxValue()
{
return attPattern.maxValue;
};


bool AttPattern::operator==(AttPattern& target)
{
return target.pos==pos && target.minValue==minValue && target.maxValue==maxValue;
};

string print()
{
char line[256];

sprintf(line, "%d, %0.3f, %0.3f", position, minVal, maxVal);
return string(line);
}


}// end namespace
#endif
