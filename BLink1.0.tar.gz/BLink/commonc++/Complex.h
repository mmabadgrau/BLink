#include <iostream.h>

class Complex
{
public:
	Complex(float re, float im)
	: myReal(re), myImag(im)
	{}

	friend istream& operator>>(istream&, Complex&);
	friend ostream& operator<<(ostream&, const Complex&);

private:
	float myReal;
	float myImag;
};

istream& operator>>(istream& in, Complex& c)
{
	double real, imag;
	in >> real >> imag;
	if (in.good())
	{
		c.myReal = real;
		c.myImag = imag;
	}
	return in;
}

ostream& operator<<(ostream& out, const Complex& c)
{
	out << "(" << c.myReal << "," << c.myImag << ")";
	return out;
}