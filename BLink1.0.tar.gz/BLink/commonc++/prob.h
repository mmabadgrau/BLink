/* File: prob.h */


#ifndef __prob_h__
#define __prob_h__


#include<iostream>////
#include<fstream>//
#include<cstring>//
#include<cstdio>//                                              //
#include <cstdlib>//
#include <cctype>//
#include <cmath>//
#include <sys/stat.h>                                                       
#include "pair.h"//

using namespace std;

namespace BIOS {



/////////////////////////////////
class prob: public pair<double> //
{//
public://
 prob(double numerator, double denominator); // constructor
 prob(double numerator, double denominator, float alpha, int size); // constructor
 prob operator/ (prob & origen);
 void addAlpha (float alpha, int size);

};//


}//end namespace
#endif
