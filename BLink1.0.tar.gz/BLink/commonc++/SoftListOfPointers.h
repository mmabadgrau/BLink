/* File: SoftListOfPointers.h */


#ifndef __SoftListOfPointers_h__
#define __SoftListOfPointers_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.cpp"
#include "list.cpp"
//#include "SoftListOfPointers.h"

//#include "Diplotype.h"


/**
    @memo Declaration of a SoftListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* SoftListOfPointers DEFINITION */
  /************************/


  /**
          @memo SoftListOfPointers 
   
  	@doc
          Definition:
          A set of SoftListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the SoftListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */

//Container<int, list>

 //template <class T, template <class T> class Cont> class Container: public Cont<T>
 
template <class T> class SoftListOfPointers: public list<T*>
//  template <class T, template <class T> class Cont> class SoftListOfPointers: public Container<T*, Cont>
  {

public:

/*
   typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;
      ~node() {delete &element; Next=NULL; Previous=NULL;};
    };
*/

   //Node::~Node() {delete &element; Next=NULL; Previous=NULL;};

public:

 //  typedef node * NodePointer2;

   //protected:  void copy(const typename SoftListOfPointers<T>::NodePointer source);

 
   
    /////////////////////////



    /* PUBLIC FUNCTIONS (INTERFACE) */

  public:

//	list<int>* getIntList();


	//template <class U> list<U>* getPrimitiveList();
	

    ~SoftListOfPointers ();

    SoftListOfPointers();

    SoftListOfPointers(SoftListOfPointers &source);

  SoftListOfPointers(SoftListOfPointers &source, typename SoftListOfPointers<T>::NodePointer first, typename SoftListOfPointers<T>::NodePointer last);

    SoftListOfPointers(char* filename, char* tokens=NULL);
	
 //   SoftListOfPointers (list<T*> &source, list<int> *Sampling=NULL);

    virtual ComparisonType compareElement(T *arg1, T *arg2);

  
    virtual void Order(bool ascendent=true);

  
	virtual  string print(bool forward=true);

 void modularPrint(bool forward=true);

     typename SoftListOfPointers<T>::NodePointer   findFinalElement(void* element);


 //   SoftListOfPointers<T>* ExtractList(int indexVector[], int size);

   void * findElement(void* element);

   typename SoftListOfPointers<T>::NodePointer findElement(T* element);

};
/*
typedef SoftListOfPointers<int> intSoftListO;
typedef SoftListOfPointers<float, floatList> floatSoftList;
typedef Container<double, list> doubleList;
typedef Container<string, list> stringList;
*/
}; // end namespace
#endif

//#include "SoftListOfPointers.cpp"

/* Fin Fichero: SoftListOfPointers.h */
