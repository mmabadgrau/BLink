/* File: tabla.cpp */


#ifndef __tabla_cpp__
#define __tabla_cpp__

#include "tabla.h"//



namespace BIOS {


////////
unsigned short int tabla::desborde(unsigned int max, unsigned int desplazamiento) //
{ //
if (desplazamiento>=max) //
 return(1); //
else return(0);//
}//
///////////////
unsigned int tabla::ordenar(unsigned int tam, float *tabla1) //
{//
float *tabla2;//
unsigned int i, fin=0, tam2;//
//cout <<"tam" <<tam; //
//exit(0);
if ((tabla2=new float[tam])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
//exit(0);
tabla::iniciar(maxreal, tam, tabla2);//
i=0; //
//exit(0);

do //
{//
 posicion=tabla::minimo(tam-i, tabla1);//
 tabla2[i]=tabla1[posicion];//
 if (tabla1[posicion]==(float)maxreal) //
  fin=1; //
 else //
  tabla1[posicion]=(float)maxreal;//
 i=i+1;//
} //
while ((i<tam) && (fin==0));//
tam2=i-1;//
for (i=0; i <tam; i++) //
 tabla1[i]=tabla2[i];//
//cout <<"TAM2:" <<tam2;//
zap (tabla2);
return (tam2); //
}//

///////////////////////////////////////////////
unsigned int tabla::maximo(unsigned int tam, float *tabla_reales)//
{//
posicion=0;//
maximo_real=0;//
for (contador=0;contador<tam;contador++)//
 if (tabla_reales[contador] > maximo_real)//
 {//
  maximo_real=tabla_reales[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
///////////////////////////////////////////////
unsigned int tabla::maximo(unsigned int tam, double *tabla_reales)//
{//
posicion=0;//
maximo_doble=0;//
for (contador=0;contador<tam;contador++)//
 if (tabla_reales[contador] > maximo_doble)//
 {//
  maximo_doble=tabla_reales[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
/////////////////////////////////////////////
unsigned int tabla::maximo(unsigned int tam, unsigned int *tabla_enteros)//
{//
posicion = 0;//
maximo_entero=0;//
for (contador=0;contador<tam;contador++)//
 if (tabla_enteros[contador] > maximo_entero)//
 {//
  maximo_entero=tabla_enteros[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
/////////////////////////////////////////////
unsigned int tabla::maximo(unsigned int tam, int *tabla_enteros)//
{//
posicion = 0;//
maximo_largo_entero=0;//
for (contador=0;contador<tam;contador++)//
 if (tabla_enteros[contador] > maximo_largo_entero)//
 {//
  maximo_largo_entero=tabla_enteros[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
/////////////////////////////////////////////
unsigned int tabla::maximo(unsigned int tam,   int *tabla_enteros)//
{//
posicion = 0;//
maximo_corto=0;//
for (contador=0;contador<tam;contador++)//
 if (tabla_enteros[contador] > maximo_corto)//
 {//
  maximo_corto=tabla_enteros[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
/////////////////////////////////////////////
template <class T> unsigned int tabla::empatemaximo(unsigned int tam, T * tabla)//
{//
unsigned int posicionMax = maximo(tam, tabla);//
T maximo=tabla[posicionMax];//
unsigned int empate;//
empate=1; //

for (contador=0;contador<tam;contador++)//
 if ((tabla[contador] == maximo) && (contador!=posicionMax))//
    empate=1;  //
return(empate);//
}//
/*
/////////////////////////////////////////////
unsigned int tabla::empatemaximo(unsigned int tam, double *tabla_largos)//
{//
double maximo_largo=0;//
posicion = 0;//
unsigned int empate;//
empate=0; //
for (contador=0;contador<tam;contador++)//
{//
//cout <<"\nvlaor:" <<tabla_largos[contador];//
 if (tabla_largos[contador] > maximo_largo)//
 {//
  maximo_largo=tabla_largos[contador];//
  posicion=contador;//
//  cout <<"desempate: " << contador <<"frecuencia:" <<tabla_enteros[contador];//
  empate=0;  //
 }//
 else //
 if (fabs(tabla_largos[contador]-maximo_largo)<1.0e-10) //
 {//
   empate=1;  //
//  cout <<"empate: " << contador <<"frecuencia:" <<tabla_enteros[contador];//
}//
 }//
// exit(0);//
//cout <<"empate:" <<empate;//
return(empate);//
}//
*/
//////////////////////////////////////////////
unsigned int tabla::ordenado_fuerte(unsigned int *ind, unsigned int tam)//
{//
unsigned int  valido=1;//
 contador=0;//
 while ((contador < tam-1) && (valido==1))//
 {//
  if (ind[contador] >= ind[contador+1])//
   valido=0;//
  contador=contador+1;//
 }//
//if ((tam==2)&& (valido==1))//
//if (valido==1)//
//{//
//for (cont3=0; cont3<tam;cont3++)//
//cout <<"ind[:" <<cont3 <<",]:" <<indice[cont3] <<",";//
//cout << "\n";//
//cin >> m;//
//}//
 return (valido); //
}//
///////////////////////////////////////////////
void tabla::obtener_indice(unsigned int pos, //
unsigned int *dimensiones, unsigned int numero_dimensiones, unsigned int *ind)//
{//

//if ((indice = new unsigned int[numero_dimensiones])==NULL) //
// {//
// cout <<"Falta memoria";//
// exit(0);//
// }//


unsigned int tajo=1;//
for (contador=0; contador < numero_dimensiones; contador++)//
 {//
  tajo=tabla::producto(0, contador, dimensiones);//
//if (numero_dimensiones==1) exit(0);//
  if (contador==0) //
   ind[contador]=pos%dimensiones[0];//
  else//
  ind[contador]=pos/tajo;//
  }//
//if (numero_dimensiones==2)//
//cout <<"pos:" <<pos <<", INdiCE[0]:" <<indice[0] << ", INdiCE[1]:" <<indice[1] ;//
 }//
/////////////////////////////////////////////
int tabla::producto (unsigned int pos, int tam, unsigned int *tab)//
{//
int prod=1;//
for (contador=pos; contador <tam; contador++)//
  prod = prod*(int)*(tab+contador);//
return (prod);//
}//
/////////////////////////////////////////////
int tabla::producto (unsigned int pos, int tam, int *tab)//
{//
int prod=1;//
 for (contador=pos; contador <tam; contador++)//
  prod = prod*(int)*(tab+contador);//
return (prod);//
}//
/////////////////////////////////////////////
unsigned int tabla::suma (unsigned int pos, unsigned int tam, unsigned int *tab)//
{//
unsigned int suma=0;//
 for (contador=pos; contador <tam; contador++)//
  suma = suma+tab[contador];//
//cout <<"suma:" <<suma;//
return (suma);//
}//
//////////////////////////////////////////////
int tabla::obtener_posicion(unsigned int *ind, //
unsigned int *dimensiones, unsigned int numero_dimensiones)//
{//
// devuelve la posicion lineal que tiene un valor en una tabla
//en la que el tamao de cada dimensin est expresado
// en "dimensiones", con "numero_dimensiones" dimensiones si la posicion
//expresada por indices es la que aparece en la tabla de indices

int  tajo, pos=0; //
for (contador=0; contador < numero_dimensiones; contador++)//
{//
 tajo=tabla::producto(0, (unsigned int) contador, dimensiones);//

 pos=pos+(int)*(ind+contador)*tajo; //
}//
 return(pos);//
 }//
//////////////////////////////////////////////
int tabla::obtener_posicion(int *ind, //
int *dimensiones, unsigned int numero_dimensiones)//
{//
int  tajo, pos=0;//
for (contador=0; contador < numero_dimensiones; contador++)//
{//
 tajo=tabla::producto(0, contador, dimensiones);//
 pos=pos+*(ind+contador)*tajo; //
}//
 return(pos);//
 }//

//////////////////////////////////////////////
unsigned int tabla::minimo(unsigned int tam, float *tabla_reales)//
{//
posicion=0;//
 for (contador=0;contador<tam;contador++)//
 if ((tabla_reales[contador] < minimo_real) || (contador==0))//
 {//
  minimo_real=tabla_reales[contador];//
  posicion=contador;//
//  cout <<"pos: " << posicion;//
 }//
return(posicion);//
}//
///////////////////////////////////////////////
unsigned int tabla::minimo(unsigned int tam, double *tabla_reales)//
{//
posicion=0;//
for (contador=0;contador<tam;contador++)//
{
//cout <<"con:" << contador;
 if ((tabla_reales[contador] < minimo_doble) || (contador==0))//
 {//
  minimo_doble=tabla_reales[contador];//
  posicion=contador;//
 }//
}
return(posicion);//
}//
/////////////////////////////////////////////
unsigned int tabla::minimo(unsigned int tam, unsigned int *tabla_enteros)//
{//
posicion=0;//
minimo_entero=32767;//
for (contador=0;contador<tam;contador++)//
{//
 if (tabla_enteros[contador] < minimo_entero)//
 {//
  minimo_entero=tabla_enteros[contador];//
  posicion=contador;//
 }//
}//
return(posicion);//
}//
/////////////////////////////////////////////
unsigned int tabla::minimo(  int tam,   int *tabla_enteros)//
{//
posicion=0;//
minimo_entero=32767;//
for (contador=0;contador<tam;contador++)//
 if (tabla_enteros[contador] < minimo_entero)//
 {//
  minimo_entero=tabla_enteros[contador];//
  posicion=contador;//
 }//
return(posicion);//
}//
////////////////////////////
void tabla::iniciar(bool valor, unsigned int tam, bool *tabla_logicos)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_logicos+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(unsigned int valor, unsigned int tam, unsigned int *tabla_enteros)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_enteros+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(unsigned short int valor, unsigned int tam, unsigned short int *tabla_enteros)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_enteros+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(unsigned int valor, unsigned int tam, int *tabla_enteros)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_enteros+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(unsigned int valor, int tam, int *tabla_enteros)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_enteros+contador)=valor;//
}//
////////////////////////////
////////////////////////////
void tabla::iniciar(int valor, unsigned int tam, int *tabla_enteros)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_enteros+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(float valor, unsigned int tam, float *tabla_reales)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_reales+contador)=valor;//
}//
////////////////////////////
void tabla::iniciar(double valor, unsigned int tam, double *tabla_reales)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_reales+contador)=valor;//
} //
////////////////////////////
void tabla::iniciar(char valor, unsigned int tam, char *tabla_char)//
{//
for (contador=0;contador<tam;contador++)//
 *(tabla_char+contador)=valor;//
}//
///////////////////////
unsigned int tabla::buscar_siguiente(char valor, unsigned int desde, unsigned int largo, //
char *tabla_caracteres)//
{//
  int fin;//
contador=desde;//
fin=0;//
do//
{//
  if ((tabla_caracteres[contador] == valor) || (contador == largo))  //
   fin = 1;//
 else   contador=contador+1;//
}//
while (fin==0);//
return (contador);//
}//
///////////////////////
unsigned int tabla::buscar(double valor, unsigned int tam, double *tabla_reales)//
{//
  int fin;//
contador=0;//
fin=0;//
do//
{//
  if ((tabla_reales[contador] > valor) || (contador == tam))  //
   fin = 1;//
 else   contador=contador+1;//
}//
while (fin==0);//
return (contador);//
}//
///////////////////////
void tabla::insertar(double valor, unsigned int pos, //
unsigned int tam, double *tabla_reales)//
{//
for (contador = tam-1; contador > posicion; contador--)//
 tabla_reales[contador]=tabla_reales[contador-1];//
tabla_reales[pos]=valor;//
}//
///////////////////////
void tabla::insertar(unsigned int valor, unsigned int pos, //
unsigned int tam, unsigned int *tabla_enteros)//
{//
for (contador = tam-1; contador > pos; contador--)//
 tabla_enteros[contador]=tabla_enteros[contador-1];//
tabla_enteros[pos]=valor;//
}//
}
#endif
