  /**
    * @file ManageColumns.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Fachade.h"

/* This program performs tasks by columns in text files. Column numbers starts by number 0*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<column to be changed/removed (starting at 0)>" <<"<new pos(-1 if to be removed, -2 to be added, -3: newColumn)>" <<" <remove heading (0 default)>" << "<if change/remove/added: separations (default: ,), if newColumn: value to add\n";
        exit(0);
        }
     char filename[128], filename2[128], columns[1024], separations[10]="\t, \n\r", newValue[10];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}

	 strcpy(columns, argv[3]);
	 int newPos=atoi(argv[4]);

   bool removeHeading=false;

	 if (argc>=6)
 removeHeading=atoi(argv[5]);

//cout <<"argc:" << argc;

 if (argc==7)
 if (newPos!=-3)
 strcpy(separations, argv[6]);
else  strcpy(newValue, argv[6]);


//	cout <<"\ncol:" <<columns <<"hin\n";
intList* columnList=getNumbers(columns);
	//cout <<"\nfilename:" <<filename;

 ifstream  InputFile;
ofstream OutputFile;

    try
    {
//	cout <<"\nfilename:" <<filename;
//end();
      if (!existFile(filename))
        throw ErrorFile();

	InputFile.open (filename, ifstream::in);
      OutputFile.open (filename2, ifstream::out);
      if (InputFile.peek()==EOF)
        throw EmptyFile();


stringList* l=NULL, *l2=NULL;
char* line;

int column=columnList->GetFirstElement();

if ((newPos>=0  || newPos==-2) && columnList->GetSize()>1)
{
cout <<"Error, only one column should be provided if want to change its position\n";
end();
}
int i=0;


while (InputFile.peek()!=EOF)
{
	
//l=new stringList();
//cout << "s:" << getSize(&InputFile);
line=CaptureLine(&InputFile);
if (removeHeading==false || (removeHeading==true && i>0))
	{
l=getList(line, separations);
if (!empty(l))
{
if (newPos==-1)
{
l2=l->copyElementsWithoutPositionsIn(columnList);
zap(l);
l=l2;
//cout <<"\nl is:" << *l;
}
else
if (newPos==-2)
l->insertElementAtPos(l->GetElement(column), newPos);
else
if (newPos==-3)
l->insertElement(string(newValue));
else
l->moveElement(column, newPos);
OutputFile << *l <<"\n";
//cout << *l;
}
delete line;
delete l;
	}

i++;
//if (i>1) end();

}


InputFile.close();
OutputFile.close();

}
  catch (ErrorFile NoFile) {NoFile.PrintMessage(filename);}
    catch (EmptyFile EFile) {EFile.PrintMessage(filename);}

cout <<"Changes have been recorded in file " << filename2 << "\n";
return 0;


}










