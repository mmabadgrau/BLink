/* File: ListOfPointers.h */


#ifndef __ListOfPointers_h__
#define __ListOfPointers_h__

//#include "ExceptionsBasic.h"
//#include "basic.cpp"
//#include "list.cpp"

/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A set of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
 //template <class T, template <class T> class Cont> class ListOfPointers: public Container<T, SoftListOfPointers>
 
template <class T> class ListOfPointers: public SoftListOfPointers<T>
  {

    //  node() {Next=NULL; Previous=NULL; element=NULL; };
    //  ~node() {Next=NULL; Previous=NULL; zap(element); element=NULL;};
  
    /* PUBLIC FUNCTIONS (INTERFACE) */

  public:

  //void copy(const typename ListOfPointers<T>::NodePointer source, const typename ListOfPointers<T>::NodePointer last=NULL);
  
//void insertElement (T* element);//it is required for copy constructors
 

    virtual ~ListOfPointers ();

    ListOfPointers();

//void hardCopy(char filename[256]);
 

 //   ListOfPointers(ListOfPointers &source) {cout <<"ListOfPointers(&) not implemented yet"; end();};;

  //ListOfPointers(const ListOfPointers &source) {cout <<"ListOfPointers(const) not implemented yet"; end();};

ListOfPointers(ListOfPointers &source, typename ListOfPointers<T>::NodePointer first=NULL, typename ListOfPointers<T>::NodePointer last=NULL);

ListOfPointers(ListOfPointers &source, Sampling* sampling);

    ListOfPointers(char* filename, char* tokens=NULL);

    ListOfPointers & cloneSecond(const ListOfPointers & e);
    
    ListOfPointers & operator=(const ListOfPointers & e);

ListOfPointers & operator=(ListOfPointers & e){cout << "ListOfPointers = not implemented yet"; end();};
//  typename ListOfPointers<T>::NodePointer GetClosestGreaterPointerToElement(T* argument, bool checkOrder);

      bool isOrdered(bool ascendent);

  
 virtual void deleteElement (T * element);
 
 virtual void assignElement (typename ListOfPointers<T>::NodePointer p, T* element);
 

  //  ListOfPointers<T>* ExtractList(int indexVector[], int size);


    void moveElement(int oldPos, int newPos);
 
  virtual void ReadInfo (ifstream * is, char* tokens);

};
/*______________________________________________________*/

     template<class T> ostream& operator<<(ostream& out, ListOfPointers<T>& l)
{
if (l.GetSize()>1) out <<"(";
typename ListOfPointers<T>::NodePointer p=l.GetFirst();
while (p!=NULL)
    {
 out << *(p->element); 
p=l.GetNext(p); 
   if (l.GetSize()>1) if (p!=NULL) out <<","; else out <<")";
}
return out;
}

}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
