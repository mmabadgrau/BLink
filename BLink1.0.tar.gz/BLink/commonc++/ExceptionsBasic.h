
#ifndef __ExcepBasic__
#define __ExcepBasic__

#include <iostream>


using namespace std;

namespace BIOS {

class NullValue {
public:
string message;

NullValue(string message)
{
this->message=string(message);
}
NullValue(){};
        void PrintMessage() {
                cout << "\nNull value (pointer == NULL) at " << message << ".\n";
		exit(1);
		}
		void PrintMessage(const char* f) {
                cout << "\nNull value (pointer == NULL) at function " << f <<" called from " << message << ".\n";
		exit(1);
	}

};
class MissingArguments {
public:
string message;

MissingArguments(string message)
{
this->message=string(message);
}
MissingArguments(){};
        void PrintMessage() {
                cout << "\nMissing arguments at " << message << ".\n";
		exit(1);
		}
		void PrintMessage(const char* f) {
                cout << "\nMissing arguments at function " << f <<" called from " << message << ".\n";
		exit(1);
	}

};

class NanValue {
public:
        void PrintMessage() {
                cout << "\nNaN value.\n";
		exit(1);
		}
		void PrintMessage(const char* f) {
                cout << "\nNaN value at function " << f << ".\n";
		exit(1);
	}

};


class NoMemory {
public:
        void PrintMessage() {
                cout << "\nNot enough memory.\n";
		exit(1);
		}
		void PrintMessage(const char* f) {
                cout << "\nMemory fault at function " << f << ".\n";
		exit(1);
	}
};

class OutOfBounds {
public:
int first, second;
OutOfBounds(int first, int second)
{
this->first=first;
this->second=second;
}
     void PrintMessage(string s) {
                cout << "\nTrying to access position: " << first <<" at " << s << " but there are only " << second <<" positions [0:" << second-1 << "].\n";
		exit(1);
	};
	     	};

class NonSNP {
public:
        void PrintMessage(char* message) {
                cout << " is not a nucleotide value at " << message << ".\n";
		exit(1);
		}
		   void PrintMessage(unsigned long int value) {
                cout << value << " is not a nucleotide value.\n";
		exit(1);
	}
//	   void PrintMessage(short int value) {
//                cout << value << " is not a nucleotide value.\n";
//		exit(1);
//	   }
};

class OutOfRange {
public:
        void PrintMessage(unsigned int value) {
                cout << "Some metric for SNP " << value << " is out of range.\n";
		exit(1);
		}
		 void PrintMessage() {
                cout << "Some metric is out of range.\n";
		exit(1);
		}
		 void PrintMessage(char * message) {
                cout << "Some metric is out of range at " << message <<".\n";
		exit(1);
		}
};


class BadSize {
const char* f;
int first, second;
public:

        BadSize() {};

        BadSize(const char* f)
{
	this->f=f;
};
        BadSize(const char * t, int first, int second) 
	{
	f=t;
	this->first=first;
	this->second=second;
	};
        void PrintMessage() {
                cout << "\nDifferent size at " << f <<": " << first <<":" << second <<".\n";
		exit(1);
	}
     void PrintMessage(int first, int second) {
                cout << "\nDifferent size: " << first <<":" << second <<".\n";
		exit(1);
	}
	     void PrintMessage(const char * t, int first, int second) {
                cout << "\nDifferent size in " << t << ": " << first <<":" << second <<".\n";
		exit(1);
	}
	void PrintMessage(const char * t) {
                cout << "\nDifferent size in " << f << ": " << first <<":" << second <<" at " << t << ".\n";
		exit(1);
	}
};

class EOFile {
public:
        void PrintMessage() {
                cout << "\nEnd of file error.\n";
		exit(1);
	}
};

class BadFile {
public:
        void PrintMessage() {
                cout << "\nIncorrect file format.\n";
		exit(1);
	}
};


class ErrorFile {
string s;
public:
ErrorFile(){};
ErrorFile(char* name) {s=string(name);};
        void PrintMessage() {
                cout << "\nFile " << s << " does not exist, is damaged or cannot be created.\n";
		exit(1);
	}
		  void PrintMessage(const char* name) {
                cout << "\nFile \"" << name << "\" does not exist, is damaged or cannot be created.\n";
		exit(1);
	}
		  void PrintMessage(const char* name, const char* message) {
                cout << "\nError in " << message <<", file " << name << " does not exist, is damaged or cannot be created.\n";
		exit(1);
	}
};


class AlreadyExist {
public:
        void PrintMessage() {
                cout << "\nFile already exists.\n";
		exit(1);
	}
};


class EmptyFile {
public:
        void PrintMessage(const char* filename) {
                cout << "\nFile " << filename << " does not have data.\n";
		exit(1);
	}
};




class NonBoolean {
public:
        void PrintMessage() {

         cout << "Error, must be a boolean value (0 or 1)\n";
	exit(1);
	}
};




class BadFormat {
public:
string s;
 BadFormat(string message) {
s=string(message);
	};

BadFormat() {};

        void PrintMessage() {

         cout << "Error, incorrect format\n";
	exit(1);
	}
		 void PrintMessage(const char* file) {

         cout << "Error, incorrect format in file " << file << "\n";
	exit(1);
	}
	 void PrintMessage(const char* file, const char* message) {

         cout << "Error at " << message << ", incorrect format in file " << file << "\n";
	exit(1);
	}
	 void PrintMessage(string message) {

         cout << "Error at " << message << ", incorrect format called from " << s << "\n";
	exit(1);
	}
};



class ZeroValue {
public:
string message;
ZeroValue(string s)
{
this->message=s;
}
        void PrintMessage() {

         cout << "Error, value is zero at " << message << "\n";
	exit(1);
	}
		 void PrintMessage(const char* s) {

         cout << "Error, value is zero at " << message << " called from " << s <<"\n";
	exit(1);
	}
};


class NonProb {
string message;
public:
NonProb(string s)
{
this->message=s;
}
        void PrintMessage() {

         cout << "Error, non a probability\n";
	exit(1);
	}
        void PrintMessage(float val) {

         cout << "Error, " << val << " is non a probability\n";
	exit(1);
	}
		 void PrintMessage(const char* s) {

         cout << "\nError, non a probability " << message << " called from " << s <<"\n";
	exit(1);
	}
};

class NonDiscrete {
string message;
public:
NonDiscrete(string s)
{
this->message=s;
}
        void PrintMessage() {

         cout << "Error, non discretized attribute\n";
	exit(1);
	}
		 void PrintMessage(const char* s) {

         cout << "\nError, non discretized attribute " << message << " called from " << s <<"\n";
	exit(1);
	}
};

class MissingValue {
public:
string message;
MissingValue(string s)
{
message=s;
};
MissingValue(){};
        void PrintMessage() {

         cout << "Error, missing value\n";
	exit(1);
	}
		 void PrintMessage(const char* message, int row, string col) {

         cout << "Error, missing value in row " << row << " and col " << col << " at " << message << "\n";
	exit(1);
	}
			 void PrintMessage(const char* message) {

         cout << "Error, missing value  at " << message << "\n";
	exit(1);
	}
};


} // end namespace
#endif
