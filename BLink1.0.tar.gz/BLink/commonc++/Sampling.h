/* File: Sampling.h */


#ifndef __Sampling_h__
#define __Sampling_h__

#include<sstream>
#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
#include <string>
#include <iostream>
#include <cmath>
#include <stdio.h>//

#include "ExceptionsBasic.h"

namespace BIOS {


/************************/
/* Sampling STATISTIC*/
/************************/


/**
        @memo Sampling

	@doc
        Definition:
        An array Pos of Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Sampling  {


protected:
    /** @name Implementation of class Sampling
        @memo Private part.
    */


  
  






/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

  int  * Pos;
 int Size;

Sampling(int size, bool repetition=false);
~Sampling();
int* getPositionsTable();


};  // End of class Sampling




};  // End of Namespace

#endif

/* End of file: Sampling.h */




