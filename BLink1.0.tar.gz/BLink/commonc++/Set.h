/* File: Set.h */


#ifndef __Set_h__
#define __Set_h__



/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A set of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */


 template <class T, template <class T> class Cont> class Set: public Container<T, Cont>
   {


  public:

    virtual string print(bool forward=true)
    {
      if (this->GetSize()==0) return string("Empty set");
      else
      {
        return SoftListOfPointers<T>::print(forward);
      }
    };
   
      /*___________________________________________________________*/

// template<class V> Set<T, Cont>(V& other):Container<T, Cont>()
 //V must be a class inherited from Set

Set<T, Cont>(Set<T, Cont>& other):Container<T, Cont>()
 {
  typename Set<T, Cont>::NodePointer p=other.GetFirst();
  while (p!=NULL)
  {
  this->insertElement(other.GetElement(p));
  p=other.GetNext(p);
  }
  };

    /*___________________________________________________________*/
/*
 Set<T, Cont>(Set<T, Cont>& other):Container<T, Cont>(other)
 {}
   
    /*___________________________________________________________*/

    Set<T, Cont>(): Container<T, Cont>()
    {}
    /*___________________________________________________________*/

    virtual ~Set<T, Cont>()
    {
 //  destroy(this->List);
}
    /*___________________________________________________________*/

    virtual void insertElement (T* element)
    {
//cout <<"inserting " <<element->print() <<"\n";
      bool exists=false;
      typename Set<T, Cont>::NodePointer p=this->GetFirst();

      while (p!=NULL)
      {
        if (*this->GetElement(p)==*element)
        {
       //   cout <<"Error in Set::insertElement in set \n" << this->print() <<"\nElement " << element->print() << " is already in the set";
      //    end();
exists=true;
        }
        p=this->GetNext(p);
      };

     if (!exists) Container<T, Cont>::insertElement(element);
    }

    /*___________________________________________________________*/

    Set<T, Cont>* removeSubsets ()
    {
     typename Set<T, Cont>::NodePointer p=this->GetFirst(), pNext, p2=NULL;
      bool found;
      while (p!=NULL)
      {
      p2=this->GetFirst();
      found=false;
      while(p2!=NULL && !found)
      {
      if (p!=p2 && this->GetElement(p)->includes(this->GetElement(p2)))
      {
      p2=this->removeNode(p2);
      found=true;
      }
      else p2=this->GetNext(p2);
      }
      p=this->GetNext(p);
      }
    }
    /*___________________________________________________________*/

    Set<T, Cont>* getCommonNodes (Set<T, Cont>* otherSet)
    {
      if (otherSet==NULL)
      {
        cout <<"Error in Set::getCommonNodes, argument is NULL";
        end();
      }
      Set<T, Cont>* commonSet=new Set<T, Cont>();
      Set<T, Cont>* orderedSet1=NULL;
      Set<T, Cont>* orderedSet2=NULL;
      // choose this shortest list
      if (this->GetSize()>otherSet->GetSize())
      {
        orderedSet1=new Set<T, Cont>(*this);
        orderedSet2 =new Set<T, Cont>(*otherSet);
      }
      else
      {
        orderedSet1=new Set<T, Cont>(*otherSet);
        orderedSet2 =new Set<T, Cont>(*this);
      }
      T* element=NULL;
      typename Set<T, Cont>::NodePointer p=orderedSet1->GetFirst(), pNext, p2=NULL;
      
      while (p!=NULL)
      {
        element=orderedSet1->GetElement(p);
	if (element==NULL)
	{
	cout <<"EERRR";
	end();
	}
	//cout <<"\nfinding element" << element->print() <<" in bag:" << orderedSet2->print();
        p2=orderedSet2->findElement(element);
        if (p2!=NULL)
        {
          commonSet->insertElement(element);
          orderedSet2->removeNode(p2);
        }
        p=orderedSet1->GetNext(p);
      }
      
      zap(orderedSet1);
      zap(orderedSet2);
      return commonSet;
    }
   
    /*___________________________________________________________________________________*/

    bool comparison(Set<T, Cont> & Source, int type)
    {
      Set<T, Cont>* fSet=new Set<T, Cont>(*this);
      fSet->Order();
      Set<T, Cont>* sSet=new Set<T, Cont>(*Source);
      sSet->Order();
      bool comparison= this->ListOfPointers<T>::comparison(*(ListOfPointers<T>*)Source, type);
      zap(fSet);
      zap(sSet);
      return comparison;
    }
};

/*______________________________________________________*/

   template <class T, template <class T> class Cont> ostream& operator<<(ostream& out, Set<T, Cont>& lista)
  {
   typename Set<T, Cont>::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << *lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<"; ";
    }
   
    return out;
  }


typedef Set<Integer, ListOfPointers> IntegerSet;

    

}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
