  /**
    * @file copyRowPositionswithRowInSecondFile.cpp
    * @brief Program to get rows positions when the row is in a second source file
    *
    */


#include "Fachade.h"


/* This program get row positions for rows in a second source file. Result is a file with the selected row numbers, starting by 0*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<4)
     {
        cerr << "Error: you have to specify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <input file2> " << " <output file> "  <<" ";
        exit(0);
        }
     char filename[256], filename2[256], filename3[256];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

	 strcpy(filename3, argv[3]);




if (strcmp(filename, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename, filename3)==0)
{
cout << "error, files must have different names";
exit(0);
}
if (strcmp(filename3, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}

stringList* currentLine=NULL;

Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename2);	


ofstream OutputFile;
OpenOutput(filename3, &OutputFile);

int cont=0;
TextFile* tf=new TextFile(filename);
currentLine=tf->readLine();
string value;
while (!tf->eof())
{

if (l->findElement(currentLine)!=NULL)
OutputFile << cont  <<"\n";
zap(currentLine);
currentLine=tf->readLine();
cont++;
}

zap(currentLine);
OutputFile.close();

zap(tf);
zap(l);

cout <<"\nResults have been saved in file " << filename3 <<"\n";

}










