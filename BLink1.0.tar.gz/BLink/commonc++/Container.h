/* File: Container.h */


#ifndef __Container_h__
#define __Container_h__





/**
    @memo Declaration of a Container (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* Container DEFINITION */
  /************************/


  /**
          @memo Container 
   
  	@doc
          Definition:
          A set of Container's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the Container
   
      @author Maria M. Abad Grau
  	@version 1.0
  */

  template <class T, template <class T> class Cont> class Set;
 
  template <class T, template <class T> class Cont> class Container: public Cont<T>
  {
  public:
  Container<T, Cont>(char* file, char* tokens=NULL):Cont<T>(file, tokens){};
  Container<T, Cont>(Container<T, Cont>& source, Sampling* sampling):Cont<T>(source, sampling){};

  Container<T, Cont>():Cont<T>(){};
 Container<T, Cont>(int i):Cont<T>(i){};
  virtual ~Container<T, Cont>(){};
  virtual Container<T, Cont> *clone();
//  Container<T, Cont>(const Container<T,Cont>& other){cout <<"Container(const) not implemented yet"; end();};
//Container<T, Cont>(Container<T,Cont>& other){cout <<"Container(&) not implemented yet"; end();};
  Container<T, Cont>(Container<T,Cont>& other, typename Container<T, Cont>::NodePointer first=NULL, typename Container<T, Cont>::NodePointer last=NULL):Cont<T>(other, first, last){};

  virtual Container<int, list>* copyPositionsByContents(Container<T, Cont>* c, int type);
  virtual Container<T, Cont>* copyElementsByContents(Container * Source, int type, bool orderedByThis=true);
  virtual Container<T, Cont>* copyElementsIn(Container* Source, bool orderedByThis=true);
  virtual Container<T, Cont>* copyElementsNotIn(Container * Source, bool orderedByThis=true);
  virtual Container<int, list>* copyPositionsWithElementsIn(Container<T, Cont>* Source);
  virtual Container<int, list>* copyPositionsWithoutElementsIn(Container<T, Cont>* Source);
  virtual Container<T, Cont>* copyElementsWithoutPositionsIn(Container<int, list> * sourceList);
  virtual Container<T, Cont>* copyElementsWithPositionsIn(Container<int, list> * sourceList, bool orderedByThis=true);
  virtual Container<T, Cont>* extractElementsWithoutPositionsIn(Container<int, list> * sourceList);
  virtual Container<T, Cont>* extractElementsWithPositionsIn(Container<int, list> * sourceList);
  virtual Container<T, Cont>* copyElementsByPositions(Container<int, list> * sourceList, int type, bool orderedByThis=true);
 virtual Container<T, Cont>* extractElementsByPositions(Container<int, list> * sourceList, int type, bool orderedByThis=true);
 //virtual Container<T, Cont>* mergeWith(Container<T, Cont>* secondList);

  virtual void removeElementsIn(Container* Source);
//  virtual void removeElementsWithPositionsIn(Container<int, list>* Source);
  Container<Integer, ListOfPointers>* getIntegerList();
  Set<Integer, ListOfPointers>* getIntegerSet();
   Container<int, list>* getIntListFromPointerList();

 Set<Integer, ListOfPointers>* getIntegerSetFromIntegerList();
 
  //T GetElement(typename Container<T,Cont>::NodePointer p);
   //typename Container<T, Cont>::NodePointer findElement(T& element);
//  typename Container<T, Cont>::NodePointer findFinalElement(T& element);

 Container<int, list>* getIntList();
Container<float, list>* getFloatList();

 Container<T, Cont>* reverse();
 
  //Container<T, list>* operator Container<T, list>(){return (Container<T, list>*)this;};


  };  // End of class Container

  //typedef  char s40[40];
typedef Container<int, list> intList;
typedef Container<float, list> floatList;
typedef Container<double, list> doubleList;
typedef Container<string, list> stringList;

typedef Container<Integer, ListOfPointers> IntegerList;

/*
template <class T, template <class T> class Cont> ostream& operator<<(ostream& out, Container<T, Cont>& lista)
{
cout << (Cont<T>&)lista;
}
*/
//template <typename T> Container<list<T>, Container<list<T>, ListOfPointers> > class Sample;

//typedef Container<list<int>, Container<list<int>, ListOfPointers> intSample;
//typedef Container<float, list> floatSample;
//typedef Container<double, list> doubleSample;
//typedef Container<string, list> stringSample;
/*______________________________________________________*/
/*
   template <class T, template <class T> class Cont> ostream& operator<<(ostream& out, Container<T, Cont>& lista)
  {
out <<"(";
   typename Container<T, Cont>::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << *lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<","; else out <<")";
    }
     out <<"\n";
 
    return out;
  }
/*______________________________________________________*/
/*
   ostream& operator<<(ostream& out, intList& lista)
  {
out <<"(";
    intList::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<","; else out <<")";
    }
     out <<"\n";
 
    return out;
  }
/*______________________________________________________*/
/*
   ostream& operator<<(ostream& out, floatList& lista)
  {
out <<"(";
    floatList::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<","; else out <<")";
    }
     out <<"\n";
 
    return out;
  }
/*______________________________________________________*/
/*
   ostream& operator<<(ostream& out, stringList& lista)
  {
    stringList::NodePointer p=lista.GetFirst();
out <<"(";
 while (p!=NULL)
    {
         out << lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<","; else out <<")";
    }
   out <<"\n";
    return out;
  }
*/
} // end namespace
#endif

//#include "Container.cpp"

/* Fin Fichero: Container.h */


/* Fin Fichero: Container.h */
