/* File: Binomial.cpp */


#ifndef __Binomial_cpp__
#define __Binomial_cpp__


#include "Binomial.h"


namespace BIOS {

#define RAND_UNIFORME (double)rand()/(double)RAND_MAX


/**********************************/
Binomial::Binomial(int n, double Prob)
{
Size=2;
this->n=n;
p=Prob;
values=Initialize(n, 0);
setAllValues();
pointer=0;
}
/**********************************/
Binomial::Binomial(int n)
{
Size=2;
this->n=n;
values=Initialize(n, 0);
pointer=0;
}
/**********************************/
Binomial::~Binomial()
{
zaparr(values);
}
/**********************************/
int* Binomial::getFrequencies()
{
int* frequencies=Initialize(Size, 0);
for (int i=0;i<n;i++)
 frequencies[values[i]]++;
return frequencies;
}
/**********************************/
int Binomial::getNextValue()
{
pointer++;
return values[pointer-1];
}
/**********************************/
void Binomial::setAllValues()
{
if (n==1)
 values[0]=random_binomial();
else
{
Binomial* one;
for (int i=0;i<n;i++)
{
one=new Binomial(1, p);
values[i]=one->random_binomial();
zap(one);
}
};
};
/**********************************/

int Binomial::random_binomial()
{
//if (n!=1)
//throw BadSize("Binomial::random_binomial()");
double t=p/(1-p);
double u=RAND_UNIFORME;
double p0=std::pow((1-p),n);
double g=p0;
unsigned int k=0;
while (u>g)
    {
    p0*=t*(n-k)/(k+1);
    g+=p0;
    k++;
    };
return n-k;
}

/**********************************/
/*
int Binomial::random_binomial()
{
double t=p/(1-p);
double u=RAND_UNIFORME;
double p0=std::pow(p,n);
double g=p0;
unsigned int k=0;
while (u>g)
    {
    p0*=t*(n-k)/(k+1);
    g+=p0;
    k++;
    };
return k;
}
*/

};  // End of Namespace

#endif

/* End of file: Binomial.h */




