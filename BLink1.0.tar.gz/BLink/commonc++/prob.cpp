/* File: prob.cpp */


#ifndef __prob_cpp__
#define __prob_cpp__

                                                   
#include "prob.h"//

using namespace std;

namespace BIOS {



prob::prob(double num=0, double den=1):pair<double>(num, den)
{
if ((num>den) || (num*den<0))
{
	cout <<"\nError in prob::new, non a probability, num:" << num <<", den:" << den;
	end();
}
}
/////////////
prob::prob(double num, double den, float alpha, int size):pair<double>(num, den)
{
if ((num>den) || (num*den<0))
{
	cout <<"\nError in prob::new, non a probability, num:" << num <<", den:" << den;
	end();
}
addAlpha(alpha, size);
}
/////////////////
prob prob::operator/ (prob & rat2)
{
prob result(0,0);
result.numerator=numerator*rat2.denominator;
result.denominator=denominator*rat2.numerator;

if (result.numerator>result.denominator)
{
	cout <<"\nError in prob::operator/, non a probability " << print() <<" divided by " << rat2.print();
	end();
}
pair<double> r=pair<double>(numerator, denominator), r2=pair<double>(rat2.numerator, rat2.denominator), r3=r/r2;

result=prob(r3.numerator, r3.denominator);
return result;
}
/////////////////
void prob::addAlpha (float alpha, int size)
{
numerator=numerator+alpha/size;
denominator=denominator+alpha;
}

}//end namespace
#endif
