#ifndef Sample_h//
#define Sample_h//

#include "basic.h"
#include "ListOfPointers.h"
#include "Prob.h"

namespace BIOS 
{



template<class T, template <class T> class Cont,template <class Cont> class SuperCont>
    class Sample: public Container<Container<T,Cont>, SuperCont>
{
  protected:
  
 Container<T, Cont>* ReadElement (ifstream * source, char* tokens);


// Container<T,Cont>* getElement(typename Sample<T, Cont, SuperCont>::NodePointer p);

// void ReadInfo (ifstream * is, char* tokens);


public:

int getTotalMissingValues();

   Sample<T, Cont, SuperCont>* mergeWith(Sample<T, Cont, SuperCont>* secondList);
   // Sample<T, Cont, SuperCont>* mergeWithUsingColumn(Sample<T, Cont, SuperCont>* secondList, int column);

/*
  int getTotalPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last);
  int getTotalLeftPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last, typename Sample<T, list, ListOfPointers>::NodePointer between);
  int getTotalRightPatterns(typename Sample<T, list, ListOfPointers>::NodePointer first, typename Sample<T, list, ListOfPointers>::NodePointer last, typename Sample<T, list, ListOfPointers>::NodePointer between);
*/

    Sample():Container<Container<T,Cont>, SuperCont>(){};

    //Sample(Sample &source):Container<Container<T,Cont>, SuperCont>(source){};

//Sample(const Sample &source){cout <<"Sample(const) not implemented yet";end();};

//Sample(Sample &source){cout <<"Sample(&) not implemented yet";end();};


Sample(Sample &source, typename Sample<T, Cont, SuperCont>::NodePointer first=NULL, typename Sample<T, Cont, SuperCont>::NodePointer last=NULL):Container<Container<T,Cont>, SuperCont>(source, first, last){};


Sample(Sample &source, Sampling* sampling):Container<Container<T,Cont>, SuperCont>(source, sampling){};

    Sample(char* filename, char* tokens="\t ,\n"):Container<Container<T,Cont>, SuperCont>()
    {
    this->GetInfo(filename, tokens);
    };

Sample<T, Cont, SuperCont>* clone()
{
return new Sample(*this);
}
   Sample<T, Cont, SuperCont>* extractRowsWithPositionsIn(intList* posList);

  // Sample<T, Cont, SuperCont>* extractElementsWithPositionsIn(intList* posList);

  //  void selectColumns(intList* columns);
 
   // Sample<T, SuperCont>* ExtractList(int indexVector[], int size);

    //Sample():SuperCont<Container<T, Cont>, Cont>(){};

    //Sample(Sample &source):SuperCont<Container<T, Cont>, Cont>(source){};

   // Sample(char* filename, char* tokens):SuperCont<Container<T, Cont>, Cont>()
   // {
   // this->GetInfo(filename, tokens);
   // };
 
 Sample<T, Cont, SuperCont>* copyColumns(intList* posList, bool orderedByThis=true);

 // typename Sample<T, Cont, SuperCont>::NodePointer findFinalElement(T element);

// Sample(char* filename): para leer directamente de un fichero

	~Sample(){};


//Sample<T, Cont, SuperCont>* copyColumns(int indexVector[], int size);

Sample<T, Cont, SuperCont>*  moveColumn(int oldPos, int newPos);
 
//void HardCopy();

long int GetSampleSize(); 

//char* print(bool* seleccionados, bool* integer);

//void HardCopy(char filename[128], bool* indexVector, bool* integer);

//void HardCopy(char filename[128], bool* indexVector);

//void selectAndOrderColumns(intList* columns);
 
//void Order(int column, bool ascendent);

long int GetAbsoluteFrequency(Set<AttPattern, ListOfPointers >* attPattern) throw (OutOfBounds);

//double GetRelativeFrequency(Set<AttPattern, ListOfPointers>* attPattern);

//Prob GetConditionalFrequency(Set<AttPattern, ListOfPointers>* attPattern, Set<AttPattern, ListOfPointers>* conditioners);

//Sample<T, Cont, SuperCont>* CopyColumns(int indexVector[], int size);//

//Sample<T, Cont, SuperCont>* copyColumn(int col);//

//Sample<T, Cont, SuperCont>* removeColumn(int col);//

//Sample<T, Cont, SuperCont>* SecondCopyColumns(int indexVector[], int size);//

Container<T, Cont>* getColumn(int index);//
Sample<T, Cont, SuperCont>* transpose();//

//typename Container<T, Cont>::NodePointer findFinalElement(T element);

  
   intList* getOptimalBlanket (Container<T, Cont>* otherSet);
 
   int getOptimalSingleBlanket (Container<T, Cont>* otherSet);
  
 
};

/*______________________________________________________*/

template<class T, template <class T> class Cont,template <class Cont> class SuperCont> ostream& operator<<(ostream& out, Sample<T, Cont, SuperCont>& lista)
  {
  typename Sample<T, Cont, SuperCont>::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << *lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<"\n";
    }
   
    return out;
  }

  
  
 //template <class T, template <class T> class SuperCont> class Container: public SuperCont<T>
 
//template<template<class> class <template-parameter-2-1>
//Container<int, list>
typedef Sample<int, list, ListOfPointers> intSample;
typedef Sample<float, list, ListOfPointers> floatSample;
typedef Sample<double, list, ListOfPointers> doubleSample;
typedef Sample<string, list, ListOfPointers> stringSample;

} // end namespace
#endif
