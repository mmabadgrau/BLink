/* File: MultidimensionalTable.h */


#ifndef __MultidimensionalTable_h__
#define __MultidimensionalTable_h__

#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"

using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  template <class T> class MultidimensionalTable //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  protected:

    int size;
    T* table;
    int totalDimensions;
    T totalCounts;

  public:

    intList *dimensionList;
 
    /*______________________________________________________*/

    MultidimensionalTable()
    {
     set();
    };
/*______________________________________________________*/

    void set()
    {
      this->totalDimensions=0;
      this->table=NULL;
      this->dimensionList=NULL;
       size=0;
      totalCounts=0;
    };
    /*______________________________________________________*/

    MultidimensionalTable(intList* dimensionList)
    {
    set(dimensionList);
    };
      /*______________________________________________________*/

    MultidimensionalTable(MultidimensionalTable &source)
    {
try{
 if (source.dimensionList==NULL) set();
    else 
{

 this->totalCounts=source.totalCounts;
  set(source.dimensionList);
      for (int i=0; i<size;i++)
       setValue(i, source.getValue(i));
}
}
catch (MissingValue mv){mv.PrintMessage("MultidimensionalTable(MultidimensionalTable &source)");end();}
      }
     /*______________________________________________________*/

    void set(intList *dimensionList) throw (NullValue)
    {
if (dimensionList==NULL)
throw NullValue("MultidimensionalTable::set(intList*): NULL value");
this->dimensionList=new intList(*dimensionList);

totalDimensions=dimensionList->GetSize();
if (totalDimensions==0)
throw NullValue("MultidimensionalTable::set(intList*): 0 dimensions");
setSize();
this->table=new T[size];
         //this->initialize();
      }
 
  /*______________________________________________________*/

void initialize()
{
InitializeList(this->table, size, (T)0);
}
  /*______________________________________________________*/

T GetMax()
{
return BIOS::GetMax(table, size);
}
   /*______________________________________________________*/

    void setSize() throw (ZeroValue)
    {
    size=1;
      for (int i=0; i<totalDimensions;i++)
        size=size*dimensionList->GetElement(i);
	if (size==1) throw ZeroValue("MultidimensionalTable::setSize");
    }
       /*______________________________________________________*/

  //  virtual ostream& operator<<(ostream& out);//{cout <<"MultidimensionalTable:print() Not implemented yet"; end();};
     /*______________________________________________________*/

    ~MultidimensionalTable(){empty();};
    /*______________________________________________________*/

    void empty(){zaparr(table); zap(dimensionList);};

 /*_______________________________________________________________*/

  MultidimensionalTable<T>* project(intList* sourcePosList)
  {
  this->setTotalCounts();
  intList* newDimensionList=dimensionList->copyElementsWithPositionsIn(sourcePosList);
  intList* missingDimensionList=dimensionList->copyElementsWithoutPositionsIn(sourcePosList);
  MultidimensionalTable<T>* newMultidimensionalTable=new MultidimensionalTable<T>(newDimensionList);
  MultidimensionalTable<T>* missingTable=new  MultidimensionalTable<T>(missingDimensionList);
  zap(missingDimensionList);
  zap(newDimensionList);
  int completePositions[totalDimensions], missingVarPositions[missingTable->getDimension()], * currentPositions=dimensionList->getTable(), *remainingPositions, *remainingVarPositions=sourcePosList->getTable(), c, *missingPositions;
  c=0;
  for (int j=0;j<totalDimensions;j++)
    if (sourcePosList->findElement(j)==NULL)
        {
          missingVarPositions[c]=j;
          c++;
        }
  for (int i=0; i<newMultidimensionalTable->size;i++)
  {
  remainingPositions=newMultidimensionalTable->getPositions(i);
  disperseValues(remainingPositions, newMultidimensionalTable->totalDimensions, remainingVarPositions, currentPositions, totalDimensions);
try
{
   for (int j=0;j<missingTable->size;j++)
     {
     missingPositions=missingTable->getPositions(j);
     disperseValues(missingPositions, missingTable->getDimension(), missingVarPositions, currentPositions, totalDimensions);
     missingTable->setValue(j, this->getValue(currentPositions));
//cout <<"\n\n\n val at pos " << j <<" is:" << missingTable->print();
     zaparr(missingPositions);
     }
}
catch (MissingValue mv){mv.PrintMessage("MultidimensionalTable::project");end();}
    missingTable->setTotalCounts();
   // this->setTotalCounts();

   // cout <<"totalCounts";
//BIOS::print(missingTable->getTotalCounts());
//cout <<"\n";
    newMultidimensionalTable->setValue(i, (T)missingTable->getTotalCounts());
/*
    if (this->getTotalCounts()<missingTable->getTotalCounts())
    {
    cout <<"Error in MultidimensionalTable:project";// of vars dims " << *this->dimensionList  <<" on vars dim "  << *this->dimensionList <<" gives " << missingTable->getTotalCounts() << " versus " << this->getTotalCounts();
    end();
    }
*/
    zaparr(remainingPositions);
   }
  zap(missingTable);
  zaparr(currentPositions);
zaparr(remainingVarPositions);
return newMultidimensionalTable;
  };
/*______________________________________________________*/

  void setTotalCounts()
  {
//cout <<*this <<"\n";
if (size>0)
{
    totalCounts=table[0];
     for (int i=1; i<size;i++)
          totalCounts=totalCounts+table[i];
}
  };
     /*______________________________________________________*/

    T getTotalCounts()
    {
      return totalCounts;
    };

  /*______________________________________________________*/
/*
   template<> T* MultidimensionalTable<Prob>::getTotalCounts()
 
    {
      return &totalCounts;
    };
    /*______________________________________________________*/

    void setValue(int* pos, T value)
    {
     table[getPos(pos)]=value;
    
    };
    /*______________________________________________________*/

    void setValue(int pos, T value)
    {
      table[pos]=value;
    };
    /*______________________________________________________*/
/*
    virtual void setValue(int pos, double numerator, double denominator)
    {
      table[pos]=(T)(numerator/denominator);
    };
/*______________________________________________________*/

    virtual void addValue(int pos, T value)
    {
      table[pos]=table[pos]+value;
    };

/*______________________________________________________*/

    virtual void addValue(int* pos, T value)
    {
addValue(getPos(pos), value);
    };
    /*______________________________________________________*/
/*
    void addValue(int pos, double numerator,double denominator)
    {
      table[pos]=table[pos]+(T)(numerator/denominator);
    };
    /*______________________________________________________*/

    int getSubtableSize(int dim)
    {
      int subsize=1;
      for (int i=dim+1; i<totalDimensions;i++)
        subsize=subsize*dimensionList->GetElement((int)i);
      return subsize;
    }
    /*______________________________________________________*/

    int getPos(int *pos)
    {
      int absPos=0;
      for (int i=0; i<totalDimensions;i++)
        absPos=absPos+pos[i]*getSubtableSize(i);
	
      if (absPos>=size)
      {
      cout <<"OutOfRange error in MultidimensionalTable::getPos, with (" << *dimensionList <<") dimensions, size is " << size <<" and it is trying to access at pos " << absPos;
       for (int i=0; i<totalDimensions;i++)
     	cout <<"\nval at pos" <<i<<" is: " << pos[i];
      end();
      }
     // cout <<"pos is " << absPos <<"\n";
      return absPos;
    };
    /*______________________________________________________*/

    int getDimension()
    {
      return totalDimensions;
    };
    /*______________________________________________________*/

    int* getPositions(int pos)
    {
      int *positions=new int[totalDimensions], rem;
      for (int i=0; i<totalDimensions;i++)
      {
        rem=getSubtableSize(i);
        positions[i]=pos/rem;
        pos=pos-positions[i]*getSubtableSize(i);
      }
      return positions;
    };

/*______________________________________________________*/

    int getIndexPositionOfIndexVar(int pos, int var)
    {
    // given a pos in Table and a var, it returns the index position of such a var
      int *positions=getPositions(pos);
      int index=positions[var];
zaparr(positions);
      return index;
    };
    /*______________________________________________________*/

    bool isCompletelyMissing(int *pos)
    {
      int totalMissing=0;
      for (int i=0;i<totalDimensions;i++) 
      {
      if (i>=dimensionList->GetSize())//eliminar comprobacion
      {
      cout <<"Error in MultidimensionalTable::isCompletelyMissing";
      end();
      }
      if (pos[i]==dimensionList->GetElement(i)) totalMissing++;
      }
      if (totalMissing==totalDimensions) return true; else return false;

    }
     /*______________________________________________________*/

    void setMissing(int* pos, int index)
    {
      pos[index]=dimensionList->GetElement(index);
      }
 /*______________________________________________________*/

    bool isMissing(int *pos)
    {
      int totalMissing=0;
      int i=0;
      while (i<totalDimensions)
      {
      if (i>=dimensionList->GetSize())//eliminar comprobacion
      {
      cout <<"Error in MultidimensionalTable::isCompletelyMissing";
      end();
      }
      if (pos[i]==dimensionList->GetElement(i)) return true;
      i++;
      }
      return false;
      }
    /*______________________________________________________*/

    T getValue(int pos)
    {
    return table[pos];
    }
    /*______________________________________________________*/

    T getValue(int *pos) throw (MissingValue)
    {
      int totalMissing=0;

      for (int i=0;i<totalDimensions;i++) if (pos[i]==dimensionList->GetElement(i)) totalMissing++;
      if (totalMissing==0) return getValue(getPos(pos)); 
        //   cout <<"hh" << totalMissing << "and total dim:" << totalDimensions;
      if (totalMissing==totalDimensions) throw MissingValue("MultidimensionalTable::getValue");
      
     intList *remainingVarPositions=new intList();
     int remainingPositions[totalDimensions-totalMissing], c=0;

     for (int i=0;i<totalDimensions;i++)
      {
        if (pos[i]!=dimensionList->GetElement(i))
        {
          remainingVarPositions->insertElement(i);
          remainingPositions[c]=i;
          c++;
        }
      }
    
     MultidimensionalTable* mT=project(remainingVarPositions);
          cout <<"HERE\n";
     T value=mT->getValue(remainingPositions);
     zap(mT);
     return value;

   };

    /*______________________________________________________*/

    int getSize() {return size;};
    /*______________________________________________________*/

    int getSize(int* values)
    {
      int size=1;
      for (int i=0; i<totalDimensions;i++)
        if (values[i]!=dimensionList->GetElement(i))
          size=size*dimensionList->GetElement((int)i);

      return size;
    };
/*_______________________________________________________________*/


  virtual void normalize()
  {
  BIOS::normalize(table, size);
   // for (int i=0;i<size;i++)
   //  setValue(i, getValue(i), totalCounts);
}
  
    /*_______________________________________________________________*/

  void removeInconsistenciesWithEvidence(intList* sourcePosList, T value)
  {
if (sourcePosList==NULL)
{
cout <<"Error in MultidimensionalTable::removeInconsistenciesWithEvidence, NULL pattern";
end();
}
    int *pos;
    int j;
    double numerator, denominator;
    bool inconsistency=true, conditionalInconsistency=false;
    for (int i=0; i<getSize();i++)
    {
      inconsistency=false;
      pos=getPositions(i);
      j=0;
      do
      {
        if (pos[j]!=sourcePosList->GetElement(j) && sourcePosList->GetElement(j)!=dimensionList->GetElement(j))
          inconsistency=true;
        j++;
      }
      while (j<getDimension() && inconsistency==false);
      if (inconsistency)
         setValue(getPos(pos), 0);
       zap(pos);
    }
//    setTotalCounts();
 //   normalize();
  }
 
    /*_______________________________________________________________*/
//template<template <class T> class X> class A { };
//template<class T> class B { };
 
//A<B> a;


/*
template<template <class T> class X>  class Table
{
Table* operator*(Table* source);
Table* operator/(Table* source);
}



     Table<B>::operator*(Table<T> >* source)
  {
  return this->product(source, true);
   };
  
 
   
   
/*______________________________________________________*/

  virtual string print()
  {
    string result=string("");
    char posChar[2000];
    int *pos=NULL;
    int pv;
    for (int i=0; i<this->size;i++)
    {
      pos=this->getPositions(i);
      result=result+"\nFreq (";
      strcpy(posChar,"\0");

      for (int j=0; j<dimensionList->GetSize();j++)
      {
        sprintf(posChar, "Pos %d= %d, ", j, pos[j]);
        result=result+"var ";
        result=result+string(posChar);
      }

      result=result+ ") = ";

      result=result+tos(this->getValue(pos));
     
      zaparr(pos);
    };
    return result;

  };

  
   }; // end class
  
 
   
   /*______________________________________________________*/
   /*
  //template <class T> ostream& MultidimensionalTable<T>::operator<<(ostream& out)
 template <class T>  ostream& operator<<(ostream& out, MultidimensionalTable<T>& p)
 
  //template <class T> string MultidimensionalTable<T>::print()
  {
    //string result=string("");
    char posChar[2000];
    int *pos=NULL;
    int pv;
    T t;
    for (int i=0; i<p.getSize();i++)
    {
      pos=p.getPositions(i);
      out << "\nValue (";
      strcpy(posChar,"\0");

      for (int j=0; j<p.dimensionList->GetSize();j++)
      {
        out << j <<"= " << pos[j] <<",";
        out<<"var ";
       }

      out << ") = ";

      t=p.getValue(pos);
      out << t;

      zaparr(pos);
    };
   return out;
  };

/*______________________________________________________*/
/*
  template<> void MultidimensionalTable<Prob>::setTotalCounts()
  {
    totalCounts=Prob(0,0);
    int *pos=NULL;
    
    for (int i=0; i<size;i++)
    {
      pos=getPositions(i);
      totalCounts=totalCounts+getValue(pos);
      zap(pos);
    };
  };
  /*______________________________________________________*/
/*
   template<> void MultidimensionalTable<Prob>::setValue(int pos, double numerator, double denominator)
    {
      table[pos]=Prob(numerator,denominator);
    };
/*_______________________________________________________________*/


  template<> void MultidimensionalTable<Prob>::normalize()
  {
  /*
    for (int i=0;i<size;i++)
     setValue(i, getValue(i).getNumerator(), totalCounts);
     */
}
/*______________________________________________________*/
/*
    template<>  void MultidimensionalTable<Prob>::addValue(int pos, double numerator, double denominator)
    {
    Prob a=this->table[pos], b=Prob(numerator, denominator);
      this->table[pos]=a+b;
    };
/*______________________________________________________*/
/*
    template<>  MultidimensionalTable<Prob>* MultidimensionalTable<Prob>::project(intList * dimensionList)
    {
   cout <<"MultidimensionalTable<Prob>::project not implemented yet";
end();
    };
  /*______________________________________________________*/
/*
      template<>  Prob MultidimensionalTable<Prob>::getTotalCounts()
    {
      return ProbtotalCounts;
    };
  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, MultidimensionalTable<T>& p)
  {
    out << p.print();
    return out;
  }
}
#endif
