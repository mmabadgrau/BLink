/* File: listP.h */


#ifndef __listP_h__
#define __listP_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>


#include "list.h"


  /**
      @memo Declaration of a listP (FIFO)
      @doc
      */
//using namespace std;
//using namespace UTILS;

namespace BIOS {

/************************/
/* listP DEFINITION */
/************************/


/**
        @memo listP 

	@doc
        Definition:
        A set of listP's features 

        Memory space: O(SizeP), which SizeP being the number of elements in the listP

    @author Maria M. Abad
	@version 1.0
*/

	
	
template <class T> class listP: public list<T> {

public:	

/////////////////////////

T GetLastElement();
T* GetPointerToElement(typename list<T>::NodePointer e);//  (node * e);//
T* GetPointerToElement(int k);
	  //virtual 
T ReadElement (ifstream * is, int size); // if word virtual is not included, end loop
T Pop();
	
};


} // end namespace
#endif

#include "listP.cpp"

/* Fin Fichero: listP.h */
