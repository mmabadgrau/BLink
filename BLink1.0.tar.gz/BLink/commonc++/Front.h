
#ifndef __Front_cpp__
#define __Front_cpp__

#include "basic.cpp"

#include "list.cpp"
#include "ListOfPointers.cpp"
#include "Basic2.cpp"
using namespace std;

namespace BIOS
{


}
// end namespace

//#include "Front.cpp"
#endif


