/* File: Bag.h */


#ifndef __Bag_h__
#define __Bag_h__



#include "ExceptionsBasic.h"
#include "basic.cpp"
#include "AttPattern.h"

/**
    @memo Declaration of a list (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* list DEFINITION */
  /************************/


  /**
          @memo list 
   
  	@doc
          Definition:
          A set of list's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the list
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
/*
 template <class T> typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;

    };
*/
	template <class T> class Bag: public ListOfPointers<T>
  {

 
public:
 
	bool operator==(Bag & source)
	{
     list<T>* lista=new list<T>((list<T>&)source);
     list<T>* lista2=new list<T>((list<T>&)*this);
	 lista->order();
	 lista2->order();
     bool result=(*lista==*lista2);
	 zap(lista);
	 zap(lista2);
	 return result;
	}

	}
} // end namespace
#endif


/* Fin Fichero: Bag.h */


/* Fin Fichero: Bag.h */
