
#ifndef __Basic2_cpp__
#define __Basic2_cpp__


#include "Basic2.h"
using namespace std;

namespace BIOS
{

void print(char* filename)
{
TextFile *textFile=new TextFile(filename, true);
textFile->print();
}
/*_______________________________________________________________*/

  template <class T> bool empty(list<T>* lista)
  {return lista==NULL || lista->GetSize()==0;}

/*_______________________________________________________________*/

  template <class T> T GetMean (Pair<T>* values, int size, bool first)
  {
    T total=0;
    for (int i=0;i<size;i++)
      if (first)   total=total+values[i].First;
      else total=total+values[i].Second;
    return total/size;
  }

 /*_______________________________________________________________*/

  intList* getNumbers (char* input)
  {
intList* result=new intList();
stringList* vals=getList(input, ","), *list2;
char value[10];
for (int i=0;i<vals->GetSize();i++)
{
strcpy(value, vals->GetElement(i).c_str());
 list2=getList(value, ":");
if (list2->GetSize()>2)
{
cout << "Error in argument, character ':' is allowed only once\n";
end();
}
if (list2->GetSize()==1) 
result->insertElement(atoi(list2->GetFirstElement().c_str()));
else 
for (int j=atoi(list2->GetFirstElement().c_str());j<=atoi(list2->GetLastElement().c_str());j++)
 result->insertElement(j);
 }
return result;
}
  /* _____________________________________________________*/

   template <class T> Container<T, list>* createList(T* array, int length)
	{
Container<T, list>* newList=new Container<T, list>();
		for (int i=0; i<length;i++)
newList->insertElement(array[i]);
			return newList;
	}
  /* _____________________________________________________*/

  stringList*  getList (char * genotypebuf2, char* tokensSource)
  {
//bool doubleQuoteMark=false;
char genotypebuf[strlen(genotypebuf2)];
    if (genotypebuf==NULL) return NULL;
  stringList* strList=new stringList();
  
strcpy(genotypebuf, genotypebuf2);
    char tokens[10];
    if (tokensSource==NULL) strcpy(tokens, "\t, \n");
else
    if (strstr(tokensSource, ",\"")!=NULL ||
strstr (tokensSource, "\",")!=NULL)
{
//doubleQuoteMark=true;
string st=string(tokensSource);
//cout <<"orig:" << st;

replaceAll(st, string("\","), string("\t"));
replaceAll(st, string(",\""), string("\t"));

//cout <<"tokens:" << st;
strcpy(tokens, st.c_str());
strcpy(genotypebuf, genotypebuf+1);//remove first char (double quote mark)
genotypebuf[strlen(genotypebuf)-1]='\0'; // remove last char
string st2=string(genotypebuf);
string oldS=string("\",\""), newS=string("\t");
replaceAll(st2, oldS, newS);
strcpy(genotypebuf,st2.c_str());
//cout <<"\nNewrow:" << genotypebuf;

}
else strcpy(tokens, tokensSource);



    string s;
    char *cad;

    cad = strtok (genotypebuf, tokens);
int i=0;
while (cad!=NULL) // && cad[0]!='\n')// && cad[0]!='\r' && cad[0]!='/')
    {

        if (i==0)
          strList=new stringList();
        s=cad;
        strList->insertElement(s);
      
      cad = strtok (NULL, tokens);

      
        i++;
	
    };

//cout <<"\nnewlist:" << *strList;
return strList;
  };
}
// end namespace

//#include "basic.cpp"
#endif


