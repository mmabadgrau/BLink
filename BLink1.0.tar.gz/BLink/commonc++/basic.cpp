
#ifndef __basic_cpp__
#define __basic_cpp__


#include "basic.h"


namespace BIOS
{
	/*
	 template <class T> ostream& operator<<(ostream& out, T& clase)
	 {
	out << clase.print();
	return out;
	 }
*/
 /*______________________________________________________*/
/*
  template<class T> ofstream& operator<<(ofstream& out, const T& p)
{
	out << p.print();
	return out;
}
/*___________________________________________________________________________________*/
	/*
	template <class T> T* ExtractList(T object, int indexVector[], int size)//
	{
		T* newList=new T(*object);
                newList->selectElements(indexVector, size);
                return newList;
	};
	*/
	
string print(double e)
{
char val[10];
sprintf(val, "%0.4f", e);
return string(val);
}
	/*---------------------------------------------------------------*/
	
	template<class T> int compare(const void *arg1, const void *arg2)
	{
		if(*(T *) arg1 < *(T *)arg2) return -1;
		else if(*(T*) arg1 > *(T *)arg2) return 1;
		else return 0;
	}
	/*---------------------------------------------------------------*/
	
	
	template<class T> int compareinv(const void *arg1, const void *arg2)
	{
		if(*(T *) arg1 > *(T *) arg2) return -1;
		else if(*(T *) arg1 < *(T *) arg2) return 1;
		else return 0;
	}
	/*---------------------------------------------------------------*/
	
	template<class T> int comparePointer(const void *arg1, const void *arg2)
	{
//cout << ((T*)arg2)->print() <<"\n";
//return 1;
//end();
		if(**(T **) arg1 < **(T **)arg2) 
{
//cout <<"val " << ((T*)arg1)->print() << " is lower than val " << ((T*)arg2)->print();
return -1;
}
		else 
if(**(T**) arg1 > **(T **)arg2) 
{
//cout <<"\nval " << ((T*)arg1)->print() << " is greater than val " << ((T*)arg2)->print();

return 1;
}
		else 
return 0;

	}
	/*---------------------------------------------------------------*/
	
	
	template<class T> int compareinvPointer(const void *arg1, const void *arg2)
	{
		if(**(T **) arg1 > **(T **) arg2) return -1;
		else if(**(T **) arg1 < **(T **) arg2) return 1;
		else return 0;
	}
	
	
	template <class T> string tos(T i)
		// convert  string
	{
		stringstream s;
		s << i;
		return s.str();
	};
	template <> string tos(double i)
		// convert  string
	{
        char cad [20];
        sprintf(cad, "%0.5lf", i);
        return (string(cad));
		
	};
	string tos(double i, int integerPart, int decimalPart)
		// convert  string
	{
        char cad [20];
        char cad2[10];
        strcpy(cad2, "%");
        sprintf(cad2, "%s%d", cad2, integerPart);
        strcat(cad2, ".");
        sprintf(cad2, "%s%d", cad2, decimalPart);
        strcat(cad2, "lf");
        sprintf(cad, cad2, i);
        return (string(cad));
		
	};
	
	/////////
	
	int pow (int base, int exp)
	{
		return (int) std::pow((double)base, (double)exp);
	}
	////////////////
	double log_2 (double numero)//
	{//
		double result=0;//
		result=log(numero)/log((double)2);//
		return(result);//
	}//
	
	/////////
	template <class T> T sum (T* array, unsigned int length)
	{
		T total=0;
		for (int i=0; i<length;i++)
			total=total+array[i];
		return total;
	}

	/////////
	template <class T> void change (T & val1, T  & val2) //=swap
	{
		T s;
		s=val1;
		val1=val2;
		val2=s;
	}
	/////////
	/*---------------------------------------------------------------*/
	
	template <class T>
		T * Initialize(int size, T val)
	{
		T * x;
		try
		{
			if ((x = new T [size])==NULL) //
				throw NoMemory();
		}
		catch (NoMemory NM)
		{
			NM.PrintMessage();
		}
		
		InitializeList(x, size, val);
		return (x);
	}
	/*---------------------------------------------------------------*/
	
	template <class T>
		void InitializeList(T* list, int size, T val)
	{
		for (int i=0;i<size;i++)
			list[i]=val;
	}
	/*---------------------------------------------------------------*/
	
	template <class T>
		void disperseValues(T* array, int size, T* pos, T* targetArray, int sizeTarget)
	{
	// copy values from array to targetArray at positions specified in array pos. Arrays pos and array have same size, leq of array sizeTarget
	try
	{
	 if (sizeTarget<size) 
           throw NoMemory();

	 	for (int i=0;i<size;i++)
		 if (pos[i]>=sizeTarget) throw NoMemory();
		 else targetArray[pos[i]]=array[i];

	}
	catch (NoMemory NM)
	{
			NM.PrintMessage("basic::disperseValues");
	
	}
			
			
	}
/*---------------------------------------------------------------*/
	
	template <class T>
		void reorderValues(T* array, int size, T* targetPos,  T* targetArray)
	{
for (int i=0;i<size;i++)
targetArray[targetPos[i]]=array[i];
}

	/*---------------------------------------------------------------*/
	
	template <class T>
		void collapseValues(T* array, int size, T* pos, T* targetArray, int sizeTarget)
	{
	// copy values from array to targetArray at positions specified in array pos. Arrays pos and targetArray have same size, leq of array array
	try
	{
	 if (sizeTarget>size) 
	 {
	 	cout <<"\nTarget has size " << sizeTarget <<" and source " << size;

	 throw NoMemory();
	 }
	 	for (int i=0;i<sizeTarget;i++)
		 if (pos[i]>=size) 
		 {
		 	cout <<"\nTrying to access at pos " << pos[i] <<" when source size is " << size;

		 throw NoMemory();
		 }
		 else targetArray[i]=array[pos[i]];

	}
	catch (NoMemory NM)
	{
			NM.PrintMessage("basic::collapseValues");
	
	}
			
	}
	/*---------------------------------------------------------------*/
	
	template <class T> bool IsOne (T value)
	{
		double val=(double) value;
		if ((val>=(1.0-zero)) && (val<=(1.0+zero)))
			return true;
		else return false;
	}
	///////
	bool existFile (char* namefile)
	{
		struct stat fs;
		//	cout <<"val" << stat(namefile, &fs);
		if (stat(namefile, &fs)==0) return (true); else return (false);
	}
	//////////////////
	int maxlong () //
	{ //
		int larg, result=0; //
		unsigned int contador;//
		for (contador=0; contador<(sizeof(larg)*8); contador++) //
			result=result+pow(2, contador); //
		return (result); //
	} //
	/*---------------------------------------------------------------*/
	
	bool IsAZero(unsigned int column, unsigned int pos)
	{
		// this function returns 0 if pos has a 0 at column or 1 if it has a 1 at column, considering
		// a basis2 table with TotalColumns (i.e., 2^TotalColumns positions)
		//cout <<"pos:" << pos <<", column:" << column;
		unsigned int min= (pos/pow(2,column+1))*pow(2,column+1);
		//	cout <<"min:" << min;
		//(pos%(2^column-1));
		unsigned int max= min+pow(2,column);
		//	cout <<"max:" << max;
		if ((pos>=min) && (pos<max))
			return true;
		else return false;
	}
	/*---------------------------------------------------------------*/
	
	int getGauss (int num) {if (num<1) return 0; return num+num*(num-1)/2;}
	
	/*---------------------------------------------------------------*/
	
	unsigned int GetTotalColumns (char* filename)
	{
		ifstream InputFile;
		char * cad=NULL, * genotypebuf=NULL;
		
		unsigned int maxN=20000;
		
		try
		{
			if ((genotypebuf=new char[maxN*4])==NULL)
				throw NoMemory();
			//if ((cad=new char[maxN*4])==NULL)
			// throw NoMemory();
			
			
			
			InputFile.open (filename, ifstream::in);
			
			if (InputFile.peek()==EOF)
				throw EmptyFile();
			
			InputFile.getline (genotypebuf, maxN*4, '\n');
			
			InputFile.close();
			
		}
		catch (ErrorFile NoFile)
		{
			NoFile.PrintMessage(filename);
		}
		catch (EmptyFile EFile)
		{
			EFile.PrintMessage(filename);
		}
		catch (NoMemory NM)
		{
			NM.PrintMessage();
		}
		
		
		unsigned int Columns=0;
		
		cad = strtok (genotypebuf," ,\t");
		
		do
		{
			cad = strtok (NULL," ,\t");
			Columns++;
		}
		while (cad!=NULL);
		
		//zap(cad);
		zaparr(genotypebuf);
		
		return Columns;
	}
	
	////////
	// Put an assert to check if x is NULL, this is to catch
	// program "logic" errors early. Even though delete works
	// fine with NULL by using assert you are actually catching
	// "bad code" very early
	
	// Defining Zap using templates
	// Use zap instead of delete as this will be very clean
	template <class T>
		void zap(T & x)
	{
		//       assert(x != NULL);
		if (x!=NULL)
		{
			delete x;
			x = NULL;
		}
x = NULL;
	}
	// In C++ the reason there are 2 forms of the delete operator is because
	// there is no way for C++ to tell the difference between a pointer to
	// an object and a pointer to an array of objects. The delete operator
	// relies on the programmer using "[]" to tell the two apart.
	// Hence, we need to define zaparr function below.
	// To delete array of pointers
	
	template <class T>
		void zaparr(T & x)
	{
		//  assert(x != NULL);
		if (x!=NULL)
			delete [] x;
		x = NULL;
	}
/*_______________________________________________________________*/

template <class T>
		void zaparr(T & x, int size)
	{
		//  assert(x != NULL);
		if (x!=NULL)
		for (int i=0;i<size;i++)
		 zap (x[i]);
		zap(x);

	}
	/*_______________________________________________________________*/
	
	float GetMean (float * values, int size)
	{
		float total=0;
		for (int i=0;i<size;i++)
			total=total+values[i];
		return total/size;
	}
	
   /*_______________________________________________________________*/

	void end()
	{
		cout <<"\n";
		exit(0);
	}


	/*_______________________________________________________________*/
	
	float GetSampleSD (float * values, int size)
	{
		float mean=GetMean(values, size);
		float sd=0;
		for (int i=0;i<size;i++)
			sd=sd+std::pow(values[i]-mean, 2);
		sd=sqrt(sd/(float)(size-1));
		return sd;
	}
	/*_______________________________________________________________*/
	
	template<class T> void normalize (T * values, int size) throw (ZeroValue)
	{
		T total=0;
		for (int i=0;i<size;i++)
		total=total+values[i];
            if (total==0)
{
for (int i=0;i<size;i++)
cout <<"\nvalues[" << i<<"]=" <<values[i];
	      throw ZeroValue("normalize()");
}
		for (int i=0;i<size;i++)
             //if (total==0) values[i]=1/size;
//		  else 
values[i]=values[i]/total;
		}
	/*---------------------------------------------------------------*/
	int median(int * ip, int  size)
	{
		if ((size % 2) != 0)
			return ip[size / 2];
		else
			return (ip[size / 2 - 1] +
			ip[size / 2]) / 2; // it is not exact, because sometimes we can have an interval and the median is undetermined
		// here we get the floor value
	}
		/*---------------------------------------------------------------*/

long factorial(long n)
{
	if(n<1)
		return 1;	// we set 0! = 1
	return n*factorial(n-1);
}
	/*---------------------------------------------------------------*/

long product(long first, long last)
{
long r=1;
if (first>last)
{
cout <<"Error in product";
end();
}
for (int i=first;i<=last;i++)
r=r*i;
return r;
}
		/*---------------------------------------------------------------*/

double combinations(long n, long m)
{
	if (n<m) 
	{
		cout <<"Error in basic: combinations, n<m";
		end();
	}
	return product(maxi(n-m+1,m), n)*factorial(mini(n-m,m));
}
/*---------------------------------------------------------------*/

double getAccuraciesSampleVariance(int num, int total)
{
double mean=num/(double)total;
if (total==num) return 0;
else return num/(double)(total-1)-std::pow((double)mean,(double)2)*(total)/(double)(total-1);
}
/*---------------------------------------------------------------*/

double getAccuraciesSampleSD(int num, int total)
{
return sqrt(getAccuraciesSampleVariance(num, total));
}
	/*____________________________________________________________________*/
	
	bool IsOne(double number)
	{
		if (number>=1)
			if ((number-zero)<1)
				return true;
			else return false;
			if (number<1)
				if ((number+zero)>1)
					return true;
				else return false;
				return false;
	}
	double median(double * ip, int  size)
	{
		return percentile(ip, size, 50);
	}
	/*---------------------------------------------------------------*/
	
	double percentile(double * ip, int  size, double perc)
	{
		int lower=size;
		int upper=0;
		int lowerperc=(int) floor (size * perc/(double)100);
		double range=ip[size]-ip[0];
		double intervalperc;
		double val=ip[lowerperc];
		for (int i=0;i<size;i++)
		{
			if ((ip[i]==val) && (lower==size))
				lower=i;
			if (ip[i]==val) upper=i;
		}
		if (upper>lower)
		{
			intervalperc=(double)(ip[upper]-ip[lower])/(double)range;
			return ip[lower]+(ip[upper]-ip[lower])*(double)(perc-lowerperc)/(double)intervalperc;
		}
		else return ip[lower];
	}
	/*---------------------------------------------------------------*/
	
	double percentile(struct FreqAndVal * ip, int  size, double perc)
	{
		double TotalFrequency=0.0;
		// Use pont instead of perc because FreqAndVal.frequency can sum other than 1.
		for (int i=0;i<size;i++)
			TotalFrequency=TotalFrequency+ip[i].frequency;
		double freq=(double)perc*TotalFrequency/(double)100;
		int lower=size;
		int upper=0;
		double val=0; //ip[(int) floor (size * perc/(double)100)].value;
		double lowerfreq, upperfreq;
		// double range=ip[size].value-ip[0].value,
		//double intervalfreq;
		TotalFrequency=0.0;
		//cout<<"freq:"<<freq;
		try
		{
			for (int i=0;i<size;i++)
			{
				TotalFrequency=TotalFrequency+ip[i].frequency;
				if (TotalFrequency>freq && lower==size && i>0)
				{
					val=ip[i-1].value;
					lower=i-1;
					upper=i;
					lowerfreq=TotalFrequency-ip[i].frequency;
					upperfreq=TotalFrequency;
				}
				if (TotalFrequency==freq || (TotalFrequency>freq && i==0))
				{
					upper=i;
					lower=i;
				}
			}
			//if (!IsOne(TotalFrequency)) {cout <<"TotalFrequency:" << TotalFrequency; throw NonProb();}
			//cout << "TotalFrequency:" << TotalFrequency;
			//cout<<"upper:"<<upper<<",lower:"<<lower;
			
			/*
			if (upper>lower)
			{
			intervalfreq=(double)ip[upper].frequency;
			//cout <<"\nIntervalfreq:"<< intervalfreq;
			return ip[lower].value+(ip[upper].value-ip[lower].value)*(double)(freq-lowerfreq)/intervalfreq;
			}
			else return ip[lower].value;
			*/
			return ip[upper].value;
		}
		
		catch (ErrorFile NoFile)
		{
			NoFile.PrintMessage("in percentile");
		}
	}
	
	/*---------------------------------------------------------------*/
	template <class T> T maxi(T a, T b)//
	{//
		if (a >= b)//
			return (a);//
		else return (b);//
	}//
	/*---------------------------------------------------------------*/
	double max(struct FreqAndVal a, struct FreqAndVal b)//
	{//
		if (a.frequency >= b.frequency)//
			return (a.value);//
		else return (b.value);//
	}//
	/*---------------------------------------------------------------*/
	template <class T> T mini(T a, T b)//
	{//
		if (a <= b)//
			return (a);//
		else return (b);//
	}//
	/*---------------------------------------------------------------*/
	template <class T> T GetExtreme(T* array, int size, bool IsMax=true)//
	{//
		return array[GetExtremePos(array, size, IsMax)];
	}//
	/*---------------------------------------------------------------*/
	template <class T> int GetExtremePos(T* array, int size, bool IsMax=true)//
	{//
		T Extreme=array[0];
		int ExtremePos=0;
		
		for (int i=1;i<size;i++)
			if ((array[i]>Extreme && IsMax==true) || (array[i]<Extreme && IsMax==false))
			{
				Extreme=array[i];
				ExtremePos=i;
			}
			return (ExtremePos);
	}//
	/*---------------------------------------------------------------*/
	template <class T> T GetMax(T* array, int size)//
	{
		return GetExtreme(array, size, true);
	}
	/*---------------------------------------------------------------*/
	template <class T> T GetMin(T* array, int size)//
	{
		return GetExtreme(array, size, false);
	}
	/*---------------------------------------------------------------*/
	template <class T> int GetMaxPos(T* array, int size)//
	{
		return GetExtremePos(array, size, true);
	}
	/*---------------------------------------------------------------*/
	template <class T> int GetMinPos(T* array, int size)//
	{
		return GetExtremePos(array, size, false);
	}
	/*---------------------------------------------------------------*/
	bool isANumber (const char* cad)
	{
		int i=0;
		bool dot=false;
		while (i<strlen(cad))
		{
		if (i==0)
		{
		if (cad[i]!='-' && cad[i]!='+' && cad[i]!='.' && (cad[i]<'0' || cad[i]>'9'))
		{
		cout <<"val" << cad[i];
		return false;
		}
		else if (cad[i]=='.') dot=true;
		
		}
		else
		{
		if (cad[i]!='.' &&  (cad[i]<'0' || cad[i]>'9'))
		return false;
		else if (cad[i]=='.')
		if (dot==true) return false; else dot=true;
		}
	        i++;
		}
		
		return true;
	}
	/*---------------------------------------------------------------*/
	bool isAnInteger (const char* cad)
	{
	        if (isANumber(cad) && strchr(cad, '.')==NULL)
		return true;
		else return false;
	}
	/*---------------------------------------------------------------*/
	bool isAFloat (const char* cad)
	{
	        return isANumber(cad) && !isAnInteger(cad);
	}
	/*---------------------------------------------------------------*/
	void ChangeExtension (char* FileSource, char*FileTarget, char* Extension)
	{
	char* pointer=strrchr(FileSource, '.');
        if (pointer==NULL)
{
cout <<"Error in basic::ChangeExtension";
end();
}

        
		strncpy (FileTarget, FileSource, pointer-FileSource);
FileTarget[pointer-FileSource]='.';
	FileTarget[pointer-FileSource+1]='\0';
		//FileTarget = strtok(FileTarget+2, ".")-2;
		strcat (FileTarget, Extension);
//		strcat (FileTarget, "\0");
		//  cout <<"\n" << FileTarget;
		//  exit(0);
	}
	/*---------------------------------------------------------------*/
	char* GetFileExtension (char* FileSource)
	{
		int pos=0;
		for (unsigned int i=0;i<strlen(FileSource);i++)
			if (FileSource[i]=='.')
				pos=i;
			char * p=&FileSource[pos+1];
			return p;
	}
	/*---------------------------------------------------------------*/
	char* GetFilePath (char* FileSource)
	{
		char path[256], *p=path;
		strcpy(path, FileSource);
		int pos=0;
bool hasPath=false;
		for (unsigned int i=0;i<strlen(FileSource);i++)
			if (FileSource[i]=='/')
{
				pos=i;
hasPath=true;
}
if (hasPath)
{
			path[pos+1]='\0';
			return p;
}
else return "";
	}
	/*---------------------------------------------------------------*/
	char* RemoveDir (char* FileSource)
	{
      	char *p=new char[256];
      
		unsigned int pos=0, i;
		for (i=0;i<strlen(FileSource);i++)
			if (FileSource[i]=='/')
				pos=i+1;
			
			for (i=0;i<strlen(FileSource)-pos;i++)
				p[i]=FileSource[i+pos];
			p[i]='\0';
			return p;

	}
	/*---------------------------------------------------------------*/
	char* GetFilename (char* FileSource)
	{
		char* p=RemoveDir(FileSource);
return strtok(p, ".");
return p;
	};
	/*---------------------------------------------------------------*/
	void ChangeFilename (char* FileSource, char*FileTarget, char* newname)
	{
		char *p=GetFileExtension(FileSource);
		
		strcpy(FileTarget, newname);
		strcat(FileTarget, ".");
		strcat(FileTarget, p);
	}
	/*_________________________________________________________*/
	
	char* AddFilename (char* FileSource, char* chunk)
	{
		char *p;
		p=new char[128];
		strcpy(p, GetFilename(FileSource));
		strcat(p, chunk);
		ChangeFilename(FileSource, p, p);
		return p;
	}
	/*_________________________________________________________*/
	
	void AddFilename (char* FileSource, char* FileTarget, char* chunk)
	{
		strcpy(FileTarget, GetFilename(FileSource));
		strcat(FileTarget, chunk);
		ChangeFilename(FileSource, FileTarget, FileTarget);
	}
	/*---------------------------------------------------------------*/
	bool HasThisExtension (char* FileSource, char* Extension, unsigned short int ExtensionLength)
	{
		char * p=GetFileExtension(FileSource);
		if (strncmp(p, Extension, ExtensionLength)==0) return true; else return false;
		
	}
	/*---------------------------------------------------------------*/
	int getLineSize (ifstream * source)
	{
		
		
		int p=source->tellg();
		char* c;
		while (*c!=EOF && *c!='\n')
		{
			p=p+1;
			c=(char*)(source+p);
		}
		p=p+1;
		return p+1;
	}
    /*---------------------------------------------------------------*/
	/*
	char* CaptureLineOld (ifstream * source)
	{
		if (source->is_open()==false)
		{
			cout <<"Error in CaptureLine";
			exit(0);
		}
		char* buffer=NULL;//=NULL
		string s;
		std::getline(*source, s);
		
		if (s[s.size()-1]=='\r') // DOS Mode
		{
		buffer=new char[s.length()];
//		strncpy (buffer, s.c_str(), s.length()-1);
		strcpy (buffer, s.c_str());
        buffer[s.length()-1]='\n';
		}
		else
	{
		buffer=new char[s.length()+1];
		strcpy (buffer, s.c_str());
		strcat (buffer, "\n");

		}
		
			if (buffer==NULL) cout << "S"; else cout <<"N";
		return buffer;
	}
	 /*---------------------------------------------------------------*/
	/*
	char* CaptureLineOld (ifstream * source)
	{
		if (source->is_open()==false)
		{
			cout <<"Error in CaptureLine";
			exit(0);
		}
		char* buffer=NULL;//=NULL
		string s;
		std::getline(*source, s);
		
		if (s[s.size()-1]=='\r') // DOS Mode
		{
		cout <<"fff";
		buffer=new char[s.length()];
//		strncpy (buffer, s.c_str(), s.length()-1);
		strcpy (buffer, s.c_str());
        buffer[s.length()-1]='\n';
		}
		else
	{
			cout <<"x";
		buffer=new char[s.length()+2];
		strcpy (buffer, s.c_str());
		strcat (buffer, "\n");
cout <<buffer;
		}
		//end();		
			if (buffer==NULL) cout << "S"; else cout <<"N";
		return buffer;
	}
	   /*---------------------------------------------------------------*/
char* CaptureLine (ifstream * source)
	{
if (source->is_open()==false)
		{
			cout <<"Error in CaptureLine";
			exit(0);
		}
		char* buffer=NULL;//=NULL
		string s;
		std::getline(*source, s);
		if (s[s.length()-1]=='\r') // DOS Mode
		{
		//cout <<"y";
		buffer=new char[s.length()];
		strncpy (buffer, s.c_str(), s.length()-1);
                buffer[s.length()-1]='\0';
		}
		else
	{
		buffer=new char[s.length()+1];
		strcpy (buffer, s.c_str());
		strcat (buffer, "\0");

		}
		return buffer;
}

/*
	char* CaptureLine (ifstream * source)
	{

		char* buffer=NULL;//=NULL
		string s;
		std::getline(*source, s);

                if (s[s.length()-1]=='\r') 
		s=s.substr(0, s.length()-1);



	
		buffer=new char[s.length()+1];
		strncpy (buffer, s.c_str(), s.length());
		strcat (buffer, "\0");
		
	cout <<buffer;
		return buffer;
	
	}
	/*_______________________________________________________________*/
	
	int GetLineLength (char * FileName)
	{
		ifstream  InputFile;
		OpenInput(FileName, &InputFile);
		
		char c;
		int i=0;
		do
		{
			InputFile.get (c);
			i++;
		}
		while (c!='\n' && c!=EOF);
		
		InputFile.close();
		return i;
	}
	
	
	/*---------------------------------------------------------------*/
	void NextLine (ifstream* InputFile)
	{
		
		char c;
		int i=0;
		while (InputFile->peek()!='\n')
		{
			InputFile->get (c);
			i++;
		}
		InputFile->get (c);
		
	}
	/*____________________________________________________*/
	
	void splitword (char * out, char *in, char stop)
	{
		int i, j,k;
		for (i=0; in[i] && (in[i]!=stop); i++)
			out[i]=in[i];
		
		out[i]='\0'; //terminar
		if (in[i])
			++i;
		
		k=strlen(in)-strlen(out);
		
		for (j=0; (in[j]&&(j<k));) // desplazar el resto de in
			in [j++]=in[i++];
		in[j]='\0';
	}
	/*______________________________________________________________*/
	
	void FileCopy (char* forigen, char* fdestino)
	{
		ofstream OutputFile;
		OpenOutput(fdestino, &OutputFile);
		ifstream InputFile;
		OpenInput(forigen, &InputFile);
		
		char a;
		
		InputFile.get(a);
		
		while (!InputFile.eof())
		{
			OutputFile << a;
			InputFile.get(a);
		}
		OutputFile.close();
		InputFile.close();
	}
/*______________________________________________________________*/
	
	void FileAppend (char* forigen, char* fdestino)
	{
		ofstream OutputFile;
		OpenOutputAdd(fdestino, &OutputFile);
		ifstream InputFile;
		OpenInput(forigen, &InputFile);
		
		char a;
		
		InputFile.get(a);
		
		while (!InputFile.eof())
		{
			OutputFile << a;
			InputFile.get(a);
		}
		OutputFile.close();
		InputFile.close();
	}
	/*____________________________________________________*/
	
	void CopyWithoutChar (char * out, char *in, char rem)
	{
		int tam=strlen(in), i=0, j=0;
		while (i<tam)
		{
			while (i<tam && in[i]!=rem)
			{
				out[j]=in[i];
				i++;
				j++;
			}
			if (i<tam) // then rem
				i++;
		}
		out[j]='\0';
	}
	/*---------------------------------------------------------------*/
	int GetTotalLines (char * FileName)
	{
		ifstream  InputFile;
		
		//int length=GetLineLength (FileName);
		//length=5000;
		int i=0;
		//char line[length];
		OpenInput(FileName, &InputFile);
		char* genotypebuf=NULL;
		
		do
		{
		genotypebuf=CaptureLine(&InputFile);
		//	InputFile.getline (line, length*2, '\n');
			i++;
			zaparr(genotypebuf);
		}
		while (!InputFile.eof() && InputFile.peek()!='\n' && InputFile.peek()!='\r');
		
		if (InputFile.peek()==EOF) i--;
		InputFile.close();
		return i;
	}
	/*____________________________________________________________ */
	
	void OpenOutput(char* filename, ofstream* OutputFile)
	{
		try
		{
			OutputFile->open (filename, ifstream::out);
			if (!*OutputFile)
				throw ErrorFile();
		}
		catch (ErrorFile NoFile)
		{
			NoFile.PrintMessage(filename);
		}
	}
	/*____________________________________________________________ */
	
	void OpenOutputAdd(char* filename, ofstream* OutputFile)
	{
		
		OutputFile->open (filename, ifstream::app);
		
	}
/*____________________________________________________________ */
	
	void CheckFile(char* FileName, bool exists)
	{
		
		try
		{
			if ((!existFile(FileName) && exists) || (existFile(FileName) && !exists))
				throw ErrorFile();
				}
		catch (ErrorFile NoFile)
		{
			NoFile.PrintMessage(FileName);
		}
		
	}
	/*____________________________________________________________ */
	
	void OpenInput(char* FileName, ifstream* InputFile)
	{
		
		try
		{
			if (!existFile(FileName))
				throw ErrorFile();
			
			InputFile->open (FileName, ifstream::in);
	
			if (InputFile->peek()==EOF)
				throw EmptyFile();

		}
		catch (ErrorFile NoFile)
		{
			NoFile.PrintMessage(FileName);
		}
		catch (EmptyFile EFile)
		{
			EFile.PrintMessage(FileName);
		}
	}
	/*____________________________________________________________ */
	
	long int GetFileSize(char* nomfich)
	{
		FILE *fichero;
		
		if  ((fichero=fopen(nomfich, "rb"))==NULL)
			return -1;
		
		
		long int posicion, taman;
		posicion=ftell(fichero);
		fseek(fichero, 0L, 2); //2: ir al final del fichero
		taman=ftell(fichero);
		fseek(fichero, posicion, 0); //0: ir al principio
		fclose (fichero);
		return(taman);
	}
	/*____________________________________________________________ */
	
	uli getSize(ifstream* f)
	{
		f->seekg (0, ios::end);
		uli length = f->tellg();
		f->seekg (0, ios::beg);
		return(length);
	}

/*_______________________________________________________________*/

void replaceAll(string &source, string oldPattern, string newPattern)
{
int pos=source.length();
while (source.rfind(oldPattern, pos)!=string::npos)
{
//cout <<"\nfound at pos " << source.rfind(oldPattern, pos);
source.replace(source.rfind(oldPattern, pos), oldPattern.length(), newPattern);
//cout <<"\n\nnow is " << source;
}
}

	/*_____________________________________________________________*/
	
	int GetStringLinePosition (char* FileName, char* string)
	{
		// if not found, return the total number of lines in the file
		ifstream InputFile;
		OpenInput(FileName, &InputFile);
		int length=100000;
		int i=0;
		bool found=false;
		char line[length];
		do
		{
			InputFile.getline (line, length, '\n');
			if (strstr(line, string)!=NULL)
				found=true;
			else i++;
		}
		while (!InputFile.eof() && !found);
		
		InputFile.close();
		return i;
	}


}
// end namespace
#endif

