/* File: rational.h */


#ifndef __rational_h__
#define __rational_h__


#include<iostream>////
#include<fstream>//
#include<cstring>//
#include<cstdio>//                                              //
#include <cstdlib>//
#include <cctype>//
#include <cmath>//
#include <sys/stat.h>                                                       
#include "basic.h"//
#include "pair.h"//

using namespace std;

namespace BIOS {


////////////////////
 class rational: public pair<int> //
{

/////////////
rational (int num, int den): pair<int>(num, den)
{
}
//////////////
rational(const rational & origen): pair<int>(origen)
{
}
/////////////////
rational rational::operator/ (const prob & rat2)
{
if (rat2.numerator==0)
{
	cout <<"error in rational::operator/, denominator is 0";
	exit(0);
}
return pair<int>::operator/(rat2);
}
	};

}//end namespace
#endif
