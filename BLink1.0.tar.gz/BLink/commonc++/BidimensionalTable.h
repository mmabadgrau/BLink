/* File: BidimensionalTable.h */


#ifndef __BidimensionalTable_h__
#define __BidimensionalTable_h__


using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  template <class T> class BidimensionalTable: public MultidimensionalTable<T> //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  public:

 
    /*______________________________________________________*/

    BidimensionalTable()
    {
     cout <<"Error in BidimensionalTable";
     end();
    };
/*______________________________________________________*/

    void set()
    {
      this->totalDimensions=2;
      this->table=NULL;
      this->dimensionList=NULL;
      this->size=0;
      this->totalCounts=0;
    };

  /*______________________________________________________*/

    BidimensionalTable(intList* dimensionList):MultidimensionalTable<T>()
    {
    set(dimensionList);
    };
    /*______________________________________________________*/

    BidimensionalTable(int xDim, int yDim):MultidimensionalTable<T>()
    {
    set(xDim, yDim);
    };
      /*______________________________________________________*/
/*
    BidimensionalTable(BidimensionalTable &source):MultidimensionalTable()
    {
 if (source.dimensionList==NULL) set();
    else 
{

 this->totalCounts=source.totalCounts;
  set(source.dimensionList);
      for (int i=0; i<size;i++)
       setValue(i, source.getValue(i));
}
      }
     /*______________________________________________________*/

    void set(intList *dimensionList)
    {


if (dimensionList==NULL)
{
cout <<"Error in BidimensionalTable::set(intList *dimensionList), dimensionList is NULL";
end();
}
        this->dimensionList=new intList(*dimensionList);

this->totalDimensions=dimensionList->GetSize();
if (this->totalDimensions!=2)
{
cout <<"Error in BidimensionalTable::set(intList*), " << this->totalDimensions << " dimensions";
end();
}
         this->setSize();
         this->table=new T[this->size];

      }
/*______________________________________________________*/

    void set(int xDim, int yDim)
    {
        intList* cDimensionList=new intList();

cDimensionList->insertElement(xDim);
cDimensionList->insertElement(yDim);
set (cDimensionList);
}
/*___________________________________________________*/

void setValue (int i, int j, T value)
{
int* pos=new int();
pos[0]=i;
pos[1]=j;
MultidimensionalTable<float>::setValue(pos, value);
zaparr(pos);
}
/*___________________________________________________*/

T getValue (int i, int j)
{
int* pos=new int();
pos[0]=i;
pos[1]=j;
T value=MultidimensionalTable<float>::getValue(pos);
zaparr(pos);
return value;
}
/*___________________________________________________*/

int getPos (int i, int j)
{
int* pos=new int();
pos[0]=i;
pos[1]=j;
int position=MultidimensionalTable<float>::getPos(pos);
zaparr(pos);
return position;
}
};
  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, BidimensionalTable<T>& p)
  {
  out << "\t\t|\t";
      for (int i=0; i<p.dimensionList->GetElement(1);i++)
        out << i << "\t|\t";
      out <<"\n";
      for (int i=0; i<p.dimensionList->GetElement(1);i++)
      out <<"_____________________";
out <<"\n";
  for (int j=0; j<p.dimensionList->GetFirstElement();j++)
{
out  << "\t" <<  j << "\t|\t";
  for (int i=0; i<p.dimensionList->GetElement(1);i++)
   out << p.getValue(j,i) <<"\t|\t";
out <<"\n";
}
out <<"\n";
return out;
  };
}
#endif
