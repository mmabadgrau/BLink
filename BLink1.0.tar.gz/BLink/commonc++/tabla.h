/* File: tabla.h */


#ifndef __tabla_h__
#define __tabla_h__

#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"

using namespace std;

namespace BIOS {

/////////////////////////////////////////
class tabla//
{//
//
unsigned int  posicion, contador, maximo_entero, minimo_entero;//
int maximo_largo_entero, contadorlargo;//
float maximo_real, minimo_real;//
double minimo_doble, maximo_doble;//
int maximo_corto;//
public://
//
unsigned int *indice; //
unsigned int maximo (unsigned int, float*);//
unsigned int maximo (unsigned int, double*);//
unsigned int maximo (unsigned int, unsigned int*);//
unsigned int maximo (unsigned int, int*);//
unsigned int maximo (unsigned int,   int*);//
//unsigned int empatemaximo (unsigned int, <T*>);//
template <class T> unsigned int tabla::empatemaximo(unsigned int tam, T * tabla);//
//unsigned int empatemaximo (unsigned int, double*);//
unsigned int minimo (unsigned int, float*);//
unsigned int minimo (unsigned int, double*);//
unsigned int minimo (unsigned int, unsigned int*);//
unsigned int minimo (  int,   int*);//
void obtener_indice(unsigned int, unsigned int*, unsigned int, unsigned int*);//
int producto(unsigned int, int, unsigned int*);//
int producto(unsigned int, int, int*);//
unsigned int suma (unsigned int, unsigned int, unsigned int*);//
int obtener_posicion(unsigned int*, unsigned int*,   unsigned int);//
int obtener_posicion(int*, int*, unsigned int);//
unsigned int ordenado_fuerte (unsigned int*, unsigned int); //
void iniciar (bool, unsigned int, bool*);//
void iniciar (unsigned int, unsigned int,  unsigned int*);//
void iniciar (unsigned short int, unsigned int,  unsigned short int*);//
void iniciar (unsigned int, unsigned int,  int*);//
void iniciar (unsigned int, int,  int*);//
void iniciar (int, unsigned int, int*);//
void iniciar (float, unsigned int,  float*);//
void iniciar (double, unsigned int,  double*);//
void iniciar (char, unsigned int,  char*);//
unsigned int buscar(double, unsigned int, double*);//
unsigned int buscar_siguiente(char, unsigned int, unsigned int, char*);//
void insertar(double, unsigned int, unsigned int, double*);//
void
insertar(unsigned int, unsigned int, unsigned int, unsigned int*);//
unsigned int ordenar(unsigned int, float*); //
unsigned short int desborde (unsigned int, unsigned int); //
~tabla(){};
//
};//
#include "tabla.cpp"
}
#endif
