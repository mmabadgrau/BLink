/* File: Binomial.h */


#ifndef __Binomial_h__
#define __Binomial_h__



namespace BIOS {


/************************/
/* Binomial STATISTIC*/
/************************/


/**
        @memo Binomial

	@doc
        Definition:
        Binomial distribution of size Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Binomial  {


protected:
    /** @name Implementation of class Binomial
        @memo Private part.
    */
double p;
int* values, pointer, n, Size;
/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* PUBLIC FUNCTIONS (INTERFACE) */

public:


Binomial(int samples, double prob);
Binomial(int samples);
~Binomial();
//int  * getValues(int n);
int getNextValue();
int random_binomial();
void setAllValues();
int* getFrequencies();

};  // End of class Binomial




};  // End of Namespace

#endif

/* End of file: Binomial.h */




