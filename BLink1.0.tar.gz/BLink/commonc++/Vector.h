/* File: Vector.h */


#ifndef __Vector_h__
#define __Vector_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.h"
#include "AttPattern.h"
//#include "Diplotype.h"


  /**
      @memo Declaration of a Vector (FIFO)
      @doc
      */

using namespace UTILS;

namespace BIOS {

/************************/
/* Vector DEFINITION */
/************************/


/**
        @memo Vector 

	@doc
        Definition:
        It is a list in which methods RemoveElement 

        Memory space: O(SizeP), which SizeP being the number of elements in the Vector

    @author Maria M. Abad
	@version 1.0
*/

	
	
template <class T> class Vector {

public:	
		
typedef struct node
{
 T element;
 struct node* Next;
 struct node* Previous;

};


typedef node * NodePointer;

protected:		
NodePointer Vector, Last;

int Size;




/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

/////////////////////////////////////////////
void destroy(NodePointer e);

void copy(NodePointer & target, const NodePointer source);

void ReadInfo (ifstream * is, int linesize);

//T ReadElement (ifstream * is, int size) {cout <<"ggg";};

//virtual template <class T> T Vector<T>::ReadElement(ifstream * is);

/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


      /**
         @memo Destructor
	 @doc
           Deallocate memory used by Vector.
           Time complexity O(1).

      */
      ~Vector ();
//////////////////////////////////////////////




      /** @name Operations on Vector 
        @memo Operations on a Vector 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
      Vector();
  /////////////////////////////////////////////
      /**
         @memo Copy constructor
         @param target: Vector where will be copy
         @param origen: Vector to copy
         @doc
           Make a copy of Vector
           Time complexity in time O(1).
        */

  	  
	 // Vector (Vector &source, int *Sampling, int size);
        Vector(Vector &source, Vector<int> *Sampling);


	  Vector(char* filename);
 
///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: Vector to copy.
         @return Reference to the receptor Vector.
	 @doc
           Copy the Vector in the receptor Vector.
           Time complexity O(1).

      */
      Vector & operator=(const Vector & e);
////////////////////////////////////////////////////
   
	void GetInfo(char *FileName);

      /**
         @memo Is equal
         @param g: Vector to compare with.
	 @return
           Return true if the SNP is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const Vector & e);
      /**
         @memo Is different
         @param g: Vector to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const Vector & e);


	  //virtual 
		  T ReadElement (ifstream * is, int size); // if word virtual is not included, end loop


	  	        /**
         @memo Obtain the element pointed by the nodepointer.
         @return return a pointer to the first Vector in the Vector
         Time complexity O(1)

      */
	  T GetElement(NodePointer e);

	  T GetElement(int k);

	        /**
         @memo Obtain the first Vector in the Vector.
         @return return a pointer to the first Vector in the Vector
         Time complexity O(1)

      */
	  NodePointer GetFirst () {return Vector;};
	        /**
         @memo Obtain the first Vector in the Vector.
         @return return a pointer to the first Vector in the Vector
         Time complexity O(1)

      */
	  NodePointer GetLast () {return Last;};

      /**
         @memo Obtain the Next Vector in the Vector.
         @param The pointer to the current Vector
         @return return a pointer to the Next Vector in the Vector
         Time complexity O(1)

      */
        NodePointer GetPrevious (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Previous;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};
      /**
         @memo Obtain the Next Vector in the Vector.
         @param The pointer to the current Vector
         @return return a pointer to the Next Vector in the Vector
         Time complexity O(1)

      */
        NodePointer GetNext (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Next;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};

   /**
         @memo Obtain the element at pos k in the Vector.
         @param The pointer to the current Vector
         @return return a pointer to the Next Vector in the Vector
         Time complexity O(1)

      */
        NodePointer GetNode (int k)
		{
		NodePointer i=Vector;
		try {
		for (int c=0;c<k;c++)
		 if ((i=i->Next)==NULL) throw NullValue();
		}
		catch (NullValue null) {null.PrintMessage();}
		return i;};             

	 
      /**
         @memo Obtain the Vector SizeP.
         @return the size of a Vector
         @doc Return the number of Vectors in the Vector. This value
         is in the variable SizeP.
         Time complexity O(1)

      */
        int GetSize ();         
		
		int GetPos(NodePointer p);

		  /**
         @memo Add an element to the Vector.
         @param Position: Position of this element in the Vector
         Time complexity O(1)

      */
	  virtual void insertElement (T element);

	  //void insertElement (char* element);

  	  void insertElementAtPointer (T element, NodePointer & p);

		  /**
         @memo Remove the element at pos n from the Vector.
         @param Position: Position of this element in the Vector
         Time complexity O(1)

      */
	 
/*____________________________________________________________ */

void RemoveElement(NodePointer Pointer)
{

NodePointer Previous, Next;

try
{
if (Size==0)  throw NullValue();		
}
catch (NullValue null) {null.PrintMessage();}

if (Pointer!=NULL)
{
 //cout <<"h";
 Previous=Pointer->Previous;
 Next=Pointer->Next;
 if (Pointer!=Vector) Previous->Next=Pointer->Next;
 else Vector=Next;

 if (Pointer!=Last) Next->Previous=Previous;
 else Last=Previous;

// Pointer=Previous;
 delete Pointer;
 Size--;
}
} ;
/*____________________________________________________________ */


	  void Order(int* NewOrder, int size);

	  void Order(int funcioncomparar (const void *arg1, const void *arg2));

  	  void Remove(bool* RemovePos);

	  void ReplaceNode(NodePointer p, T NewElement);

	  bool IsEmpty();

	  void Empty();


	  void Pop()
	  {

		// extract the last element from the Vector

       RemoveElement(Last);
	  }

	T GetDistance(Vector* otherVector);

	NodePointer GetClosestGreaterElement(T argument);

	long int GetAbsoluteFrequency(Vector<AttPattern<T> >* attVector);

	double GetRelativeFrequency(Vector<AttPattern<T> >* values);

	double GetConditionalFrequency(Vector<AttPattern<T> >* independents, Vector<AttPattern<T> >* conditioners);

	void HardCopy(char filename[128]);

	Vector<T>* ExtractVector(int TotalElements);

	Vector<T>* ExtractVector(long int[] indexVector);



};  // End of class Vector

typedef  char s40[40];

//	float Vector<float>::ReadElement (ifstream * is, int size){};


//	unsigned int Vector<unsigned int>::ReadElement (ifstream * is, int size){};


//	int Vector<int>::ReadElement (ifstream * is, int size){};


//	char* Vector<char*>::ReadElement (ifstream * is, int size){};


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/////////////////////////////////////////////
template <class T> void Vector<T>::destroy(Vector<T>::NodePointer e)
{

       		if(e!= NULL)
			 destroy (e->Next);
			delete e;
            
}
//////////////////////////////////////////

template <class T> void Vector<T>::copy (Vector<T>::NodePointer & Target, const Vector<T>::NodePointer Source)
{
	try
	{
	  if ((Target=new node)==NULL)
            throw NoMemory();

	     Target->element=Source->element;
     	 
         if (Source->Next!=NULL)
           copy(Target->Next,Source->Next);     
		 else Target->Next=NULL;

	}
	catch (NoMemory wm) 
{
 wm.PrintMessage();
}        

}
/*___________________________________________________________ */

template <class T> void Vector<T>::ReadInfo (ifstream * is, int linesize)
{
//	T* e;
//	e=new T(ReadElement(is, size));
//	if (size!=18)
//	cout << e->PrintPhenotype();
//	T e;
//	T e(ReadElement(is, size));
	insertElement(ReadElement(is, linesize));
//	Size++;
//	Last=p;
//	insertElement(e);
//if (size!=18) exit(0);
//	cout <<"val";
	if (is->peek()!=EOF) // && is->peek()>='0' && is->peek()<='?') 
	 ReadInfo(is, linesize);
}

/*____________________________________________________________ */

template <class T> void Vector<T>::GetInfo(char *FileName)
{

//cout << "Reading elements ...\n";

int linesize=GetLineLength(FileName)*2+100; //double because there can be longer lines
//if (linesize!=18)
//exit(0);
ifstream  InputFile;

try
{
 if (!ExistFile(FileName))
	 throw ErrorFile();
  InputFile.open (FileName, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
catch (EmptyFile EFile) {EFile.PrintMessage(FileName);}
ReadInfo (&InputFile, linesize);

InputFile.close();
//cout <<"Elements reading has finished\n";
};
///////////////////
//// public ////////
///////////////////

template <class T> Vector<T>::Vector()
{
Vector=NULL;
Last=NULL;
Size=0;
}

/*____________________________________________________________ */

template <class T> Vector<T>::Vector (Vector<T> &source, Vector<int> *Sampling=NULL)
{
// copy elements with pos in Sampling, they can be repeated

int cont=0;
Vector=NULL;
Last=NULL;
Size=0;

if (Sampling!=NULL)
{
Vector<int>::NodePointer p=Sampling->GetFirst();

  while (p!=NULL)
  {
  insertElement(source.GetElement(Sampling->GetElement(p)));
  p=Sampling->GetNext(p);
  }
}
else
 copy (Vector, source.Vector);

}
/*____________________________________________________________ */

template <class T> Vector<T>::Vector (char* filename)
{
Vector=NULL;
Last=NULL;
Size=0;
GetInfo(filename);
}

/*____________________________________________________________ */

template <class T> Vector<T>::~Vector ()
{
	if (Vector!=NULL) destroy(Vector);
	Vector=NULL;
}
 /*____________________________________________________________ */

template <class T> T Vector<T>::GetElement(Vector<T>::NodePointer e)
{
	try
	{
  if (e==NULL) 
   // throw NullValue(" in GetElement");
   throw NullValue();
  else return e->element;
	}

   catch (NullValue nv) {
                nv.PrintMessage();}
}
 /*____________________________________________________________ */

template <class T> T Vector<T>::GetElement(int k)
{
return GetElement(GetNode(k));
}



/*____________________________________________________________ */

template <class T> void Vector<T>::ReplaceNode(Vector<T>::NodePointer p, T NewElement)
{
  try {
  if (p==NULL)
   throw NullValue();

  p->element=NewElement;
      
  }
  catch (NullValue null) {
    null.PrintMessage();
    }
}
/*____________________________________________________________ */

template <class T> int Vector<T>::GetPos(Vector<T>::NodePointer p)
{
  int k=0;
  NodePointer i=Vector;
  
	  while (i!=NULL)
	  {
		if (i==p) return k;
		k++;
		i=i->Next;
	  }
  
  return k;
}
/*____________________________________________________________ */


template <class T> int Vector<T>::GetSize()
{
	 return Size;
};

/*____________________________________________________________ */

template <class T> Vector<T>& Vector<T>::operator=(const Vector<T> & Source)
{
  if (this!=&Source)  
  {
	//  cout <<"prueba";
	  if (Vector!=NULL)
  destroy(Vector);
copy (Vector, Source.Vector);
  //	  exit(0);

  }
  return *this;
}
/*____________________________________________________________ */

template <class T> void Vector<T>::insertElement (T element)
{
//	cout <<"size:" << Size;
	NodePointer Pointer=NULL;
	
//			 if (Size==1) cout<<"\nmmmlast" << Last <<"pointer:" << Pointer << "posfirst:" << Vector <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << Vector->Previous;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
//		 if (Size==1) cout<<"\nmmmlast" << Last <<"pointer:" << Pointer << "posfirst:" << Vector <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << Vector->Previous;

	Pointer->element=element;      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;

	if (Size>0) Last->Next=Pointer; 
	else Vector=Pointer;
	Last=Pointer;
//	 if (Size==1) cout<<"\nposfirst:" << Vector <<",pstlast:" << Last << "next:" << Last->Next <<"prev" << Vector->Previous;


	Size++;
};
/*____________________________________________________________ */
/*
void Vector<char[40]>::insertElement (char element[40])
{
	
	NodePointer Pointer;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	strcpy(Pointer->element, element);      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;
	if (Size>0) Last->Next=Pointer; 
	else Vector=Pointer;
	Last=Pointer;
	Size++;





};

/*____________________________________________________________ */

template<> void Vector<char*>::insertElement (char* element)
{
	
	NodePointer Pointer;

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	strcpy(Pointer->element, element);      	      
	Pointer->Next=NULL;
	Pointer->Previous=Last;
	if (Size>0) Last->Next=Pointer; 
	else Vector=Pointer;
	Last=Pointer;
	Size++;





};


/*____________________________________________________________ */

template <class T> void Vector<T>::insertElementAtPointer (T element, NodePointer & p)
{
	// if pointer is NULL, insert element at the end of the Vector
    NodePointer Pointer, previous;


if (p==NULL) insertElement(element);
else
{

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	

	Pointer->element=element;  
	Pointer->Next=p;

    if (p!=Vector)
	{
    previous=p->Previous;
    Pointer->Previous=previous;
	previous->Next=Pointer;
	}
	else
	{
	Vector=Pointer;
    Pointer->Previous=NULL;
	}

    p->Previous=Pointer;

	Size++;
}

};



/*____________________________________________________________ */

template <class T>  void Vector<T>::Order(int* NewOrder, int size)
{
 	 int pos;
	
	 Vector<T> *Vector2;
	 try
	 {
	 if (Size!=size)
		 throw NoMemory();
 	if ((Vector2=new Vector<T>())==NULL)
		throw NoMemory();
	 }

	 catch (NoMemory NM ) {
      NM.PrintMessage();
	}


	for (int i=0;i<Size;i++)
	{
      pos=NewOrder[i];
	  Vector2->insertElement(GetElement(GetNode(pos)));  
	 }

	destroy(Vector);
	NodePointer p=Vector2->GetFirst();
    while (p!=NULL) 
	{
	  insertElement(GetElement(p));  
	  p=Vector2->GetNext(p);
	}

	

  cout <<"Sorting has finished\n";
}
/*____________________________________________________________ */

template <class T>  void Vector<T>::Order(int funcioncomparar (const void *arg1, const void *arg2))
{
 
 NodePointer IndPosition=GetFirst();

 int i=0;

 T *Vector2;
 if ((Vector2=new T[Size])==NULL)
  throw NoMemory();

 while (IndPosition!=NULL)
 {
  Vector2[i]=IndPosition->element;
  IndPosition=GetNext(IndPosition);
  i++;
 }
 qsort ((void*)Vector2, Size, sizeof (T), funcioncomparar);

IndPosition=GetFirst();
i=0;
while (IndPosition!=NULL)
{
 IndPosition->element=Vector2[i];
 IndPosition=GetNext(IndPosition);               
 i++;
}

if (Vector2!=NULL) delete Vector2;
	
}
/*____________________________________________________________ */

template <class T> bool Vector<T>::IsEmpty()
{
	return Vector==NULL;
}
/*____________________________________________________________ */

template <class T> void Vector<T>::Empty()
{	
	if (Vector!=NULL) 
	{
	destroy(Vector);
	Vector=NULL;
	Last=NULL;
	Size=0;
	}
}
/*____________________________________________________________ */

template <class T> void Vector<T>::Remove(bool* PosVector)
{
	// PosVector contains true in positions to be removed

 	 int pos, i=0;
	
	 try
	 {
	 if (Size!=sizeof(*PosVector))
		 throw NoMemory();
	 }

	 catch (NoMemory NM ) {NM.PrintMessage();
	}

	NodePointer p=GetFirst(), oldp;
	
	while (p!=NULL)
	{
	if (PosVector[i]==true)
	  p=RemoveElement(p);  
	else p=GetNext(p);
	}  
	

  cout <<"Sorting has finished\n";
};
/*____________________________________________________________________________________ */


template<class T> T Vector<T>::GetDistance(Vector<T>* otherVector)
{
typename Vector<T>::NodePointer otherPointer=otherVector->GetFirst(), 
thisPointer=GetFirst();
T distance=(T) 0;
 while (thisPointer!=NULL && otherPointer!=NULL)
 {
  distance=distance+(T)fabs(GetElement(thisPointer)-otherVector->GetElement(otherPointer));
  thisPointer=GetNext(thisPointer);
  otherPointer=otherVector->GetNext(otherPointer);
 }  
 return distance;
};
/*___________________________________________________________ */

template<class T> typename Vector<T>::NodePointer Vector<T>::GetClosestGreaterElement(T argument)
{
// it returns a pointer to the element in the Vector which has the closest upper value than argument  
 typename Vector<T>::NodePointer pk=GetFirst(), pk2=NULL;
 T NextValue, ClosestValue=maxreal;
   while (pk!=NULL)
   {
	NextValue=GetElement(pk);

	if (NextValue>=argument && NextValue<ClosestValue)
	{
		ClosestValue=NextValue;
		pk2=pk;
	}
	pk=GetNext(pk);
   }
return pk2;
}
/*___________________________________________________________________________________*/

template <class T>  long int Vector<T>::GetAbsoluteFrequency(Vector<AttPattern<T> >* attVector)
{
// Given a Vector of Attrribute positions and a Vector of ranges it resturns the number of members which values in the same range for the Vector of attribute positions

long int frequency=0;
typename Vector<T>::NodePointer p=GetFirst();
typename Vector<AttPattern<T> >::NodePointer pA;
Vector<T>* pattern;
bool inconsistent;
int position;
T minValue, maxValue;
AttPattern<T> attValue;
T value;
bool continuous;
while(p!=NULL)
{
pattern=GetElement(p);
pA=attVector->GetFirst();
inconsistent=false;
while(pA!=NULL && !inconsistent)
{
attValue=attVector->GetElement(pA);
value=pattern->GetElement(attValue.GetPos());
continuous=(attValue.GetMinValue()!=attValue.GetMaxValue());
if ((!continuous && value!=attValue.GetMinValue()) ||
    (continuous && (attValue.GetMinValue()>value || attValue.GetMaxValue()<=value)))
 inconsistent=true;
pA=attVector->GetNext(pA);
}
if (!inconsistent) frequency++;
p=GetNext(p);
}
return frequency;
}; 
/*___________________________________________________________________________________*/

template <class T>  double Vector<T>::GetRelativeFrequency(Vector<AttPattern<T> >* values)
{
return GetAbsoluteFrequency(values)/(double)GetSize();
} 


/*___________________________________________________________________________________*/

template <class T> double Vector<T>::GetConditionalFrequency(Vector<AttPattern<T> >* independents, Vector<AttPattern<T> >* conditioners)
{
Vector<AttPattern<T> >* joint;
*joint=*independents;// value copy 
typename Vector<AttPattern<T> >::NodePointer pC=conditioners->GetFirst();

//// First, add conditioners to compose the joint distribution
while (pC!=NULL)
{
 joint->insertElement(conditioners->GetElement(pC));
 pC=conditioners->GetNext(pC);
}

///// Now, compute frequencies for the joint and the marginal 
double pjoint=(double)GetAbsoluteFrequency(joint);
double marginal=(double)GetAbsoluteFrequency(conditioners);

delete joint;

return pjoint/marginal;
};
/*___________________________________________________________________________________*/

template <class T>  void Vector<T>::HardCopy(char filename[128])
{ 
ofstream  OutputFile;
OpenOutput(filename, &OutputFile);
Vector<T> *pattern;
typename Vector<T>::NodePointer p=GetFirst();
while (p!=NULL)
{
 pattern=GetElement(p);
 OutputFile << pattern->Print();
 p=GetNext(p);
}
OutputFile.close();
}
/*___________________________________________________________________________________*/

template <class T> Vector<T>* Vector<T>::ExtractVector(int TotalElements)//
{ 
//it randomly extracts TotalElements from the original sample and put them in a new Vector
int elegido;
NodePointer p;

Vector<T>* newVector;

//cout <<"TotalPrueba:" << TotalPrueba;
//cout <<"size:" << splittedSample.trainingSample->Vector<InputAttributesPattern*>::GetSize();
for (int contador=0;contador<TotalPrueba;contador++)
{ 
 if (GetSize()<=0)
 {
 cout <<"error for " << contador;
 exit(0);
 }
 elegido=rand() % GetSize();
 p=GetNode(elegido);
 newVector->insertElement(GetElement(p));
 RemoveElement(p);
}
return newVector;
}
/*___________________________________________________________________________________*/

template <class T> Vector<T>* Vector<T>::ExtractVector(long int[] indexVector)//
{ 
//it extracts elements at pos in indexVector from the original sample and put them in a new Vector
NodePointer p;

Vector<T>* newVector;

//cout <<"TotalPrueba:" << TotalPrueba;
//cout <<"size:" << splittedSample.trainingSample->Vector<InputAttributesPattern*>::GetSize();
for (int contador=0;contador<sizeof(*indexVector);contador++)
{ 
	if (GetSize()<=0)
	{
		cout <<"error for " << contador;
		exit(0);
	}
  p=GetNode(indexVector[contador]);
  newVector->insertElement(GetElement(p));
  RemoveElement(p);
}
return newVector;
}
/*___________________________________________________________________________________*/

template <class T> Vector<T>* Vector<T>::ExtractColumns(long int[] indexVector)//
{ 
// it applies only for Vector<Vector<T> >
// it extract columns and put them in a new Vector<Vector> >
NodePointer p=GetFirst();

Vector<Vector<T> >* newVector;
newVector=new Vector<Vector<T> >();

while (p!=NULL)
{
for (int contador=0;contador<sizeof(*indexVector);contador++)
{ 
	if (GetSize()<=0)
	{
		cout <<"error for " << contador;
		exit(0);
	}
  p=GetNode(indexVector[contador]);
  newVector->insertElement(GetElement(p));
  RemoveElement(p);
}
return newVector;
}

/* _____________________________________________________*/

template<> int Vector<int>::ReadElement (ifstream * source, int size)
{
	char genotypebuf[size]; 
	CaptureLine(source, genotypebuf, size);
    return (int) atol(genotypebuf);
}
/* _____________________________________________________*/

template<> double Vector<double>::ReadElement (ifstream * source, int size)
{
	char genotypebuf[size]; 
	CaptureLine(source, genotypebuf, size);
    return (double) atof(genotypebuf);
}


} // end namespace
#endif

/* Fin Fichero: Vector.h */
