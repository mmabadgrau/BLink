/* File: ficheros.cpp */


#ifndef __ficheros_cpp__
#define __ficheros_cpp__

#include "ficheros.h"

namespace BIOS
{



unsigned short int fichero_entrada::existefichero (char* nomfich)
{
struct stat fs;
if (stat(nomfich, &fs)==0) return (1); else return (0);
}
/////////////////////
void fichero_entrada::abrir(char referencia[63])//
{//
 strcpy(ref, referencia);//
 if (fichero_entrada::existefichero (ref)==0)
 {
 cout <<"Error, fichero " << referencia << " no existe";
 exit(0);
 }

fichero_entrada::open(ref, ios::in); //
 if (!fichero_entrada())//
 {//
  cout << "No se puede abrir el archivo.";//
  }//
}//

////////////////////////////////
unsigned int fichero_entrada::taman()//
{//
posicion=fichero_entrada::tellg();//
fichero_entrada::seekg(ios::beg);//
patron=0;//
//cout <<  "Leyendo fichero\n";//
fichero_entrada::get(carac);//
while (!fichero_entrada::eof())//
{//
 fichero_entrada::get(carac);//
 if (!fichero_entrada::eof())//
 if (carac=='\n')//
 {//
// cout  << patron << "\r";//
 patron=patron+1;//
}//
}//
fichero_entrada::clear();
fichero_entrada::seekg (posicion);//
return(patron);//
}//
//////////////////////////////////////
void fichero_entrada::ir (unsigned int pos, unsigned int ancho_registro)//
{//
fichero_entrada::seekg(ancho_registro*pos, ios::cur); //
}//
/////////////////////////////////////////
void fichero_entrada::fin_de_linea()//
{//
char cad[256];//
//fichero_entrada::get(cad, 256, '\n');//
fichero_entrada::getline(cad, 256);
//fichero_entrada::get(cara); //
}//



/////////////////////
void fichero_salida::abrir(char referencia[63])//
{//
 strcpy(ref, referencia);//
  fichero_salida::open(ref, ios::out);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//
///////////////////////
void fichero_salida::abrir_truncando(char referencia[63])//
{//
 strcpy(ref, referencia);//
  fichero_salida::open(ref, ios::trunc);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//
/////////////////////
void fichero_salida::anadir(char referencia[63])//
{//
 strcpy(ref, referencia);//
  fichero_salida::open(ref, ios::app);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//

}
#endif
