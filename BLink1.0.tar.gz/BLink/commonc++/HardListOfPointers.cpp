/* File: ListOfPointers.cpp */


#ifndef __ListOfPointers_cpp__
#define __ListOfPointers_cpp__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.h"
#include "AttPattern.h"
#include "ListOfPointers.h"
//#include "ListOfPointers.h"
//#include "Diplotype.h"


/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A set of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */
  /*____________________________________________________________ */
/*
  template <class T> ListOfPointers<T>::~ListOfPointers<T>()
  {
  //   destroy(this->List);
  }  
    /*____________________________________________________________ */

  template <class T> void ListOfPointers<T>::moveElement(int oldPos, int newPos)
  {
  ListOfPointers::moveElement(oldPos, newPos);
  }
  /*____________________________________________________________ */

  template <class T> void ListOfPointers<T>::deleteElement (T * element)
  {
   zap(element);
    }    
    /*____________________________________________________________ */

  template <class T> void ListOfPointers<T>::assignElement (typename ListOfPointers<T>::NodePointer p, T* element)
  {
  p->element=new T(*element);
    }    
 
  
} // end namespace
#endif

/* Fin Fichero: ListOfPointers.cpp */
