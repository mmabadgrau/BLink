
#ifndef __basic_h__
#define __basic_h__

#include<sstream>
#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
#include <string>
#include <iostream>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include <values.h>

//#define maxint ((int)(~(unsigned int)HIBITI))

#define  maxint MAXINT //
#define  maxline 100000//
#define maxreal MAXFLOAT // 1.7E+38//
#define zero 0.1E-10 //
using namespace std;

namespace BIOS {


ofstream OutputFile;
ifstream InputFile;

typedef int uli;

typedef	  struct FreqAndVal
  {
	  double value;
	  double frequency;
  } ;
	//template <class T> T* ExtractList(T object, int indexVector[], int size);//
string print (double e);
void replaceAll(string &source, string oldPattern, string newPattern);
void print(char* filename);
void FileAppend (char* forigen, char* fdestino);
 /*______________________________________________________*/
	template <class T>
		void reorderValues(T* array, int size, T* pos,  T* targetArray);

 //   template <class T> ofstream& operator<<(ofstream& out, const T& p);
template <class T>
	void disperseValues(T* array, int size, T* pos, T* targetArray, int sizeTarget);
  int getLineSize (ifstream * source);
    template <class T> int compare(const void *arg1, const void *arg2);
 // virtual template <class T> ostream& operator<<(ostream& out, T& clase);
    template <class T> int compareinv(const void *arg1, const void *arg2);
    	template<class T> int comparePointer(const void *arg1, const void *arg2);
	template<class T> int compareinvPointer(const void *arg1, const void *arg2);

void OpenOutput(char* filename, ofstream* OutputFile);
void OpenOutputAdd(char* filename, ofstream* OutputFile);
void OpenInput(char* FileName, ifstream* InputFile);
	
int GetLineLength (char * FileName);
int pow (int base, int exp);
int pow (int base, int exp);
double log_2 (double numero);//
int getGauss (int num);
double pdfChiSquare(double x, int df);
double pdfTestChiSquare(double x, int df);
double ddfChiSquare(double x, int df);
double chiTest (double* observed, double*expected, int df);
void CheckFile(char* filename, bool exists=true);

template <class T> string tos(T i);
string tos(double i, int integerPart, int decimalPart);

void end();

  char* CaptureLine (ifstream * source);
template <class T> T sum (T* array, unsigned int length);
template <class T> void change (T & val1, T  & val2);//swap
template <class T>
T * Initialize(int size, T val);
template <class T>
void InitializeList(T* list, int size, T val);
template <class T> bool IsOne (T value);

bool existFile (char* namefile);

int maxlong ();
bool IsAZero(unsigned int column, unsigned int pos);
unsigned int GetTotalColumns (char* filename);

template <class T> void zap(T & x);

template <class T> void zaparr(T & x);

template <class T> void zaparr(T & x, int size);

long factorial(long n);

double getAccuraciesSampleSD(int num, int total);

double getAccuraciesSampleVariance(int num, int total);

/*_______________________________________________________________*/

long product(long first, long last);

/*_______________________________________________________________*/

double combinations(long n, long m);

/*_______________________________________________________________*/

bool isANumber (const char* cad);

/*_______________________________________________________________*/

bool isAnInteger (const char* cad);
float GetMean (float * values, int size);
float GetSampleSD (float * values, int size);
template <class T> void normalize (T * values, int size) throw (ZeroValue);
int median(int * ip, int  size);
bool IsOne(double number);
double percentile(double * ip, int  size, double perc);
double percentile(struct FreqAndVal * ip, int  size, double perc);
template <class T> T maxi(T a, T b);
double max(struct FreqAndVal a, struct FreqAndVal b);
template <class T> T mini(T a, T b);
template <class T> T GetExtreme(T* array, int size, bool IsMax=true);
template <class T> int GetExtremePos(T* array, int size, bool IsMax=true);
template <class T> T GetMax(T* array, int size);
template <class T> T GetMin(T* array, int size);
template <class T> int GetMaxPos(T* array, int size);
template <class T> int GetMinPos(T* array, int size);
void ChangeExtension (char* FileSource, char*FileTarget, char* Extension);
char* GetFileExtension (char* FileSource);
char* GetFilePath (char* FileSource);
char* RemoveDir (char* FileSource);

char* GetFilename (char* FileSource);

void ChangeFilename (char* FileSource, char*FileTarget, char* newname);
char* AddFilename (char* FileSource, char* chunk);
void AddFilename (char* FileSource, char* FileTarget, char* chunk);
bool HasThisExtension (char* FileSource, char* Extension, unsigned short int ExtensionLength);
//void CaptureLine (ifstream * source, char* genotypebuf);
char* GetLine (ifstream * source);
int GetLineLength (char * FileName);
int GetTotalColumns2(char * FileName);
void NextLine (ifstream* InputFile);
void splitword (char * out, char *in, char stop);

/*______________________________________________________________*/

void FileCopy (char* forigen, char* fdestino);


void CopyWithoutChar (char * out, char *in, char rem);

/*---------------------------------------------------------------*/
int GetTotalLines (char * FileName);

/*____________________________________________________________ */




long int GetFileSize(char* nomfich);

int GetStringLinePosition (char* FileName, char* string);



}
// end namespace

//#include "basic.cpp"
#endif


