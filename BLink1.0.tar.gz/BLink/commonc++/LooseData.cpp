  /**
    * @file ManageColumns.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Fachade.h"

/* This program produce a new sample with missing data*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "< rate of missing data (in percent)>";
        exit(0);
        }
     char filename[128], filename2[128];
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

	 int ratioMissing=atoi(argv[3]);

  



stringSample* sample=new stringSample(filename);
stringList *row=sample->GetFirstElement();
int totalColumns=row->GetSize();
int totalLines=sample->GetSize();
int totalMissing=sample->getTotalMissingValues();
int totalItems=totalLines*totalColumns;
int missing=ratioMissing*totalItems/100;
Sampling* sampling=new Sampling(totalItems, false);
//cout <<"missing:" << missing;
//if (totalMissing<missing)
{
int newMissing=missing;//-totalMissing;
//cout <<"miss:" << missing << "totlmis:" << newMissing;
//end();

int j=0;
int r, c;
bool found;
for (int i=0;i<newMissing;i++)
{
//cout <<"pos:" << sampling->Pos[i];
found=false;
while (!found)
{
r=sampling->Pos[j]/totalColumns;
c=sampling->Pos[j]%totalColumns;
row=sample->GetElement(r);
if (strcmp(row->GetElement(c).c_str(), "?")!=0)
{
found=true;
//cout <<"\nfound. Old:\n" << *row;
//cout <<"r:" << r;
row->changeElementAtPos(string("?"), c);
//cout <<"\nNew:\n" << *row;
}
else j++;
}
j++;
}
//cout <<"j was:" << j;
}

ofstream OutputFile;
OpenOutput(filename2, &OutputFile);

OutputFile << *sample;

cout <<"Changes have been recorded in file " << filename2 << "\n";
return 0;


}










