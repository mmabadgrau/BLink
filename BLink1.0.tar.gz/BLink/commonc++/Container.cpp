/* File: Container.cpp */


#ifndef __Container_cpp__
#define __Container_cpp__




#include "Container.h"




/**
@memo Declaration of a list (FIFO)
@doc
*/


namespace BIOS
{

  /************************/
  /* list DEFINITION */
  /************************/


  /**
  @memo list 

    @doc
    Definition:
    A set of list's features 
    
  	Memory space: O(SizeP), which SizeP being the number of elements in the list
  	
  	  @author Maria Mar Abad Grau<< "\n
  	  @version 1.0
  */



  /**********************************/
  /* DEFINITIONS OF THE FUNCTIONS */
  /**********************************/

  /*___________________________________________________________________________________________*/

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::clone()
{
return new Container(*this);
}

  /*___________________________________________________________________________________________*/

  template <class T, template <class T> class Cont> floatList* Container<T, Cont>::getFloatList()
  {
 floatList *primitiveList=new floatList();
    typename Container<T, Cont>::NodePointer p=this->GetFirst();
    while (p!=NULL)
    {
      primitiveList->insertElement(this->GetElement(p));
      p=this->GetNext(p);
    }
    return primitiveList;
  }

  /*___________________________________________________________________________________________*/

  template <class T, template <class T> class Cont> intList* Container<T, Cont>::getIntList()
  {
    intList *primitiveList=new intList();
    typename Container<T, Cont>::NodePointer p=this->GetFirst();
    while (p!=NULL)
    {
      primitiveList->insertElement((int)this->GetElement(p));
      p=this->GetNext(p);
    }
    return primitiveList;
  }
/*___________________________________________________________________________________________*/

   template <class T, template <class T> class Cont> intList* Container<T, Cont>::getIntListFromPointerList()
  {
    intList *primitiveList=new intList();
    typename Container<T, Cont>::NodePointer p=this->GetFirst();
    while (p!=NULL)
    {
      primitiveList->insertElement(this->GetElement(p)->getValue());
      p=this->GetNext(p);
    }
    return primitiveList;
  }
   /*___________________________________________________________________________________________*/

   template<> Set<Integer, ListOfPointers>* Container<Integer, ListOfPointers>::getIntegerSetFromIntegerList()
  {
    Set<Integer, ListOfPointers> *integerSet=new Set<Integer, ListOfPointers>();
    Container<Integer, ListOfPointers>::NodePointer p=this->GetFirst();
    Integer* i;
    while (p!=NULL)
    {
      i=new Integer(*this->GetElement(p));
      integerSet->insertElement(i);
      zap(i);
      p=this->GetNext(p);
    }
    return integerSet;
  }
  /*___________________________________________________________________________________________*/

  template<> Set<Integer, ListOfPointers>* intList::getIntegerSet()
  {
  Container<Integer, ListOfPointers> *integerList=this->getIntegerList();
  Set<Integer, ListOfPointers> *integerSet=integerList->getIntegerSetFromIntegerList();
  zap(integerList);
  
    return integerSet;
  }
  /*___________________________________________________________________________________________*/

   template <class T, template <class T> class Cont> Container<Integer, ListOfPointers>* Container<T, Cont>::getIntegerList()
  {
    Container<Integer, ListOfPointers> *integerList=new Container<Integer, ListOfPointers>();
    typename Container<T, Cont>::NodePointer p=this->GetFirst();
    Integer* i;
    while (p!=NULL)
    {
      i=new Integer(this->GetElement(p));
      integerList->insertElement(i);
      zap(i);
      p=this->GetNext(p);
    }
    return integerList;
  }
/*____________________________________________________________ */
/*
  template <class T, template <class T> class Cont> void Container<T, Cont>::removeElementsWithPositionsIn(Container<int, list>* sourceList)
  {
   Container<T, Cont> *result= this->copyElementsWithoutPositionsIn(sourceList);
   zap(this);
   this=result;
    }
/*____________________________________________________________ */

  template <class T, template <class T> class Cont> void Container<T, Cont>::removeElementsIn(Container<T, Cont>* sourceList)
  {
    if (sourceList==NULL)
    {
      cout <<"Error in list::selectElementsByContents";
      end();
    }

    typename Container::NodePointer p=sourceList->GetFirst(), p2;
    while (p!=NULL)
    {
      if (this->findElement(sourceList->GetElement(p))!=NULL)
        this->removeNode(this->findElement(sourceList->GetElement(p)));
      p=sourceList->GetNext(p);
     }
  }

  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<int, list>* Container<T, Cont>::copyPositionsByContents(Container<T, Cont>* sourceList, int type)
  {
    if (sourceList==NULL)
    {
      cout <<"Error in list::selectElementsByContents";
      end();
    }

    typename Container::NodePointer p=this->GetFirst(), p2;
    int i=0;
    intList* newList=new intList();
    while (p!=NULL)
    {
      if ((sourceList->findElement(this->GetElement(p))==NULL && type==1) ||  (sourceList->findElement(this->GetElement(p))!=NULL && type==0))
        newList->insertElement(i);
      p=this->GetNext(p);
      i++;
    }
    return newList;
  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsByContents(Container<T, Cont> * Source, int type, bool orderedByThis)
  {
    // type=0: common, 1: different
    intList* newList=copyPositionsByContents(Source, type);
    Container<T, Cont> *result=this->copyElementsWithPositionsIn(newList, orderedByThis);

    zap(newList);
    return result;
  }


  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsByPositions(intList* sourceList, int type, bool orderedByThis)
  // type 0; copywith, 1: copyWithout
  {
//cout <<"Container::copyElementsByPositions\n";
    if (sourceList==NULL)
    {
      cout <<"Error in list::processElementsByPositions";
      end();
    }
    //Container<T, Cont>* newList=new Container<T, Cont>();

    Container<T, Cont>* newList=this->clone();
    newList->Empty();
   
    if (orderedByThis)
    {
     typename Container::NodePointer p;

      p=this->GetFirst();
//if (sourceList->GetSize()==37) cout << "in copy\n" <<*this <<"\n\n";
      int pos=0;
      while (p!=NULL)
      {
//if (sourceList->GetSize()==37)
//cout <<"\nelement pos " << pos << " is: \n" << this->GetElement(p) <<"\n";

        if ((sourceList->findElement(pos)!=NULL && (type==0)) || (sourceList->findElement(pos)==NULL && (type==1)))
        {
//if (sourceList->GetSize()==37)
//cout <<"Selected element pos " << pos << " is: \n" << this->GetElement(p) <<"\n";

          newList->insertElement(this->GetElement(p));
//if (sourceList->GetSize()==37)
//cout <<"\n after inserting\n";
         }
        p=this->GetNext(p);
        pos++;
      }
//if (sourceList->GetSize()==37) cout <<"in two\n";
    }
    else
    {
     typename intList::NodePointer p2;

    if (type==1) 
    {
       cout <<"Error in list::processElementsByPositions";
      end();

    }
      p2=sourceList->GetFirst();
      while (p2!=NULL)
      {
        newList->insertElement(this->GetElement(sourceList->GetElement(p2)));
        p2=sourceList->GetNext(p2);
      }
    }
    return newList;
  }
/*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::extractElementsByPositions(intList* sourceList, int type, bool orderedByThis)
  // type 0: extractWith, 1: extractWithout
  {
typedef typename list<struct node*>::NodePointer NP;
 list<NP>* listPos=new list<NP>();
  int i=0;
//cout <<"totalelements:" << this->GetSize() <<", type:" << type <<", sourcelist:" << *sourceList <<"\n";
    typename Container<T, Cont>::NodePointer p=this->GetFirst();
    while (p!=NULL)
    {
if ((sourceList->findElement(i)!=NULL && type==0) || (sourceList->findElement(i)==NULL && type==1)) 
    listPos->insertElement((NP)p);
    p=this->GetNext(p);
i++;
    }
if (listPos->GetSize()!=sourceList->GetSize())
{
cout <<"Error in Container::extractElementsByPositions";
cout <<"Some positions of " <<*sourceList << "are beyond the size of the container, which has size " << this->GetSize() <<" or the position list has repeated positions";
}
   Container<T, Cont>* newList=copyElementsByPositions(sourceList, type, orderedByThis);
     typename list<NP>::NodePointer p2;
      p2=listPos->GetFirst();
        while (p2!=NULL)
      {
       this->removeNode((typename Container<T, Cont>::NodePointer)listPos->GetElement(p2));
       p2=listPos->GetNext(p2);
        }
   zap(listPos);
    return newList;
  };

 /*____________________________________________________________ */
/*
 template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::mergeWith(Container<T, Cont>* secondList)
  {
   Container<T, Cont>* result=new  Container<T, Cont>();
   typename Container<T, Cont>::NodePointer p=this->GetFirst(), p2=secondList->GetFirst();
   while (p!=NULL || p2!=NULL)
 {
 while (p!=NULL && 
(p2!=NULL && this->GetElement(p)>=secondList->GetElement(p2)) || p2==NULL)
{
  result->insertElement(GetElement(p));
  p=this->GetNext(p);
}
 while (p2!=NULL && 
(p!=NULL && this->GetElement(p)<secondList->GetElement(p2)) || p==NULL)
{
  result->insertElement(secondList->GetElement(p2));
  p2=secondList->GetNext(p2);
}
 }
return result;
  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsWithPositionsIn(intList * sourceList, bool orderedByThis)
  {
    return copyElementsByPositions(sourceList, 0, orderedByThis);

  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsWithoutPositionsIn(intList* sourceList)
  {
    return copyElementsByPositions(sourceList, 1);

  }
  /*____________________________________________________________ */
  /*
    template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyAndSortElementsWithPositionsIn(intList * sourceList)
    {
  	 return processElementsByPositions(sourceList, 0);
   
    }
   /*____________________________________________________________ */


  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::extractElementsWithPositionsIn(intList * sourceList)
  {
    return extractElementsByPositions(sourceList, 0);
  };
  /*____________________________________________________________ */


  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::extractElementsWithoutPositionsIn(intList * sourceList)
  {
    return extractElementsByPositions(sourceList, 1);
  };

  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsIn(Container<T, Cont> * Source, bool orderedByThis)
  {
    return copyElementsByContents(Source, 0, orderedByThis);
  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::copyElementsNotIn(Container<T, Cont> * Source, bool orderedByThis)
  {
    return copyElementsByContents(Source, 1, orderedByThis);
  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<int, list>* Container<T, Cont>::copyPositionsWithElementsIn(Container<T, Cont> * Source)
  {
    return copyPositionsByContents(Source, 0);
  }
  /*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<int, list>* Container<T, Cont>::copyPositionsWithoutElementsIn(Container<T, Cont> * Source)
  {
    return copyPositionsByContents(Source, 1);
  }
/*____________________________________________________________ */

  template <class T, template <class T> class Cont> Container<T, Cont>* Container<T, Cont>::reverse()
  {
  Container<T, Cont>* result=new Container<T, Cont>();
  typename Container<T, Cont>::NodePointer p=this->GetLast();
while (p!=NULL)
{
 result->insertElement(this->GetElement(p));
p=this->GetPrevious(p);
}
    return result;
  }
  
  
 
  
} // end namespace
#endif

/* Fin Fichero: list.cpp */
// void zap<list<float>::node*>(list<float>::node*&);


