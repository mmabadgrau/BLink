/* File: listP.cpp */


#ifndef __listP_cpp__
#define __listP_cpp__




#include "listP.h"


/**
    @memo Declaration of a listP (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

template <class T> T* listP<T>::GetPointerToElement(typename list<T>::NodePointer e)
  {
    try
    {
      if (e==NULL)
        // throw NullValue(" in GetElement");
        throw NullValue();
      else return &(listP<T>::e->element);
    }

    catch (NullValue nv)
    {
      nv.PrintMessage();
    }
  };
  /*____________________________________________________________ */

  template <class T> T* listP<T>::GetPointerToElement(int k)
  {
    return GetPointerToElement(listP<T>::GetNode(k));
  };

  /*___________________________________________________________________________________*/

  template <class T> T listP<T>::GetLastElement ()
  {
    return listP<T>::GetElement(listP<T>::GetLast());
  };
  /*___________________________________________________________________________________*/

  template <class T> T listP<T>::Pop()
  {
    T last=listP<T>::GetLastElement ();

    // extract the last element from the list

    RemoveElement(listP<T>::GetLast());
    return last;
  };
  /* _____________________________________________________*/

  template<> int listP<int>::ReadElement (ifstream * source, int size)
  {
    char genotypebuf[size];
    CaptureLine(source, genotypebuf, size);
    return (int) atol(genotypebuf);
  };
  /* _____________________________________________________*/

  template<> double listP<double>::ReadElement (ifstream * source, int size)
  {
    char genotypebuf[size];
    CaptureLine(source, genotypebuf, size);
    return (double) atof(genotypebuf);
  };



} // end namespace
#endif

/* Fin Fichero: listP.h */
