  /**
    * @file MergeFiles.cpp
    * @brief Program to merge text files when value at some column is the same
    *
    */

#include "Fachade.h"
/* This program divide a text file in two, with %rows in the first file, where % is especified as an argument*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;
//using namespace std;

int main(int argc, char*argv[]) {
   
     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << "<output file1>" << " <output file2> " << "<percent in first file (default is 50)>\n";
        exit(0);
        }
     char filename[128], filename2[128], filename3[128];
int column;
        
	 strcpy(filename, argv[1]);

   	 strcpy(filename2, argv[2]);

	 strcpy(filename3, argv[3]);

int percent=50;
if (argc==5) percent= atoi(argv[4]);




if (strcmp(filename, filename2)==0 || strcmp(filename, filename3)==0 || strcmp(filename3, filename2)==0)
{
cout << "error, files must have different names";
exit(0);
}



ofstream OutputFile, OutputFile2;
OpenOutput(filename2, &OutputFile);
OpenOutput(filename3, &OutputFile2);
//cout <<"filename" << filename;


Sample<string, list, ListOfPointers> * l=new Sample<string, list, ListOfPointers>(filename), * result1, *result2=NULL;

int size=l->GetSize(), sizeF=percent*size/100;

Sampling* sampling=new Sampling(size, false);
intList* positions=createList(sampling->Pos, sizeF);

result1=new Sample<string, list, ListOfPointers>(*l, sampling);

result2=(Sample<string, list, ListOfPointers>*)result1->extractElementsWithPositionsIn(positions);

OutputFile << *result1;
OutputFile2 << *result2;
OutputFile.close();
OutputFile2.close();
delete l, result1, result2;
cout <<"\nResults have been saved in files " << filename2 << " and " << filename3 <<"\n";

//zap(result);


}










