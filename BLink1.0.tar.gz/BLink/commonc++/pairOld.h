/* File: pair.h */


#ifndef __pair_h__
#define __pair_h__


#include<iostream>////
#include<fstream>//
#include<cstring>//
#include<cstdio>//                                              //
#include <cstdlib>//
#include <cctype>//
#include <cmath>//
#include <sys/stat.h>                                                       
#include "basic.h"//

using namespace std;

namespace BIOS {


////////////////////
template <class T> class pair //
{
protected:
public:
	T numerator;
	T denominator;
	~pair();
	pair (T numerator, T denominator); // constructor
	pair (const pair<T> & origen);// constructor de copia
	double log2();
	pair operator* (const pair<T> & rat2);
	bool operator< (pair<T> & rat2);
	virtual pair<T> operator/ (pair<T> & rat2);
	double convert ();
	string print();
	bool isUndefined ();

};
/////////////
template <class T> pair<T>::~pair ()
{
}
/////////////
template <class T> pair<T>::pair (T num, T den)
{
 numerator=num;
 denominator=den;
}
//////////////
template <class T> pair<T>::pair (const pair<T> & origen)
{
 numerator=origen.numerator;
 denominator=origen.denominator;
}
/////////////////
template <class T> pair<T> pair<T>::operator* (const pair<T> & rat2)
{
pair result(0,0);
result.numerator=numerator*rat2.numerator;
result.denominator=denominator*rat2.denominator;
return (result);
}
/////////////////
template <class T> bool pair<T>::operator< (pair<T> & rat2)
{
return (this->convert()< rat2.convert());
}
/////////////////
template <class T> pair<T> pair<T>::operator/ (pair<T> & rat2)
{
pair<T> result(0,0);
if (isUndefined() && rat2.isUndefined()) return result;
if (numerator==0 && rat2.numerator==0) return result;

if (rat2.numerator==0)
{
	cout <<"\nError in pair::operator/ for " << this->print() <<" and " << rat2.print() <<", denominator is 0";
	end();
}
result.numerator=numerator*rat2.denominator;
result.denominator=denominator*rat2.numerator;
return (result);
}
//////////////////
template <class T> double pair<T>::log2()
{
 if (numerator==denominator) return (0);
 if (numerator==0) 
	 {
cout <<"\nError, not a number in pair::log2";
exit(0);
}
 else return (log_2((double)numerator)-log_2((double)denominator));//
}
//////////////////
template <class T> double pair<T>::convert ()
{
if (denominator==0) 
{
cout <<"\nError, not a number (denominator is 0) in pair::convert():" << print();
end();
}
if (numerator==denominator) return (1);
else return ((double)numerator/(double)denominator);
}
//////////////////
template <class T> bool pair<T>::isUndefined ()
{
if (numerator==0 && denominator==0)
return true; else return false;
}
//////////////////
template <class T> string pair<T>::print ()
{
char line[20];
sprintf(line, " (%.4f, %.4f)", numerator, denominator);
string s=string(line);
return s;
}
}//end namespace
#endif
