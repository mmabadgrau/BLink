/* File: ListOfLists.h */


#ifndef __ListOfLists_h__
#define __ListOfLists_h__




/**
    @memo Declaration of a ListOfList (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* list DEFINITION */
  /************************/


  /**
          @memo ListOfList 
   
  	@doc
          Definition:
          A set of list's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the list
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
/*
 template <class T> typedef struct node
    {
      T element;
      struct node* Next;
      struct node* Previous;

    };
*/
  template <class T> class ListOfLists: public ListOfPointers<ListOfPointers< T> > 
  {

 public:
 
    ListOfLists(ListOfLists<T> &source, list<int> *Sampling):ListOfPointers<ListOfPointers< T> >(source, Sampling){};

    ListOfLists(char* filename, char* tokens=NULL):ListOfPointers<ListOfPointers< T> >(filename, tokens){};

 typename ListOfLists<T>::NodePointer findFinalElement(T* element)//
  {
 typename ListOfLists<T>::NodePointer p=this->GetFirst();
typename ListOfPointers<T>::NodePointer pp;

 while (p!=NULL)
{
pp=GetElement(p)->findElement(element);
if (pp!=NULL) return p;
p=this->GetNext(p);
}
return NULL;

  };


  };  // End of class list



} // end namespace
#endif

//#include "list.cpp"

/* Fin Fichero: list.h */


/* Fin Fichero: list.h */
