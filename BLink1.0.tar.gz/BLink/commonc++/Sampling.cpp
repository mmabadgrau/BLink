/* File: Sampling.cpp */


#ifndef __Sampling_cpp__
#define __Sampling_cpp__



#include "Sampling.h"


namespace BIOS {


/************************/
/* Sampling STATISTIC*/
/************************/


/**
        @memo Sampling

	@doc
        Definition:
        An array Pos of Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



///////////////////
//// public ////////
///////////////////


/**********************************/
Sampling::Sampling(int size, bool repetition)
{
Size=size;
bool *Chosen;


try {
if ((Pos=new int[size])==NULL)
      throw NoMemory();


if (repetition==true)
for (int  i=0; i<size;i++)
 Pos[i]=rand() % (size);     //
else // without repetition
{
int pos;
if ((Chosen=new bool[size])==NULL)
    throw NoMemory();
for (int  i=0;i<size;i++)
	Chosen[i]=false;

int cont2, posNotChosen;

for (int i=0; i<size;i++)
  {//
   cont2=0;//
   pos=rand() % (size-i);     //
   posNotChosen=0;
   for (int i2=0; i2<=pos; i2++)
   {
   while (Chosen[posNotChosen]==true)
    posNotChosen++;
   if (i2<pos)
   posNotChosen++;
   }
   Pos[i]=posNotChosen;
   Chosen[posNotChosen]=true;
  }//
} // end without repetition 
  }
catch (NoMemory no) {
  no.PrintMessage();
  }
if (Chosen!=NULL)
delete Chosen;
}
/**********************************/

Sampling::~Sampling()
{
//	if (SamplingValue!=NULL)
//	delete SamplingValue;
zaparr(Pos);
}

/**********************************/
int* Sampling::getPositionsTable()
{
return Pos;
}

};  // End of Namespace

#endif

/* End of file: Sampling.h */




