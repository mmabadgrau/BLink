/* File: ListOfPointers.cpp */


#ifndef __ListOfPointers_cpp__
#define __ListOfPointers_cpp__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "ExceptionsBasic.h"
#include "basic.h"
#include "AttPattern.h"
#include "ListOfPointers.h"
//#include "ListOfPointers.h"
//#include "Diplotype.h"


/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A set of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */
  /*____________________________________________________________ */
  
     template <class T> ListOfPointers<T>::ListOfPointers():SoftListOfPointers<T>()
    {
     }  

    /*____________________________________________________________ */
/*
  template <class T> void ListOfPointers<T>::copy (const typename ListOfPointers<T>::NodePointer Source, const typename ListOfPointers<T>::NodePointer last)
  {
// DEJAR COMO NO RECURSIVO

    typename ListOfPointers<T>::NodePointer p=Source;
   
   while (p!=NULL && (last==NULL || p!=last->Next))
{
cout <<"\n\n\nhere";
      insertElement(p->element);
cout <<"last";
      p=p->Next;
    }
  }
       /*____________________________________________________________ */
/*

   template <class T>  ListOfPointers<T>::ListOfPointers (ListOfPointers<T> &source):SoftListOfPointers<T>()
  {
	this->init();

    if (&source!=NULL)
    {

             this->copy (source.List);
    }
  }
       /*____________________________________________________________ */


   template <class T>  ListOfPointers<T>::ListOfPointers (ListOfPointers<T> &source, typename ListOfPointers<T>::NodePointer first, typename ListOfPointers<T>::NodePointer last):SoftListOfPointers<T>()
  {
   this->init();
   typename ListOfPointers<T>::NodePointer ini=first;
   if (&source!=NULL)
    {
    if (first==NULL) ini=source.GetFirst();
    copy (ini, last);
    }
  }

/*____________________________________________________________ */


  template <class T> ListOfPointers<T>::ListOfPointers (ListOfPointers<T> &source, Sampling* sampling):SoftListOfPointers<T>()
  {
   this->init();
   createWithSampling(source, sampling);
  }

/*___________________________________________________________________________________*/
/*
  template <class T>  void ListOfPointers<T>::hardCopy(char filename[256])
  {

	  
    ofstream  OutputFile;
    OpenOutput(filename, &OutputFile);

  typename ListOfPointers<T>::NodePointer p=this->GetFirst();

    while (p!=NULL)
    {
	OutputFile << *p->element <<"\n";// error linkage when *GetElement(p)
      p=this->GetNext(p);
    }


//OutputFile << *this;

	 OutputFile.close();
  }
    
  /*____________________________________________________________ */

   template <class T> ListOfPointers<T>::ListOfPointers(char* filename, char* tokens):SoftListOfPointers<T>()
  {
	this->init();
    this->GetInfo(filename, tokens);

  }

  /*____________________________________________________________ */

   template <class T> ListOfPointers<T>::~ListOfPointers ()
  {
   destroy(this->List);
   }

      /*____________________________________________________________ */

   template <class T>  void ListOfPointers<T>::moveElement(int oldPos, int newPos)
  {
    ListOfPointers::moveElement(oldPos, newPos);
  }
  /*____________________________________________________________ */

   template <class T>  void ListOfPointers<T>::deleteElement (T * element)
  {
    zap(element);
  }
  
   /*___________________________________________________________ */

   template <class T>  void ListOfPointers<T>::ReadInfo (ifstream * is, char* tokens)
  {
//cout <<"gg";
 T* element;
 char a, b;
 a=is->get();
 if (a!=EOF) b=is->get();
     while (a!=EOF && b!=EOF)
    {
     is->putback(b);
     is->putback(a);
        element=this->ReadElement(is, tokens);
      if (element!=NULL)
{
      insertElement(element);
 a=is->get();
 if (a!=EOF) b=is->get();
}

      zap(element);

    }


  }
   /*___________________________________________________________________________________*/
/*
  template <class T> void ListOfPointers<T>::selectAndOrderElements(list<int>* elementList)//
  {
 
list<int>::NodePointer p=elementList->GetFirst();

ListOfPointers<T> *row=new ListOfPointers<T>();

row=new ListOfPointers<T>();
while (p!=NULL)
{
row->insertElement(this->GetElement(elementList->GetElement(p)));
p=elementList->GetNext(p);
}

this->Empty();
this->copy(row->List);
zap(row);
};
    /*___________________________________________________________ */
	/*
	template <class T> void Sample<T>::ReadInfo (ifstream * is, char* tokens=NULL)
	{
		
		while (is->peek()!='\n' &&  is->peek()!='\r' && is->peek()!=EOF) 
		{
			insertElement(ReadElement(is, tokens));
			
		}
		
		
	}
   /*____________________________________________________________ */

 /*
    template <class T>  ListOfPointers<T>* ListOfPointers<T>::ExtractList(int indexVector[], int size)
	{
 SoftListOfPointers<T>* eList=this->SoftListOfPointers<T>::ExtractList(indexVector, size);
	ListOfPointers<T>*newList=new ListOfPointers<T>(*(ListOfPointers<T>*)eList);
	zap(eList);
	   return newList;   };

 /*____________________________________________________________ */
 /*
 template <class T> void ListOfPointers<T>::insertElement (T* element)
  {
    typename ListOfPointers<T>::NodePointer Pointer=NULL;
//cout <<"before list " << *this <<"\n";
    try
    {
      if ((Pointer=new typename ListOfPointers<T>::node)==NULL)
        throw NoMemory();
      assignElement(Pointer, element);
//cout <<"here\n";
    Pointer->Next=NULL;
    Pointer->Previous=this->Last;

    if (this->Size>0) 
    if (this->Last==NULL) throw NullValue(); else this->Last->Next=Pointer;
//     else this->List=Pointer;
    this->Last=Pointer;
    this->Size++;
//cout << *this <<"\n";

}
 catch (NoMemory NM ) {NM.PrintMessage();}
 catch (NullValue null) {null.PrintMessage("in list::insertElement");}
  };
  /*____________________________________________________________ */

   template <class T>  void ListOfPointers<T>::assignElement (typename ListOfPointers<T>::NodePointer p, T* element)
  {
p->element=NULL;
/*
if (element->GetSize()==33)
{
cout <<"element:\n" << *element <<"\n\n";
if (p==NULL) cout <<"p is null\n"; else cout <<"p is not null\n";
if (p->element==NULL) cout <<"p element is null\n"; else cout <<"p element is not null\n";

}
*/
   p->element=new T(*element);
/*
if (element->GetSize()==33)
{
cout <<"succeded\n\n";
}
*/
  }


} // end namespace
#endif

/* Fin Fichero: ListOfPointers.cpp */
