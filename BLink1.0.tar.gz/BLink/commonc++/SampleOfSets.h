#ifndef SampleOfSets_h//
#define SampleOfSets_h//

#include "basic.h"
#include "ListOfPointers.h"
#include "Prob.h"

namespace BIOS 
{

// template <class T, template <class T> class SuperCont> class Container: public SuperCont<T>
 
////////////////////////////
//template <class T> class SampleOfSets: public ListOfPointers<Container<T, list> >
//  class ListOfAttributes: public Set<Attribute, ListOfPointers>
//   template <class T, template <class T> class SuperCont> class Container: public SuperCont<T>
//template
//<
//    typename T,
//    template <class> class F,
//    template < class, template <class> class > class S
//>


//template<class T, template <class T> class Cont,template <class Cont> class SuperCont>
//    class SampleOfSets: public Container<Container<T,Cont<T> >, SuperCont>

template<class T>
    class SampleOfSets: public Container<Set<T,ListOfPointers>, ListOfPointers>
{
 
  public:
  
  
    intList* getBlankets (Set<T, ListOfPointers>* otherSet);

   Set<T, ListOfPointers>* getUnionOfIntersections ();


   intList* getOptimalMaxIntersection (Set<T, ListOfPointers>* otherSet);
 
   int getOptimalBlanket (Set<T, ListOfPointers>* otherSet);
   int getMaxIntersection (Set<T, ListOfPointers>* otherSet);

    
   SampleOfSets(SampleOfSets &source):Container<Set<T,ListOfPointers>, ListOfPointers>(source){};
 SampleOfSets():Container<Set<T,ListOfPointers>, ListOfPointers>(){};
 ~SampleOfSets(){};
   SampleOfSets<T>* getCommonNodes (Set<T, ListOfPointers>* otherSet);
   
   Set<T, ListOfPointers>* jointSets ();


};

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, SampleOfSets<T>& lista)
  {
  typename SampleOfSets<T>::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << *lista.GetElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<"\n";
    }
   
    return out;
  }

  
  
 //template <class T, template <class T> class SuperCont> class Container: public SuperCont<T>
 
//template<template<class> class <template-parameter-2-1>
//Container<int, list>


} // end namespace
#endif
