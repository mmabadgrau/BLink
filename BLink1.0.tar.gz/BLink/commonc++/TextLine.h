/*
 * TextLine.java
 *
 * Created on 9 de diciembre de 2005, 10:10
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package file;

import java.io.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.*;
import javax.swing.*;
/**
 *
 * @author mabad
 */
public class TextLine {
    
    private String line=new String();
    private BufferedReader bufferedReader;
    private String separators;
    /** Creates a new instance of TextLine */
    public TextLine(BufferedReader bufferedReader, String separators) {
        this.bufferedReader=bufferedReader;
        this.separators=separators;
        try{        readLine();}catch (IOException e){
           JOptionPane.showMessageDialog(null,"Incorrect format. It is not a text file");
                            
         }; 
          }
    public int readLine () throws IOException
    {
         
         
        String s=null;
        
      
        try{
        line=bufferedReader.readLine();
        if (line==null) return 1; 
        StringTokenizer st=new StringTokenizer(line, separators);     
        if (!st.hasMoreTokens()) return 1;
        if (line.length()>1000000)
            throw (new IOException());
        }
        catch (IOException e){
           JOptionPane.showMessageDialog(null,"Incorrect format. It is not a text file");
             return 1;               
         }; 
        return 0;
    }
    public String getLine() {
        return line;
    }
  
    public int getLineSize() {
        return line.length();
    }
    public ArrayList getWordsInLine() throws IOException
    {
        ArrayList stringList=new ArrayList();
        String separators=new String(" ,\t\n\r\f");
            
        StringTokenizer st=new StringTokenizer(line, separators);
       //  st.ordinaryChar(',');
      //   st.ordinaryChar('\t');
      //   st.ordinaryChar(' ');
         
        String s=null;
        
         try{
            while (st.hasMoreTokens()  && stringList.size()<100) { 
               s=st.nextToken();
                stringList.add(s);
            //           JOptionPane.showMessageDialog(null,"taoalel:"+s);
            }
              
        //        JOptionPane.showMessageDialog(null,"taoalel:"+stringList.size());
      
           if (stringList.size()==100) throw (new IOException());
              
        }
         catch (IOException e){
                JOptionPane.showMessageDialog(null,"Incorrect format. It is not a text file");
                    return null;
                   
         }; 
        return stringList;
    }
 
    
}
