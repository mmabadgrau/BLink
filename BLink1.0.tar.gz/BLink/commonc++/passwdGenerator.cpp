#include <sys/stat.h>  
#include <string>
#include <iostream>
#include <cstdio>//
#include <stdio.h>//
#include <iostream>
#include <fstream>

using namespace std;

int main (int argc, char** argv)
{
if (argc<2) {cout <<"One argument with the lenght is required"; exit(0);}
int length=atoi(argv[1]);
int total=1;
if (argc==3)
total=atoi(argv[2]);
srand(time(NULL));	/* Generador de números aleatorios */

char pass[length];

for (int t=0;t<total;t++)
{
for (int i=0;i<length;i++)
		pass[i]=(char)((rand()%26)+'a');	
cout <<"\n" << pass;
}
cout <<"\nDone.\n";
}
