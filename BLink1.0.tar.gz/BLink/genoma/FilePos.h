/* File: positions.h */

#ifndef __FilePos_h__
#define __FilePos_h__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//


#include "basic.h"

#include "Exceptions.h"

#include "SNP.h"

#include "list.h"


//using namespace std;
//using namespace string;

using namespace TAD;

namespace BIOS {


/************************/
/* positions DEFINITION */
/************************/


/**
        @memo positions for SNPs

	@doc
        Definition:
        A set of phenotype's features and genotypes for an positions

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in the sample
        Each positions in a sample has been genotyped for the same TotalSNPs SNPs.

        @author Maria M. Abad
	@version 1.0
*/

 
 typedef struct position
  {
  double pos;
  bool filepos;
  };
	
	
class positions: public list <position>
	 {

  private:
    /** @name Implementation of class positions
        @memo Private part.
    */
  
  SNPPos TotalSNPs;

  char filepos[256];

  bool OrderedPositions;

/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


void ReadInfo (ifstream * origen, NodePointer ppos);

SNPPos GetPositionInList (double value, positions * pos);



      /* PUBLIC FUNCTIONS (INTERFACE) */




      public:



      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */
	/*  void WriteResults (char* filename);   */
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by positions.
           Time complexity O(1).

      */
	//  ~positions ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */


  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

//		positions(const positions& origen); 


//	  positions(const phenotype& porigen, const genotype& gorigen, IndCategory ic);

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		positions(char* filename); 

		positions(SNPPos TotalSNPs); 

        void GetInfo(ifstream *InputFile);

		  
	  /**
         @memo Creates a new positions object with the phase resolved.
         @param Origen: the origianl positions object 
         Time complexity O(TotalSNPs*Size*Size)

      */
        void PrintOrderedPositions();

		SNPPos GetTotalSNPs();
		

	   void OrderPositions();
  
	   bool IsOrdered ();

	   void SetPositions (char* filepos);

	   void CheckRangeSNP(SNPPos SNP);


};  // End of class positions



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private


/*___________________________________________________________ */

void positions::ReadInfo (ifstream* source, NodePointer ppos)
{

	char *genotypebuf, *cad;
    if ((genotypebuf=new char[20])==NULL)
     throw NoMemory();


     double pos;

bool Unordered=false;
position* targetold, *targetpos=&(ppos->element);	 
do
{
  	source-> getline (genotypebuf, 20, '\n');
	cad = strtok (genotypebuf," \t");
//        sscanf (cad, "%f", &pos);
    pos=atof(cad);
    targetold=targetpos; 
	targetpos->pos= pos;
	if (TotalSNPs>0)
	{
	if (pos<targetold->pos)
	{
         Unordered=true;
	 //cout << "\ndesordenado, " << pos << "menor que " << (targetpos->Previous)->pos;
	}
        if (pos==targetold->pos)
         targetpos->unrepeated=false;
        else targetpos->unrepeated=true;
	}
        else targetpos->unrepeated=true;
	targetpos->filepos=TotalSNPs;
	targetpos->selected=true;
    // cout <<"pos:" << TotalSNPs; 


	
	TotalSNPs++;
	if ((source->peek()!=EOF) && (source->peek()!='\n'))
	{
	if ((ppos->Next=new node)==NULL)
     throw NoMemory();
	ppos=ppos->Next;
    // ReadInfo (source, targetpos->Next);
	}
	else
	 ppos->Next=NULL;
    
}
while ((source->peek()!=EOF) && (source->peek()!='\n'));

	assert (genotypebuf!=NULL);
    delete genotypebuf;

}

/*____________________________________________________________ */

void positions::SetPositions(char *filepos)
{

//cout <<"TS:" << TotalSNPs;
TotalSNPs=0;
cout << "Reading positions ...\n";

try
{
 if (!ExistFile(filepos))
	 throw ErrorFile();
 InputFile.open (filepos, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(filepos);
   }

GetInfo(&InputFile);


InputFile.close();



};



///////////////////
//// public ////////
///////////////////



	/*____________________________________________________________ */

positions::positions(char* filename)
{

OrderedPositions=false;

TotalSNPs=0;

if (strncmp(strtok(filename+2, ".")-2, "pos", 3)!=0)
{
	cout <<"File pos is required";
	exit (0);
}

SetPositions(filename);        

}





/*____________________________________________________________ */

bool positions::IsOrdered ()
{
	return OrderedPositions;
}


/*____________________________________________________________ */

void positions::PrintOrderedPositions ()
 {

  if (OrderedPositions==false)
	  OrderPositions();

  
  char* filepos2;

 if ((filepos2=new char[128])==NULL)
		 throw NoMemory();


 
         strcpy (filepos2, filepos);
         strtok(filepos2, ".");
         strcat (filepos2, ".poo\0");




  FILE * OutputFile; 
  
  try
{
  OutputFile=fopen (filepos2, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
fprintf(OutputFile, "%.0f\n", (GetElement(IndPosition)).pos);
IndPosition=GetNext(IndPosition);
}
  
 fclose(OutputFile);

 delete filepos2;

 }
/*____________________________________________________________ */

SNPPos positions::GetPositionInList (double value, positions * pos)
{
// find the position of position.pos=value in object pos
SNPPos  count=0;
NodePointer IndPosition=pos->GetFirst();
position Pos;
try
{
while (IndPosition!=NULL)
{
 Pos=GetElement(IndPosition);
 if (value==Pos.pos)
  return count;
 else 
 {
  count++;
  IndPosition=pos->GetNext(IndPosition);
 }
}
throw NonExist();
}

catch (NonExist ne) {
  ne.PrintMessage(0);
  }

}
 
/*____________________________________________________________ */

void positions::OrderPositions()
{
 SNPPos i=0;

 NodePointer IndPosition=GetFirst();

 cout << "Sorting SNPs by positions...\n";
	
 double *ListPos;
 if ((ListPos=new double[TotalSNPs])==NULL)
  throw NoMemory();

positions *pos2;
pos2=new positions(*this);

 while (IndPosition!=NULL)
 {
  position Pos=GetElement(IndPosition);
  ListPos[i]=Pos.pos;
  IndPosition=GetNext(IndPosition);
  i++;
 }
 qsort ((void*)ListPos, TotalSNPs, sizeof (*ListPos), compare);

 cout <<"or:";

bool OrderedPositions=true, found;
i=0;

IndPosition=GetFirst();

position Pos;

while (IndPosition!=NULL)
{
 Pos=GetElement(IndPosition);
 Pos.pos=ListPos[i];
 Pos.filepos=GetPositionInList (ListPos[i], pos2);
 IndPosition=GetNext(IndPosition);               
}

delete ListPos;
//delete pos2;
}
/*____________________________________________________________ */

SNPPos positions::GetTotalSNPs()
{
 return TotalSNPs;
}
/*__________________________________________________________*/

void positions::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}
/*__________________________________________________________*/

bool positions::IsSelected(SNPPos SNP)
{
return GetElement(GetNode(SNP)).selected;
}
};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
