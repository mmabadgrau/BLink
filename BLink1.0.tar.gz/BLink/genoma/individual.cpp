#include <string>

#include <iostream>
#include <cassert>
#include <fstream>

#include "individual.h"
#include "Exceptions.h"

#include "individual.h"


namespace SNP {


/*_____________________________________________________________*/


void individual::CountHaps (unsigned int* comb, genotype::Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP) 
//count known haplotypes
{
 if (genotype::IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[0]=comb[0]+2;// 1 1 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[1]=comb[1]+2;// 1 2 
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[3]=comb[3]+2;// 2 2 
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[2]=comb[2]+2;// 2 1         
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))         
 {
       comb[0]++; // 1 1 
       comb[1]++; // 1 2
 }
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))         
 {
       comb[2]++; // 2 1 
       comb[3]++; // 2 2
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
 {
	 comb[0]++;// 1 1 
     comb[2]++; // 2 1
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
 {
	 comb[1]++; // 1 2 
     comb[3]++; // 2 2
 }

}  
    	 
/*_________________________________________________________________________*/

void individual::ObtenerBestPhase (unsigned int* comb, unsigned int FirstSNP, unsigned int LastSNP, 
IndCategory ic)
// this function computes the number of 11 12 21 and 22 haplotypes existing
// in the dataset for those children with the same haplotypes for
// LeftHaplotype and RightHaplotype.
{
Phenotype * IndPhenotype=TheFirstPhenotype;
Genotype * IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++)
{
 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
  if (IsANonMissingSNP (IndGenotype, FirstSNP) && IsANonMissingSNP (IndGenotype, LastSNP)) 
   CountHaps(comb, IndGenotype, FirstSNP, LastSNP);     
IndPhenotype=IndPhenotype->Next;
IndGenotype=IndGenotype->Next;
}
}

/*__________________________________________________________*/

unsigned int individual::AssignPhase (unsigned int FirstHetero, unsigned int LastHetero, IndCategory ic, unsigned int OldMayorPhase)
{
                                 
unsigned int Frequencies[4], total, MajorPhase;
double numerator;

for (int i=0;i<4;i++)
 Frequencies[i]=0;     
    
ObtenerBestPhase (&Frequencies[0], FirstHetero, LastHetero, ic);
  
total=Frequencies[0]+Frequencies[1]+Frequencies[2]+Frequencies[3];
     
Frequencies[0]++; // A
Frequencies[1]++; // a
Frequencies[2]++; // B
Frequencies[3]++; // b

numerator=((Frequencies[0]/total)*(Frequencies[3]/total))-((Frequencies[1]/total)*(Frequencies[2]/total));
  
if (numerator > 0)
  MajorPhase=1;
else 
  MajorPhase=2;
 
return MajorPhase;
} 
/*____________________________________________________________ */

void individual::ResolvePhase (IndCategory ic)
{
unsigned int LastResolved, OldMajorPhase, MajorPhase;
cout << "\nReconstructing haplotypes...";
this->OrderSNPs(ic);
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype* IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++)
 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
 {
  LastResolved=0; 
 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
 {
  if (IsHeterozygous(IndGenotype, SNP))
  {
   if (LastResolved==0) //    UnknownPreviousPhase
    LastResolved=SNP;
   else  // if not the first heterozygote SNP 
   {
    if (((*((IndGenotype->Left)+LastResolved)==*(MajorAllele+LastResolved)) && 
		(*((IndGenotype->Left)+SNP)==*(MajorAllele+SNP))) || 
		((*((IndGenotype->Left)+LastResolved)==*(MinorAllele+LastResolved)) && 
		(*((IndGenotype->Left)+SNP)==*(MinorAllele+SNP))))
     OldMajorPhase=1;
    else 
	 OldMajorPhase=2;
          
    MajorPhase=AssignPhase (LastResolved, SNP, ic, OldMajorPhase);
	MajorPhase=1;

    if (*((IndGenotype->Left)+LastResolved)==*(MajorAllele+LastResolved))
	{
     if (MajorPhase==1)
	 {
      (*((IndGenotype->Left)+SNP)=*(MajorAllele+SNP));
	  (*((IndGenotype->Right)+SNP)=*(MinorAllele+SNP));
	 }
	 if (MajorPhase==2)
	 {
      (*((IndGenotype->Left)+SNP)=*(MinorAllele+SNP));
	  (*((IndGenotype->Right)+SNP)=*(MajorAllele+SNP));
	 }
	}
     else // left last hetero SNP was phased as a 2
     {
     if (MajorPhase==1)
	 {
      (*((IndGenotype->Left)+SNP)=*(MinorAllele+SNP));
	  (*((IndGenotype->Right)+SNP)=*(MajorAllele+SNP));
	 }
	 if (MajorPhase==2)
	 {
      (*((IndGenotype->Left)+SNP)=*(MajorAllele+SNP));
	  (*((IndGenotype->Right)+SNP)=*(MinorAllele+SNP));
	 }
	}
   if (MajorPhase!=0) LastResolved=SNP;    
   } // end not the first hetero
  } // end is hetero
 } //end for each SNP
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
} // end for each individual
cout << "\nReconstruction has finished";
}

}

