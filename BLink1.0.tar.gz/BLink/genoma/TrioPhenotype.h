/* File: TrioPhenotype.h */


#ifndef __TrioPhenotype_h__
#define __TrioPhenotype_h__



#include "Phenotype.cpp"
#include "PhenotypeSample.cpp"


namespace BIOS {


/************************/
/* SNP'S PhenotypePointer DEFINITION */
/************************/


/**
        @memo PhenotypePointer for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class TrioPhenotype {


public:
    /** @name Implementation of class PhenotypePointer
        @memo Private part.
    */
	

	PhenotypePointer FatherPhenotype, MotherPhenotype, ChildPhenotype;

   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on PhenotypePointer 
        @memo Operations on a PhenotypePointer 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */


		TrioPhenotype();

		TrioPhenotype (PhenotypePointer FatherPhenotype,  PhenotypePointer MotherPhenotype, PhenotypePointer ChildPhenotype);


      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
//      ~TrioPhenotype ();



	  PhenotypePointer GetFatherPhenotype ();

	  PhenotypePointer GetMotherPhenotype ();

	  PhenotypePointer GetChildPhenotype ();

	  void SetFatherPhenotype (PhenotypePointer phenotype);

	  void SetMotherPhenotype (PhenotypePointer phenotype);

	  void SetChildPhenotype (PhenotypePointer phenotype);


	  char* PrintPhenotype();


};  // End of class PhenotypePointer



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

TrioPhenotype::TrioPhenotype ()
{

}

/*____________________________________________________________ */

TrioPhenotype::TrioPhenotype (PhenotypePointer FatherP,  PhenotypePointer  MotherP,  PhenotypePointer ChildP)
{
try
{
if (FatherP==NULL || MotherP==NULL || ChildP==NULL)
 throw NullValue();
}
 catch (NullValue ov) {ov.PrintMessage(" Trio::constructor");}

FatherPhenotype=FatherP;
MotherPhenotype=MotherP;
ChildPhenotype=ChildP;
}
/*____________________________________________________________ */
/*
char* TrioPhenotype::PrintPhenotype ()
{
char *p=line;
strcpy(line,"\0");
strcat(line, FatherPhenotype->element.PrintPhenotype().c_str());
strcat(line, MotherPhenotype->element.PrintPhenotype().c_str());
strcat(line, ChildPhenotype->element.PrintPhenotype().c_str());
return p;
}
/*____________________________________________________________ */

PhenotypePointer TrioPhenotype::GetFatherPhenotype ()
{
	return FatherPhenotype;
}
/*____________________________________________________________ */

PhenotypePointer TrioPhenotype::GetMotherPhenotype ()
{
	return MotherPhenotype;
}
/*____________________________________________________________ */

PhenotypePointer TrioPhenotype::GetChildPhenotype ()
{
	return ChildPhenotype;
}
/*____________________________________________________________ */

void TrioPhenotype::SetFatherPhenotype (PhenotypePointer phenotype)
{
FatherPhenotype=phenotype;
}
/*____________________________________________________________ */

void TrioPhenotype::SetMotherPhenotype (PhenotypePointer phenotype)
{
MotherPhenotype=phenotype;
}/*____________________________________________________________ */

void TrioPhenotype::SetChildPhenotype (PhenotypePointer phenotype)
{
ChildPhenotype=phenotype;
}

/*______________________________________________________*/

ostream& operator<<(ostream& out,TrioPhenotype& trio)
{
   // out << "\n";
out << trio.FatherPhenotype->element.PrintPhenotype();
out << " " << trio.MotherPhenotype->element.PrintPhenotype();
out << " " << trio.ChildPhenotype->element.PrintPhenotype() <<"\n";
return out;
  }

template <> ostream& operator<<(ostream& out, list<TrioPhenotype>& l){};

};  // End of Namespace

#endif

/* End of file: PhenotypePointer.h */




