/* File: Genotype.h */


#ifndef __RepeatedGenotype_h__
#define __RepeatedGenotype_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "RepeatedPositions.h"
#include "UnorderedRepeatedGenotype.h"

using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A  pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class RepeatedGenotype: public UnorderedRepeatedGenotype {

//protected:

    /** @name Implementation of class Genotype
        @memo Private part.
    */
	   
      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   

/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
	
	void CheckRepeated(RepeatedPositions *pos);

		/* PUBLIC FUNCTIONS (INTERFACE) */

   public:

	void PrintGenotype(RepeatedPositions *pos); 


};  // End of class Genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



/*____________________________________________________________ */

void RepeatedGenotype::CheckRepeated(RepeatedPositions *pos)
{
	SNPPos TotalSNPs=GetTotalSNPs(), i=0;
	bool RepeatedPos[TotalSNPs], *p=RepeatedPos;

	 list<PosS>::NodePointer IndPosition=pos->GetFirst();
     double posi, oldposi; 
     while (IndPosition!=NULL)
	 {
	  posi=(pos->GetElement(IndPosition)).pos;
	  if (i>0 && posi==oldposi)
		  RepeatedPos[i]=true;
	  else RepeatedPos[i]=false;
	  oldposi=posi;
	  IndPosition=pos->GetNext(IndPosition);
	  i++;
	 }

DiplotypeList->Remove(p);	

}



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

void RepeatedGenotype::PrintGenotype(RepeatedPositions *pos)
{
  OrderSNPs(pos);

  PrintCompleteGenotype();
}

};  // End of Namespace

#endif

/* End of file: Genotype.h */




