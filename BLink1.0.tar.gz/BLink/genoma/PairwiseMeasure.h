/* File: PairwiseMeasure.h */


#ifndef __PairwiseMeasure_h__
#define __PairwiseMeasure_h__


#include "../commonc++/Sampling.cpp"

#include "GenotypeSample.cpp"

#include "TrioSample.h"


//using namespace stats;

namespace BIOS {


/************************/
/* SNP'S PairwiseMeasure DEFINITION */
/************************/


/**
        @memo PairwiseMeasure for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	template <class T> class PairwiseMeasure {


protected:

    /** @name Implementation of class PairwiseMeasure
        @memo Private part.
    */

	  BayesType Bayes;

	  float alphaBayes;

	  IndCategory ic;

	  T * sample;

	  double nAB, nAb, naB, nab, totalknown, totalhaplotypes, nHH;

	  SNPPos SNP1, SNP2;

	  char *line;

	  bool missing, OnlyKnown;

	  float distance;

bool* Marked;

       
/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

    double GetnxyKnown(bool IsMajor1, bool IsMajor2);


	void CheckFrequency (double f, bool fa);


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on PairwiseMeasure 
        @memo Operations on a PairwiseMeasure 
    */
	PairwiseMeasure(SNPPos SNP1, SNPPos SNP2, T * samp, bool* Marked, IndCategory ic=everybody, BayesType  Bay=MLE, float alphaBayes=0, float distance=0.0, bool OnlyKnown=false);

	PairwiseMeasure(SNPPos SNP1, SNPPos SNP2, T * samp, IndCategory ic=everybody, BayesType  Bay=MLE, float alphaBayes=0.0, float distance=0.0, bool OnlyKnown=false);

	void set(SNPPos SNP1, SNPPos SNP2, T * samp, bool* Marked, IndCategory ic=everybody, BayesType  Bay=MLE, float alphaBayes=0.0, float distance=0.0, bool OnlyKnown=false);

	PairwiseMeasure(T * samp);

	~PairwiseMeasure()
	{
	zap(line);
	};

	double GetTotalUnKnown ();

	double GetTotalKnown();

	double GetTotalKnown(double nAB, double nAb, double naB, double nab);

	double GetfAB();

	double GetfABNoEM();

    double GetnA();

	double GetnB();
	
    double Getna();

	double Getnb();

	double GetfA();

	double GetfB();

	double GetnAB();

	double GetnAb();

	double GetnaB();
	
	double Getnab();

        int GetAllelePair();

	//IndPos SetBootstrapFrequenciesOld(double *DPrimeList, unsigned long int size);

	IndPos SetBootstrapFrequencies(double* AbsDPrimeList, unsigned long int size);

	IndPos SetBootstrapFrequenciesFast(double* AbsDPrimeList, unsigned long int size);

	void GetSampleFrequencies(IndPos & bnAB, IndPos & bnAb,IndPos & bnaB,IndPos & bnab);

	void SetDPrimeDistribution();

	void SetDDistribution();

	double GetMaxDPrime();

	double GetQuantileDPrime (float quantile);

	char* PrintHaplotypeFrequencies();

	//void InitializeMarkers();

	void SetCounters();


};  // End of class PairwiseMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////
/*_________________________________________________________________*/

template <class T> PairwiseMeasure<T>::PairwiseMeasure(SNPPos S1, SNPPos S2, T * samp, bool* Marked, IndCategory i, BayesType Bay, float alphaBayes, float dist, bool OnlyK)
{
set (S1, S2, samp, Marked, i, Bay, alphaBayes, dist, OnlyK);
}

/*_________________________________________________________________*/

template <class T> PairwiseMeasure<T>::PairwiseMeasure(SNPPos S1, SNPPos S2, T * samp, IndCategory i, BayesType Bay, float alphaBayes, float dist, bool OnlyK)
{
set (S1, S2, samp, NULL, i, Bay, alphaBayes, dist, OnlyK);
}

/*_________________________________________________________________*/

template <class T> void PairwiseMeasure<T>::set(SNPPos S1, SNPPos S2, T * samp, bool* Marked, IndCategory i, BayesType Bay, float alphaBayes, float dist, bool OnlyK)
{
this->Marked=Marked;
	SNP1=S1;
	SNP2=S2;
	sample=samp; 
	Bayes=Bay; 
	this->alphaBayes=alphaBayes;
	ic=i; 
	missing=false;
	distance=dist;
	OnlyKnown=OnlyK;
	line=NULL;

	SetCounters();

        double nA=nAB+nAb+nHH;
	double nB=nAB+naB+nHH;

	double MLfA=nA/(nA+naB+nab+nHH);
	double MLfB=nB/(nB+nAb+nab+nHH);
 
	nAB=AddBayesHap(nAB, Bayes, distance, 0, MLfA, MLfB, alphaBayes);
	nAb=AddBayesHap(nAb, Bayes, distance, 1, MLfA, MLfB, alphaBayes);
	naB=AddBayesHap(naB, Bayes, distance, 2, MLfA, MLfB, alphaBayes);
	nab=AddBayesHap(nab, Bayes, distance, 3, MLfA, MLfB, alphaBayes);
	nA=nAB+nAb+nHH;
	nB=nAB+naB+nHH;
	totalknown=nAB+nAb+naB+nab;
	totalhaplotypes=totalknown+2*nHH;

	
	if ((nA/totalhaplotypes)<0.5)
	{
		change (nAb, nab);
		change (nAB, naB);
		nA=nAB+nAb+nHH;
	}

	if ((nB/totalhaplotypes)<0.5)
	{
		change (nAB, nAb);
		change (naB, nab);
		nB=nAB+naB+nHH;

	}

}


/*_________________________________________________________________*/

template <class T> void PairwiseMeasure<T>::SetCounters()
{

	
//exit(0);

	IndPos TotalInds=sample->GenotypeSample::GetSize();

	
 
 		
	if (sample->GenotypeSample::GetTotalMissing(SNP1, Marked)!=0 || sample->GenotypeSample::GetTotalMissing(SNP2, Marked)!=0)
	missing=true;

    nAB=sample->GenotypeSample::GetHap(SNP1, SNP2, true, true, Marked);
	nAb=sample->GenotypeSample::GetHap(SNP1, SNP2, true, false, Marked);
	naB=sample->GenotypeSample::GetHap(SNP1, SNP2, false, true, Marked);
	nab=sample->GenotypeSample::GetHap(SNP1, SNP2, false, false, Marked);

	if (!OnlyKnown)	nHH=sample->GenotypeSample::GetUnsolvedDoubleHeterozygous(SNP1, SNP2, Marked);
        else nHH=0;

  

}

/*____________________________________________________________ */


template<> void PairwiseMeasure<TrioSample>::SetCounters ()
{
	bool IsPartiallySolved=!OnlyKnown;
	
	if (sample->GetTotalMissing(SNP1, ic)!=0 || sample->GetTotalMissing(SNP2, ic)!=0) missing=true;


	
	nAB=sample->GetHap(SNP1, SNP2, ic, true, true, IsPartiallySolved);
	nAb=sample->GetHap(SNP1, SNP2, ic, true, false, IsPartiallySolved);
	naB=sample->GetHap(SNP1, SNP2, ic, false, true, IsPartiallySolved);
	nab=sample->GetHap(SNP1, SNP2, ic, false, false, IsPartiallySolved);

	nHH=sample->GetUnsolvedDoubleHeterozygous(SNP1, SNP2, ic, IsPartiallySolved);

  
}

/*____________________________________________________________ */

template <class T> void PairwiseMeasure<T>::CheckFrequency (double f, bool fa)
{

char message[100];

try
{

if (f==1.0 || f==0.0)
{
	 sprintf (message, "%s%d or %d", "PairwiseMeasure::CheckFrequency, SNP:", SNP1+1, SNP2+1);
	 cout <<PrintHaplotypeFrequencies();
     cout <<"nHH:" << nHH ;

	 throw NonSNP();
	 //
}

}

catch (NonSNP ns) { ns.PrintMessage(message);};

if (f<(0.5-zero))
{
	
if (fa)
sprintf(message, "%s is %0.4lf, ", " PairwiseMeasure::CheckFrequency of fA", f);
else
sprintf(message, "%s is %0.4lf, ", " PairwiseMeasure::CheckFrequency of fB", f);

cout <<"error, major allele should be minor allele between SNPs " << SNP1+1 << " and " << SNP2+1;
cout <<PrintHaplotypeFrequencies();
cout <<"nHH:" << nHH << message;
exit(0);

//return 1-f;
}
//else return f;


	
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnA ()
{


	return nAB+nAb+nHH;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::Getna ()
{


	return naB+nab+nHH;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnB ()
{


	return nAB+naB+nHH;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::Getnb ()
{


	return nAb+nab+nHH;
}

/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfA ()
{


	double den=GetTotalKnown()+(double)2*nHH;
	return GetnA()/den;


}


/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfB ()
{
	double den=GetTotalKnown()+(double)2*nHH;
	return GetnB()/den;


}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnAB ()
{
	return nAB;

}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnAb ()
{
	return nAb;

}/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnaB ()
{
	return naB;

}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::Getnab ()
{
	return nab;

}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetTotalKnown ()
{

return GetTotalKnown(nAB, nAb, naB, nab);			
}

/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetTotalKnown (double nAB, double nAb, double naB, double nab)
{

return (double) nAB+nAb+naB+nab;			
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetTotalUnKnown ()
{
return (double) nHH;			
}
/*____________________________________________________________ */

template <class T> char* PairwiseMeasure<T>::PrintHaplotypeFrequencies ()
{
	if (line==NULL)
	line=Initialize(50, ' ');
	//char *p=line;
	strcpy(line, "\0");
	sprintf(line, "nAB: %0.2f, nAb: %0.2f, naB: %0.2f, nab: %0.2f", nAB, nAb, naB, nab);
	return line;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfAB()
{
Table2x2 T2x2;

double fA=GetfA(), fB=GetfB(), totalknownBayes=GetTotalKnown();

if (fA==0  || fB==0){cout <<"error in PairwiseMeasure::getfAB"; exit(0);};


return T2x2.EstimateMLE (fA*fB, nHH, nAB, totalknownBayes, fA, fB, 1000);//fAB
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfABNoEM()
{
Table2x2 T2x2;

double fA=GetfA(), fB=GetfB(), totalknownBayes=GetTotalKnown();

if (fA==0  || fB==0){cout <<"error in PairwiseMeasure::getfAB"; exit(0);};

return nAB/(double)totalknownBayes;
//return T2x2.EstimateMLE (fA*fB, 0, nAB, totalknownBayes, fA, fB, 1000);//fAB
}
/*____________________________________________________________ */

template <> IndPos PairwiseMeasure<TrioSample>::SetBootstrapFrequenciesFast(double* AbsDPrimeList, unsigned long int size)
{
Sampling * bootstrap=NULL;
Table2x2 T2x2;
IndPos Total=sample->GetTotalTrios(), totalused=0;
if (ic==parent) Total=Total*2;
if (ic==everybody) Total=Total*3;
//TrioSample* g=NULL;
double fA, fB, fAB;
InitializeList(AbsDPrimeList, size, (double)2.0);
PairwiseMeasure<TrioSample> *PM=NULL;

GenotypeCode ReducedGenotypes[Total], Boot[Total];
IndPos Counters[12];
InitializeList(Counters, (unsigned long int)12, (IndPos)0);
Genoma* G=NULL;
list<Trio>::NodePointer TrioPos=sample->TrioList->GetFirst();

IndPos i=0;

while (TrioPos!=NULL)
{
	
for (int m=0; m<=2; m++)
if (ic==(IndCategory)m || ic==everybody || (ic==parent && m<2))
{
 G=new Genoma(TrioPos->element, (IndCategory)m);
 ReducedGenotypes[i]=G->GetGenotypeCode(SNP1, SNP2, sample->MajorAllele);
 i++;
 zap(G);
}

 TrioPos=sample->TrioList->GetNext(TrioPos);
}
bool invertedA=false, invertedB=false;
IndPos na, nb, nA, nB;
for (int s=0; s<size;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();
for (IndPos i=0;i<Total;i++)
{
	Boot[i]=ReducedGenotypes[bootstrap->Pos[i]];
	Counters[(int)Boot[i]]++;
}
//typedef enum {Missing=0, ABAB=1, ABAb=2, ABaB=3, ABab=4, AbAb=5, AbaB=6, Abab=7, aBaB=8, aBab=9, abab=10, Unphased=11} GenotypeCode ; // 

nA=2*Counters[1]+2*Counters[2]+Counters[3]+Counters[4]+2*Counters[5]+Counters[6]+Counters[11];
na=Counters[3]+2*Counters[4]+Counters[6]+Counters[7]+2*Counters[8]+2*Counters[9]+2*Counters[10]+Counters[11];
if (na>nA) 
{
change(nA, na);
invertedA=true;
}

nB=2*Counters[1]+Counters[2]+2*Counters[3]+Counters[4]+Counters[6]+2*Counters[8]+Counters[9]+Counters[11];
nb=Counters[2]+Counters[4]+2*Counters[5]+Counters[6]+2*Counters[7]+Counters[9]+2*Counters[10]+Counters[11];
if (nb>nB) 
{
change(nB, nb);
invertedB=true;
}

if (!invertedA && !invertedB)
nAB=2*Counters[1]+Counters[2]+Counters[3]+Counters[4];
if (invertedA && !invertedB) // aB
nAB=Counters[3]+Counters[6]+2*Counters[8]+Counters[9];
if (!invertedA && invertedB) // Ab
nAB=Counters[2]+2*Counters[5]+Counters[6]+Counters[7];
if (!invertedA && !invertedB) // ab
nAB=Counters[4]+Counters[7]+Counters[9]+2*Counters[10];

nHH=Counters[12];

totalknown=nAB+nAb+naB+nab;
totalhaplotypes=totalknown+2*nHH;
fA=GetfA();
fB=GetfB();
fAB=GetfAB();

AbsDPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
zap(bootstrap);
} // for each boostrap sample
return totalused;
}





};  // End of Namespace

#endif

/* End of file: PairwiseMeasure.h */




