  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream.h>

//#include <individual.h>
//#include <string>
//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
#include <cstdio>//
#include <cmath>//

#include "genoma.h"
#include "PhaseResolver.h"
//#include "Tables2x2.h"


//using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//       typefile tf;

//IndCategory ic;

//using namespace std;
//using namespace string;

namespace SNP 
	 {



/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

void PhaseResolution(char *filename, unsigned int TotalSNPs, unsigned int Size, bool ExistPhenotype, IndCategory ic, 
					 unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance, float MAF, 
					 unsigned short int PhaseMode, short unsigned int ReduceSample, unsigned short int affected=1, bool OnlyU=false, bool Bayes=false, 
					 bool OutputWay=false)
{
char *filename2, *filename3, *filepos;
//strcpy(filename2, filename);
genoma *Sample, *PhasedSample;


 if ((filepos=new char[64])==NULL)
		 throw NoMemory();

  if ((filename2=new char[64])==NULL)
		 throw NoMemory();

    if ((filename3=new char[64])==NULL)
		 throw NoMemory();


	 strcpy (filepos, filename);
	 strtok(filepos, ".");
	 strcat (filepos, ".poo\0");

cout <<"Uploading file " << filename <<"...\n";


bool ComputeHaplotypes=false;


//if ((Sample = new genoma(filename, filepos, TotalSNPs, Size, true, ic))==NULL)
// throw NoMemory();


//Sample=new individual(TotalSNPs);
//if ((PhasedSample = new genoma(*Sample, ic))==NULL)
// throw NoMemory();


if ((PhasedSample = new genoma(filename, filepos, TotalSNPs, Size, ExistPhenotype, ic,  ComputeHaplotypes, (PhaseType)PhaseMode, MAF, affected, OnlyU, Bayes, OutputWay, ReduceSample))==NULL)
 throw NoMemory();

strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".dp\0", 4);//
strcpy (filename3, filename);
filename3=strtok(filename3, ".");
strncat(filename3, ".way\0", 4);//

PhasedSample->PrintDPrime(filename2, filename3); // OnlyU is only needed when UTSolved

strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".sw\0", 4);//
PhasedSample->PrintDPrimeSlidingWindows(filename2, SlideSize, SlideOverlap, MaxDistance);

//cout <<"Slide size:" << SlideSize <<", overlap:" << SlideOverlap <<", maxdistance:" << MaxDistance <<", MAP:" << MAP;
	
strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".sal\0", 4);//
PhasedSample->WriteResults(filename2);


strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".hap\0", 4);//
PhasedSample->WriteHaplotypes(filename2);


strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".SNPs\0", 4);//
PhasedSample->PrintSNPPositions(filename2);

}

}
/*****************/
/*          MAIN          */
/*****************/

using namespace SNP;


int main(int argc, char*argv[]) {

     if(argc<13)
     {
	cerr << "Error: you have to especify the following information:" << endl;
	cerr  << argv[0] << " <IndCategory (0:only parents/1: only children /2:all)>" 
			<< "<ReduceSample (1: all, 2: take 1 of each 2, 3: take 1 of each 3 ...)>" 
			<< "<PhaseMode>(0=Phased/1=random/2=order/3=TU/4=dHap)" 
			<< "<Phenotype (0=non-affected/1=all/2=affected)>" 
			<< "<Only untransmitted (0=false/1=true), applied only if ic=0 (parents)>" 
			<< "<Bayesian correction (0=false/1=true)>" 
			<< "<Output Way (0=false/1=true)>" 
			<< "<slide size>" << "<slide overlap>" << "<max distance>" << "<MAF>" << endl;
	exit(-1);
	}
     char* filename;
     char chromchar[3];
     if ((filename=new char[64])==NULL) throw NoMemory();
     strcpy(filename, "chromosome");   
     for (int chrom=1;xhrom<23;xhrom++)
     {
     gcvt((float)chrom, 2, chromchar);    
     strcat(filename, chromchar);
     strcat(filename, ".txt");
     unsigned int TotalSNPs=atoi(argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int IsPhenotype=atoi(argv[4]);
     IndCategory ic=(IndCategory) atoi(argv[5]);
     short unsigned int ReduceSample=atoi(argv[6]);

	 bool ExistPhenotype;

	 if (IsPhenotype==1)
		 ExistPhenotype=true;
	 else
		 ExistPhenotype=false;


		unsigned int PhaseMode=atoi(argv[7]);

		unsigned int SlideSize=1;
		unsigned int SlideOverlap=0;
		unsigned int MaxDistance=0;
		float MAP;


	 unsigned short int affected=atoi(argv[8]);
		
 unsigned short int OnlyU=0;

 if (ic==0) OnlyU=atoi(argv[9]);

 bool Bayes=false;

 if (atoi(argv[10])==1) Bayes=true;

  bool OutputWay=false;

 if (atoi(argv[11])==1) OutputWay=true;

	if (PhaseMode==3)
	 {
		 SlideSize=atoi(argv[12]);
		 SlideOverlap=atoi(argv[13]);
		 MaxDistance=atoi(argv[14]);
		 MAP=atof(argv[15]);
		 }
cout <<"Configuration: IsPhenotype=" << IsPhenotype << ", IndCategory: " << (int)ic << ", Method for phasing:" 
<< PhaseMode
<<", affected:" << affected <<", OnlyUntransmitted:" << OnlyU <<", Bayes correction:" << Bayes
<<" OutputWay:" << OutputWay <<"\n" ;

//if (
     try{                     
	 PhaseResolution(filename, TotalSNPs, TotalIndividuals, ExistPhenotype, ic, 
			 SlideSize, SlideOverlap, MaxDistance, MAP, PhaseMode, ReduceSample, affected, 
			 OnlyU, Bayes, OutputWay);
	}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (MonoAllelic ma) {
		 ma.PrintMessage();}
	 catch (NullValue nv) {
		 nv.PrintMessage();}
	 catch (ZeroValue zv) {
		 zv.PrintMessage();}
	 delete filename;

   return 0;

}





