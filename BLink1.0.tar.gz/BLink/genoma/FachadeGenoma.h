#ifndef __FachadeGenoma_h__ 
#define __FachadeGenoma_h__ 


#include "../commonc++/Fachade.h"


#include "Exceptions.h"
#include "SNP.cpp"
#include "SNPAfter.h"
#include "GenomaSample.cpp"
#include "Trio.cpp"
#include "CoupleGenotype.h"
#include "PairwiseMeasuresResults.h"
#include "TrioSample.h"
#endif
