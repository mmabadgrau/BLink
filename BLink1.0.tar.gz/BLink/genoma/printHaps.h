/*****************************************************/
void genoma::PrintDPrime (char* filename, char* filename2)
{
try
{
  OutputFile.open (filename, ofstream::out); //app
  if (OutputWay)
  OutputFile2.open (filename2, ofstream::out); //app
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
}

frequencies Frequencies;
sfrequencies Frequencies2, Frequencies3, Frequencies4;

double Pos, Pos2, probs[4];

 OutputFile 
	 << "First SNP" << "\t" <<  "Position"  << "\t" 
 	 << "Second SNP" << "\t" <<  "Position"  << "\t" 
	 << "n(A)" << "\t" 
	 << "n(a)" << "\t" 
 	 << "n(B)" << "\t" 
	 << "n(b)" << "\t" 
 	 << "n(a)n(b)" << "\t"
	 << "n(HH) (individuals)" << "\t";  

 // known haplotypes
 OutputFile 
	 << "n(AB)" << "\t" 
	 << "n(Ab)" << "\t" 
	 << "n(aB)" << "\t" 
	 << "n(ab)" << "\t"  
	 << "D for known phase" << "\t"
 	 << "max LD for known phase" << "\t" 
	 << "Dprime for known phase" <<"\t"
	 << "R2 for known phase" <<"\t";


 // infered haplotypes using families
OutputFile
	 << "n(AB) for infered phase from families" << "\t" 
	 << "n(Ab) for infered phase from families" << "\t" 
	 << "n(aB) for infered phase from families" << "\t" 
	 << "n(ab) for infered phase from families" << "\t"  
	 << "D for infered phase from families" << "\t"
 	 << "max LD for infered phase from families" << "\t" 
 	 << "Dprime for infered phase from families" <<"\t"
	 << "R2 for infered phase from families" <<"\t";

 OutputFile << "HH (individuals)??" << "\t";

// plus known

OutputFile
	 << "n(AB) for infered phase from families plus known" << "\t" 
	 << "n(Ab) for infered phase from families plus known" << "\t" 
	 << "n(aB) for infered phase from families plus known" << "\t" 
	 << "n(ab) for infered phase from families plus known" << "\t"  
	 << "D for for infered phase from families plus known" << "\t"
 	 << "max LD for infered phase from families plus known" << "\t" 
	 << "Dprime for infered phase from families plus known" <<"\t"
     << "R2 for infered phase from families plus known" <<"\t";

if (!OnlyU)
{
// infered haplotypes using EM after families
OutputFile
	 << "f(AB) for infered phase from families using EM afterwards" << "\t" 
	 << "f(Ab) for infered phase from families using EM afterwards" << "\t" 
	 << "f(aB) for infered phase from families using EM afterwards" << "\t" 
	 << "f(ab) for infered phase from families using EM afterwards" << "\t"  
	 << "D for infered phase from families using EM afterwards" << "\t"
 	 << "max LD for infered phase from families using EM afterwards" << "\t" 
	 << "Dprime for infered phase from families using EM afterwards" << "\t" 
	 << "R2 for infered phase from families using EM afterwards" <<"\t";

// plus known
OutputFile
	 << "f(AB) for known and infered phase from families using EM afterwards" << "\t" 
	 << "f(Ab) for known and infered phase from families using EM afterwards" << "\t" 
	 << "f(aB) for known and infered phase from families using EM afterwards" << "\t" 
	 << "f(ab) for known and infered phase from families using EM afterwards" << "\t"  
	 << "D for known and infered phase from families using EM afterwards" << "\t"
 	 << "max LD for known and infered phase from families using EM afterwards" << "\t" 
	 << "Dprime for known and infered phase from families using EM afterwards" << "\t" 
	 << "R2 for known and infered phase from families using EM afterwards" <<"\t";

// infered haplotypes using EM for all HH positions
OutputFile
 	 << "f(AB) for infered phase using EM" << "\t" 
	 << "f(Ab) for infered phase using EM" << "\t" 
	 << "f(aB) for infered phase using EM" << "\t" 
	 << "f(ab) for infered phase using EM" << "\t"  
	 << "D for infered phase using EM" << "\t"
 	 << "max LD for infered phase using EM" << "\t" 
 	 << "Dprime for infered phase using EM" << "\t" 
	 << "R2 for infered phase using EM" <<"\t";

// plus known
OutputFile
 	 << "f(AB) for infered phase using EM plus known" << "\t" 
	 << "f(Ab) for infered phase using EM plus known" << "\t" 
	 << "f(aB) for infered phase using EM plus known" << "\t" 
	 << "f(ab) for infered phase using EM plus known" << "\t"  
	 << "D for infered phase using EM plus known" << "\t"
 	 << "max LD for infered phase using EM plus known" << "\t" 
	 << "Dprime for infered phase using EM plus known" << "\t" 
	 << "R2 for infered phase using EM plus known" <<"\t";


// infered haplotypes using rLD max after families 

OutputFile
 	 << "n(AB) rLDmax for infered phase from families" << "\t" 
	 << "n(Ab) rLDmax for infered phase from families" << "\t" 
	 << "n(aB) rLDmax for infered phase from families" << "\t" 
	 << "n(ab) rLDmax for infered phase from families" << "\t"  
 	 << "rDMax for infered phase from families" << "\t"
  	 << "max rDmax for infered phase from families" << "\t" 
	 << "rDMaxprime for infered phase from families" << "\t" 
	 << "rR2max for infered phase from families" <<"\t";


// infered haplotypes using rLD max after families 
OutputFile
 	 << "n(AB) rLDmin for infered phase from families" << "\t" 
	 << "n(Ab) rLDmin for infered phase from families" << "\t" 
	 << "n(aB) rLDmin for infered phase from families" << "\t" 
	 << "n(ab) rLDmin for infered phase from families" << "\t"  
  	 << "rDMin for infered phase from families" << "\t"
	 << "max rDmin for infered phase from families" << "\t" 
 	 << "rDMinprime for infered phase from families" << "\t" 
 	 << "rR2min for infered phase from families" <<"\t";

//  plus known

OutputFile
 	 << "n(AB) rLDmax for infered phase from families plus known" << "\t" 
	 << "n(Ab) rLDmax for infered phase from families plus known" << "\t" 
	 << "n(aB) rLDmax for infered phase from families plus known" << "\t" 
	 << "n(ab) rLDmax for infered phase from families plus known" << "\t"  
 	 << "rDMax for infered phase from families plus known" << "\t"
 	 << "max rDmax for infered phase from families plus known" << "\t" 
 	 << "rDMaxprime for infered phase from families plus known" << "\t" 
	 << "rR2Dmax for infered phase from families plus known" <<"\t";

OutputFile
 	 << "n(AB) rLDmin for infered phase from families plus known" << "\t" 
	 << "n(Ab) rLDmin for infered phase from families plus known" << "\t" 
	 << "n(aB) rLDmin for infered phase from families plus known" << "\t" 
	 << "n(ab) rLDmin for infered phase from families plus known" << "\t"  
 	 << "max rDmin for infered phase from families plus known" << "\t" 
   	 << "rDMin for infered phase from families plus known" << "\t"
 	 << "rDMinprime for infered phase from families plus known" << "\t"
 	 << "rR2Min for infered phase from families plus known";
}
OutputFile <<"\n";

unsigned int SNP2;
bool found;
for (unsigned int SNP=0; SNP<(genotype::TotalSNPs-1);SNP++)
// if ((GetTotalFreqAllele(SNP, false,  (IndCategory)0)>=MAF) && (GetTotalFreqAllele(SNP, false,  (IndCategory)0)>0))
 {
 try
 {
 SNP2=SNP+1;
// found=false;
// do
// {
// if ((GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>=MAF) && (GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>0))
// {
// found=true;
  if (SNP%100==0)
  cout <<"\nsnp:" << SNP;
//cout <<" and " << SNP2;
 Pos=GetPosition(SNP);
 Pos2=GetPosition(SNP2);
 // Pos2=GetPosition(25);

 //cout <<"SNP:" << SNP <<",SNP2:" << SNP+1;
  SetFrequencies(Frequencies, SNP, SNP2); 
 // SetFrequencies(Frequencies, SNP, 25, MAF); 



 OutputFile 
	 << SNP+1 << "\t" <<  (unsigned int) Pos  << "\t" 
  << SNP2+1 << "\t" <<  (unsigned int) Pos2  << "\t" 
  //	 << 26 << "\t" <<  (unsigned int) Pos2  << "\t" 
   	 << GetTotalAllele(SNP, true, ic) << "\t" 
   	 << GetTotalAllele(SNP, false, ic) << "\t" 
   	 << GetTotalAllele(SNP2, true, ic) << "\t" 
  	 << GetTotalAllele(SNP2, false,  ic) << "\t" 

 	 << GetTotalAllele(SNP, false, ic)*GetTotalAllele(SNP2, false, ic) << "\t"
	 << Frequencies[4] << "\t";


 AdjustFrequencies(Known, Frequencies, Frequencies2);// known haplotypes
 PrintValues(Frequencies2, SNP,SNP2); 

 AdjustFrequencies(Infered, Frequencies, Frequencies2); // infered haplotypes using families
 PrintValues(Frequencies2, SNP,SNP2); 

 if (OutputWay) PrintWay (SNP2, Frequencies2);

 OutputFile << Frequencies[4]-Frequencies2[0]-Frequencies2[1] << "\t";

 AdjustFrequencies(Complete, Frequencies, Frequencies2);
 PrintValues(Frequencies, SNP,SNP2);// plus known

 if (!OnlyU)
 {
 bool EM=true; 
 AdjustFrequencies(Infered, Frequencies, Frequencies2, true);// infered haplotypes using EM after families Semi=true
 PrintValues(Frequencies2, SNP,SNP2, EM); 

 AdjustFrequencies(Complete, Frequencies, Frequencies2, true);// plus known
 PrintValues(Frequencies2, SNP, SNP2, EM); 

 AdjustFrequencies(Infered, Frequencies, Frequencies2, false); // infered haplotypes using EM for all HH positions
 PrintValues(Frequencies2, SNP,SNP2, EM); 

 AdjustFrequencies(Complete, Frequencies, Frequencies2, false);// plus known
 PrintValues(Frequencies2, SNP,SNP2, EM);
//
 AdjustFrequencies(Infered, Frequencies, Frequencies2, true); // Semi is true
 DistributeLDMax(Frequencies2, Frequencies3, Frequencies4);
 PrintValues(Frequencies3, Frequencies4, true, SumFreqs(Frequencies2)+Frequencies[4]*2, SNP,SNP2); // max infered haplotypes using rLD max after families 
 DistributeLDMin(Frequencies2, Frequencies3, Frequencies4);
 PrintValues(Frequencies3, Frequencies4, false, SumFreqs(Frequencies2)+Frequencies[4]*2, SNP,SNP2); // min  

 // infered haplotypes using rLD min after families 
 AdjustFrequencies(Complete, Frequencies, Frequencies2, true);
 DistributeLDMax(Frequencies2, Frequencies3, Frequencies4);
 PrintValues(Frequencies3, Frequencies4, true, SumFreqs(Frequencies2)+Frequencies[4]*2, SNP,SNP2); // plus known, max
 DistributeLDMin(Frequencies2, Frequencies3, Frequencies4);
 PrintValues(Frequencies3, Frequencies4, false, SumFreqs(Frequencies2)+Frequencies[4]*2, SNP,SNP2); // min
 
 }
 OutputFile <<"\n";

// } // if SNP2 is a real SNP
// SNP2++;
// } // end do
// while ((found==false) && (SNP2<genotype::TotalSNPs));
 } // end try


	 catch (NonSNP ns) {
		 ns.PrintMessage(SNP);}  
	 catch (OutOfRange ora) {
	 ora.PrintMessage(SNP);}

 
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise D has been saved in file " << filename <<"\n";
 
 OutputFile.close();
 if (OutputWay) 
 {
 OutputFile2.close();
 cout << "\nInformation about phase solution has been saved in file " << filename2 <<"\n";
 }
 
}
/*****************************************************/
void genoma::ComputeWindowsValues(unsigned int mini, position* i, unsigned int SNP, double Pos, 
								  unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance)
{
frequencies Frequencies;
sfrequencies Frequencies2, Frequencies3, Frequencies4;

position* j=i;
unsigned int LastComparison;
double probs[4];
bool Semi;

double total=0.0;
unsigned int comparisons=0, SNP1;

double 
MultiLDKnown=0.0,
MultiLDPrimeKnown=0.0,
MultiR2Known=0.0,
MultiLDFamilies=0.0,
MultiLDPrimeFamilies=0.0,
MultiR2Families=0.0,
MultiLDFamiliesAndKnown=0.0,
MultiLDPrimeFamiliesAndKnown=0.0,
MultiR2FamiliesAndKnown=0.0,
MultiLDEMafterfamilies=0.0,
MultiLDPrimeEMafterfamilies=0.0,
MultiR2EMafterfamilies=0.0,
MultiLDEMafterfamiliesAndKnown=0.0,
MultiLDPrimeEMafterfamiliesAndKnown=0.0,
MultiR2EMafterfamiliesAndKnown=0.0,
MultiLD=0.0,
MultiLDPrime=0.0,
MultiR2=0.0,
MultiLDAndKnown=0.0,
MultiLDPrimeAndKnown=0.0,
MultiR2AndKnown=0.0,
MultirLDMaxInfered=0.0,
MultiR2MaxInfered=0.0,
MultirLDMaxInferedAndKnown=0.0,
MultiR2MaxInferedAndKnown=0.0,
MultirLDMinInfered=0.0,
MultiR2MinInfered=0.0,
MultirLDMinInferedAndKnown=0.0,
MultiR2MinInferedAndKnown=0.0,
MultirLDPrimeMaxInfered=0.0,
MultirLDPrimeMaxInferedAndKnown=0.0,
MultirLDPrimeMinInfered=0.0,
MultirLDPrimeMinInferedAndKnown=0.0;


for (unsigned int SNP2=SNP+1; SNP2<=mini;SNP2++) // until the end of the windows
{
// if ((GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>=MAF) && (GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>0))
 {  	

   SNP1=SNP; 
   LastComparison=SNP2+positions::GetTotalSNPs(j, MaxDistance);

   LastComparison=min(LastComparison, mini);
   
   for (unsigned int SNP3=SNP2+1; SNP3<LastComparison;SNP3++) // until max distance allowed

 //  if ((GetTotalFreqAllele(SNP3, false,  (IndCategory)0)>=MAF) && (GetTotalFreqAllele(SNP3, false,  (IndCategory)0)>0))
   {

	    comparisons++;


	    SetFrequencies(Frequencies, SNP2, SNP3); 

        AdjustFrequencies(Known, Frequencies, Frequencies2); // known haplotypes 
		if (!MarginalIsZero(Frequencies2)) 
        { 
     	UseProbabilities(Frequencies2, &probs[0]);	    
        MultiLDKnown=MultiLDKnown+GetLD(probs);
        MultiLDPrimeKnown=MultiLDPrimeKnown+GetLDPrime(probs);
    	MultiR2Known=MultiR2Known+GetR2(probs, SNP2, SNP3);
		ComparisonsKnown++;
		}
		
        AdjustFrequencies(Infered, Frequencies, Frequencies2); // infered haplotypes using families
		if (!MarginalIsZero(Frequencies2)) 
		{
    	UseProbabilities(Frequencies2, &probs[0]);
		MultiLDFamilies=MultiLDFamilies+GetLD(probs);
        MultiLDPrimeFamilies=MultiLDPrimeFamilies+GetLDPrime(probs);
    	MultiR2Families=MultiR2Families+GetR2(probs, SNP2, SNP3);
		ComparisonsFamilies++;
		}
		
        AdjustFrequencies(Complete, Frequencies, Frequencies2); // plus known
    	if (!MarginalIsZero(Frequencies2)) 
		{
		UseProbabilities(Frequencies2, &probs[0]);
		MultiLDFamiliesAndKnown=MultiLDFamiliesAndKnown+GetLD(probs);
		MultiLDPrimeFamiliesAndKnown=MultiLDPrimeFamiliesAndKnown+GetLDPrime(probs);
    	MultiR2FamiliesAndKnown=MultiR2FamiliesAndKnown+GetR2(Frequencies2, SNP2, SNP3);
		ComparisonsFamiliesAndKnown++;
		}
		}
		if (!OnlyU)
		{
		Semi=true; // compute EM after solving the phase from families
        AdjustFrequencies(Infered, Frequencies, Frequencies2, Semi); // infered haplotypes using families and EM
    	if (!MarginalIsZero(Frequencies2)) 
        { 
		ResolvePhase(Frequencies2, &probs[0], SNP2, SNP3);
     	MultiLDEMafterfamilies=MultiLDEMafterfamilies+GetLD(probs);
		MultiLDPrimeEMafterfamilies=MultiLDPrimeEMafterfamilies+GetLDPrime(probs);
       	MultiR2EMafterfamilies=MultiR2EMafterfamilies+GetR2(probs, SNP2, SNP3);
		ComparisonsEMafterfamilies++;
		}
	
		AdjustFrequencies(Complete, Frequencies, Frequencies2, Semi); // plus known
    	if (!MarginalIsZero(Frequencies2)) 
        { 
		ResolvePhase(Frequencies2, &probs[0], SNP2, SNP3);
    	MultiLDEMafterfamiliesAndKnown=MultiLDEMafterfamiliesAndKnown+GetLD(probs);
    	MultiLDPrimeEMafterfamiliesAndKnown=MultiLDPrimeEMafterfamiliesAndKnown+GetLDPrime(probs);
       	MultiR2EMafterfamiliesAndKnown=MultiR2EMafterfamiliesAndKnown+GetR2(probs, SNP2, SNP3);
		ComparisonsEMafterfamiliesAndKnown++;
		}
		
		Semi=false;  //  compute EM for all HH positions
        AdjustFrequencies(Infered, Frequencies, Frequencies2, Semi); 
    	if (!MarginalIsZero(Frequencies2)) 
        { 
		ResolvePhase(Frequencies2, &probs[0], SNP2, SNP3);
     	MultiLD=MultiLD+GetLD(probs);
    	MultiLDPrime=MultiLDPrime+GetLDPrime(probs);
       	MultiR2=MultiR2+GetR2(probs, SNP2, SNP3);
		Comparisons1++;
		}
        
		AdjustFrequencies(Complete, Frequencies, Frequencies2, Semi); // plus known
    	if (!MarginalIsZero(Frequencies2)) 
        { 
		ResolvePhase(Frequencies2, &probs[0], SNP2, SNP3);
    	MultiLDAndKnown=MultiLDAndKnown+GetLD(probs);
    	MultiLDPrimeAndKnown=MultiLDPrimeAndKnown+GetLDPrime(probs);
    	MultiR2AndKnown=MultiR2AndKnown+GetR2(probs, SNP2, SNP3);
		ComparisonsAndKnown++;
		}
		Semi=true;
        AdjustFrequencies(Infered, Frequencies, Frequencies2, Semi); 
		DistributeLDMax(Frequencies2, Frequencies3, Frequencies4);
		total=0.0;
		for(int a=0;a<4;a++)
			total=total+Frequencies3[a];
		if (total>0.0)
		{
		if (GetLD(Frequencies3)>GetLD(Frequencies4))
		{
			MultirLDMaxInfered=MultirLDMaxInfered+GetLD(Frequencies3)/(double)total;
			MultiR2MaxInfered=MultiR2MaxInfered+GetR2(Frequencies3, SNP2, SNP3);
		}
		else
		{
			MultirLDMaxInfered=MultirLDMaxInfered+GetLD(Frequencies4)/(double)total;
			MultiR2MaxInfered=MultiR2MaxInfered+GetR2(Frequencies4, SNP2, SNP3);

		}
		if (GetLDPrime(Frequencies3)>GetLDPrime(Frequencies4))
			MultirLDPrimeMaxInfered=MultirLDPrimeMaxInfered+GetLDPrime(Frequencies3);
		else
			MultirLDPrimeMaxInfered=MultirLDPrimeMaxInfered+GetLDPrime(Frequencies4);

        DistributeLDMin(Frequencies2, Frequencies3, Frequencies4);
		total=0;
		for(int a=0;a<4;a++)
			total=total+Frequencies3[a];
		if (GetLD(Frequencies3)<GetLD(Frequencies4))
		{
			MultirLDMinInfered=MultirLDMinInfered+GetLD(Frequencies3)/(double)total;
	       	MultiR2MinInfered=MultiR2MinInfered+GetR2(Frequencies3, SNP2, SNP3);
		}
		else
		{
			MultirLDMinInfered=MultirLDMinInfered+GetLD(Frequencies4)/(double)total;
	       	MultiR2MinInfered=MultiR2MinInfered+GetR2(Frequencies4, SNP2, SNP3);
		}

		if (GetLDPrime(Frequencies3)<GetLDPrime(Frequencies4))
			MultirLDPrimeMinInfered=MultirLDPrimeMinInfered+GetLDPrime(Frequencies3);
		else
			MultirLDPrimeMinInfered=MultirLDPrimeMinInfered+GetLDPrime(Frequencies4);
		} // end total>0.0
		
		AdjustFrequencies(Complete, Frequencies, Frequencies2, Semi); 
		DistributeLDMax(Frequencies2, Frequencies3, Frequencies4);
		total=0.0;
		for(int a=0;a<4;a++)
			total=total+Frequencies3[a];
//		if (total==0.0)
//		{cout <<"Error4"; exit(0);}

		if (GetLD(Frequencies3)>GetLD(Frequencies4))
		{
    		MultirLDMaxInferedAndKnown=MultirLDMaxInferedAndKnown+GetLD(Frequencies3)/(double)total;
			MultiR2MaxInferedAndKnown=MultiR2MaxInferedAndKnown+GetR2(Frequencies3, SNP2, SNP3);
		}
		else
		{
    		MultirLDMaxInferedAndKnown=MultirLDMaxInferedAndKnown+GetLD(Frequencies4)/(double)total;
			MultiR2MaxInferedAndKnown=MultiR2MaxInferedAndKnown+GetR2(Frequencies4, SNP2, SNP3);
		}
		if (GetLDPrime(Frequencies3)>GetLDPrime(Frequencies4))
    		MultirLDPrimeMaxInferedAndKnown=MultirLDPrimeMaxInferedAndKnown+GetLDPrime(Frequencies3);
		else
    		MultirLDPrimeMaxInferedAndKnown=MultirLDPrimeMaxInferedAndKnown+GetLDPrime(Frequencies4);

		DistributeLDMin(Frequencies2, Frequencies3, Frequencies4);
		total=0;
		for(int a=0;a<4;a++)
			total=total+Frequencies3[a];
	//	if (total==0)
//		{cout <<"Error5"; exit(0);}
		if (GetLD(Frequencies3)<GetLD(Frequencies4))
		{
    		MultirLDMinInferedAndKnown=MultirLDMinInferedAndKnown+GetLD(Frequencies3)/(double)total;
                        MultiR2MinInferedAndKnown=MultiR2MinInferedAndKnown+GetR2(Frequencies3, SNP2, SNP3);
		}
		else
		{
    		MultirLDMinInferedAndKnown=MultirLDMinInferedAndKnown+GetLD(Frequencies4)/(double)total;
                        MultiR2MinInferedAndKnown=MultiR2MinInferedAndKnown+GetR2(Frequencies4, SNP2, SNP3);
		}
		if (GetLDPrime(Frequencies3)<GetLDPrime(Frequencies4))
    		MultirLDPrimeMinInferedAndKnown=MultirLDPrimeMinInferedAndKnown+GetLDPrime(Frequencies3);
		else
    		MultirLDPrimeMinInferedAndKnown=MultirLDPrimeMinInferedAndKnown+GetLDPrime(Frequencies4);
		} // end !OnlyU
		//	cout <<", M:" << MultiLD;


   } // end for each SNP3 with freq>MAF
 } // end if freq>MAF
 j=positions::GetNext(j);
} // end for each SNP2

 if (comparisons1>0)
 {
 OutputFile << SNP+1 << "\t" <<  Pos 
	 << "\t" << comparisons1
 	 << "\t" << MultiLDKnown/(double)(comparisonsKnown) 
	 << "\t" << MultiLDPrimeKnown/(double)(comparisonsKnown) 
	 << "\t" << MultiR2Known/(double)(comparisonsKnown) 
  	 << "\t" << MultiLDFamilies/(double)(comparisonsFamilies) 
 	 << "\t" << MultiLDPrimeFamilies/(double)(comparisonsFamilies) 
 	 << "\t" << MultiR2Families/(double)(comparisonsFamilies) 
 	 << "\t" << MultiLDFamiliesAndKnown/(double)(comparisonsFamiliesAndKnown) 
	 << "\t" << MultiLDPrimeFamiliesAndKnown/(double)(comparisonsFamiliesAndKnown) 
  	 << "\t" << MultiR2FamiliesAndKnown/(double)(comparisonsFamiliesAndKnown);
 cout << SNP1+1 << "\n";
 }
 if (!OnlyU)
	 OutputFile
 	 << "\t" << MultiLDEMafterfamilies/(double)(comparisonsafterfamilies)
	 << "\t" << MultiLDPrimeEMafterfamilies/(double)(comparisonsafterfamilies)
	 << "\t" << MultiR2EMafterfamilies/(double)(comparisonsafterfamilies)
 	 << "\t" << MultiLDEMafterfamiliesAndKnown/(double)(comparisonsafterfamiliesAndKnown)
	 << "\t" << MultiLDPrimeEMafterfamiliesAndKnown/(double)(comparisonsafterfamiliesAndKnown)
	 << "\t" << MultiR2EMafterfamiliesAndKnown/(double)(comparisonsafterfamiliesAndKnown)
 	 << "\t" << MultiLD/(double)(comparisons1)
	 << "\t" << MultiLDPrime/(double)(comparisons1)
  	 << "\t" << MultiR2/(double)(comparisons1)
 	 << "\t" << MultiLDAndKnown/(double)(comparisonsAndKnown)
	 << "\t" << MultiLDPrimeAndKnown/(double)(comparisonsAndKnown)
 	 << "\t" << MultiR2AndKnown/(double)(comparisonsAndKnown)
 	 << "\t" << MultirLDMaxInfered/(double)(comparisons)
 	 << "\t" << MultirLDMaxInferedAndKnown/(double)(comparisons)
	 << "\t" << MultirLDMinInfered/(double)(comparisons) 
	 << "\t" << MultirLDMinInferedAndKnown/(double)(comparisons) 
	 << "\t" << MultirLDPrimeMaxInfered/(double)(comparisons)
  	 << "\t" << MultirLDPrimeMaxInferedAndKnown/(double)(comparisons)
	 << "\t" << MultirLDPrimeMinInfered/(double)(comparisons) 
	 << "\t" << MultirLDPrimeMinInferedAndKnown/(double)(comparisons);

 OutputFile <<"\n";

}
