rm(list=ls())
#############################################################
################## Function GetErrorProb ####################
#############################################################
# It checks if a value can be a probability
GetErrorProb<-function (prob) 
{
ifelse ((prob<0 || prob >1), FALSE, TRUE)
}
#############################################################
################## Function GetMLDPrime #####################
#############################################################
# It computes the real ML estimator of signed DPrime

GetMLDPrime2<-function(VectorGenotypes, Method, BayesType,TrueMAF, TrueMAFa, TrueMAFb, TrueD, EM) 
{
DPrimeVector<-c(0.01*-100:100)
frequency<-c(0*-100:100)
MaxFrequency=0
Max=0

if (EM==FALSE)
{
nAB=2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]+VectorGenotypes[4]
nAb=VectorGenotypes[2]+2*VectorGenotypes[5]+VectorGenotypes[6]+VectorGenotypes[7]
naB=VectorGenotypes[3]+VectorGenotypes[6]+2*VectorGenotypes[8]+VectorGenotypes[9]
nab=VectorGenotypes[4]+VectorGenotypes[7]+VectorGenotypes[9]+2*VectorGenotypes[10]
} 
else
{
nAB=2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]
nAb=VectorGenotypes[2]+2*VectorGenotypes[5]+VectorGenotypes[7]
naB=VectorGenotypes[3]+2*VectorGenotypes[8]+VectorGenotypes[9]
nab=VectorGenotypes[7]+VectorGenotypes[9]+2*VectorGenotypes[10]
} 

if (TrueD>0) 
{
ini=101
end=length(DPrimeVector)
} else
{
ini=1
end=101
}

for (i in ini:end)
{
fA=1-TrueMAFa #GetfA(VectorGenotypes,Method, BayesType,TrueMAF)
fB=1-TrueMAFb #GetfB(VectorGenotypes,Method, BayesType,TrueMAF)
#write(Method,"")
#stop()
# case fAB>fAfB
if (DPrimeVector[i]>=0)
DMax=min(fA*(1-fB), (1-fA)*fB)
else
DMax=-min(fA*fB, (1-fA)*(1-fB))
D=DPrimeVector[i]*DMax
fAB=D+fA*fB
fAb=fA-fAB
faB=fB-fAB
fab=1-fAB-fAb-faB


if (EM==TRUE)
frequency[i]=(fAB^nAB)*(fAb^nAb)*(faB^naB)*(fab^nab)*((fAB*fab+fAb*faB)^(VectorGenotypes[4]+VectorGenotypes[6]))
else frequency[i]=(fAB^nAB)*(fAb^nAb)*(faB^naB)*(fab^nab)

if (frequency[i]>=MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
}
}
#write(frequency,"")
DPrime<-DPrimeVector[Max]
}
#############################################################
################## Function GetMLDPrime #####################
#############################################################
# It computes the real ML estimator of DPrime
# TrueD is not used
GetMLDPrime<-function(VectorGenotypes, Method, BayesType,TrueMAF, TrueMAFa, TrueMAFb, TrueD, EM) 
{
DPrimeVector<-c(0.01*-100:100)
#frequency<-c(0*-100:100)
frequency<-c(1:201)*0
MaxFrequency=-Inf
Max=0

fA=GetfA(VectorGenotypes,Method, BayesType,TrueMAF, TrueMAFa, TrueMAFb) #1-TrueMAFa
fB=GetfB(VectorGenotypes,Method, BayesType,TrueMAF, TrueMAFa, TrueMAFb) #1-TrueMAFb


if (EM==FALSE)
total <- sum(VectorGenotypes)
else 
total <- (sum(VectorGenotypes)-VectorGenotypes[4]-VectorGenotypes[6])*2

if (Method==Bayes) total <- total+alpha

if (EM==FALSE)
{
nAB<-GetfAB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)*total
nAb<-fA*total-nAB
naB<-fB*total-nAB
} 
else
{
nAB=GetnAB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb); 
nAb=GetnA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)-nAB
naB=GetnB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)-nAB
} 
nab<-total-nAB-nAb-naB

if (fA==1 || fB==1) stop("si")
for (i in 1:length(DPrimeVector))
{
#write(Method,"")
#stop()
# case fAB>fAfB
if (DPrimeVector[i]>=0)
DMax=min(fA*(1-fB), (1-fA)*fB)
else
DMax=min(fA*fB, (1-fA)*(1-fB))
D=DPrimeVector[i]*DMax
fAB=D+fA*fB
if (abs(fA-fAB)<zero) fAb=0
else fAb=fA-fAB
if (abs(fB-fAB)<zero) faB=0
else faB=fB-fAB
if (abs(1-fAB-fAb-faB)<zero) fab=0
else fab=1-fAB-fAb-faB

#if (fAB>=0 && fAb>=0 && faB>=0 && fab>=0)
{
frequency[i]=0
#write(fA,"")
#write(fB,"")

#write(nAB,"")
#write(nAb,"")
#write(naB,"")
#write(nab,"")
#write(fAB,"")
#write(fAb,"")
#write(faB,"")
#write(fab,"")

#write(D,"")
#write(DMax,"")
#write(DPrimeVector[i],"")

if (nAB>0) frequency[i]=frequency[i]+nAB*log(fAB)
#write(frequency[i], "")
#write(fAB,"")

if (nAb>0) frequency[i]=frequency[i]+nAb*log(fAb)
#write(frequency[i], "")
#write(fAb,"")
if (naB>0) frequency[i]=frequency[i]+naB*log(faB)
#write(frequency[i], "")
#write(faB,"")

if (nab>0) frequency[i]=frequency[i]+nab*log(fab)
#write(frequency[i], "")
#write(fab,"")

#frequency[i]=nAB*log(fAB)+nAb*log(fAb)+naB*log(faB)+nab*log(fab)
#write(frequency[i],"")
if (EM==TRUE)
frequency[i]=frequency[i]+(VectorGenotypes[4]+VectorGenotypes[6])*log(fAB*fab+fAb*faB)
#write(frequency[i], "")
if (frequency[i]>=MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
}

#write(paste (DPrimeVector[i], ", ",frequency[i]),"")
if (DPrimeVector[i]==2)#never occur

if (DPrimeVector[i]==-1 || DPrimeVector[i]==1 || DPrimeVector[i]==0)#never occur
{
write (i,"")
write(fAB,"")
write(fAb,"")
write(faB,"")
write(fab,"")
write(frequency[i],"")
write(nAB,"")
write(nAb,"")
write(naB,"")
write(nab,"")
write(fA,"")
write(fB,"")
plot(DPrimeVector, frequency)
write(Max,"")
if (DPrimeVector[i]==1) 
stop()
}

}
}
DPrime<-DPrimeVector[Max]
#write(DPrime,"")
DPrime
}
#############################################################
################## Function GetMLDPrime #####################
#############################################################
# It computes the real ML estimator of DPrime

GetMLDPrime2<-function(VectorGenotypes, Method, BayesType,TrueMAF) 
{
DPrimeVector<-c(0.01*0:100)
frequency<-c(0*0:100)
MaxFrequency=0
Max=0
for (i in 1:length(DPrimeVector))
{
fA=GetfA(VectorGenotypes,Method, BayesType,TrueMAF)
fB=GetfB(VectorGenotypes,Method, BayesType,TrueMAF)
#write(Method,"")
#stop()
# case fAB>fAfB
DMax=min(fA*(1-fB), (1-fA)*fB)
D=DPrimeVector[i]*DMax
if (D<=(DMax+zero))
{
fAB=D+fA*fB
fAb=fA-fAB
faB=fB-fAB
fab=1-fAB-fAb-faB
} else stop("error en positive DPrime, likelihood, DPrime:")

# case fAB<fAfB
DMax2=-min(fA*fB, (1-fA)*(1-fB))
D2=DPrimeVector[i]*DMax2
if (D2>=(DMax2+zero))
{
f2AB=D2+fA*fB
f2Ab=fA-f2AB
f2aB=fB-f2AB

f2ab=1-f2AB-f2Ab-f2aB
}
if ((D2<(DMax2+zero)) || f2AB==fAB)
{
f2AB=0
f2Ab=0
f2aB=0
f2ab=0
}
nAB=2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]+VectorGenotypes[4]
nAb=VectorGenotypes[2]+2*VectorGenotypes[5]+VectorGenotypes[6]+VectorGenotypes[7]
naB=VectorGenotypes[3]+VectorGenotypes[6]+2*VectorGenotypes[8]+VectorGenotypes[9]
nab=VectorGenotypes[4]+VectorGenotypes[7]+VectorGenotypes[9]+2*VectorGenotypes[10]

frequency[i]=(fAB^nAB)*(fAb^nAb)*(faB^naB)*(fab^nab)*((fAB*fab+fAb*faB)^(VectorGenotypes[4]+VectorGenotypes[5]))+(f2AB^nAB)*(f2Ab^nAb)*(f2aB^naB)*(f2ab^nab)*((f2AB*f2ab+f2Ab*f2aB)^(VectorGenotypes[4]+VectorGenotypes[5]));
if (frequency[i]>=MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
}
}
#write(frequency,"")
DPrime<-DPrimeVector[Max]
DPrime
}
#############################################################
################## Function GetDMax #########################
#############################################################
# It computes DMax given p(a), (called MAFa, minor allele frequency locus a),
# p(b) (called MAFb, minor allele frequency for locus b) and
# signed DPrime or D (only the sign is used, so it does not matter if we five
# signed DPrime or D. 
# This function will be used to compute population DMax or sample DMax.
# Usually DMax is computed using estimations from sample for
# MAFa, MAFb and D, in order to compute an estimation of DPrime from the sample.
# In this program this function is also used to compute (TRUE) population
# DMax, considering that we know (TRUE) population DPrime, p(a) and p(b).
# With population DMax later we will be able to obtain population D.maxPositiveD1-,maxPositiveD2)

GetDMax<-function(DOrSignedDPrime, MAFa, MAFb, TrueMAFa, TrueMAFb, IsU, Method, BayesType, SampleSize, TrueMAF) 
{
GetErrorProb(MAFa) 
GetErrorProb(MAFb) 
{
if(TrueMAF)
if (IsU==FALSE)
ifelse(DOrSignedDPrime<0,min(TrueMAFa*TrueMAFb,(1-TrueMAFa)*(1-TrueMAFb)),min(TrueMAFa*(1-TrueMAFb),(1-TrueMAFa)*TrueMAFb))
else 
min(TrueMAFa*(1-TrueMAFb),(1-TrueMAFa)*TrueMAFb)

else # if !TrueMAF
{
if (
   (LocusIsInverted(MAFa, TrueMAFa) && 
    LocusIsInverted(MAFb, TrueMAFb))
||
   (!LocusIsInverted(MAFa, TrueMAFa) && 
    !LocusIsInverted(MAFb, TrueMAFb))
	)
if (IsU==FALSE)
ifelse(DOrSignedDPrime<0,min(MAFa*MAFb,(1-MAFa)*(1-MAFb)),min(MAFa*(1-MAFb),(1-MAFa)*MAFb))
else min(MAFa*(1-MAFb),(1-MAFa)*MAFb)
else # only one is inverted
if (IsU==FALSE)
ifelse(DOrSignedDPrime>0,min(MAFa*MAFb,(1-MAFa)*(1-MAFb)),min(MAFa*(1-MAFb),(1-MAFa)*MAFb))
else min(MAFa*MAFb,(1-MAFa)*(1-MAFb))
}
}
}
#############################################################
################## Function GetMinU ########################
#############################################################
# It computes MinU, the minimum value of U (negative value)
GetMinU<-function(PosMAFa, PosMAFb, TrueMAF)
{
D<- GetDMax(-1,Population.VectorMAFa[PosMAFa],Population.VectorMAFb[PosMAFb], Population.VectorMAFa[PosMAFa],Population.VectorMAFb[PosMAFb], FALSE, MLE, 0, 0, TrueMAF)# it computes the minimum U
MinU<- D/GetDMax(-1,Population.VectorMAFa[PosMAFa],Population.VectorMAFb[PosMAFb], Population.VectorMAFa[PosMAFa],Population.VectorMAFb[PosMAFb], TRUE, MLE, 0, 0, TrueMAF)# it computes the - maximum D.
-MinU
}
#############################################################
################## Function GetTrueD ########################
#############################################################
# It computes population D for each MAFa in vector VectorMAFa, each MAFb in vector VectorMAFb and 
# each DPrime in vector VectorDPrime, considering that DPrime=D/DMax
# Results are written in VectorD. 
GetTrueD<-function(VectorDPrime,VectorMAFa, VectorMAFb, IsU, TrueMAF)
{
ArrayD<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorDPrime)))*0
dim(ArrayD)<-c(length(VectorMAFa),length(VectorMAFb),length(VectorDPrime))
for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorDPrime))
# if (!	IsU || GetMinU(i,j, TrueMAF)<VectorDPrime[k])
 ArrayD[i,j,k]<-VectorDPrime[k]*GetDMax(VectorDPrime[k],VectorMAFa[i],VectorMAFb[j], VectorMAFa[i],VectorMAFb[j], IsU, 0, 0, 0, TrueMAF)
ArrayD 
}
#############################################################
################## Function GetTruefAB ########################
#############################################################
# It computes population DfABfor each MAFa in vector VectorMAFa, each MAFb in vector VectorMAFb and 
# each DPrime in vector VectorDPrime, considering that DPrime=D/DMax
# Results are written in VectorD. 
GetTruefAB<-function(VectorD,VectorMAFa, VectorMAFb)
{
ArrayfAB<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorD[1,1,])))*0
dim(ArrayfAB)<-c(length(VectorMAFa),length(VectorMAFb),length(VectorD[1,1,]))
for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorD[1,1,]))
{
 ArrayfAB[i,j,k]<-VectorD[i,j,k]+(1-VectorMAFa[i])*(1-VectorMAFb[j])
 GetErrorProb(ArrayfAB[i,j,k])
 }
ArrayfAB
}
#############################################################
################## Function GetTrueU ########################
#############################################################
# It computes population U for each MAFa in vector VectorMAFa, each MAFb in vector VectorMAFb and 
# each DPrime in vector VectorDPrime, considering that DPrime=D/DMax
# Results are written in VectorD.
GetTrueU<-function(VectorD,VectorDPrime, VectorMAFa, VectorMAFb, TrueMAF)
{
ArrayU<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorDPrime)))*0
dim(ArrayU)<-c(length(VectorMAFa),length(VectorMAFb),length(VectorDPrime))
for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorDPrime))
 ArrayU[i,j,k]<-VectorD[i,j,k]/GetDMax(VectorD[i,j,k],VectorMAFa[i],VectorMAFb[j], VectorMAFa[i],VectorMAFb[j], TRUE, 0, 0, 0, TrueMAF)
ArrayU
}
#############################################################
################## Function GetTrueR ########################
#############################################################
# It computes population R for each MAFa in vector VectorMAFa, each MAFb in vector VectorMAFb and 
# each DPrime in vector VectorDPrime, considering that DPrime=D/DMax
# Results are written in VectorD.
GetTrueR<-function(VectorD,VectorMAFa, VectorMAFb)
{
ArrayR<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(Population.VectorDPrime)))*0
dim(ArrayR)<-c(length(VectorMAFa),length(VectorMAFb),length(Population.VectorDPrime))
for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(Population.VectorDPrime))
 ArrayR[i,j,k]<-VectorD[i,j,k]/sqrt(VectorMAFa[i]*VectorMAFb[j]*
 (1-VectorMAFa[i])*(1-VectorMAFb[j]))
ArrayR 
}

#############################################################
################## Function GetTrueHaps #####################
#############################################################
# It computes p(AB),p(Ab),p(aB),p(ab) using population allele
# frequencies for loci a and b and D, considering that 
# p(AB)=D-p(A)p(B), p(Ab)=p(A)-p(AB), p(aB)=p(B)-p(AB) 
# and p(ab)=1-p(AB)-p(Ab)-p(aB)
# Calculations are done for all D values in ArrayD returned by function GetTrueD
GetTrueHaps<-function (VectorDPrime, VectorMAFa, VectorMAFb, ArrayD, IsU, TrueMAF)
{
ArraypHaplotypes<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorDPrime)*4))*0
dim(ArraypHaplotypes)<-c(length(VectorMAFa),length(VectorMAFb), length(VectorDPrime), 4)

for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorDPrime))
 if (!IsU || GetMinU(i,j, TrueMAF)<VectorDPrime[k])
{
#// p(AB)
 ArraypHaplotypes[i,j,k,1]<-ArrayD[i,j,k]+(1-VectorMAFa[i])*(1-VectorMAFb[j])
 if (ArraypHaplotypes[i,j,k,1]<0)
 {
 write("Error, haplotype AB has frequency ","")
 stop(ArraypHaplotypes[i,j,k,1])
 }

#// p(Ab)
 ArraypHaplotypes[i,j,k,2]<-(1-VectorMAFa[i])-ArraypHaplotypes[i,j,k,1]
 if (ArraypHaplotypes[i,j,k,2]<0)
 {
 write("Error, haplotype Ab has frequency ","")
 stop(ArraypHaplotypes[i,j,k,2])
 }

#// p(aB)
 ArraypHaplotypes[i,j,k,3]<-(1-VectorMAFb[j])-ArraypHaplotypes[i,j,k,1]
 if (ArraypHaplotypes[i,j,k,3]<0)
 {
 write("Error, haplotype aB has frequency ","")
 stop(ArraypHaplotypes[i,j,k,3])
 }

#// p(ab)
ArraypHaplotypes[i,j,k,4]<-1-ArraypHaplotypes[i,j,k,1]-ArraypHaplotypes[i,j,k,2]-ArraypHaplotypes[i,j,k,3]
 if (ArraypHaplotypes[i,j,k,4]<0)
 {
 write("Error, haplotype ab has frequency ","")
 stop(ArraypHaplotypes[i,j,k,4])
 }


if (!GetErrorProb(sum(ArraypHaplotypes[i,j,k,])))
 stop("sum of haplotype probabilities different from 1")
}
ArraypHaplotypes 
}
#####################################################################
################## Function GetTrueGenotypes ########################
#####################################################################
# It computes the 10 (TotalGenotypes) values of population genotype probabilities 
# assuming 2-loci HWE
# given population haplotypes p(AB), p(Ab), p(aB) and p(ab).
# These 10 values are
# 1: p(AB/AB), 
# 2: p(AB/Ab),
# 3: p(AB/aB), 
# 4: p(AB/ab), 
# 5: p(Ab/Ab), 
# 6: p(Ab/aB), 
# 7: p(Ab/ab), 
# 8: p(aB/aB), 
# 9: p(aB/ab) and
# 10: p(ab/ab).
# The function compute genotypes for every set of p(AB), p(Ab), p(aB) and p(ab)
# in the array ArraypHaplotypes returned by function GetTrueHaps
GetTrueGenotypes<-function(VectorDPrime, VectorMAFa, VectorMAFb, ArrayD, ArraypHaplotypes, IsU)
{
ArraypGenotypes<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorDPrime)*TotalGenotypes))*0
dim(ArraypGenotypes)<-c(length(VectorMAFa),length(VectorMAFb),length(VectorDPrime),TotalGenotypes)

for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorDPrime))
 if (!IsU || GetMinU(i,j, TrueMAF)<VectorDPrime[k])

{
#// p(AB)(AB)
 ArraypGenotypes[i,j,k,1]<-ArraypHaplotypes[i,j,k,1]^2
#// p(AB)(Ab)
 ArraypGenotypes[i,j,k,2]<-2*ArraypHaplotypes[i,j,k,1]*ArraypHaplotypes[i,j,k,2]
#// p(AB)(aB)
 ArraypGenotypes[i,j,k,3]<-2*ArraypHaplotypes[i,j,k,1]*ArraypHaplotypes[i,j,k,3]
#// p(AB)(ab)
 ArraypGenotypes[i,j,k,4]<-2*ArraypHaplotypes[i,j,k,1]*ArraypHaplotypes[i,j,k,4]
#// p(Ab)(Ab)
 ArraypGenotypes[i,j,k,5]<-ArraypHaplotypes[i,j,k,2]^2
#// p(Ab)(aB)
 ArraypGenotypes[i,j,k,6]<-2*ArraypHaplotypes[i,j,k,2]*ArraypHaplotypes[i,j,k,3]
#// p(Ab)(ab)
 ArraypGenotypes[i,j,k,7]<-2*ArraypHaplotypes[i,j,k,2]*ArraypHaplotypes[i,j,k,4]
#// p(aB)(aB)
 ArraypGenotypes[i,j,k,8]<-ArraypHaplotypes[i,j,k,3]^2
#// p(aB)(ab)
 ArraypGenotypes[i,j,k,9]<-2*ArraypHaplotypes[i,j,k,3]*ArraypHaplotypes[i,j,k,4]
#// p(ab)(ab)
 ArraypGenotypes[i,j,k,10]<-ArraypHaplotypes[i,j,k,4]^2

if ((sum(ArraypGenotypes[i,j,k,])-1)>zero)
{
PrintGenotypes(ArraypGenotypes[i,j,k,])
stop(sum(ArraypGenotypes[i,j,k,]))
}

}

ArraypGenotypes
}
#######################################################
################## Function GetfA #####################
#######################################################
# It computes major allele frequency fA from a sample with the 10 values of
# genotype frequencies at VectorGenotype


GetfA<-function(VectorGenotype, Method, BayesType,TrueMAF, MAFa, MAFb) 
{
denominator<-2*sum(VectorGenotype)
if (!TrueMAF)
numerator<-max(2*VectorGenotype[1]+2*VectorGenotype[2]+2*VectorGenotype[5]+VectorGenotype[3]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[7],2*VectorGenotype[8]+2*VectorGenotype[9]+2*VectorGenotype[10]+VectorGenotype[3]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[7])
else
numerator<-MAFa*denominator
#numerator<-2*VectorGenotype[1]+2*VectorGenotype[2]+2*VectorGenotype[5]+VectorGenotype[3]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[7]
fA<-numerator/denominator
if (Method==Bayes) 
 denominator<-denominator+alpha
if (Method==Bayes && BayesType==Uniform)
numerator<-numerator+alpha/2
if (Method==Bayes && BayesType==Equilibrium)
numerator<-numerator+alpha*fA
#numerator<-numerator+alpha*(1-MAFa)
if (Method==Bayes && BayesType==MaxEntropy)
{
fB<-GetfB(VectorGenotype, MLE, BayesType,TrueMAF, MAFa, MAFb)
if (fA<=fB) #fA<fB so fAfb<fafB
 numerator<-numerator+2
else
 numerator<-numerator+4*fA
}
numerator/denominator
#1-MAFa
}
#######################################################
################## Function GetfB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# genotype frequencies at VectorGenotype


GetfB<-function(VectorGenotype, Method, BayesType, TrueMAF, MAFa, MAFb)
{
denominator<-2*sum(VectorGenotype)
if (!TrueMAF)
numerator<-max(2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8]+VectorGenotype[2]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[9], 2*VectorGenotype[5]+2*VectorGenotype[7]+2*VectorGenotype[10]+VectorGenotype[2]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[9])
else
numerator<-MAFb*denominator
#numerator<-2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8]+VectorGenotype[2]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[9]

fB<-numerator/denominator

if (Method==Bayes)
 denominator<-denominator+alpha

if (Method==Bayes && BayesType==Uniform)
numerator<-numerator+alpha/2


if (Method==Bayes && BayesType==Equilibrium)
 numerator<-numerator+fB*alpha
#numerator<-numerator+(1-MAFb)*alpha

if (Method==Bayes && BayesType==MaxEntropy)
{
fA<-GetfA(VectorGenotype, MLE, BayesType,TrueMAF, MAFa, MAFb)
if (fA>=fB) #fA>fB so fAfb>fafB
 numerator<-numerator+2
else
 numerator<-numerator+4*fB
}
numerator/denominator
#1-MAFb
}
#######################################################
################## Function LocusIsInverted #####################
#######################################################
# It returns true only if n(a)>n(A) for sample in VectorGenotype
LocusIsInverted<-function(MAF, trueMAF) 
{
IsInverted<-FALSE
if ((MAF>0.5 && trueMAF<0.5) || (MAF<0.5 && trueMAF>0.5))
IsInverted<-TRUE
IsInverted
}
#######################################################
################## Function LocusAIsInverted #####################
#######################################################
# It returns true only if n(a)>n(A) for sample in VectorGenotype
LocusAIsInverted<-function(VectorGenotype) 
{
IsInverted<-FALSE
if ((2*VectorGenotype[1]+2*VectorGenotype[2]+2*VectorGenotype[5]+VectorGenotype[3]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[7])<(2*VectorGenotype[8]+2*VectorGenotype[9]+2*VectorGenotype[10]+VectorGenotype[3]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[7]))
IsInverted<-TRUE
IsInverted
}
#######################################################
################## Function LocusBIsInverted #####################
#######################################################
# It returns true only if n(b)>n(b) for sample in VectorGenotype

LocusBIsInverted<-function(VectorGenotype) 
{
IsInverted<-FALSE
if ((2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8]+VectorGenotype[2]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[9])< (2*VectorGenotype[5]+2*VectorGenotype[7]+2*VectorGenotype[10]+VectorGenotype[2]+VectorGenotype[4]+VectorGenotype[6]+VectorGenotype[9]))
IsInverted<-TRUE
IsInverted
}
#######################################################
################## Function GetnAB ##################
#######################################################
# It computes nAB, i.e., the absolute frequency of haplotype AB from a population
# with genotype frequencies at VectorGenotypes, considering that 
# phase is unknown, so n(AB/ab)+n(Ab/ab) is VectorGenotypes[4]+VectorGenotypes[6]
# but neither n(AB/ab) or n(Ab/ab) is known.
# This function is used in this program when the EM algorithm is used to compute
# D values. 


GetnAB<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb) 
{
if (!TrueMAF)
{
if (!LocusAIsInverted(VectorGenotypes))
ifelse (!LocusBIsInverted(VectorGenotypes),
 result<-2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3],#AB
result<-2*VectorGenotypes[5]+VectorGenotypes[2]+VectorGenotypes[7]) #Ab
else
ifelse (!LocusBIsInverted(VectorGenotypes),
 result<-2*VectorGenotypes[8]+VectorGenotypes[3]+VectorGenotypes[9],#aB
 result<-2*VectorGenotypes[10]+VectorGenotypes[7]+VectorGenotypes[9]) #ab
}
else
result<-2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]
if (Method==Bayes && BayesType==Uniform)
 result<-result+alpha/4
if (Method==Bayes && BayesType==Equilibrium)
#result<-result+alpha*(1-MAFa)*(1-MAFb)
result<-result+alpha*GetfA(VectorGenotypes,Method, BayesType,TrueMAF, MAFa, MAFb)*GetfB(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
if (Method==Bayes && BayesType==LD)
{
fA<-GetfA(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
fB<-GetfB(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
if (fA*(1-fA)>(1-fA)*fB) result<-result+alpha*fB
else result<-result+alpha*fA
}
if (Method==Bayes && BayesType==MaxEntropy)
{
fB<-GetfB(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
fA<-GetfA(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
if (fA<=fB) #fA<fB so fAfb<fafB
 result<-result+alpha*fB/2
else
 result<-result+alpha*fA/2
}
result
}
#######################################################
################## Function GetnA ##################
#######################################################
# It computes nA, i.e., the absolute frequency of allele A from a population
# with genotype frequencies at VectorGenotypes, considering only 
# those individuals whose phase is unknown.
# This function is used in this program to compute MLDPrime when Phase for nHH individuals
# is not known


GetnA<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb) 
{
if (!TrueMAF)
{
if (!LocusAIsInverted(VectorGenotypes))
 result<-2*VectorGenotypes[1]+2*VectorGenotypes[2]+VectorGenotypes[3]+2*VectorGenotypes[5]+VectorGenotypes[7]#A
else
 result<-VectorGenotypes[3]+VectorGenotypes[7]+2*VectorGenotypes[8]+2*VectorGenotypes[9]+2*VectorGenotypes[10]#a
}
else
result<-2*VectorGenotypes[1]+2*VectorGenotypes[2]+VectorGenotypes[3]+2*VectorGenotypes[5]=VectorGenotypes[7]

if (Method==Bayes && BayesType==Uniform)
 result<-result+alpha/2
if (Method==Bayes && BayesType==Equilibrium)
result<-result+alpha*GetfA(VectorGenotypes,Method, BayesType,TrueMAF, MAFa, MAFb)
result
}
#######################################################
################## Function GetnB ##################
#######################################################
# It computes nA, i.e., the absolute frequency of allele B from a population
# with genotype frequencies at VectorGenotypes, considering only 
# those individuals whose phase is unknown.
# This function is used in this program to compute MLDPrime when Phase for nHH individuals
# is not known


GetnB<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb) 
{
if (!TrueMAF)
{
if (!LocusAIsInverted(VectorGenotypes))
 result<-2*VectorGenotypes[1]+2*VectorGenotypes[3]+VectorGenotypes[2]+2*VectorGenotypes[8]+VectorGenotypes[9]#B
else
 result<-VectorGenotypes[2]+VectorGenotypes[9]+2*VectorGenotypes[5]+2*VectorGenotypes[7]+2*VectorGenotypes[10]#b
}
else
 result<-2*VectorGenotypes[1]+2*VectorGenotypes[3]+VectorGenotypes[2]+2*VectorGenotypes[8]+VectorGenotypes[9]#B

if (Method==Bayes && BayesType==Uniform)
 result<-result+alpha/2
if (Method==Bayes && BayesType==Equilibrium)
result<-result+alpha*GetfB(VectorGenotypes,Method, BayesType,TrueMAF, MAFa, MAFb)
result
}
#######################################################
################## Function GetfAB ####################
#######################################################
# It computes sample relative frequency of haplotype AB, given (phased) genotypes for the
# sample in VectorGenotypes.

GetfAB<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb) 
{
if (!TrueMAF)
{
if (!LocusAIsInverted(VectorGenotypes))
ifelse (!LocusBIsInverted(VectorGenotypes),
 numerator<-2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]+VectorGenotypes[4],#AB
numerator<-2*VectorGenotypes[5]+VectorGenotypes[2]+VectorGenotypes[7]+VectorGenotypes[6]) #Ab
else
ifelse (!LocusBIsInverted(VectorGenotypes),
 numerator<-2*VectorGenotypes[8]+VectorGenotypes[3]+VectorGenotypes[9]+VectorGenotypes[6],#aB
numerator<-2*VectorGenotypes[10]+VectorGenotypes[7]+VectorGenotypes[9]+VectorGenotypes[4]) #ab
}
else
numerator<-2*VectorGenotypes[1]+VectorGenotypes[2]+VectorGenotypes[3]+VectorGenotypes[4] #AB


denominator<-2*sum(VectorGenotypes)
if (Method==Bayes) 
 denominator<-denominator+alpha
 
if (Method==Bayes && BayesType==Uniform)
 numerator<-numerator+alpha/4
if (Method==Bayes && BayesType==Equilibrium)
#numerator<-numerator+alpha*(1-MAFa)*(1-MAFb)
numerator<-numerator+alpha*GetfA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)*GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
if (Method==Bayes && BayesType==LD)
{
fA<-GetfA(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
fB<-GetfB(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
if (fA*(1-fA)>(1-fA)*fB)
 numerator<-numerator+alpha*fB
else
  numerator<-numerator+alpha*fA
}
if (Method==Bayes && BayesType==MaxEntropy)
{
fB<-GetfB(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
fA<-GetfA(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
if (fA<=fB) #fA<fB so fAfb<fafB
 numerator<-numerator+alpha*fB/2
else
 numerator<-numerator+alpha*fA/2
}
numerator/denominator
}

#######################################################
################## Function GetfAB2 ####################
#######################################################
# It computes sample relative frequency of haplotype AB, given (phased) genotypes for the
# sample in VectorGenotypes.


GetfAB2<-function(nAB, individuals, Method, BayesType, TrueMAF, MAFa, MAFb) 
{
numerator<-nAB
denominator<-2*individuals
if (Method==Bayes) 
 denominator<-denominator+alpha
 
if (Method==Bayes && BayesType==Uniform)
 numerator<-numerator+alpha/4
if (Method==Bayes && BayesType==Equilibrium)
#numerator<-numerator+alpha*(1-MAFa)*(1-MAFb)
numerator<-numerator+alpha*GetfA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)*GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
if (Method==Bayes && BayesType==LD)
{
fA<-GetfA(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
fB<-GetfB(VectorGenotypes,Method, BayesType, TrueMAF, MAFa, MAFb)
if (fA*(1-fA)>(1-fA)*fB)
 numerator<-numerator+alpha*fB
else
  numerator<-numerator+alpha*fA
}
if (Method==Bayes && BayesType==MaxEntropy)
{
fB<-GetfB(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
fA<-GetfA(VectorGenotypes, MLE, BayesType,TrueMAF, MAFa, MAFb)
if (fA<=fB) #fA<fB so fAfb<fafB
 numerator<-numerator+alpha*fB/2
else
 numerator<-numerator+alpha*fA/2
}
numerator/denominator
}
#######################################################
################## Function GetD ######################
#######################################################
# It estimates D from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# D is computed as Estf(AB)-Estf(A)*Estf(B)

GetD<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
 GetfAB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)-GetfA(VectorGenotypes, Method, BayesType,TrueMAF, MAFa, MAFb)*GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)

#######################################################
################## Function GetD2 ######################
#######################################################
# It estimates D from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# D is computed as Estf(AB)-fAfB

GetD2<-function(EstnAB, Individuals, Method, BayesType, TrueMAF, MAFa, MAFb)
 GetfAB2(EstnAB, Individuals, Method, BayesType, TrueMAF, MAFa, MAFb)-(1-MAFa)*(1-MAFb)

#######################################################
################## Function GetDEM ####################
#######################################################
# It computes D using EM algorithm to obtain the frequency for haplotype AB
# If a Bayesian method was used to compute haplotype frequencies for known
# phases, the number of known-phase instances used by the EM algorithm has to be changed.
# This number (in total) will be increased by alpha for uniform Bayesian method, and 
# by alpha/4 for reduced uniform or euqilibrium BayesType methods.
 
GetDEM<-function(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
{
total <- (sum(VectorGenotypes)-VectorGenotypes[4]-VectorGenotypes[6])*2
if (Method==Bayes)
 total <- total+alpha

nHH<-VectorGenotypes[4]+VectorGenotypes[6]
if(nHH>0)
{
fAB<-EstimateMLE(GetnAB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb),
nHH,
GetfA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)*(GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)),
total,
GetfA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb),
GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb))
fAb<-GetfA(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)-fAB
faB<-GetfB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)-fAB
fab<-1-fAB-fAb-faB
DEM<-fAB*fab-fAb*faB
}
else
DEM<-GetD(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
DEM
}
#######################################################
################## Function EstimateMLE ###############
#######################################################
# It computes relative frequency of haplotypes AB using EM algorithm.
# Input values are the number of AB haplotypes, in nABknown, the number
# of individuals heterozygotic at both loci, in nHH, non-phased relative frequency
# of haplotype AB in the sample, major allele frequency for locus a in the sample, fA
# and major allele frequency for locus a in the sample, fB.


EstimateMLE <-function(nABKnown, nHH, fAB, total, fA, fB)
{
first<-TRUE
fABNew<-fAB
loop<-1
first<-TRUE
while ((first==TRUE) || ((abs(fAB-fABNew)>0.00005) && (loop<=1000)))
{
first<-FALSE
fAB<-fABNew
fAb<-fA-fAB
faB<-fB-fAB
fab<-1-fAB-fAb-faB

denominator<-fAB*fab+fAb*faB

if (denominator==0) 
{
write (fAB, "")
write (fAb, "")
write (faB, "")
write (fab, "")
write (fA, "")
write (fB, "")  
write (total, "")
write (nABKnown, "")
write (nHH, "")
 stop ("denominator is zero")
 }
 
PhaseFrequencies<-(fAB*fab)/denominator
 

 fABNew<-(nABKnown+nHH*PhaseFrequencies)/(total+2*nHH) #// AB





# fAbNew<-fA-fABNew
# faBNew<-fB-fABNew
# fabNew<-1-fABNew-fAbNew-faBNew

# if ((1-fABNew-faBNew-fAbNew-fabNew)>0.0001) 
#         stop("e2")

loop<-loop+1
}
fABNew
}
#######################################################
################## Function GetPermutation ############
#######################################################
# This function is used for a permutation analysis method for bias correction.
# Given absolute frecuencies of Genotypes generated for a sample 
# (Genotypes has dimension[TotalGenotypes]) 
# the function computes a permutation for the sample assuming equilibrium (D'=0) 
# It means that no association has to be kept among loci. 
# So the algorithm just do common permutations.
GetPermutation<-function(Genotypes)
{
SampleSize<-sum(Genotypes)
# a and b have size double of the sample
# a is for locus a, b for locus b
# They represent the value of each pair of alleles (father and mother) for each individual.
# Double size is because it contains father and mother alleles.
# For each parent and each genotype, 1 is written if this genotype has the major allele for this parent
# and 2 if it has the minor allele.
# For example, Genotypes[1] represent the number of individuals in the sample with genotype
# AB/AB.
# It means that all of these individuals have father with the major allele at loci a and b. 
# The same for the mother.
# Values will be written in the suited positions of vectors a and b.
# Here we have the meaning of each configuration whose frequency is in Genotypes:
# 1: (AB/AB), 
# 2: (AB/Ab),
# 3: (AB/aB), 
# 4: (AB/ab), 
# 5: (Ab/Ab), 
# 6: (Ab/aB), 
# 7: (Ab/ab), 
# 8: (aB/aB), 
# 9: (aB/ab) and
# 10: (ab/ab).

      
  a<-(1:(SampleSize*2))*0
  b<-(1:(SampleSize*2))*0

   offset<-0
   for (g in 1:TotalGenotypes)
   {
   if (Genotypes[g]!=0)
   for (c in (1:Genotypes[g])*2) # 2, 4, 6, ... Genotype[g]
   {
   # write("valor de c","")
   # write(c, "")
   # locus a
    ifelse (g<=7, a[c-1+offset]<-1, a[c-1+offset]<-2) # major and minor alleles from the father
    ifelse ((g==1 ||g==2 || g==5), a[c+offset]<-1,  a[c+offset]<-2) # major and minor alleles from the mother
   # locus b
    ifelse ((g<=4 ||g==8 || g==9), b[c-1+offset]<-1,  b[c-1+offset]<-2) # major and minor alleles from the father
    ifelse ((g==1 || g==3 || g==6 || g==8), b[c+offset]<-1,  b[c+offset]<-2) # major and minor alleles from the mother
    }
    offset<-offset+Genotypes[g]*2
   }

                                                               
  # Make permutations
  PermutatedA<-sample(a)
  PermutatedB<-sample(b)

  #stop("")
  Permutation<-c(1:TotalGenotypes)*0
  for (pos in (1:SampleSize)*2)  # 2, 4, 6, ... SampleSize
  {
  if (PermutatedA[pos-1]==1 && PermutatedA[pos]==1 && PermutatedB[pos-1]==1 && PermutatedB[pos]==1) # AB/AB
   Permutation[1]<-Permutation[1]+1
  if (PermutatedA[pos-1]==1 && PermutatedA[pos]==1 && PermutatedB[pos-1]==2 && PermutatedB[pos]==2) # Ab/Ab ...
   Permutation[5]<-Permutation[5]+1
  if (PermutatedA[pos-1]==1 && PermutatedA[pos]==1 && PermutatedB[pos-1]!=PermutatedB[pos]) # AB/Ab or Ab/AB 
   Permutation[2]<-Permutation[2]+1
  if (PermutatedA[pos-1]==2 && PermutatedA[pos]==2 && PermutatedB[pos-1]==1 && PermutatedB[pos]==1) # aB/aB
   Permutation[8]<-Permutation[8]+1
  if (PermutatedA[pos-1]==2 && PermutatedA[pos]==2 && PermutatedB[pos-1]==2 && PermutatedB[pos]==2) # ab/ab
   Permutation[10]<-Permutation[10]+1
  if (PermutatedA[pos-1]==2 && PermutatedA[pos]==2 && PermutatedB[pos-1]!=PermutatedB[pos]) # aB/ab or ab/aB
   Permutation[9]<-Permutation[9]+1
  if (PermutatedA[pos-1]!=PermutatedA[pos] && PermutatedB[pos-1]==1 && PermutatedB[pos]==1) # AB/aB or aB/AB
   Permutation[3]<-Permutation[3]+1
  if (PermutatedA[pos-1]!=PermutatedA[pos] && PermutatedB[pos-1]==2 && PermutatedB[pos]==2) # Ab/ab or ab/Ab
   Permutation[7]<-Permutation[7]+1
  if (PermutatedA[pos-1]!=PermutatedA[pos] && PermutatedB[pos-1]!=PermutatedB[pos]) # Ab/aB or aB/Ab or AB/ab or ab/AB
   if (PermutatedA[pos]==PermutatedB[pos]) # AB/ab
    Permutation[4]<-Permutation[4]+1 
   else  # Ab/aB
    Permutation[6]<-Permutation[6]+1
  }
  if (sum(Permutation)!=SampleSize)
  stop ("Error in permutations")

  Permutation 
}

#######################################################
################## Function PrintGenotypes ############
#######################################################
# It prints genotype absolute frequencies in a sample.
# It was used only for testing.
PrintGenotypes<-function(VectorGenotypes)
{
for (i in 1:10)
 write (VectorGenotypes[i],"")
}
###############################################################################################
######################################### Main program ########################################
###############################################################################################

# INPUTS
# There are 2 input variables for this program: Method and BayesType.
# To do things easier for me, these 2 values are setting at the beginning of the main
# program, instead of supplying them as arguments to the program.
# Method can be: Lewontin (0), Bayes (1), Bootstrapping (2) and Permutation (3).
# Only when Method is Bayesian, the second input variable is used: BayesType.
# BayesType can be: Uniform (1), and Equilibrium (3).


# The program when Method is Lewontin does simulations computing standard DPrime.
# If Method is Bayes, it does Bayesian simulations in order to correct the bias.
# If is Bootstrapping, it does bootstrapping (Teare's paper) in order to correct the bias.
# If method is Permutation, it does permutation analysis in order to correct the bias.



# OUTPUTS
# 2 arrays: Simulations.ArrayMeanDPrime and Simulations.ArrayMeanDEMPrime.
# Regardless the input values, the program always does simulations for 
# each population DPrime from -1 to 1 in steps of 0.1 (in Population.VectorDPrime), 
# each MAF locus a in {0.05, 0.1, 0.25, 0.5} (in Population.VectorMAFa),
# each MAF locus b in {0.05, 0.1, 0.25, 0.5} (in Population.VectorMAFb) and
# each sample size in {10, 50, 100, 200, 500, 1000} individuals (in VectorSize).

# Dimensions of both output arrays are
# length(Population.VectorMAFa) x 
# length(Population.VectorMAFb) x 
# length(Population.VectorDPrime)) x
# length(VectorSize)

# Array Simulations.ArrayMeanDPrime contains the mean DPrime values for the 1000 
# sample simulations for each combination of population MAFa, MAFb, DPrime
# and sample size.
# For example, Simulations.MeanDprime[1,1,1,1] contains the mean DPrime of the
# 1000 DPrime values, one for each simulated (phased) sample, with all samples
# having the first value of MAFa (0.05), the first value of MAFb (0.05), the first
# value of DPrime (-1) and the first value of sample size (50).   

# Array Simulations.ArrayMeanDEMPrime is like Simulations.ArrayMeanDEMPrime but samples are
# non-phased and the EM algorithm is used to solve the phase.

genotypes<-0
binomial<-1
multinomial<-2
SimulationMode<-binomial
SimulationMode<-multinomial
SimulationMode<-genotypes

UseThreshold<-FALSE
MAFThreshold<-0


MLE<-0 # MLE estimation for Lewontin's D'
Bayes<-1
Bootstrapping<-2
Permutation<-3     
UCorrection<-4
# Here is where the first input variable is setting.
#  Method<-Permutation
# Method<-Bootstrapping
Method<-MLE
#Method<-UCorrection
#Method<-Bayes
Uniform<-1
Equilibrium<-3
LD<-4
MaxEntropy<-5

ifelse (Method==UCorrection, U<-TRUE, U<-FALSE)

TrueMAF<-TRUE # is true if allele frequencies in the samples are defined as in the population

# Here is where the second input variable is setting.
BayesType<-Uniform
#BayesType<-Equilibrium
#BayesType<-LD
#BayesType<-MaxEntropy
#memory.size(512)
alpha<-1

zero<-1e-10

# Initialization


# INFORMATION ABOUT POPULATIONS 

# there can be 10 different types of "phased" genotypes:
# AB/AB, AB/Ab, AB/aB, AB/ab, Ab/Ab, Ab/aB, Ab/ab, aB/aB, aB/ab, ab/ab
TotalGenotypes<-10 

# Population DPrime used to make simulations goes from -1 to 1 in steps of 0.1
Population.VectorDPrime<-c(0.1*-10:10)

# Population AbsDPrime used to make simulations goes from 0 to 1 in steps of 0.1
#Population.VectorAbsDPrime<-c(0.1*0:10)

# Population MAF locus a used to make simulations can be 0.05, 0.1, 0.25 or 0.5
Population.VectorMAFa<-c(0.05,0.1,0.25,0.5)
#Population.VectorMAFa<-c(0.25)

# Population MAF locus b used to make simulations can be 0.05, 0.1, 0.25 or 0.5
Population.VectorMAFb<-c(0.05,0.1,0.25,0.5)
#Population.VectorMAFb<-c(0.25)


# Population.ArrayD must have D true values for each combination of MAFa, MAFb and DPrime
Population.ArrayD<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)))*0
dim(Population.ArrayD)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime))
#U<-TRUE # to check true D versus mean sample U
Population.ArrayD<-GetTrueD(Population.VectorDPrime, Population.VectorMAFa, Population.VectorMAFb, U, TrueMAF)
#U<-FALSE # now TRUE to check true D versus mean sample U (only affects GetDMax function)

# Population.ArrayfAB must have fAB true values for each combination of MAFa, MAFb and DPrime
Population.ArrayfAB<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)))*0
dim(Population.ArrayfAB)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime))
Population.ArrayfAB<-GetTruefAB(Population.ArrayD, Population.VectorMAFa, Population.VectorMAFb)

# Population.ArrayU must have U true values for each combination of MAFa, MAFb and DPrime
Population.ArrayU<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)))*0
dim(Population.ArrayU)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime))
Population.ArrayU<-GetTrueU(Population.ArrayD, Population.VectorDPrime, Population.VectorMAFa, Population.VectorMAFb, TrueMAF)

# Population.ArrayR must have R true values for each combination of MAFa, MAFb and DPrime
Population.ArrayR<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)))*0
dim(Population.ArrayR)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime))
Population.ArrayR<-GetTrueR(Population.ArrayD, Population.VectorMAFa, Population.VectorMAFb)

# Population.ArraypHaplotypes must have true haplotype frequencies for each combination of MAFa, MAFb and DPrime
Population.ArraypHaplotypes<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*4))*0
dim(Population.ArraypHaplotypes)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),4)
Population.ArraypHaplotypes<-GetTrueHaps(Population.VectorDPrime, Population.VectorMAFa, Population.VectorMAFb, Population.ArrayD, U, TrueMAF)

# Population.ArraypGenotypes must have true genotype frequencies for each combination of MAFa, MAFb and DPrime
Population.ArraypGenotypes<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*TotalGenotypes))*0
dim(Population.ArraypGenotypes)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),TotalGenotypes)
Population.ArraypGenotypes<-GetTrueGenotypes(Population.VectorDPrime, Population.VectorMAFa, Population.VectorMAFb, Population.ArrayD, Population.ArraypHaplotypes, U)

# INFORMATION ABOUT SAMPLING
# Now we need variables with information about samples

# Simulations will be done for samples with 5 different sizes: 50, 100, 200, 500 and 1000.
VectorSize<-c(20, 60, 100, 200, 500, 1000)

# Repetitions1 is the number of simulated samples used to compute mean DPrime is 1000
Repetitions1<-1000 # for basic sampling

# Only for permutation analysis and bootstrapping, Repetitions2 is the
# number boostrapping or permutation samples used respectively.
# In Teare's paper this number is 3000.
# (I think I should reduce this number to reduce computation time, because in 
# the computer I am using, I would need about 2 months to have results for 
# all population MAFa, MAFb and DPrime considered in this program)
Repetitions2<-300 # for permutation and bootstrapping methods 




# Given a simulation defined by a trio of population values:
# MAFa, MAFb and DPrime (so that haplotypes frequencies and genotypes frequencies
# under 2-loci HWE can be inferred)
# and given a sample size
# genotypes for the 1000 simulated samples will be written in Simulations.ArraynGenotypes.
# So here the array is initialized.
Simulations.ArraynGenotypes<-c(1:(TotalGenotypes*Repetitions1))*0
dim(Simulations.ArraynGenotypes)<-c(TotalGenotypes,Repetitions1)

Simulations.ArraynAB<-c(1:Repetitions1)*0
dim(Simulations.ArraynAB)<-c(Repetitions1)


Simulations.ArraynHaps<-c(1:(4*Repetitions1))*0
dim(Simulations.ArraynHaps)<-c(4,Repetitions1)

# From samples phased genotypes, sample D can be computed.
# Mean DPrime of the 1000 simulations given population MAFa, MAFb, DPrime and
# given the samples sizes will be written in Simulations.ArrayMeanD.
# So here the array is initialized.
Simulations.ArrayMeanD<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanD)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsD<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsD)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanU<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanU)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsU<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsU)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanR<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanR)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMaxR<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMaxR)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMinR<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMinR)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))


Simulations.ArrayMeanAbsR<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsR)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

# The same when sampled genotypes are unphased and EM algorithm is used.
# Here the array is initialized.
Simulations.ArrayMeanDEM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanDEM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsDEM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsDEM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanUEM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanUEM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsUEM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsUEM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanREM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanREM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMaxREM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMaxREM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMinREM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMinREM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsREM<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsREM)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanMAFa<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanMAFa)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanMAFb<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanMAFb)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))


Simulations.ArrayMeanfAB<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanfAB)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayfAB<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(Simulations.ArrayfAB)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)



# From samples phased genotypes, sample DPrime can be computed.
# Mean DPrime of the 1000 simulations given population MAFa, MAFb, DPrime and
# given the samples sizes will be written in Simulations.ArrayMeanDPrime.
# So here the array is initialized.
Simulations.ArrayMeanDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMaxDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMaxDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMinDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMinDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(Simulations.ArrayDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)

# The same when sampled genotypes are unphased and EM algorithm is used.
# Here the array is initialized.
Simulations.ArrayMeanDEMPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanDEMPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMaxDEMPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMaxDEMPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMinDEMPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMinDEMPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanAbsDEMPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsDEMPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))


BadSample<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(VectorSize)))*0
dim(BadSample)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(VectorSize))

# CORE PROGRAM
# For each configuration of population values MAFa, MAFb, DPrime and for each
# sample size, samples will be simulated considering the Method.
# MeanDPrime and MeanDEMPrime will be computed as the avarage of DPRime and DEMPrime
# respectively of the Repetitions1 samples (1000).
for (i in 1:length(Population.VectorMAFa))
for (j in 1:length(Population.VectorMAFb))
for (k in 1:length(Population.VectorDPrime))
for (l in 1:length(VectorSize))
{
for (m in 1:Repetitions1)
{
do
{
Simulations.ArraynGenotypes[m,]<-rmultinom(1, VectorSize[l], Population.ArraypGenotypes[i,j,k,])
# Compute MAF a and MAF b for each sample
 MAFa<-1-GetfA(Simulations.ArraynGenotypes[,m])
 MAFb<-1-GetfB(Simulations.ArraynGenotypes[,m])
}
while (MAFa==0 || MAFb==0)
GetfAB(VectorGenotypes, Method, BayesType, TrueMAF, MAFa, MAFb)
} # end for each subsample


} # end for each MAFa, MAFb, DPrime, sample size





