/* File: list.h */


#ifndef __list_h__
#define __list_h__


#include "ExceptionsBasic.h"
//#include "base.h"


/************************/
/* list DEFINITION */
/************************/


/**
        @memo list 

	@doc
        Definition:
        A set of list's features 

        Memory space: O(SizeP), which SizeP being the number of elements in the list

    @author Maria M. Abad
	@version 1.0
*/
namespace UTILS {

typedef unsigned long int Pos;	
	
template <class T> class list {

public:	
		
typedef struct node
{
 T element;
 struct node* Next;
};


typedef node * NodePointer;

protected:		
NodePointer List;




/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

/////////////////////////////////////////////
void destroy(NodePointer e);

void copy(NodePointer & target, const NodePointer source);

void ReadInfo (ifstream * is, Pos size);


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


      /**
         @memo Destructor
	 @doc
           Deallocate memory used by list.
           Time complexity O(1).

      */
      ~list ();
//////////////////////////////////////////////




      /** @name Operations on list 
        @memo Operations on a list 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
      list();
  /////////////////////////////////////////////
      /**
         @memo Copy constructor
         @param target: list where will be copy
         @param origen: list to copy
         @doc
           Make a copy of list
           Time complexity in time O(1).
        */
	  list(char* filename);

  	  
	  list (list &source, Pos *Sampling, Pos size);


	  void GetInfo(char *FileName);

///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: list to copy.
         @return Reference to the receptor list.
	 @doc
           Copy the list in the receptor list.
           Time complexity O(1).

      */
      list & operator=(const list & e);
////////////////////////////////////////////////////
 
      bool operator==(const list & e);
      /**
         @memo Is different
         @param g: list to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const list & e);


	  virtual T ReadElement (ifstream * is, unsigned long int size);

	  	        /**
         @memo Obtain the element pointed by the nodepointer.
         @return return a pointer to the first list in the list
         Time complexity O(1)

      */
	  T GetElement(NodePointer e);

	  T GetElement(Pos k);

	        /**
         @memo Obtain the first list in the list.
         @return return a pointer to the first list in the list
         Time complexity O(1)

      */
	  inline NodePointer GetFirst () {return List;};

      /**
         @memo Obtain the Next list in the list.
         @param The pointer to the current list
         @return return a pointer to the Next list in the list
         Time complexity O(1)

      */
       inline NodePointer GetNext (const NodePointer i)
		{
			try { if (i==NULL) throw NullValue();else  return i->Next;}
            catch (NullValue nv) {nv.PrintMessage(); }
		};

   /**
         @memo Obtain the element at pos k in the list.
         @param The pointer to the current list
         @return return a pointer to the Next list in the list
         Time complexity O(1)

      */
      inline  NodePointer GetNode (Pos k)
		{
		NodePointer i=List;
		try {
		for (long unsigned int c=0;c<k;c++)
		 if ((i=i->Next)==NULL) throw NullValue();
			}
		catch (NullValue null) {null.PrintMessage();}
		return i;};             

	 
      /**
         @memo Obtain the list SizeP.
         @return the size of a list
         @doc Return the number of lists in the list. This value
         is in the variable SizeP.
         Time complexity O(1)

      */
        Pos GetSize ();         
		
		Pos GetPos(NodePointer p);

		  /**
         @memo Add an element to the list.
         @param Position: Position of this element in the list
         Time complexity O(1)

      */
	  void InsertElement (T element);

  
		  /**
         @memo Remove the element at pos n from the list.
         @param Position: Position of this element in the list
         Time complexity O(1)

      */
	  void RemoveElement (NodePointer e);

	  void Order(Pos* NewOrder, Pos size);

	  void Order(int funcioncomparar (const void *arg1, const void *arg2));

  	  void Remove(bool* RemovePos);

	  void ReplaceNode(NodePointer p, T NewElement);

	  bool IsEmpty();


};  // End of class list


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/////////////////////////////////////////////
template <class T>  void list<T>::destroy(list::NodePointer e)
{

       		if(e!= NULL)
			 destroy (e->Next);
			delete e;
            
}
//////////////////////////////////////////

template <class T>  void list<T>::copy (list<T>::NodePointer & Target, const list<T>::NodePointer Source)
{
	try
	{

	  if ((Target=new node)==NULL)
            throw NoMemory();
 
	     Target->element=Source->element;
        	 
         if (Source->Next!=NULL)
           copy(Target->Next,Source->Next);     
		 else Target->Next=NULL;

	}
	catch (NoMemory wm) 
{
 wm.PrintMessage();
}        

}
/*___________________________________________________________ */

template <class T> void list<T>::ReadInfo (ifstream * is, Pos size)
{
//	T* e;
//	e=new T(ReadElement(is, size));
//	if (size!=18)
//	cout << e->PrintPhenotype();
//	T e;
//	T e(ReadElement(is, size));
	InsertElement(ReadElement(is, size));
//	InsertElement(e);
//if (size!=18) exit(0);
	if (is->peek()!=EOF && is->peek()>='0' && is->peek()<='?') 
	 ReadInfo(is, size);
}


///////////////////
//// public ////////
///////////////////

template <class T> list<T>::list()
{

  List=NULL; 
}
/*____________________________________________________________ */

template <class T> list<T>::list<T> (char* filename)
{

GetInfo(filename);
}
/*____________________________________________________________ */

template <class T>  list<T>::list (list<T> &source, Pos *Sampling=NULL, Pos SizeP=0)
{
// copy elements with pos in Sampling, they can be repeated

Pos cont=0;
List=NULL;

if (Sampling!=NULL)
{
  while (cont<SizeP)
  {
  InsertElement(source.GetElement(Sampling[cont]));
  cont++;
  };
}
else
 copy (List, source.List);

}


/*____________________________________________________________ */

template <class T>  list<T>::~list ()
{
	if (List!=NULL) destroy(List);
}
/*____________________________________________________________ */

template <class T> void list<T>::GetInfo(char *FileName)
{

//cout << "Reading elements ...\n";

List=NULL;
unsigned long int size=GetLineLength(FileName)*2; //double because there can be longer lines
cout <<"size:" << size <<"\n";
//if (size!=18)
//exit(0);
ifstream  InputFile;

try
{
 if (!ExistFile(FileName))
	 throw ErrorFile();
  InputFile.open (FileName, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
catch (EmptyFile EFile) {EFile.PrintMessage(FileName);}


ReadInfo (&InputFile, size);

InputFile.close();
//cout <<"Elements reading has finished\n";

};
 /*____________________________________________________________ */

template <class T> T list<T>::GetElement(list<T>::NodePointer e)
{
	try
	{
  if (e==NULL) 
   // throw NullValue(" in GetElement");
   throw NullValue();
  else return e->element;
	}

   catch (NullValue nv) {
                nv.PrintMessage();}
}

 /*____________________________________________________________ */

template <class T> T list<T>::GetElement(Pos k)
{
return GetElement(GetNode(k));
}



/*____________________________________________________________ */

template <class T>  void list<T>::ReplaceNode(list<T>::NodePointer p, T NewElement)
{
  try {
  if (p==NULL)
   throw NullValue();

  p->element=NewElement;
      
  }
  catch (NullValue null) {
    null.PrintMessage();
    }
}
/*____________________________________________________________ */

template <class T> Pos list<T>::GetPos(list<T>::NodePointer p)
{
  Pos k=0;
  NodePointer i=List;
  
	  while (i!=NULL)
	  {
		if (i==p) return k;
		k++;
		i=i->Next;
	  }
  
  return k;
}
/*____________________________________________________________ */


template <class T>  Pos list<T>::GetSize()
{
	Pos Size=0;

	NodePointer i=List;

     while (i!=NULL)
	 {
		 i=i->Next;
		 Size++;
	 }

	 return Size;
}
/*____________________________________________________________ */

template <class T>  list<T>& list<T>::operator=(const list<T> & Source)
{
  if (this!=&Source)  
  {
  destroy(List);
  copy (List, Source.List);
  }
  return *this;
}
/*____________________________________________________________ */

template <class T>  void list<T>::InsertElement (T element)
{
	
	NodePointer OldPointer=NULL, Pointer=GetFirst();

	while (Pointer!=NULL) 
	{
		OldPointer=Pointer;
		Pointer=GetNext(Pointer);
	}

	try
	{
	if ((Pointer=new node)==NULL)
            throw NoMemory();
	}
	 catch (NoMemory NM ) {NM.PrintMessage();}
	
	Pointer->element=element;      	      
	Pointer->Next=NULL;
	if (OldPointer!=NULL) OldPointer->Next=Pointer; else List=Pointer;
	
}

/*____________________________________________________________ */

template <class T>  void list<T>::RemoveElement (list<T>::NodePointer Pointer)
{
	
try
{
	NodePointer Pointer2=List;

	while ((Pointer2->Next!=Pointer) && (Pointer!=NULL))
     Pointer2=GetNext(Pointer2);

	if (Pointer==NULL)
		//throw NullValue("when removing an element");
		   throw NullValue();

	else 
	{
		delete Pointer;
		if (Pointer2!=NULL)
		 Pointer2->Next=Pointer->Next;
		else // Pointer is the first element, list will be empty
         List=NULL;
	}
}
catch (NullValue null) {
    null.PrintMessage();
    }


} 

/*____________________________________________________________ */

template <class T>  void list<T>::Order(Pos* NewOrder, Pos size)
{
 	 Pos Size=GetSize(), pos;
	
	 list<T> *List2;
	 try
	 {
	 if (Size!=size)
		 throw NoMemory();
 	if ((List2=new list<T>())==NULL)
		throw NoMemory();
	 }

	 catch (NoMemory NM ) {
      NM.PrintMessage();
	}
	exit(0);


	for (Pos i=0;i<Size;i++)
	{
      pos=NewOrder[i];
	  List2->InsertElement(GetElement(GetNode(pos)));  
	 }

	destroy(List);
	NodePointer p=List2->GetFirst();
    while (p!=NULL) 
	{
	  InsertElement(GetElement(p));  
	  p=List2->GetNext(p);
	}

	

  cout <<"Sorting has finished\n";
}
/*____________________________________________________________ */

template <class T>  void list<T>::Order(int funcioncomparar (const void *arg1, const void *arg2))
{
 
 NodePointer IndPosition=GetFirst();

 unsigned long int size=GetSize(), i=0;

 T *List;
 if ((List=new T[size])==NULL)
  throw NoMemory();

 while (IndPosition!=NULL)
 {
  List[i]=IndPosition->element;
  IndPosition=GetNext(IndPosition);
  i++;
 }
 qsort ((void*)List, size, sizeof (T), funcioncomparar);

IndPosition=GetFirst();
i=0;
while (IndPosition!=NULL)
{
 IndPosition->element=List[i];
 IndPosition=GetNext(IndPosition);               
 i++;
}

delete List;
	
}


/*____________________________________________________________ */

template <class T>  bool list<T>::IsEmpty()
{
	return List==NULL;
}
/*____________________________________________________________ */

template <class T>  void list<T>::Remove(bool* PosList)
{
	// PosList contains true in positions to be removed

 	 Pos Size=GetSize(), pos, i=0;
	
	 try
	 {
	 if (Size!=sizeof(*PosList))
		 throw NoMemory();
	 }

	 catch (NoMemory NM ) {NM.PrintMessage();
	}

	NodePointer p=GetFirst(), oldp;
	
	while (p!=NULL)
	{
    oldp=p;
    p=GetNext(p);
	if (PosList[i]==true)
	  RemoveElement(oldp);  
	}  
	

  cout <<"Sorting has finished\n";
}
/* _____________________________________________________*/


#endif

/* Fin Fichero: list.h */
