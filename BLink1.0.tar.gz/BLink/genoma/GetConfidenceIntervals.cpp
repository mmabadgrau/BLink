  /**
    * @file HapBlocking.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method)
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "TriosPairwiseMeasure.h"

using namespace UTILS;

namespace BIOS 
{
char filename[128], filename2[128];
IndCategory ic=parent;
BayesType BayesMode=MLE;
bool IsPartiallySolved=false;
double MAF=0.0, alpha=95.0;
double Width=0.0;
IndPos size=100;
bool unrelated=false;

/*****************/
void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "\nYou have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  <<"<max width>"
			<< " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium>" 
		<< " ic (father=0, mother=1, offspring=2, everybody=3, parent=4)" 
		<< "< Pairwise phase (0: standard phase/1: with partially solved)>" <<"<MAF>" <<"<alpha ci>"<< endl;
        exit(-1);;  
        exit(-1);
        }
        
	
	 strcpy(filename, argv[1]);

if (argc>=3) Width=atof(argv[2]);

if (argc>=4) BayesMode=(BayesType) atoi(argv[3]);

if (argc>=5) ic=(IndCategory) atoi(argv[4]);

if (argc>=6) IsPartiallySolved=atoi(argv[5]);

if (argc>=7) MAF=atof(argv[6]);

if (argc>=8) alpha=atof(argv[7]);


}



} //end namespace
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
     
		 
double upperbound, lowerbound, DPrime, r2, YulesQ;
SNPPos TotalSNPs; 

Positions * Pos;
Table2x2 T2x2;

char filepos[128], fileci[128];

ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, fileci, "ci");
Pos=new Positions (filepos);
TrioSample *Sample;
Sample=new TrioSample (filename);
//Sample->PrintSampleReducedFormat(filered, false, ic, 2); // snp 3
//Sample->WriteResults("short");

TotalSNPs=Sample->GetTotalSNPs();
if (Width>Pos->GetDistance(0, TotalSNPs-1)) 
 Width=Pos->GetDistance(0, TotalSNPs-1);

double fA, fB, fAB, MaxDPrime;
IndPos total=0, top;
TriosPairwiseMeasure *PM;
MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(Sample, (BayesType)0, ic);

ofstream OutputFile; 
try
{
	  OutputFile.open (fileci, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

double DPrime2, D, MaxD, distance;
struct Pair pair;
char line[100];
cout <<"Obtaining confidence intervals...\n";
OutputFile << "file source:" << filename <<", Bayes type:" << BayesMode << ", IndCategory:" << ic <<", Used partial phase:" << IsPartiallySolved <<", MAF: " << MAF <<", Max Width:" << Width << "alpha:" << alpha << "\n";
OutputFile <<"SNP1\tSNP2\tDPrime\tLower bound\tUpper bound\n";
for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 //if (Sample->GetTotalMissing(SNP, ic)==0) 
  if (MM.GetTotalFreqAllele(SNP, false)>MAF) 
 {
if (SNP%100==0)
 cout <<"SNP " << SNP+1<<"\n";
 
 for (SNPPos SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
  if (Width==0.0 || Pos->GetDistance(SNP, SNP2)<Width)
  // if (Sample->GetTotalMissing(SNP2, ic)==0) 
    if (MM.GetTotalFreqAllele(SNP2, false)>MAF)
   {
  distance=Pos->GetDistance(SNP, SNP2);

// cout <<"SNP2 " << SNP2+1<<"\n";
		
	PM = new TriosPairwiseMeasure (SNP, SNP2, Sample, BayesMode, ic, IsPartiallySolved, distance);
	fA=PM->GetfA();
    fB=PM->GetfB();
	if (fA<1 && fB<1) // to avoid different missing counters between both SNPs
	{ 
    fAB=PM->GetfAB();
//	cout <<"\nfAB:" << fAB <<"fA:" << fA <<"fB:" << fB;
	D=T2x2.GetD(fAB, fA, fB);
    MaxD=T2x2.GetMaxD(fAB, fA, fB);
    DPrime=T2x2.GetDPrime(fAB, fA, fB);
    r2=T2x2.GetR2(fAB, fA, fB);
    YulesQ=T2x2.GetQ(fAB, fA, fB);
 //   MaxDPrime=T2x2.GetMaxDPrime(fA, fB, fAB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
//cout <<"j";
	pair=T2x2.GetQuantilesDPrime(50-alpha/2, 50+alpha/2, fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
	lowerbound=pair.First;
	upperbound=pair.Second;
	sprintf(line, "%d\t%1.0lf\t%d\t%1.0lf\t%1.2lf\t%1.2lf\t%1.2lf\t%1.2lf\t%1.2lf\n", SNP+1, Pos->PrintPosition(SNP), SNP2+1, Pos->PrintPosition(SNP2), DPrime, lowerbound, upperbound, r2, YulesQ);

	OutputFile << line;
    }	
    delete PM;
	
	}
 }
 
 cout <<"Confidence intervals " << 50-alpha/2 << "-" << 50+alpha/2 << " have been obtained and save in file " << fileci <<"\n";

OutputFile.close();

delete Pos, Sample;

return 0;


}










