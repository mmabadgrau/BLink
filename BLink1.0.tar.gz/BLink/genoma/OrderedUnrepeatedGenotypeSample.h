/* File: OrderedUnrepeatedGenotypeSample.h */


#ifndef __OrderedUnrepeatedGenotypeSample_h__
#define __OrderedUnrepeatedGenotypeSample_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"
#include "orderedunrepeatedpositions.h"
#include "OrderedUnrepeatedGenotype.h"


using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class OrderedUnrepeatedGenotypeSample: public list<OrderedUnrepeatedGenotype>  {


protected:
    /** @name Implementation of class GenotypeSample
        @memo Private part.
    */

   	
	 /** @name Pointer to the list of the wild-type allele for every SNP
        @memo The wild-type will be the more frequent allele in the dataset
    */


        
	 allele* MajorAllele;

	 

	 /** @name Pointer to the list of the mutant allele for every SNP
        @memo The mutant will be the less frequent allele in the dataset
    */


        
	 allele* MinorAllele;


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
   orderedunrepeatedpositions* pos;

     bool ExistPhenotypes;

/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */

		OrderedUnrepeatedGenotype*  ReadElement (ifstream * source);


				   /**
         @memo Compute the more frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the more frequent value
*/

		 void SetMajorAllele();

/**
         @memo Compute the less frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the less frequent value
*/

		void SetMinorAllele();

		void SetAlleleType (bool IsMajor);


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on GenotypeSample 
        @memo Operations on a GenotypeSample 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  OrderedUnrepeatedGenotypeSample(positions * pos);


		  OrderedUnrepeatedGenotypeSample (char &* filename,  orderedunrepeatedpositions &* pos, bool & ExistPhenotypes);

    

		        /**
         @memo Copy constructor
         @param destino: GenotypeSample where will be copy
         @param origen: GenotypeSample to copy
         @doc
           Make a copy of GenotypeSample
           Time complexity in time O(1).
        */
	
		  OrderedUnrepeatedGenotypeSample (OrderedUnrepeatedGenotypeSample& Source, unsigned int *Sampling);





      /**
         @memo Is equal
         @param g: GenotypeSample to compare with.
	 @return
           Return true if all the GenotypeSample is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const OrderedUnrepeatedGenotypeSample & g);
      /**
         @memo Is different
         @param g, position: GenotypeSample to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const OrderedUnrepeatedGenotypeSample & g);

		
	  void CheckRangeSNP(SNPPos SNP);
   
 		

		   /**
         @memo Obtain the number of SNPs.
         @return the number of SNPs
         @doc Return the number of SNPs. This value
         is in the variable TotalSNPs.
         Time complexity O(1)

      */
        SNPPos GetTotalSNPs ();        

};  // End of class GenotypeSample



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

/*___________________________________________________________ */

OrderedUnrepeatedGenotype*  OrderedUnrepeatedGenotypeSample::ReadElement (ifstream * source)
{
	SNPPos TotalSNPs=pos->GetTotalSNPs(), size=TotalSNPs*4+40;

	try
	{
	
	Left[TotalSNPs], Right[TotalSNPs];	
	OrderedUnrepeatedGenotype* targetGenotype;

	if ((targetGenotype=new OrderedUnrepeatedGenotype())==NULL)
		throw NoMemory();



	ReadGenotypes (Left, Right, source, TotalSNPs, ExistPhenotype);

	GenotypeS G;


		G.Left=Left;
		G.Right=Right;
		targetPhenotype->InsertElement(G);
	}

	   
	}
	catch (NullValue nv) {nv.PrintMessage();}
	catch (NoMemory nm) {nm.PrintMessage();}

	return targetGenotype;
 }

///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

OrderedUnrepeatedGenotypeSample::OrderedUnrepeatedGenotypeSample(orderedunrepeatedpositions * pos): list<OrderedUnrepeatedGenotype>()
{
 // this->TheFirstGenotype=NULL;
  MajorAllele=NULL;
  MinorAllele=NULL;
}


/*____________________________________________________________ */


OrderedUnrepeatedGenotypeSample::OrderedUnrepeatedGenotypeSample (OrderedUnrepeatedGenotypeSample& Source, unsigned int *Sampling=NULL):list<OrderedUnrepeatedGenotype>(Source, Sampling)
{
pos=Source.pos;

try 
{
 
if (&Source==NULL)
 throw NullValue();


SetMajorAllele();
SetMinorAllele();

}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}
catch (NullValue nv) 
{
 nv.PrintMessage();
}

}
/*____________________________________________________________ */

OrderedUnrepeatedGenotypeSample::OrderedUnrepeatedGenotypeSample (char &* filename,  orderedunrepeatedpositions &* pos,  bool & ExistPhenotypes=true)
{

if (strncmp(strtok(filename+2, ".")-2, "gou", 3)!=0)
{
	cout <<"File gou is required";
	exit (0);
}

MajorAllele=NULL;
MinorAllele=NULL;



cout << "Reading genotypes ...\n";

GetInfo(filename);


cout << "Genotype reading has finished ...\n";

SetMajorAllele ();
SetMinorAllele (); 
}

};

/* _____________________________________________________*/

void GenotypeSample::SetAlleleType(bool IsMajor)
{
cout <<"Computing major alleles...\n";
NodePointer IndGenotype;
unsigned int TotalUsed;
unsigned int Basis[5], max, MaxVal;
Genotype * genotype;
if ((IsMajor==true && MajorAllele!=NULL) || (IsMajor==false && MinorAllele!=NULL))
{ cout << "Already computed"; exit(0);}

allele * Allele;

SNPPos TotalSNPs=GetTotalSNPs();

try
{
if ((Allele=new allele[TotalSNPs])==NULL)
      throw NoMemory();
}
catch (NoMemory NM ) {NM.PrintMessage();}


if (IsMajor==true) MajorAllele=Allele; else MinorAllele=Allele;

unsigned long int ChosenVal;
unsigned int ChosenPos;

for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
{
for (int c=0;c<=4;c++) Basis[c]=0;

IndGenotype=GetFirst();

while (IndGenotype!=NULL)
{
 genotype=new Genotype(GetElement(IndGenotype));
 Basis[(int)genotype->GetLeftAllele(SNP)]++; 
 Basis[(int)genotype->GetRightAllele(SNP)]++; 
 IndGenotype=GetNext(IndGenotype);
}

ChosenPos=GetExtremePos(&(Basis[1]),4, IsMajor);
ChosenVal=Basis[ChosenPos];

TotalUsed=0;
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0) TotalUsed++;    
try
{
 if (TotalUsed>2)
 throw MultiAllelic();
}
catch (MultiAllelic ma) {ma.PrintMessage(SNP);}

Allele[SNP]=(allele)MaxVal;
}
if (IsMajor==true) cout <<"Major alleles has been computed\n";
else cout <<"Minor alleles has been computed\n";
} 


/* _____________________________________________________*/

void GenotypeSample::SetMajorAllele()
{
	SetAlleleType(true);
}
/* _____________________________________________________*/

void GenotypeSample::SetMinorAllele()
{
	SetAlleleType(false);
}
/*__________________________________________________________*/

void GenotypeSample::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}            
/*____________________________________________________________ */

SNPPos GenotypeSample::GetTotalSNPs()
{
  return pos->GetTotalSNPs();
}

};  // End of Namespace

#endif

/* End of file: GenotypeSample.h */




