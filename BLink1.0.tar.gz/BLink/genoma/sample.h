/* File: sample.h */


#ifndef __sample_h__
#define __sample_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"


namespace BIOS {


/************************/
/* SAMPLE STATISTIC*/
/************************/


/**
        @memo SAMPLE

	@doc
        Definition:
        An array Pos of Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class sample  {


protected:
    /** @name Implementation of class sample
        @memo Private part.
    */


  
   int Size;






/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

  unsigned int  * Pos;

sample(unsigned int size, bool repetition);
~sample();


};  // End of class sample



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



///////////////////
//// public ////////
///////////////////


/**********************************/
sample::sample(unsigned int size, bool repetition)
{
Size=size;
bool *Chosen;
unsigned int SampleValues[size];

 srand(7258789);//    MLC++//

try {
if ((Pos=new unsigned int[size])==NULL)
      throw NoMemory();


if (repetition==true)
for (int i=0; i<size;i++)
 SampleValues[i]=rand() % (size);     //
else // without repetition
{
int pos;
if ((Chosen=new bool[size])==NULL)
    throw NoMemory();
for (int i=0;i<size;i++)
	Chosen[i]=false;

unsigned int cont2, posNotChosen;

for (int i=0; i<size;i++)
  {//
   cont2=0;//
   pos=rand() % (size-i);     //
   posNotChosen=0;
   while (Chosen[posNotChosen]==true)
    posNotChosen++;
   Pos[i]=posNotChosen;
   Chosen[posNotChosen]=true;
  }//
} // end without repetition 
  }
catch (NoMemory no) {
  no.PrintMessage();
  }
}
/**********************************/
sample::~sample()
{
//	if (SampleValue!=NULL)
//	delete SampleValue;
}

};  // End of Namespace

#endif

/* End of file: sample.h */




