  /**
    * @file HapBlocking.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method)
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "genoma.h"
#include "blockCI.h"
#include "sample.h"

using namespace UTILS;
using namespace stats;

namespace BIOS 
	 {
char* filename, *filename2;
PhaseType PhaseMode=ResolveFromTU;
IndCategory ic=everybody;
unsigned int bayes=2;
double MAF=0;
double **UpperBound, **LowerBound, DPrime[1000];
/*****************/
void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  << " <output file> ";  
        exit(-1);
        }
        
	 if ((filename=new char[128])==NULL)
		 throw NoMemory();

	 if ((filename2=new char[128])==NULL)
		 throw NoMemory();

	 strcpy(filename, argv[1]);

	 if (argc==3)
   	 strcpy(filename2, argv[2]);
	 else
	 {
	strcpy (filename2, filename);
	filename2=strtok(filename2+2, ".")-2;
	strncat(filename2, ".blocks\0", 4);//
	 }

	 
 
if (argc==4) PhaseMode=(PhaseType) atoi(argv[3]);

if (argc==5) ic=(IndCategory) atoi(argv[4]);

if (argc==6) bayes=atoi(argv[5]);

if (argc==7) MAF=atof(argv[6]);

}

/*___________________________________________________*/

void Initialization()
{
if ((UpperBound=new double*[TotalSNPs-1])==NULL)
  throw NoMemory();

for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 if ((UpperBound[SNP]=new double[min(TotalSNPs-SNP-1, Width)])==NULL)
  throw NoMemory();

for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 for (long unsigned int SNP2=0; SNP2<min(TotalSNPs-SNP-1, Width);SNP2++)
  UpperBound[SNP][SNP2-SNP-1]=maxreal;

if ((LowerBound=new double*[TotalSNPs-1])==NULL)
 throw NoMemory();
     
for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 if ((LowerBound[SNP]=new double[min(TotalSNPs-SNP-1, Width)])==NULL)
  throw NoMemory();

 for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 for (long unsigned int SNP2=0; SNP2<min(TotalSNPs-SNP-1, Width);SNP2++)
  LowerBound[SNP][SNP2-SNP-1]=maxreal;


 if ((DPrime=new double*[TotalSNPs-1])==NULL)
 throw NoMemory();
     
for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 if ((DPrime[SNP]=new double[min(TotalSNPs-SNP-1, Width)])==NULL)
  throw NoMemory();

 for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 for (long unsigned int SNP2=0; SNP2<min(TotalSNPs-SNP-1, Width);SNP2++)
  DPrime[SNP][SNP2-SNP-1]=maxreal;


}

} //end namespace
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
     
		 

GenomaSample *Sample;
Positions * Pos;
block * blocks;
Table2x2 T2x2;
double **UpperBound, **LowerBound, **DPrime, DPrimeList[1000];

ChangeExtension (filename, filepos, "pou");
Pos=new Positions (filepos);
Sample=new GenomaSample (filename);
SNPPos Width=500, TotalSNPs=Sample->GetTotalSNPs();
Initialization;
MonolociMeasure<GenomaSample> MM = MonolociMeasure<GenomaSample>(Sample, BayesMode, ic);

IndPos total=0, top;
for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 for (long unsigned int SNP2=SNP+1; (SNP2<TotalSNPs && SNP2<Width);SNP2++)
  if (Sample->GetTotalFreqAllele(SNP, false, ic)>=MAF && Sample->GetTotalFreqAllele(SNP2, false, ic)>=MAF)
   if (Sample->GetTotalMissing(SNP, ic)!=0 && Sample->GetTotalMissing(SNP2, ic)!=0) 
   {
	PM = new PairwiseMeasure<GenomaSample>(SNP, SNP2, Sample, BayesMode, ic, IsPartiallySolved);
	fAB=PM->GetfAB();
	fA=MM.GetTotalFreqAllele(SNP, true);
	fB=MM.GetTotalFreqAllele(SNP2, true);
	DPrime[SNP][SNP2]=T2x2.GetDPrime(fAB, fA, fB);
    total=PM.SetBootstrapFrequencies(DPrimeList,1000);
	if (total>0)
    { 
    qsort ((void*)DPrimeList, TotalSNPs, cont, compare);
	UpperBound[SNP][SNP2-SNP-1]=percentile(DPrimeList, total, 95);
	LowerBound[SNP][SNP2-SNP-1]=percentile(DPrimeList, total, 5);
	}
   }
 

blockCI *blockCI1;
 
 if ((blockCI1 = new blockCI(UpperBound, LowerBound, MAF, TotalSNPs, Width, genoma1, ic))==NULL)
 throw NoMemory();


blockCI1->WriteBlocks(filename2);


}

delete filename;


return 0;


}










