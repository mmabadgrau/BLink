rm dHap
echo coalescent
../PhaseResolver coalescent.txt 100 50 1
../PhaseCheckerComparingSamples coalescent.sal dHap 50 100 0 
../PhaseResolverAndChecker coalescent.txt dHap 50 100 1 0
echo crossover
../PhaseResolver crossover.txt 100 50 1
../PhaseCheckerComparingSamples crossover.sal dHap 50 100 0 
../PhaseResolverAndChecker crossover.txt dHap 50 100 1 0
echo migration
../PhaseResolver migration.txt 100 50 1
../PhaseCheckerComparingSamples migration.sal dHap 50 100 0 
../PhaseResolverAndChecker migration.txt dHap 50 100 1 0
echo crohn
../PhaseResolver crohncomplete.red 95 129 1
../PhaseCheckerComparingSamples crohncomplete.sal dHap 129 95 0 
../PhaseResolverAndChecker crohncomplete.red dHap 129 95 1 0
echo chrom1
../PhaseResolver crohncomplete.red 95 129 1
../PhaseCheckerComparingSamples crohncomplete.sal dHap 129 95 0 
../PhaseResolverAndChecker crohncomplete.red dHap 129 95 1 0
echo chrom2
../PhaseResolver crohncomplete.red 95 129 1
../PhaseCheckerComparingSamples crohncomplete.sal dHap 129 95 0 
../PhaseResolverAndChecker crohncomplete.red dHap 129 95 1 0

