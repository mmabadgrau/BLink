/* File: GenotypeSample.h */


#ifndef __GenotypeSample_h__
#define __GenotypeSample_h__

//#include <string.h>
//#include <cstdio>

#include "Exceptions.h"
#include "Diplotype.h"
#include "Genotype.h"

//#include "RepeatedGenotypeSample.h"

using namespace UTILS;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class GenotypeSample: public list<Genotype*>  {


	protected:
    /** @name Implementation of class GenotypeSample
        @memo Private part.
    */


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
     bool ExistPhenotypes, Sample;

	public:

     allele * MajorAllele;

	protected:

	 NodePointer FirstGenotype;


/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */

		//Genotype  ReadElement (ifstream * source, SNPPos size);

	
//		void  ReadGenotype (list<Diplotype::DiplotypeS>* DiplotypeList, char* line, SNPPos size);


				   /**
         @memo Compute the more frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the more frequent value
*/


/**
         @memo Compute the less frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the less frequent value
*/

		void SetMinorAllele();

		void SetAlleleType (bool IsMajor);

 	    void SetMajorAllele();

	protected:


		
		Diplotype::Diplotype ReadDiplotype (ifstream * source, unsigned long int size);


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

      /** @name Operations on GenotypeSample 
        @memo Operations on a GenotypeSample 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  

		  GenotypeSample(char * filename, bool ExistPhenotypes, AlleleOrderType AlleleOrderMode);

    

		        /**
         @memo Copy constructor
         @param destino: GenotypeSample where will be copy
         @param origen: GenotypeSample to copy
         @doc
           Make a copy of GenotypeSample
           Time complexity in time O(1).
        */
	
		//  GenotypeSample (GenotypeSample& Source, SNPPos TotalSNPs, unsigned int *Sampling);


		  GenotypeSample (const GenotypeSample& source, unsigned int *Sampling);


		  ~GenotypeSample (){if (MajorAllele!=NULL) delete MajorAllele;};


      /**
         @memo Is equal
         @param g: GenotypeSample to compare with.
	 @return
           Return true if all the GenotypeSample is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const GenotypeSample & g);
      /**
         @memo Is different
         @param g, position: GenotypeSample to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const GenotypeSample & g);

		
	  SNPPos GetTotalSNPs();
   
      SNPPos GetTotalAllele (unsigned long int SNP, bool IsMajor, const IndCategory ic);

	  SNPPos GetHap(SNPPos SNP1, SNPPos SNP2, IndCategory ic, bool IsPartiallySolved, bool IsMajor1, bool IsMajor2); 

	  SNPPos GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, bool IsPartiallySolved);

	  SNPPos GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic, bool IsPartiallySolved);
	  
	  SNPPos GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, bool IsPartiallySolved);
	  
	  SNPPos Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic, bool IsPartiallySolved);

	  /**
         @memo Obtain the number of SNPs.
         @return the number of SNPs
         @doc Return the number of SNPs. This value
         is in the variable TotalSNPs.
         Time complexity O(1)

      */
	
		SNPPos GetDoubleHeterozygous (unsigned long int SNP, unsigned long int SNP2, const IndCategory ic);

		void OrderMajorFirst ();

		void CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic);

		void PrintHaplotypes (char* filename);


};  // End of class GenotypeSample



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



///////////////////
//// public ////////
///////////////////
/*___________________________________________________________ */

Diplotype::Diplotype list<Diplotype::Diplotype>::ReadElement (ifstream * source, unsigned long int size)
//Diplotype::Diplotype GenotypeSample::ReadDiplotype (ifstream * source, unsigned long int size)

{
	char line[50];
	Diplotype::Diplotype Dip;
	char genotypebuf[size]; 
	CaptureLine(source, genotypebuf, size);
//cout << genotypebuf;	
	bool ExistPhenotypes=true;
	char *cad, cadena[2], cadena2[2];
	cad = strtok (genotypebuf," \t");
    if (ExistPhenotypes==true)
	for (int phen=0;phen<7;phen++)
     cad = strtok (NULL," \t");
try
{
    while (cad!=NULL && cad[0]>='0' && cad[0]<='?')
    {
	if (strlen(cad)==1)
	{
	strcpy(cadena, "\0");
	sscanf (cad, "%s", cadena);
	Dip.SetLeftAllele((allele) atoi(cadena));
//	cout <<"Cad:\"" << cad <<"\"";
	cad = strtok (NULL," \t");
    if (cad==NULL) 
	{
		sprintf(line, "list<Diplotype>::ReadElement, last value was: \"%s\"", cad);
		cout <<"\nsi";
		throw NullValue();
	}
	sscanf (cad, "%s", cadena);
	Dip.SetRightAllele((allele) atoi(cadena));
    }
	else
	{
	sscanf (cad, "%c%c", cadena, cadena2);
	Dip.SetLeftAllele((allele) atoi(cadena));
	Dip.SetRightAllele((allele) atoi(cadena2));
    }
	InsertElement(Dip);
	cad = strtok (NULL," \t");
	}// end while
	
}
 catch (NullValue nv) { nv.PrintMessage(line);}   
 
	return Dip;
}
/*___________________________________________________________ */

Genotype* list<Genotype*>::ReadElement (ifstream * source, unsigned long int size)
{	
	char line[size];

	list<Diplotype> *DiplotypeList;
	DiplotypeList=new list<Diplotype::Diplotype>();
	DiplotypeList->ReadElement(source, size);
	//DiplotypeList->InsertElement(ReadDiplotype(source, size);
	SNPPos cont=0, TotalSNPs=DiplotypeList->GetSize();

	Genotype* targetGenotype;
	targetGenotype= new Genotype(TotalSNPs);
	
	list<Diplotype::Diplotype>::NodePointer p=DiplotypeList->GetFirst();
	
	while (p!=NULL)
	{
		targetGenotype->SetDiplotype(DiplotypeList->GetElement(p), cont);
		p=DiplotypeList->GetNext(p);
		cont++;
	};
	
return targetGenotype;
 }

/*____________________________________________________________ */

GenotypeSample::GenotypeSample (const GenotypeSample& source, unsigned int *Sampling=NULL):list<Genotype*>(source, Sampling)
{
if (Sampling!=NULL) Sample=true;
SetMajorAllele ();
}

/*____________________________________________________________ */

GenotypeSample::GenotypeSample (char * filename,  bool  ExistPhenotypes=true, AlleleOrderType AlleleOrderMode=MajorFirst)
{
Sample=false;
if (HasThisExtension(filename, "gou", 3)==false)
{
	cout <<"File gou is required";
	exit (0);
}

cout << "Reading genotypes ...\n";

GetInfo(filename);

cout << "Genotype reading has finished ...\n";

FirstGenotype=GetFirst();

SetMajorAllele ();

switch (AlleleOrderMode)
{
case NotChanged: break;
case MajorFirst: OrderMajorFirst(); break;
};

}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetTotalSNPs ()
{
return GetElement(GetFirst())->GetTotalSNPs();
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetTotalAllele (unsigned long int SNP, bool IsMajor, const IndCategory ic=everybody)
{
GenotypeSample::NodePointer IndGenotype=FirstGenotype;
Genotype* genotype;

SNPPos Total=0;
while (IndGenotype!=NULL)
{
 genotype=new Genotype (*GetElement(IndGenotype));
 switch (IsMajor)
 {
 case true: if (genotype->GetDiplotype(SNP).IsHomozygous1 (MajorAllele[SNP])) Total=Total+2; 
			if (genotype->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) Total++; break;
 case false:if (genotype->GetDiplotype(SNP).IsHomozygous2(MajorAllele[SNP])) Total=Total+2;
			if (genotype->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) Total++; break;
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
}

return Total;
}

/*____________________________________________________________ */

SNPPos GenotypeSample::GetDoubleHeterozygous (unsigned long int SNP, unsigned long int SNP2, const IndCategory ic=everybody)
{
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* genotype;

SNPPos Total=0;
while (IndGenotype!=NULL)
{
 genotype=new Genotype (*GetElement(IndGenotype));
 if (genotype->IsHeterozygousHeterozygous (SNP, SNP2, MajorAllele)) Total=Total+1; 
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
}

return Total;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetHap(SNPPos SNP1, SNPPos SNP2, IndCategory ic=everybody, bool IsPartiallySolved=false, bool IsMajor1=true, bool IsMajor2=true) 
{
NodePointer IndGenotype=GetFirst();
Genotype* genotype;

SNPPos Total=0;
while (IndGenotype!=NULL)
{
 Total=Total+genotype->GetHap(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele);      
 IndGenotype=GetNext(IndGenotype);
}

return Total;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic=everybody, bool IsPartiallySolved=false)
{
return GetHap(SNP1, SNP2, ic, IsPartiallySolved, true, true);
};  
/*____________________________________________________________ */

SNPPos GenotypeSample::GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic=everybody, bool IsPartiallySolved=false)
{
return GetHap(SNP1, SNP2, ic, IsPartiallySolved, true, false);
};  /*____________________________________________________________ */

SNPPos GenotypeSample::GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic=everybody, bool IsPartiallySolved=false)
{
return GetHap(SNP1, SNP2, ic, IsPartiallySolved, false, true);
};  /*____________________________________________________________ */

SNPPos GenotypeSample::Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic=everybody, bool IsPartiallySolved=false)
{
return GetHap(SNP1, SNP2, ic, IsPartiallySolved, false, false);
};  
/*____________________________________________________________ */

void GenotypeSample::OrderMajorFirst ()
{
  NodePointer IndGenotype=GetFirst();
  Genotype* g;
  while (IndGenotype!=NULL)
  {
	  g=GetElement(IndGenotype);
	  g->OrderMajorFirst(MajorAllele);
	  ReplaceNode(IndGenotype, g);
	  IndGenotype=GetNext(IndGenotype);
  }
    cout <<"Sorting major first has finished\n";

}
/*____________________________________________________________ */

void GenotypeSample::CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic)
{
NodePointer IndGenotype=GetFirst();

for (int c=0;c<=4;c++) Basis[c]=0;

IndGenotype=GetFirst();
Genotype * genotype;
while (IndGenotype!=NULL)
{
 genotype=GetElement(IndGenotype);
// cout <<  genotype->GetDiplotype(SNP).PrintDiplotype();
 //cout <<"b";
 Basis[(int)genotype->GetLeftAllele(SNP)]++; 
 Basis[(int)genotype->GetRightAllele(SNP)]++; 
 IndGenotype=GetNext(IndGenotype);
}

unsigned int TotalUsed=0;
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0) TotalUsed++;    
try
{
 if (TotalUsed>2)
 throw MultiAllelic();
}
catch (MultiAllelic ma) {ma.PrintMessage(SNP);}
}
/* _____________________________________________________*/

void GenotypeSample::SetMajorAllele()
{
SNPPos TotalSNPs=GetTotalSNPs();

try
{
if ((MajorAllele=new allele[TotalSNPs])==NULL)
      throw NoMemory();
}
catch (NoMemory NM ) {NM.PrintMessage();}

ComputeMajorAllele(*this);
}

/*____________________________________________________________ */

void GenotypeSample::PrintHaplotypes (char* filename)
 {

  GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
  Genotype* genotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 

  SNPPos TotalSNPs=GetTotalSNPs();

while (IndGenotype!=NULL)
  {
   genotype=GenotypeSample::GetElement(IndGenotype);
   genotype->PrintCompleteHaplotype(left);     
   OutputFile << "\n";
   genotype->PrintCompleteHaplotype(right);     
   OutputFile << "\n";
   IndGenotype=GenotypeSample::GetNext(IndGenotype);
  }
  OutputFile.close();

cout << "\nInformation about haplotypes has been saved in file " << filename <<"\n";
 }

};
// End of Namespace

#endif

/* End of file: GenotypeSample.h */




