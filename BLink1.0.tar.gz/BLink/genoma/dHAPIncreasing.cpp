  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include <time.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "PhaseResolver.h"

using namespace UTILS;

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) 
{
BayesType BayesMode=MLE;
bool EM=true;
if(argc<2)
{
 cerr << "Error: you have to specify the following information:" << endl;
 cerr  << argv[0] << " <input file> "  << " <output file> " <<"<BayesMode(0: No Bayes(default), 1: uniform, 2: uniform distance)>" 
	 << "<EM(0:no, 1: yes(default)>";  
 exit(-1);
}
char filename[128], filename2[128], filename3[128];
        
strcpy(filename, argv[1]);


if (argc>=3)  strcpy(filename2, argv[2]);
else ChangeExtension(filename, filename2, "hap\0");
ChangeExtension(filename2, filename3, "solved.gou\0");
if (argc>=4)  BayesMode=(BayesType) atoi(argv[3]);

if (argc>=5)  EM=atoi(argv[4]);

// time_t start,end;
double dif;

//time (&start);

clock_t start, end;
double milisecs;
start=clock();
PhaseResolver *PhasedSample;
PhasedSample=new PhaseResolver (filename, false, MajorFirst, BayesMode, EM);
PhasedSample->ResolvePhaseIncreasingDistances();
PhasedSample->PrintHaplotypes(filename2);
PhasedSample->PrintGenotypes(filename3);

end=clock();
//time (&end);
//dif = difftime (end,start);
dif=(double) end-start;
milisecs=(dif/CLOCKS_PER_SEC)*1000;
printf("Computation time has been %.2lf milisecs\n", milisecs);

return 0;
}




