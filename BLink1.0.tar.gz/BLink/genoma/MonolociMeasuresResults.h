

#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"
#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
/* File: MonolociMeasureResults.h */


#ifndef __MonolociMeasureResults_h__
#define __MonolociMeasureResults_h__


#include "../commonc++/list.h"
#include "../commonc++/basic.h"
#include "../commonc++/Sampling.h"

#include "Positions.h"
#include "Tables2x2.h"
#include "MonolociMeasure.h"
#include "TrioSample.h"
#include "math.h"
#include "GenomaSample.h"
#include "MonolociMeasure.h"
#include "MonolociMeasure.h"


namespace BIOS
{


  /************************/
  /* SNP'S MonolociMeasureResults DEFINITION */
  /************************/


  /**
          @memo MonolociMeasureResults for SNPs
   
  	@doc
         
   
   
          @author Maria M. Abad
  	@version 1.0
  */


  template<class T> class MonolociMeasuresResults
  {

  private:
    char line[1024];
    char filename[256], fileSelection[256];
    float MAF;
    BayesType BayesMode;
    IndCategory ic;
    bool phase, invariant, Selection;
    float alpha, alphaBayes;
    AlleleOrderType AlleleOrderMode;
    double fAB, fA, fB, DPrime, MaxDPrime;
    T *gs, *gs2;
    char filepos[256];
    double upperbound, lowerbound, MLDPrime, YulesQ, r2;
    Positions* Pos;
    Table2x2 T2x2;
    float distance;
    Pair<double> pair;
    SNPPos TotalSNPs, total;
    MonolociMeasure<T>* MM ;
    MonolociMeasure<T>* MM2;
   bool* Marked;

    ofstream OutputFile;

  public:
    char* PrintHeading();
    char* PrintConfiguration();
    MonolociMeasuresResults(char filenam[256], float maf, BayesType BayesMod, float alphaBayes, IndCategory i, bool phas, AlleleOrderType AlleleOrderMod, float alph, bool invarian, char* filesel);
    void PrintMonolociMeasures(char filename2[256], bool PrintConf);
    ~MonolociMeasuresResults() {zaparr(Marked);};
  };
  /*______________________________________________________________*/

  template<class T> char* MonolociMeasuresResults<T>::PrintConfiguration()
  {
    char* p=line;
    sprintf(line, "file source:%s, Bayes type:%d, IndCategory:%d, Phase mode:%d\n", filename, BayesMode, ic, AlleleOrderMode);
    return p;
  }
  /*______________________________________________________________*/

  template<class T> char* MonolociMeasuresResults<T>::PrintHeading()
  {
    char* p=line;
  
      strcpy(line, "SNP, Position, rsNumber, SNPType, n(A), n(a), unknownIndividuals, missingIndividuals\n");
     
    return p;
  }
  /*______________________________________________________________*/


  template<class T> MonolociMeasuresResults<T>::MonolociMeasuresResults(char filenam[256], float maf, BayesType BayesMod, float alphaBayes, IndCategory i, bool phas, AlleleOrderType AlleleOrderMod, float alph=90, bool invarian=false, char* filesel=NULL)
  {
    strcpy(filename, filenam);
    MAF=maf;
    BayesMode=BayesMod;
    this->alphaBayes=alphaBayes;
    ic=i;
    phase=phas;
    alpha=alph;
    invariant=invarian;
    AlleleOrderMode=AlleleOrderMod;
    if (filesel==NULL)
      Selection=false;
    else
    {
      strcpy (fileSelection, filesel);
      Selection=true;
    }

 ChangeExtension (filename, filepos, "pou");
    Pos=new Positions (filepos);
    gs=new T (filename, ic, AlleleOrderMode);

  Marked=Initialize(gs->PhenotypeSample::GetSize(), true);
			  gs->SetMarked(Marked, ic);

  }
  /*______________________________________________________________*/

  template<class T> void MonolociMeasuresResults<T>::PrintMonolociMeasures(char filename2[256], bool PrintConf=true)
  {
    OpenOutput(filename2, &OutputFile);
   

    TotalSNPs=gs->GetTotalSNPs();

    cout <<"\nThere are " << TotalSNPs << " snps and " << gs->GenotypeSample::GetSize() <<" individuals in the sample\n";
    MM = new MonolociMeasure<T>(gs, Marked, BayesMode, alphaBayes, distance, ic);
    MM2=NULL;
    if (Selection)
    {
      gs2=new T (fileSelection, ic, AlleleOrderMode);
      MM2 = new MonolociMeasure<T>(gs2, Marked, BayesMode, alphaBayes, distance, ic);
    }
    if (PrintConf) OutputFile <<PrintConfiguration();
    OutputFile << PrintHeading();



    for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
    //  if (gs->GetTotalMissing(SNP, ic)==0)
        if (invariant || MM->GetTotalFreqAllele(SNP, false)>MAF)
          if (!Selection || (MM2->GetTotalFreqAllele(SNP, false)>MAF && MM2->GetTotalFreqAllele(SNP, true)>MAF))

          {
            if (SNP%100==0)
              cout <<"snp:" << SNP+1 << "\n";

                    

          



                      OutputFile << SNP+1 << ", " << Pos->PrintPosition(SNP)  << ", " << Pos->getRSNumber(SNP)  << ", "	
                      << *UnconvertAllele(gs->getMajorAllele(SNP, ic)) << "/"
                      << *UnconvertAllele(gs->getMinorAllele(SNP, ic)) << ", "
                 //     << SNP2+1 << ", "
                      << MM->GetTotalAllele(SNP, true) << ", " 
                     // << MM->GetTotalFreqAllele(SNP, true) << ", " 
					  << MM->GetTotalAllele(SNP, false) << ", " 
                     // << MM->GetTotalFreqAllele(SNP, false) << ", " 
                      << MM->GetTotalMissing(SNP) << ", " << gs->GetTotalMissing(SNP, ic) << "\n";                
    
          } // end for each SNP a real SNP


    zap(MM);
    zap(MM2);

    //zap(gs2);
    //zap(gs);
    zap(Pos);
    cout << "\nInformation about pairwise measures has been saved in file " << filename2 <<"\n";

    OutputFile.close();


  };


};  // End of Namespace

#endif

/* End of file: MonolociMeasuresResults.h */



