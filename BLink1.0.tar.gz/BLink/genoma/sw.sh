#./GetSlidingWindowsUnrelated data/crossover.gou 0 0 2 0 50000 40000
#mv data/crossover.sw data/crossoverMLE.sw
#./GetSlidingWindowsUnrelated  data/crossover.gou 0 4 2 0 50000 40000
#mv data/crossover.sw data/crossoverBDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover10.gou 0 0 2 0 50000 40000
#mv data/crossover10.sw data/crossover10MLE.sw
./GetSlidingWindowsUnrelated data/crossover10.gou 0 4 2 0 50000 40000
#mv data/crossover10.sw data/crossover10BDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover5.gou 0 0 2 0 50000 40000
#mv data/crossover5.sw data/crossover5MLE.sw
./GetSlidingWindowsUnrelated data/crossover5.gou 0 4 2 0 50000 40000
#mv data/crossover5.sw data/crossover5BDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover5-60.gou 0 0 2 0 50000 40000
#mv data/crossover5-60.sw data/crossover5-60MLE.sw
./GetSlidingWindowsUnrelated data/crossover5-60.gou 0 4 2 0 50000 40000
#mv data/crossover5-60.sw data/crossover5-60BDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover5-120.gou 0 0 2 0 50000 40000
#mv data/crossover5-120.sw data/crossover5-120MLE.sw
./GetSlidingWindowsUnrelated data/crossover5-120.gou 0 4 2 0 50000 40000
#mv data/crossover5-120.sw data/crossover5-120BDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover10-60.gou 0 0 2 0 50000 40000
#mv data/crossover10-60.sw data/crossover10-60MLE.sw
./GetSlidingWindowsUnrelated data/crossover10-60.gou 0 4 2 0 50000 40000
#mv data/crossover10-60.sw data/crossover10-60BDistanceAlpha4.sw
./GetSlidingWindowsUnrelated data/crossover10-120.gou 0 0 2 0 50000 40000 
#mv data/crossover10-120.sw data/crossover10-120MLE.sw
./GetSlidingWindowsUnrelated data/crossover10-120.gou 0 4 2 0 50000 40000
#mv data/crossover10-120.ci data/crossover10-120BDistanceAlpha4.ci
