/* File: Diplotype.cpp */


#ifndef __Diplotype_cpp__
#define __Diplotype_cpp__

//#include <string.h>
//#include <cstdio>

//#include "list.h"
#include "Diplotype.h"

//using namespace UTILS;

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

Diplotype::Diplotype(){};

/*
Diplotype::Diplotype(const DiplotypeS D)
{
Dip.Left=D.Left;
Dip.Right=D.Right;
}
*/
/*____________________________________________________________ */

Diplotype::Diplotype (const Diplotype & source)
{
Dip=source.Dip;
}
/*____________________________________________________________ */

Diplotype::Diplotype (allele left, allele right)
{
Dip.Left=left;
Dip.Right=right;
}
/*____________________________________________________________ */

Diplotype::Diplotype (DiplotypeS Dip)
{
this->Dip=Dip;
}
/*____________________________________________________________ */

Diplotype::~Diplotype ()
{
}
/*____________________________________________________________ */

void Diplotype::OrderMajorFirst(allele MajorAllele)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

      if (IsHeterozygous(MajorAllele) && Dip.Left!=MajorAllele)
        ChangeAlleles();
 
}
/*____________________________________________________________ */

void Diplotype::OrderRandomly(allele MajorAllele)
{
	// for those heterozygous positions, rewrite alleles randomly
 unsigned short int random;

      if (IsHeterozygous(MajorAllele)) 
	  {
		random=rand() % (2);
//if (random==0) cout <<"0"; else cout <<"1";
		if (random==0 && Dip.Left!=MajorAllele)
        ChangeAlleles();
 	   if (random==1 && Dip.Left==MajorAllele)
        ChangeAlleles();
	  }
}

/*____________________________________________________________ */



bool Diplotype::IsHeterozygous (allele MajorAllele)
{

return IsANonMissingSNP() 
		&& 
		((Dip.Left==MajorAllele && Dip.Right!=MajorAllele) ||
		 (Dip.Left!=MajorAllele && Dip.Right==MajorAllele));
}

/*___________________________________________________*/

bool Diplotype::IsHomozygous1 (allele MajorAllele)
{
return IsANonMissingSNP() && Dip.Left==MajorAllele && Dip.Right==MajorAllele;
}

/*___________________________________________________*/


bool Diplotype::IsHomozygous2 (allele MajorAllele)
{
return IsANonMissingSNP() && Dip.Left!=MajorAllele && Dip.Right!=MajorAllele;
};

/*___________________________________________________*/

bool Diplotype::IsHomozygous (allele MajorAllele)
{
return IsHomozygous1(MajorAllele) ||  IsHomozygous2(MajorAllele);
};

/*___________________________________________________*/

bool Diplotype::IsEqual(Diplotype g)
{
return  Dip.Left==g.GetLeftAllele() && Dip.Right==g.GetRightAllele();

}

/*____________________________________________________________ */
           
bool Diplotype::IsANonMissingSNP ()
{
return Dip.Left!=0 && Dip.Right!=0;
}
/*____________________________________________________________ */
           
bool Diplotype::IsAMissingSNP ()
{
return !IsANonMissingSNP();
}

/*___________________________________________________________ */

void Diplotype::ChangeAlleles ()
{
change (Dip.Left,Dip.Right);
}
/*___________________________________________________________ */

void Diplotype::MarkAlleles ()
{
  Dip.Left=(allele)-(int)Dip.Left;
  Dip.Right=(allele)-(int)Dip.Right;
}
/*___________________________________________________________ */

bool Diplotype::IsMarked ()
{
  return (int)Dip.Left<0 || (int)Dip.Right<0;
}
/*__________________________________________________________*/

allele Diplotype::GetLeftAllele ()
{
	return Dip.Left;
}
/*__________________________________________________________*/

allele Diplotype::GetRightAllele ()
{
	return Dip.Right;
}
/*__________________________________________________________*/

void Diplotype::SetLeftAllele (allele Left)
{
	Dip.Left=Left;
}
/*__________________________________________________________*/

void Diplotype::SetRightAllele (allele Right)
{
	Dip.Right=Right;
}

/*____________________________________________________________ */

Diplotype Diplotype::operator=(const Diplotype Source)
{
Dip=Source.Dip;
}

/*____________________________________________________________ */

string Diplotype::print(bool markUnphased)
{
char line[10];
//line[0]='\0';
if (markUnphased)
sprintf(line, " %d %d", (int)Dip.Left, (int)Dip.Right);
else
sprintf(line, " %d %d", abs((int)Dip.Left), abs((int)Dip.Right));
return string(line);
}
/*____________________________________________________________ */

string Diplotype::print(HaplotypeType h)
{
char line[10];
if (h==left) sprintf(line, "%d\0", (int)Dip.Left);
else sprintf(line, "%d\0", (int)Dip.Right);
return string(line);
}


};  // End of Namespace

#endif

/* End of file: Genotype.h */




