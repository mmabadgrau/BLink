
/* File: GenomaSample.h */



#ifndef __GenomaSample_h__
#define __GenomaSample_h__

#include "Genoma.cpp"


     
        



namespace BIOS {
class GenomaSample: public PhenotypeSample, public GenotypeSample
//class GenomaSample: public list<Genoma>
 {
	 
       //  public:


    /** @name Implementation of class GenomaSample
        @memo Private part.
    */




  public:

 void setMarked(IndCategory ic,  int gender=everyGender, int affectation=allAffectation);


  /* PUBLIC FUNCTIONS (INTERFACE) */

      public:

  IndCategory currentIc;

  int currentGender, currentAffectation;

  bool *Marked;
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by individual.
           Time complexity O(1).

      */
	  virtual ~GenomaSample ();

	  Trio GetTrioMembers (PhenotypeSample::NodePointer IndPhenotype, GenotypeSample::NodePointer IndGenotype);

	   /**7
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

	  GenomaSample::GenomaSample();

	
      GenomaSample(PhenotypeSample& sourceP, GenotypeSample& sourceG); 

      GenomaSample(GenomaSample& source); 

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

//		GenomaSample(char* filename, unsigned short int ReduceSample, bool CompleteMissing, AlleleOrderType AlleleOrderMode);

		GenomaSample(char* filename, IndCategory i=everybody, AlleleOrderType AlleleOrderMode=MajorFirst);
		GenotypeSample::NodePointer GetGenotype (PhenotypeSample::NodePointer p);

		void WriteResults (char* filename, bool PrintPhenotypes=true, IndCategory ic=everybody, SNPPos first=0,SNPPos last=0, bool markUnphased=false);

		void RemoveByCategory (IndCategory ic);

		void ExportForML (char *filename);

		void ExportForMLHAP (char *filename);

		SNPPos GetTotalAllele (SNPPos SNP, bool IsMajor, IndCategory ic, int gender=everyGender, int affectation=allAffectation);

		allele getMajorAllele (SNPPos SNP, const IndCategory ic, int gender=everyGender, int affectation=allAffectation);

		allele getMinorAllele (SNPPos SNP, const IndCategory ic, int gender=everyGender, int affectation=allAffectation);

		SNPPos GetTotalType (SNPPos SNP, IndCategory ic, GenotypeType type, int gender=everyGender, int affectation=allAffectation) {	
	    	setMarked(ic, gender, affectation); return GenotypeSample::GetTotalType (SNP, type, Marked);};

		SNPPos GetTotalHomozygous1 (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::GetTotalHomozygous1(SNP, Marked);};

		SNPPos GetTotalHomozygous2 (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetTotalHomozygous2(SNP, Marked);};

		SNPPos GetTotalHeterozygous (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetTotalHeterozygous(SNP, Marked);};

		SNPPos GetTotalMissing (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetTotalMissing(SNP, Marked);};

		SNPPos GetTotalNonMissing (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetTotalNonMissing(SNP, Marked);};

		SNPPos GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetDoubleHeterozygous(FirstSNP, LastSNP, Marked);};

		SNPPos GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool phase, int gender=everyGender, int affectation=allAffectation){ setMarked(ic, gender, affectation); return GenotypeSample::GetUnsolvedDoubleHeterozygous(FirstSNP, LastSNP, Marked);};

    		SNPPos* getAlleleFrequencies(allele alleleType, IndCategory ic,  int gender=everyGender, int affectation=allAffectation) {setMarked(ic, gender, affectation);
		return GenotypeSample::getAlleleFrequencies(alleleType, Marked);};

		//void ComputeHaps (hprobs probs, SNPPos SNP1, SNPPos SNP2, LDType mode, bool Semi, unsigned short int Bayes);
		SNPPos GetHap (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool IsMajor1, bool IsMajor2, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::GetHap(FirstSNP, LastSNP, IsMajor1, IsMajor2, Marked);};

		SNPPos GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::GetnAB(SNP1, SNP2, Marked);};

		SNPPos GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::GetnAb(SNP1, SNP2, Marked);};

		SNPPos GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::GetnaB(SNP1, SNP2, Marked);};
		
		SNPPos Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation) { setMarked(ic, gender, affectation); return GenotypeSample::Getnab(SNP1, SNP2, Marked);};
                GenomaSample* copyElementsWithPositionsIn(intList* positions, bool inThis=true);
		};  // End of class GenomaSample
};  // Fin del Namespace

#endif

/* Fin Fichero: GenomaSample.h */
