./ChangeFormat i HTYPER data/chrom1HTYPERSeptember2004.sal chrom1HTYPERSeptember2004.txt c 0 100 30 2 0

