/* File: positions.h */



#ifndef __positions_h__
#define __positions_h__

#include <string>


#include "Exceptions.h"



namespace SNP {


/************************/
/* positions DEFINITION */
/************************/


/**
        @memo positions for SNPs

	@doc
        Definition:
        A set of phenotype's features and genotypes for an positions

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in the sample
        Each positions in a sample has been genotyped for the same TotalSNPs SNPs.

        @author Maria M. Abad
	@version 1.0
*/

	 class positions
	 {

  protected:
    /** @name Implementation of class positions
        @memo Private part.
    */

  typedef struct position
  {
  float pos;
  unsigned int filepos;
  position *Next;
  position *Previous; 
  };

  position *TheFirstPosition;



/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/

  unsigned int TotalSNPs;

  bool Unordered;

//  char *genotypebuf;

        
//	 typefile tf;


/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////
  /// PRIVATE ////////
  /////////////////////

void destroy(position * Position);

void ReadInfo (ifstream * origen, position *targetpos);

void copy(position * Target, const position * Origen);

      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */
	/*  void WriteResults (char* filename);   
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by positions.
           Time complexity O(1).

      */
	  ~positions ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
	  positions(unsigned int TotalSNPs);


  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		positions(const positions& origen); 


//	  positions(const phenotype& porigen, const genotype& gorigen, IndCategory ic);

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		positions(const char* filename, unsigned int TotalSNPs); 

        void GetInfo(ifstream *InputFile, unsigned int TotalS);

		  
	  /**
         @memo Creates a new positions objet with the phase resolved.
         @param Origen: the origianl positions object 
         Time complexity O(TotalSNPs*Size*Size)

      */
		 void OrderByPosition ();   


	 	bool IsUnordered ();   



		void PrintPositions (char* filename, unsigned int FirstSNP, unsigned int TotalSNPs2);

		float GetPosition (unsigned long int Pos);

		unsigned long int GetExtremeSNP(unsigned long int Pos, unsigned long int SlideSize);

		bool IsANewSNP (unsigned long int SNP);



};  // End of class positions



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

void positions::destroy(positions::position * Position)
{
 assert (Position != NULL);
 destroy (Position->Next);
 delete Position;
};


/*___________________________________________________________ */

void positions::ReadInfo (ifstream* origen, position *targetpos)
{

	char *genotypebuf, *cad;
    if ((genotypebuf=new char[20])==NULL)
     throw NoMemory();


     float pos;


  	origen-> getline (genotypebuf, 20, '\n');
	cad = strtok (genotypebuf," \t");
	sscanf (cad, "%f", &pos);
	targetpos->pos= pos;
	if (TotalSNPs>0)
	if (pos<((targetpos->Previous)->pos))
	{
     Unordered=true;
	 //cout << "\ndesordenado, " << pos << "menor que " << (targetpos->Previous)->pos;
	}
	targetpos->filepos=TotalSNPs;

	assert (genotypebuf!=NULL);
    delete genotypebuf;

	if ((targetpos->Next=new position)==NULL)
     throw NoMemory();
	targetpos->Next->Previous=targetpos;
	
	TotalSNPs++;
	if ((origen->peek()!=EOF) && (origen->peek()!='\n'))
     ReadInfo (origen, targetpos->Next);



}

/*___________________________________________________________ */

void positions::copy(position * Target, const position * Origen)
{

  Target->pos=Origen->pos;
  Target->filepos=Origen->filepos;


 		 
 if (Origen->Next!=NULL)
 {
  if ((Target->Next=new position)==NULL)
   throw NoMemory();

  Target->Next->Previous=Target;
  TotalSNPs++;

  copy(Target->Next,Origen->Next);     
 }  
 else Target->Next=NULL;
}



/*____________________________________________________________ */

void positions::GetInfo(ifstream *InputFile, unsigned int TotalS)
{

TotalSNPs=0;
cout << "Reading positions ...\n";

try
{
 if (InputFile->peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage();
}


try {
if ((this->TheFirstPosition=new position)==NULL)
      throw NoMemory();
ReadInfo (InputFile,this->TheFirstPosition);

  }
catch (NoMemory no) {
  no.PrintMessage();
  }
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage();
   }


if (TotalSNPs != TotalS)
{
 cerr << "There are " << TotalSNPs <<" loci in the file but you have especified that the number is " << TotalS << "\n";
 exit(0);
}

cout <<"Positions reading has finished\n";

};

///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

positions::positions(unsigned int TotalSNPs)
{
	Unordered=true;
};


/*____________________________________________________________ */

positions::positions(const positions& origen)
{
Unordered=false;	
TotalSNPs=0;

  if (&origen==NULL)
  TheFirstPosition=NULL; 


else 
{
 if ((TheFirstPosition=new position)==NULL)
   throw NoMemory();
try 
{
 copy (TheFirstPosition, origen.TheFirstPosition);
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}
}


if (TotalSNPs != origen.TotalSNPs)
{
 cerr << "There are " << origen.TotalSNPs <<" loci in the original sample but only " << TotalSNPs << " has been copied\n";
 exit(0);
}

cout <<"Positions copying has finished\n";


};




/*____________________________________________________________ */

positions::positions(const char* filename, unsigned int TotalS)
{
Unordered=false;
char *IDs;


if ((IDs=new char[1400])==NULL)
 throw NoMemory();
	
ifstream InputFile; 

try
{
 InputFile.open (filename, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage();
   }


try {
if ((this->TheFirstPosition=new position)==NULL)
      throw NoMemory();
	GetInfo (&InputFile, TotalS);
  }
catch (NoMemory no) {
  no.PrintMessage();
  }

InputFile.close();
}


/*____________________________________________________________ */

bool positions::IsUnordered ()
{
	return Unordered;
}

/*____________________________________________________________ */

positions::~positions ()
{
	positions::destroy(TheFirstPosition);
}

/*____________________________________________________________ */

void positions::PrintPositions (char* filename, unsigned int FirstSNP, unsigned int TotalSNPs2)
 {
  FILE * OutputFile; 
  position *IndPosition=TheFirstPosition; 
  try
{
  OutputFile=fopen (filename, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
for (int i=0; i<(FirstSNP+TotalSNPs2);i++)
  {
	if ((i>=FirstSNP) && (i<(FirstSNP+TotalSNPs2)))
     fprintf(OutputFile, "%.0f\n", IndPosition->pos);
   IndPosition=IndPosition->Next;
	}
  
 fclose(OutputFile);


 }

/*____________________________________________________________ */

float positions::GetPosition(unsigned long int SNP)
{
// Pos is the order number of the SNP
position *i=TheFirstPosition;
  unsigned long int cont=0;
  try {
//while (i!=NULL)
//{
//i->Next;
//cont++;
//}

  for (unsigned long int c=0;c<SNP;c++)
  {
   if (i==NULL)
    throw NullValue();
     i=i->Next;
 // cout << Pos;
  }
  }
  catch (NullValue null) {
    null.PrintMessage();
    }

 // return i->pos;
  return i->pos;
};
/*____________________________________________________________ */

unsigned long int positions::GetExtremeSNP(unsigned long int SNP, unsigned long int SlideSize)
{
  position *i=TheFirstPosition;
  float InitialPos;
  unsigned long int cont=0, c;
  try {

  for (c=0;c<SNP;c++)
  {
   if (i==NULL)
    throw NullValue();
     i=i->Next;
  }
InitialPos=i->pos;
c--;
do
{
 i=i->Next;
 if (i!=NULL) c++;
}
while ((i!=NULL) && (((i->pos)-InitialPos)<SlideSize));

  }
  catch (NullValue null) {
    null.PrintMessage();
    }

 // return i->pos;
  return c;
}
/*____________________________________________________________ */

bool positions::IsANewSNP (unsigned long int SNP)
{
 if ((SNP>0) && (GetPosition(SNP)==GetPosition(SNP-1)))
	 return false;
 else return true;
}

/*____________________________________________________________ */


};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
