dircode="/home/mabad/genoma"
if [ $# -ne 4 ]
then
echo This macro needs three arguments: the first with the name of the sample -Yoruba/China/Japan/US- the second with the achronym -YRI, CHB, JPT, CEU- respectively and the third and fourth with the name of month and the year respectively
exit 0 
fi 
cd "/home/mabad/hapmap"$3$4/$1
echo Change to directory hapmap$3$4/$1 
#cp $dircode/pedigree.txt $1
echo Convert to ped format
#chromosome="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
 chromosome="4 8"
for a in $chromosome
do
# echo $a 
inputfile="genotypes_chr"$a"_"$2".txt"
outputfile="chromosome"$a"_"$2$3$4".gen"
originalfile="genotypes_chr"$a"_"$2".txt.gz"
mv $originalfile $inputfile
$dircode/hapmap $inputfile $1 $outputfile
$dircode/OrderPositions $outputfile


echo Converted to dhap format
done
