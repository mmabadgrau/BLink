/* File: PairwiseMeasure.h */


#ifndef __PairwiseMeasure_h__
#define __PairwiseMeasure_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "Positions.h"
#include "Tables2x2.h"
#include "MonolociMeasure.h"
#include "Sampling.h"

using namespace stats;

namespace BIOS {


/************************/
/* SNP'S PairwiseMeasure DEFINITION */
/************************/


/**
        @memo PairwiseMeasure for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	template <class T> class PairwiseMeasure: public Table2x2 {


private:

    /** @name Implementation of class PairwiseMeasure
        @memo Private part.
    */

	  BayesType Bayes;

	  IndCategory ic;

	  T * sample;

	  IndPos nAB, nAb, naB, nab, totalknown, totalhaplotypes, SNPPos nHH, nA, nB;

	  double fA, fB;

	  bool IsPartiallySolved;

	  SNPPos SNP1, SNP2;

	  char line[50];

/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

    double GetnxyKnown(bool IsMajor1, bool IsMajor2);

	char* PrintHaplotypeFrequencies();

		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on PairwiseMeasure 
        @memo Operations on a PairwiseMeasure 
    */
	PairwiseMeasure(SNPPos SNP1, SNPPos SNP2, T * samp, const BayesType & Bay, const IndCategory & i, const bool IsPartiallySol);

	double GetTotalKnown();

	double GetnABKnown();

	double GetnAbKnown();
	
	double GetnaBKnown();
	
	double GetnabKnown();

	double GetfAB();

	double GetDPrime();

	IndPos SetBootstrapFrequencies(double *DPrimeList, unsigned long int size);


};  // End of class PairwiseMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

template <class T> PairwiseMeasure<T>::PairwiseMeasure(SNPPos S1, SNPPos S2, T * samp, const BayesType & Bay, const IndCategory & i, const bool IsPartiallySol)
{
	SNP1=S1;
	SNP2=S2;
	sample=samp; 
	Bayes=Bay; 
	ic=i; 
	IsPartiallySolved=IsPartiallySol;

	if (sample->GetTotalNonMissing(SNP1, ic)!=sample->GetTotalNonMissing(SNP2, ic))
	{
	cout <<"Error in GetfAB: different number of nonmissing alleles";
	exit(0);
	}
	nAB=sample->GetHap(SNP1, SNP2, ic, true, true, IsPartiallySolved);
	nAb=sample->GetHap(SNP1, SNP2, ic, true, false, IsPartiallySolved);
	naB=sample->GetHap(SNP1, SNP2, ic, false, true, IsPartiallySolved);
	nab=sample->GetHap(SNP1, SNP2, ic, false, false, IsPartiallySolved);
	nHH=sample->GetUnsolvedDoubleHeterozygous(SNP1, SNP2, ic, IsPartiallySolved);
	totalknown=nAB+nAb+naB+nab;
	totalhaplotypes=totalknown+2*nHH;

	nA=nAB+nAb+nHH;
	nB=nAB+naB+nHH;

	fA=(AddBayesAllele(nAB+nAb)+nHH)/(double)(AddBayesAllele(nAB+nAb)+AddBayesAllele(naB+nab)+2*nHH);
	fB=(AddBayesAllele(nAB+naB)+nHH)/(double)(AddBayesAllele(nAB+naB)+AddBayesAllele(nAb+nab)+2*nHH);

	if (fA<0.5 || fB<0.5)
		{
		cout <<"error, major allele should be minor allele";
		exit(0);
	}
		if (fA==1.0 || fB==1.0)
		{
		cout <<"error, no SNP";
		exit(0);
	}
}

/*____________________________________________________________ */

template <class T> char* PairwiseMeasure<T>::PrintHaplotypeFrequencies ()
{
	char *p=line;
	strcpy(line, "\0");
	sprintf(line, "nAB: %d, nAb: %d, naB: %d, nab: %d", nAB, nAb, naB, nab);
	return p;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfAB()
{

	return EstimateMLE (fA*fB, nHH, AddBayesHap(nAB, Bayes), totalknown, fA, fB, 1000);//fAB
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetDPrime()
{

double fAB= EstimateMLE (fA*fB, nHH, AddBayesHap(nAB, Bayes), totalknown, fA, fB, 1000);//fAB

return T2x2::GetDPrime(fAB, fA, fB);
}
/*____________________________________________________________ */

template <class T> IndPos PairwiseMeasure<T>::SetBootstrapFrequencies(double* DPrimeList, unsigned long int size)
{
Sampling * bootstrap;

IndPos bnHH, bnAB=0, bnAb=0, bnaB=0, bnab=0;

IndPos totalused=0;
for (int s=0; s<1000;s++)
{
DPrimeList[s]=(double)maxreal;
cout <<"\n" << s;
if ((bootstrap = new Sampling(totalhaplotypes, true))==NULL) // true allows repetitions
 throw NoMemory();

for (IndPos i=0;i<total;i++)
 if (bootstrap->Pos[i]<nAB) bnAB++; else
	  if (bootstrap->Pos[i]<(nAb+nAB)) bnAb++; else
	  if (bootstrap->Pos[i]<(nAb+nAB+naB)) bnaB++; else 
	  	  if (bootstrap->Pos[i]<(nAb+nAB+naB+nab)) bnab++; else bnHH++;

double bfA=bnAB+bnAb+bnHH;
double bfB=bnAB+bnaB+bnHH;

if (bfA<0.5)
{
change(bnAB, bnaB);
change(bnAb, bnab);
};
if (bfB<0.5)
{
change(bnAB, bnAb);
change(bnaB, bnab);
};

double btotalknown=AddBayesHap(bnAB, Bayes)+AddBayesHap(bnAb, Bayes)+AddBayesHap(bnaB, Bayes)+AddBayesHap(bnab,Bayes);
bfA=(AddBayesAllele(bnAB+bnAb+bnHH, Bayes))/(totalknown+2*bnHH);
bfB=(AddBayesAllele(bnAB+bnaB+bnHH, Bayes))/(totalknown+2*bnHH);
if (bfA<1 && bfB<1)
{
bnAB=AddBayesHap(bnAB, Bayes);
double bfAB=T2x2.EstimateMLE(bfA*bfB, bnHH, bnAB, btotalknown, bfA, bfB, 1000);//fAB
DPrimeList[s]=T2x2.GetDPrime(bfAB, bfA, bfB);
totalused++;
}
}
return totalused;
}
};  // End of Namespace

#endif

/* End of file: PairwiseMeasure.h */




