/* File: ChangeFormat.h */


#ifndef __EM_h__
#define __EM_h__


#include <string>


#include "Exceptions.h"





/*_________________________________________________________________________*/

void EstimateMLE (unsigned int* comb, double * probs, unsigned int total, int it=1000)
{
Phenotype * IndPhenotype=TheFirstPhenotype;
Genotype * IndGenotype=TheFirstGenotype;

double PhaseFrequencies[2], probs2[4], t, denominator=probs[0]*probs[3]+probs[1]*probs[2];
// error if probs[0]*probs[3]+probs[1]*probs[2] equals to 0, but it shouldn't happen,
// because in this case we would not have a pair of SNPs
if (denominator==0) 
 throw ZeroValue();

 PhaseFrequencies[0]=probs[0]*probs[3]/denominator;
 PhaseFrequencies[1]=probs[1]*probs[2]/denominator;


 probs2[0]=(comb[0]+comb[4]*PhaseFrequencies[0])/(double)(total+2*comb[4]); // AB
 probs2[2]=(comb[2]+comb[4]*PhaseFrequencies[1])/(double)(total+2*comb[4]); // aB
 probs2[1]=(comb[1]+comb[4]*PhaseFrequencies[1])/(double)(total+2*comb[4]); // Ab
 probs2[3]=(comb[3]+comb[4]*PhaseFrequencies[0])/(double)(total+2*comb[4]); // ab
 
 t=probs2[0]+probs2[1]+probs2[2]+probs2[3];
 if (fabs(1-t)>0.0001) 
	 {
	 cout << "ERR" << t;

for (int i=0;i<4;i++)
 cout << "\nprobs2["<< i << "]:" << probs2[i] << ", comb["<< i << "]:" << comb[i];
cout << ", comb[4]:" << comb[4];
 exit (0);
 }



 
 bool end=true;

 for (int i=0;i<4;i++)
 {
 if (fabs(probs[i]-probs2[i])>= 0.00005)
	 end=false;
 if (it>0)
	 end=false;
 probs[i]=probs2[i];
 }
it--; 
if (!end) EstimateMLE (comb, probs, total, it);
}
