/* File: PairwiseMeasure.h */


#ifndef __PairwiseMeasure_h__
#define __PairwiseMeasure_h__

//#include <string.h>
//#include <cstdio>

#include "../commonc++/list.h"
#include "../commonc++/basic.h"

#include "Positions.h"
#include "Tables2x2.h"
#include "MonolociMeasure.h"
#include "Sampling.h"
#include "TrioSample.h"
#include "math.h"

using namespace stats;

namespace BIOS {


/************************/
/* SNP'S PairwiseMeasure DEFINITION */
/************************/


/**
        @memo PairwiseMeasure for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	template <class T> class PairwiseMeasure {


private:

    /** @name Implementation of class PairwiseMeasure
        @memo Private part.
    */

	  BayesType Bayes;

	  IndCategory ic;

	  T * sample;

	  IndPos nAB, nAb, naB, nab, totalknown, totalhaplotypes, nHH, nA, nB;

	  bool IsPartiallySolved;

	  SNPPos SNP1, SNP2;

	  char *line;

	  bool missing;

	  struct FreqAndVal *DPrimeList;

	  //bool *Marked;

/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

    double GetnxyKnown(bool IsMajor1, bool IsMajor2);

	char* PrintHaplotypeFrequencies();

	void CheckFrequency (double f, bool fa);


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on PairwiseMeasure 
        @memo Operations on a PairwiseMeasure 
    */
	PairwiseMeasure(SNPPos SNP1, SNPPos SNP2, T * samp, BayesType  Bay, IndCategory  i, bool IsPartiallySol);

	~PairwiseMeasure()
	{
		if (line!=NULL) delete line;
		if (DPrimeList!=NULL) delete DPrimeList;
	};

	unsigned int GetTotalUnKnown ();

	double GetTotalKnown();

	double GetTotalKnown(IndPos nAB, IndPos nAb, IndPos naB, IndPos nab);

	double GetfAB();

	double GetfA();

	double GetfB();

	double GetnAB();

	double GetnAb();

	double GetnaB();

	double Getnab();

	double GetnAB(IndPos n);

	double GetnAb(IndPos n);

	double GetnaB(IndPos n);

	double Getnab(IndPos n);

	//IndPos SetBootstrapFrequenciesOld(double *DPrimeList, unsigned long int size);

	IndPos SetBootstrapFrequencies(double* DPrimeList, unsigned long int size);

	IndPos SetBootstrapFrequenciesFast(double* DPrimeList, unsigned long int size);

	void GetSampleFrequencies(IndPos & bnAB, IndPos & bnAb,IndPos & bnaB,IndPos & bnab);

	void SetDPrimeDistribution();

	void SetDDistribution();

	double GetMaxDPrime();

	double GetQuantileDPrime (float quantile);

};  // End of class PairwiseMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

template <class T> PairwiseMeasure<T>::PairwiseMeasure(SNPPos S1, SNPPos S2, T * samp, BayesType Bay, IndCategory i, const bool IsPartiallySol=false)
{
	line=NULL;
	SNP1=S1;
	SNP2=S2;
	//cout <<"\nSNP1: " << SNP1 << ", SNP2:" << SNP2;
	sample=samp; 
	Bayes=Bay; 
	ic=i; 
	IsPartiallySolved=IsPartiallySol;
	missing=false;
	if (sample->GetTotalNonMissing(SNP1, ic)!=sample->GenotypeSample::GetSize() || sample->GetTotalNonMissing(SNP2, ic)!=sample->GenotypeSample::GetSize())
	{
//	cout <<"Error in PairwiseMeasure: different number of nonmissing alleles";
//	exit(0);
	missing=true;
	}
	nAB=sample->GetHap(SNP1, SNP2, ic, true, true, IsPartiallySolved);
	nAb=sample->GetHap(SNP1, SNP2, ic, true, false, IsPartiallySolved);
	naB=sample->GetHap(SNP1, SNP2, ic, false, true, IsPartiallySolved);
	nab=sample->GetHap(SNP1, SNP2, ic, false, false, IsPartiallySolved);
	nHH=sample->GetUnsolvedDoubleHeterozygous(SNP1, SNP2, ic, IsPartiallySolved);


	totalknown=nAB+nAb+naB+nab;
	totalhaplotypes=totalknown+2*nHH;
	nA=nAB+nAb+nHH;
	nB=nAB+naB+nHH;
	DPrimeList=NULL;

//	if (S1==16 && S2==60) 
	{
//		cout << PrintHaplotypeFrequencies();
		//exit(0);
	}

}

/*____________________________________________________________ */

template <class T> void PairwiseMeasure<T>::CheckFrequency (double f, bool fa)
{

char message[100];
if (f<0.5)
{
if (fa)
sprintf(message, "%s", " PairwiseMeasure::CheckFrequency of fA");
else
sprintf(message, "%s", " PairwiseMeasure::CheckFrequency of fB");

cout <<"error, major allele should be minor allele between SNPs " << SNP1+1 << " and " << SNP2+1;
cout <<PrintHaplotypeFrequencies();
cout <<"nHH:" << nHH << message;
exit(0);
}
try
{
if (f==1.0)
{
	 throw NonSNP();
	 //sprintf (line, "%d", "PairwiseMeasure::CheckFrequency
}
}

catch (NonSNP ns) { ns.PrintMessage(message);};

	
}

/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnAB ()
{

	return  AddBayesHap(nAB, Bayes);
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnAb ()
{

	return  AddBayesHap(nAb, Bayes);
}/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetnaB ()
{

	return  AddBayesHap(naB, Bayes);
}/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::Getnab ()
{

	return  AddBayesHap(nab, Bayes);
}


/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfA ()
{


	double den=AddBayesAllele(nAB+nAb, Bayes)+AddBayesAllele(naB+nab, Bayes)+2*nHH;
	double num=AddBayesAllele(nAB+nAb, Bayes)+nHH;
	double fA=num/den;
//	cout <<"num:"<< num <<"den:" << den;
	if (!missing)
	CheckFrequency (fA, true);
	return fA;

}


/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfB ()
{
	double den=AddBayesAllele(nAB+naB, Bayes)+AddBayesAllele(nAb+nab, Bayes)+2*nHH;
	double num=AddBayesAllele(nAB+naB, Bayes)+nHH;
	double fB=num/den;
//	cout <<"num:"<< num <<"den:" << den;
	if (!missing)
     CheckFrequency (fB, false);
	return fB;

}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetTotalKnown (IndPos nAB, IndPos nAb, IndPos naB, IndPos nab)
{

return AddBayesHap(nAB, Bayes)+AddBayesHap(nAb, Bayes)+AddBayesHap(naB, Bayes)+AddBayesHap(nab, Bayes);
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetTotalKnown ()
{

return GetTotalKnown(nAB, nAb, naB, nab);			
}
/*____________________________________________________________ */

template <class T> unsigned int PairwiseMeasure<T>::GetTotalUnKnown ()
{
return nHH;			
}
/*____________________________________________________________ */

template <class T> char* PairwiseMeasure<T>::PrintHaplotypeFrequencies ()
{
	if (line==NULL)
	line=Initialize(50, ' ');
	//char *p=line;
	strcpy(line, "\0");
	sprintf(line, "nAB: %d, nAb: %d, naB: %d, nab: %d", nAB, nAb, naB, nab);
	return line;
}
/*____________________________________________________________ */

template <class T> double PairwiseMeasure<T>::GetfAB()
{
Table2x2 T2x2;

double fA=GetfA(), fB=GetfB(), totalknownBayes=GetTotalKnown();

if (fA==0  || fB==0){cout <<"error in PairwiseMeasure::getfAB"; exit(0);};


return T2x2.EstimateMLE (fA*fB, nHH, AddBayesHap(nAB, Bayes), totalknownBayes, fA, fB, 1000);//fAB
}
/*____________________________________________________________ */
/*
template <class T> void PairwiseMeasure<T>::GetSampleFrequencies(IndPos & bnAB, IndPos & bnAb,IndPos & bnaB,IndPos & bnab)
{
Sampling * bootstrap;

bnAB=0, bnAb=0, bnaB=0, bnab=0;

//IndPos bnHHhap=0;

if ((bootstrap = new Sampling(totalknown, true))==NULL) // true allows repetitions
 throw NoMemory();


for (IndPos i=0;i<totalknown;i++)
 if (bootstrap->Pos[i]<nAB) bnAB++; else
	  if (bootstrap->Pos[i]<(nAb+nAB)) bnAb++; else
	  if (bootstrap->Pos[i]<(nAb+nAB+naB)) bnaB++; else bnab++;
	  //	  if (bootstrap->Pos[i]<(nAb+nAB+naB+nab)) bnab++; else bnHHhap++;

if (bnAB+bnAb+bnaB+bnab!=totalknown)
{
cout <<"ERR	OR IN BOOTSrap;" << "totl:" << totalhaplotypes <<"new:" << bnAB+bnAb+bnaB+bnab;
exit(0);
}

//bnHH=bnHHhap/(double)2;


}
/*____________________________________________________________ */
/*
template <class T> IndPos PairwiseMeasure<T>::SetBootstrapFrequenciesOld(double* DPrimeList, unsigned long int size)
{
Table2x2 T2x2;
Sampling * bootstrap;

IndPos bnAB, bnAb, bnaB, bnab;

double bnHH=nHH;

IndPos totalused=0;

for (int s=0; s<size;s++)
{
GetSampleFrequencies(bnAB, bnAb, bnaB, bnab);

//cout <<s <<"\n";

double bfA=bnAB+bnAb+bnHH;
double bfB=bnAB+bnaB+bnHH;

if (bfA<0.5)
{
change(bnAB, bnaB);
change(bnAb, bnab);
};
if (bfB<0.5)
{
change(bnAB, bnAb);
change(bnaB, bnab);
};

double btotalknown=GetTotalKnownBayes(bnAB, bnAb, bnaB, bnab);
bfA=(AddBayesAllele(bnAB+bnAb, Bayes)+bnHH)/(double)(btotalknown+2*bnHH);
bfB=(AddBayesAllele(bnAB+bnaB, Bayes)+bnHH)/(double)(btotalknown+2*bnHH);

DPrimeList[s]=2.0;

if (bfA<1 && bfB<1)
{
//cout <<"bnAB:" << bnAB <<", bnAb:" << bnAb <<", bnaB:" << bnaB << ", bnab:" << bnab;
//cout <<"bnHH:" << bnHH <<"\n";

	
double bfAB=T2x2.EstimateMLE(bfA*bfB, bnHH, AddBayesHap(bnAB, Bayes), btotalknown, bfA, bfB, 1000);//fAB
DPrimeList[s]=T2x2.GetDPrime(bfAB, bfA, bfB);
totalused++;
}
}
return totalused;
}
/*____________________________________________________________ */
/*
void PairwiseMeasure<GenomaSample>::GetIndividualSample(const SNPPos TrioSample, SNPPos IndividualSample)
{
 Sampling * bootstrap;
 if ((bootstrap = new Sampling(sample->GenotypeSample::TotalTrios, true))==NULL) // true allows repetitions
 throw NoMemory();
 GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
 PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
 short int TotalMembers;
// take a sampling of trios and create a sampling of individuals
 InitializeList(IndividualSample, sample->GenotypeSample::GetSize(), (IndPos)maxint);
 for (SNPPos i=0;i<TotalTrios;i++)
 {
  TotalMembers=0;
  while (IndGenotype!=NULL && IndPhenotype!=NULL && TotalMembers<3)
  {
   if 

/*____________________________________________________________ */
/*
template <class T> IndPos PairwiseMeasure<T>::SetBootstrapFrequencies(double* DPrimeList, unsigned long int size)
{
Table2x2 T2x2;
T* g;
PairwiseMeasure<T> *PM;
InitializeList(DPrimeList, size, (double)2.0);
IndPos TotalIndividuals=sample->GenotypeSample::GetSize(), TotalTrios=TotalIndividuals/3;
IndPos IndividualSample[TotalIndividuals];
double fA, fB, fAB;

IndPos totalused=0;

for (int s=0; s<size;s++)
{
GetIndividualSample(IndividualSample);
g=new GenomaSample (*this, IndividualSample);
MonolociMeasure<GenomaSample> MM = MonolociMeasure<T>(g, (BayesType)0, ic);
if (MM.GetTotalFreqAllele(SNP1, false)>0) 
{
PM = new PairwiseMeasure<T>(SNP1, SNP2, g, Bayes, ic, IsPartiallySolved);
fA=PM->GetfA();
fB=PM->GetfB();
fAB=PM->GetfAB();
DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
}
}
return totalused;
}
*/
/*____________________________________________________________ */
/*
template <class T> IndPos PairwiseMeasure<T>::SetBootstrapFrequencies(double* DPrimeList, unsigned long int size)
{
Sampling * bootstrap;
Table2x2 T2x2;
IndPos Total=sample->GenotypeSample::GetSize(), totalused=0;
T* g;
double fA, fB, fAB;
InitializeList(DPrimeList, size, (double)2.0);

for (int s=0; s<size;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();
g=new T(*sample, bootstrap->Pos, Total, MajorFirst);
MonolociMeasure<T> MM = MonolociMeasure<T>(g, (BayesType)0, ic);
if (MM.GetTotalFreqAllele(SNP1, false)>0) 
{
PM = new PairwiseMeasure<T>(SNP1, SNP2, g, Bayes, ic, IsPartiallySolved);
fA=PM->GetfA();
fB=PM->GetfB();
fAB=PM->GetfAB();
DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
}
}
return totalused;
}
*/
/*____________________________________________________________ */

IndPos PairwiseMeasure<TrioSample>::SetBootstrapFrequencies(double* DPrimeList, unsigned long int size)
{
Sampling * bootstrap;
Table2x2 T2x2;
IndPos Total=sample->GetTotalTrios(), totalused=0;
TrioSample* g;
double fA, fB, fAB;
InitializeList(DPrimeList, size, (double)2.0);
PairwiseMeasure<TrioSample> *PM;

for (int s=0; s<size;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();

g=new TrioSample(*sample, bootstrap->Pos, Total, MajorFirst);

MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(g, (BayesType)0, ic);

if (MM.GetTotalFreqAllele(SNP1, false)>0 && MM.GetTotalFreqAllele(SNP2, false)>0) 
{
PM = new PairwiseMeasure<TrioSample>(SNP1, SNP2, g, Bayes, ic, IsPartiallySolved);
fA=PM->GetfA();
fB=PM->GetfB();
fAB=PM->GetfAB();
DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
delete PM;
}

delete g;
delete bootstrap;
}

return totalused;
}
/*____________________________________________________________ */

IndPos PairwiseMeasure<TrioSample>::SetBootstrapFrequenciesFast(double* DPrimeList, unsigned long int size)
{
Sampling * bootstrap;
Table2x2 T2x2;
IndPos Total=sample->GetTotalTrios(), totalused=0;
if (ic==parent) Total=Total*2;
if (ic==everybody) Total=Total*3;
TrioSample* g;
double fA, fB, fAB;
InitializeList(DPrimeList, size, (double)2.0);
PairwiseMeasure<TrioSample> *PM;

GenotypeCode ReducedGenotypes[Total], Boot[Total];
IndPos Counters[12];
InitializeList(Counters, (unsigned long int)12, (IndPos)0);
Genoma* G;
list<Trio>::NodePointer TrioPos=sample->TrioList->GetFirst();

IndPos i=0;

while (TrioPos!=NULL)
{
	
for (int m=0; m<=2; m++)
if (ic==(IndCategory)m || ic==everybody || (ic==parent && m<2))
{
 G=new Genoma(TrioPos->element, (IndCategory)m);
 ReducedGenotypes[i]=G->GetGenotypeCode(SNP1, SNP2, sample->MajorAllele);
 i++;
}

 TrioPos=sample->TrioList->GetNext(TrioPos);
}
bool invertedA=false, invertedB=false;
IndPos na, nb;
for (int s=0; s<size;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();
for (IndPos i=0;i<Total;i++)
{
	Boot[i]=ReducedGenotypes[bootstrap->Pos[i]];
	Counters[(int)Boot[i]]++;
}
//typedef enum {Missing=0, ABAB=1, ABAb=2, ABaB=3, ABab=4, AbAb=5, AbaB=6, Abab=7, aBaB=8, aBab=9, abab=10, Unphased=11} GenotypeCode ; // 

nA=2*Counters[1]+2*Counters[2]+Counters[3]+Counters[4]+2*Counters[5]+Counters[6]+Counters[11];
na=Counters[3]+2*Counters[4]+Counters[6]+Counters[7]+2*Counters[8]+2*Counters[9]+2*Counters[10]+Counters[11];
if (na>nA) 
{
change(nA, na);
invertedA=true;
}

nB=2*Counters[1]+Counters[2]+2*Counters[3]+Counters[4]+Counters[6]+2*Counters[8]+Counters[9]+Counters[11];
nb=Counters[2]+Counters[4]+2*Counters[5]+Counters[6]+2*Counters[7]+Counters[9]+2*Counters[10]+Counters[11];
if (nb>nB) 
{
change(nB, nb);
invertedB=true;
}

if (!invertedA && !invertedB)
nAB=2*Counters[1]+Counters[2]+Counters[3]+Counters[4];
if (invertedA && !invertedB) // aB
nAB=Counters[3]+Counters[6]+2*Counters[8]+Counters[9];
if (!invertedA && invertedB) // Ab
nAB=Counters[2]+2*Counters[5]+Counters[6]+Counters[7];
if (!invertedA && !invertedB) // ab
nAB=Counters[4]+Counters[7]+Counters[9]+2*Counters[10];

nHH=Counters[12];

totalknown=nAB+nAb+naB+nab;
totalhaplotypes=totalknown+2*nHH;
fA=GetfA();
fB=GetfB();
fAB=GetfAB();

DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
delete bootstrap;
} // for each boostrap sample
return totalused;
}

/*____________________________________________________________ */

void PairwiseMeasure<TrioSample>::SetDPrimeDistribution()
{
double DMax, D, freq;
double fA=GetfA(), fB=GetfB(), fAB=GetfAB(), fAb, faB, fab;
double nAB=GetnAB(), nAb=GetnAb(), naB=GetnaB(), nab=Getnab();

DPrimeList=new struct FreqAndVal[101];
int cont=0;
for (int c=0; c<=100; c++)
{
 DPrimeList[c].frequency=0;
 DPrimeList[c].value=c/(float)100;
 cont=0;
 //cout <<"\nDPrime:" << DPrimeList[c].value;
 for (int sign=0;sign<2;sign++)
  if (DPrimeList[c].value>0 || sign==1)
   for (int a=1; a<100; a++)
    for (int b=1; b<100; b++)
	{
    fA=a/(float)100;
    fB=b/(float)100;
    if (sign==1) DMax=min(fA*(1-fB), (1-fA)*fB);
    else DMax=-min(fA*fB, (1-fA)*(1-fB)); 
    D=DPrimeList[c].value*DMax;
    fAB=D+fA*fB;
    fAb=fA-fAB;
    faB=fB-fAB;
    fab=1-fAB-fAb-faB;
	//if (fab<zero) fab=0;
    if (fab<-zero) {throw NonProb(); exit(0);}
    freq=     pow(fAB, nAB)// fAB with itself
              *pow(fAb, nAb)//fAB-fAb
		      *pow(faB, naB)//fAB-fAb
	          *pow(fab, nab)//fAB-fAb
			  *pow(2*fAB*fab+2*fAb*faB, nHH);
 	if (sign==1) freq=freq*max((1-fA),(1-fB));
	else freq=freq*min(fA,fB);
//freq=freq-pow(fA,nAB+nAb+nHH)*pow(1-fA, naB+nab+nHH)*pow(fB,nAB+naB+nHH)*pow(1-fB, nAb+nab+nHH);
/*
freq=-maxreal;
if (nAB>0) freq=freq+nAB*log(fAB);// fAB with itself
if (nAb>0) freq=freq+nAb*log(fAb);// fAB with itself
if (naB>0) freq=freq+naB*log(faB);// fAB with itself
if (nab>0) freq=freq+nab*log(fab);// fAB with itself
freq=freq+nHH*log(2*fAB*fab+2*fAb*faB);
*/
DPrimeList[c].frequency=DPrimeList[c].frequency+freq;
cont++;
} // for each fa, fb, sign DPrime
DPrimeList[c].frequency=DPrimeList[c].frequency/(float)cont;
}; // for each DPrime value
};
/*____________________________________________________________ */

void PairwiseMeasure<TrioSample>::SetDDistribution()
{
double DMax, D, freq;
double fA=GetfA(), fB=GetfB(), fAB=GetfAB(), fAb, faB, fab;
double nAB=GetnAB(), nAb=GetnAb(), naB=GetnaB(), nab=Getnab();

DPrimeList=new struct FreqAndVal[101];
int cont=0;
for (int c=0; c<=100; c++)
{
 DPrimeList[c].frequency=0;
 DPrimeList[c].value=c/(float)100;
 cont=0;
 //cout <<"\nDPrime:" << DPrimeList[c].value;
 for (int sign=0;sign<2;sign++)
  if (DPrimeList[c].value>0 || sign==1)
   for (int a=0; a<=100; a++)
    for (int b=0; b<=100; b++)
	{
    fA=a/(float)100;
    fB=b/(float)100;
    if (sign==1) DMax=min(fA*(1-fB), (1-fA)*fB);
    else DMax=-min(fA*fB, (1-fA)*(1-fB)); 
    D=DPrimeList[c].value*DMax;
    fAB=D+fA*fB;
    fAb=fA-fAB;
    faB=fB-fAB;
    fab=1-fAB-fAb-faB;
	//if (fab<zero) fab=0;
    if (fab< -zero) {throw NonProb(); exit(0);}
	if (fAB>=0 && fAb>=0 && faB>=0 && fab==0)
	{
    freq=     pow(fAB, nAB)// fAB with itself
              *pow(fAb, nAb)//fAB-fAb
		      *pow(faB, naB)//fAB-fAb
	          *pow(fab, nab)//fAB-fAb
			  *pow(2*fAB*fab+2*fAb*faB, nHH);
/*
freq=-maxreal;
if (nAB>0) freq=freq+nAB*log(fAB);// fAB with itself
if (nAb>0) freq=freq+nAb*log(fAb);// fAB with itself
if (naB>0) freq=freq+naB*log(faB);// fAB with itself
if (nab>0) freq=freq+nab*log(fab);// fAB with itself
freq=freq+nHH*log(2*fAB*fab+2*fAb*faB);
*/
DPrimeList[c].frequency=DPrimeList[c].frequency+freq;
cont++;
}
} // for each fa, fb, sign DPrime
//DPrimeList[c].frequency=DPrimeList[c].frequency/(float)cont;
}; // for each DPrime value
};
/*____________________________________________________________ */

double PairwiseMeasure<TrioSample>::GetMaxDPrime()
{
if (DPrimeList==NULL)
 SetDPrimeDistribution();
float maxFreq=0, maxVal=0;
for (unsigned int i=0;i<101;i++)
 if (DPrimeList[i].frequency>=maxFreq)
 {
  maxFreq=DPrimeList[i].frequency;
  maxVal=DPrimeList[i].value;
 }
return maxVal;
};
/*___________________________________________________________________________*/

double PairwiseMeasure<TrioSample>::GetQuantileDPrime (float quantile)
{
if (DPrimeList==NULL)
 SetDPrimeDistribution();
return percentile(DPrimeList, 101, quantile);
}

};  // End of Namespace

#endif

/* End of file: PairwiseMeasure.h */




