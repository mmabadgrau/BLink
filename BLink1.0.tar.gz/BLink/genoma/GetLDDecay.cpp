  /**
    * @file GetLDDecay.cpp
    * @brief Program to compute the decay of LD as a function of physical distance
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "PairwiseMeasuresResults.h"

//#include "TriosPairwiseMeasure.h"

//using namespace UTILS;

namespace BIOS 
	 {
IndCategory ic=parent;
BayesType BayesMode=MLE;
bool IsPartiallySolved=false, invariant=false;
double MAF=0.0;
double MaximumDistance=0.0;
IndPos size=100;
SNPPos SlideSize=20000;
SNPPos SlideOverlap=10000;
	bool phase;
	float alpha, alphaBayes;
	AlleleOrderType AlleleOrderMode;
	  char filename[256], filepos[256], filename2[256], *fileSel=NULL, ext[256], ext2[4];


bool trios;
// so average distances are 10, 20, 30, 40, ... kb
// which means 0-20, 10-30, 20-40, 30-50, 40-60, ... kb


/*_____________________________________________________________________________________________________________*/

void ReadData(int argc, char*argv[])
{
if(argc<3)
     {
        cerr << "\nYou have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " <<" <Trios (1: yes, 0: no)>"  <<"<max MaximumDistance>"
			<< " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium, 4: BayesDistanceUniform, 5: BayesDistanceSymmetric, 6: BayesDistanceMarginal>"
		<< " <alpha Bayes (any value, recommended positive)>" << " < ic (father=0, mother=1, offspring=2, everybody=3, parent=4) >" 
		<< "< Phase (0: (trios: standard phase, unrelated: not changed) /1: (trios: partially solved, unrelated: leftright (known phase))>" 
		<< "<slide size>" << "<slide overlap>" <<"<MAF>" <<"<invariant sites (0: no (default), 1: yes)>" << "<Selection file>" << endl;
        exit(-1);
        }


strcpy(filename, argv[1]);


if (argc>=3)  trios=atoi(argv[2]); 

if (argc>=4) MaximumDistance=atof(argv[3]);

if (argc>=5) BayesMode=(BayesType) atoi(argv[4]);

if (argc>=6) alphaBayes=atof(argv[5]);

if (argc>=7) ic=(IndCategory) atoi(argv[6]);

if (argc>=8) phase=atoi(argv[7]);

if (argc>=9) SlideSize=atoi(argv[8]);

if (argc>=10) SlideOverlap=atoi(argv[9]);

if (argc>=11) MAF=atof(argv[10]);

if (argc>=12) 
{
invariant=atoi(argv[11]);
if (MAF!=0.0 && invariant==true)
{
cout <<"Invariant can only be true if MAF is equal to 0.\n";
exit(0);
}
}

if (argc>=13) 
{
	fileSel=new char[256];
	strcpy(fileSel, argv[12]);
}


if (SlideSize<SlideOverlap) 
{ 
	cout <<"SlideOverlap cannot be greater than slide size.\n";
	exit(0);
}
}

}
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
  
if (MAF==0.0 && invariant)
strcpy(ext, "invariant\0");
else strcpy(ext, "\0");

strcpy(ext2, "dec\0"); 

switch(BayesMode)
{
case MLE:
sprintf(ext, "%sMAF%d-MLE.%s", ext, (int)(MAF*100), ext2); break;
case BDistanceUniform:
sprintf(ext, "%sMAF%d-BDistanceUniform%f.%s", ext, (int)(MAF*100), alphaBayes, ext2); break;
case BDistanceSymmetrical:
sprintf(ext, "%sMAF%d-BDistanceSymmetrical%f.%s", ext, (int)(MAF*100), alphaBayes, ext2); break;
case BDistanceMarginal:
sprintf(ext, "%sMAF%d-BDistanceMarginal%f.%s", ext, (int)(MAF*100), alphaBayes, ext2); break;
}

  

ChangeExtension (filename, filename2, ext);

if (trios)
{
PairwiseMeasuresResults<TrioSample> *PM;
AlleleOrderMode=MajorFirst;
PM=new PairwiseMeasuresResults<TrioSample>(filename, MAF, BayesMode, alphaBayes, ic, phase, AlleleOrderMode, alpha, invariant, fileSel);
PM->printLDDecay(filename2, MaximumDistance, SlideSize, SlideOverlap, false);
delete PM;
}
else
{
PairwiseMeasuresResults<GenomaSample> * PM;
AlleleOrderMode=LeftRight;
PM=new PairwiseMeasuresResults<GenomaSample>(filename, MAF, BayesMode, alphaBayes, ic, phase, AlleleOrderMode, alpha, invariant, fileSel);
PM->printLDDecay(filename2, MaximumDistance, SlideSize, SlideOverlap, false);
delete PM;
}



delete fileSel;


};








