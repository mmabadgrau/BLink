  /**
    * @file IncHAP.cpp
    * @brief Program IncHAP to resolve phase
    *
    */

#include <fstream>


#include <string>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "GenotypeSample.h"
#include "IncHAP.h"

using namespace UTILS;

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) 
{

if(argc<2)
{
 cerr << "Error: you have to specify the following information:" << endl;
 cerr  << argv[0] << " <input file> "  << " <output file>";  
 exit(-1);
}
char filename[128], filename2[128];
        
strcpy(filename, argv[1]);


if (argc>=3)  strcpy(filename2, argv[2]);
else ChangeExtension(filename, filename2, "hap\0");



IncHAP *PhasedSample;
PhasedSample=new IncHAP (filename);
PhasedSample->ResolvePhaseIncreasingDistances();
PhasedSample->PrintHaplotypes(filename2);


return 0;
}




