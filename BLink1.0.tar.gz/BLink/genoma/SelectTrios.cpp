  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"

#include "../commonc++/list.h"
#include "../commonc++/Sampling.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "GenomaSample.h"
#include "TrioSample.h"

/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<number of individuals>";
        exit(-1);
        }
     char filename[128], filename2[128];
        
	 strcpy(filename, argv[1]);

	 if (argc>=3)
   	 strcpy(filename2, argv[2]);
	 else ChangeExtension(filename, filename2, "output");
		
	 IndPos size=0;
	 if (argc==4)
   	 size= atoi(argv[3]);
 
		 

TrioSample *sample, *sample2;
sample=new TrioSample (filename, parent, NotChanged, false);// ic is only to setup major alleles; false to not complete missing values

list<IndPos> *samplingList;
samplingList=new list<IndPos>();

IndPos sampleSize=sample->TrioSample::GetTotalTrios();
Sampling* sampling;
sampling=new Sampling(sampleSize, false);
for (SNPPos i=0;i<size;i++)
{
 samplingList->InsertElement(sampling->Pos[i]);
// cout <<"\nval:" << sampling->Pos[i];
}
//delete sampling;
sample2=new TrioSample(*sample, samplingList); 
sample2->WriteResults(filename2); 
delete samplingList, sample, sample2;
cout <<"Selected Trios have been recorded in file " << filename2;

char filepos[128], filepos2[128]; 
ChangeExtension(filename2, filepos2, "pou");
ChangeExtension(filename, filepos, "pou");

FileCopy(filepos, filepos2);





return 0;


}










