/* File: IncHAP.h */

//#include <string>

#include "Exceptions.h"
#include "GenotypeSample.h"
#include "Tables2x2.h"



#ifndef __IncHAP_h__
#define __IncHAP_h__

namespace BIOS {

class IncHAP: public GenotypeSample
{
private:
	bool EM;
	BayesType BayesMode;
	char filename[128];
	short int AssignPhaseLongHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef, SNPPos FirstFirstHetero, SNPPos LastLastHetero);

public:
	IncHAP(char * filenam, bool ExistPhenotype, AlleleOrderType AlleleOrderMode, BayesType BayesMod, bool Em): GenotypeSample(filenam, ExistPhenotype, AlleleOrderMode)
	{
	BayesMode=BayesMod;
	Em=Em; 
	strcpy (filename, filenam);
	};

	~IncHAP(){};
	void IncHAP (PhaseType PhaseMode, bool UseMarkers);
	void ResolvePhaseIncreasingDistances (bool UseMarkers);
	
};

/*__________________________________________________________*/

short int IncHAP::AssignPhaseLongHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef, SNPPos FirstFirstHetero, SNPPos LastLastHetero)
{
SNPPos TotalSNPs=GetTotalSNPs();
SNPPos TotalPos=0, p, F, L;

for (p=FirstFirstHetero;p<=LastLastHetero;p++)
if (GenotypeRef->GetDiplotype(p).IsHomozygous(MajorAllele[p]))
 TotalPos++;
TotalPos=TotalPos+2; 

allele Hap[TotalPos];
SNPPos Pos[TotalPos]; 

IndPos TotalIndividuals=GetSize(), ind;
bool Marked[TotalIndividuals];


NodePointer IndGenotype=GetFirst();
Genotype * genotype;
SNPPos Total=0, i=0;
bool phased=false;
IndPos nAB=0, nAb=0, naB=0, nab=0;

for (p=FirstFirstHetero;p<=LastLastHetero;p++)
 if (GenotypeRef->GetDiplotype(p).IsHomozygous(MajorAllele[p]) || p==FirstHetero || p==LastHetero)
 {
 if (p==FirstHetero) F=i;
 else if (p==LastHetero) L=i;
 else
 Hap[i]=GenotypeRef->GetDiplotype(p).GetLeftAllele();
 Pos[i]=p;
 i++;
 }

Genotype *g;
ind=0;

while (IndGenotype!=NULL)
{
	g=GetElement(IndGenotype);
	p=FirstFirstHetero;
	Marked[ind]=true;

    if (g->GetDiplotype(FirstHetero).IsHeterozygous(MajorAllele[FirstHetero]) && g->GetDiplotype(LastHetero).IsHeterozygous(MajorAllele[LastHetero]))
    {
	i=0;
	while (i<TotalPos && (g->GetDiplotype(Pos[i]).IsHomozygous(MajorAllele[Pos[i]]) || Pos[i]==FirstHetero || Pos[i]==LastHetero))
	 i++;
	}
	if (i==(TotalPos+1)) Marked[ind]=false;
	IndGenotype=GetNext(IndGenotype);
	ind++;
}


Diplotype D=GenotypeRef->GetDiplotype(FirstHetero);
D.OrderMajorFirst(MajorAllele[FirstHetero]);
Diplotype D2=GenotypeRef->GetDiplotype(LastHetero);
D2.OrderMajorFirst(MajorAllele[LastHetero]);


Hap[F]=D.GetLeftAllele();
Hap[L]=D2.GetLeftAllele();
nAB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetLeftAllele();
Hap[L]=D2.GetRightAllele();
nAb=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetRightAllele();
Hap[L]=D2.GetLeftAllele();
naB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetRightAllele();
Hap[L]=D2.GetRightAllele();
nab=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);

if (nAB*nab>=nAb*naB) return 1; else return 2; 
} 



/*____________________________________________________________ */

void IncHAP::ResolvePhaseIncreasingDistances (bool UseMarkers=false)
{
char filepos[128];

ChangeExtension (filename, filepos, "pou");

unsigned short int MajorPhase;
SNPPos LastResolved, TotalSNPs=GetTotalSNPs(), SNP, NextHet, LastLastResolved;
cout << "\nReconstructing haplotypes...";
double distance;
Positions * Pos;
Pos=new Positions (filepos);
NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* G;
Block bl;
bool simpleDHAP;
unsigned short int Phase=0;
bool IsAnOrderedPhase;
block::NodePointer pB;
for (SNPPos gap=0;gap<(TotalSNPs-1);gap++)
{
IndGenotype=GenotypeSample::GetFirst();
while (IndGenotype!=NULL)
{
  LastLastResolved=TotalSNPs;
  G=GetElement(IndGenotype);
  LastResolved=G->GetFirstHeterozygous(MajorAllele);
  SNP=LastResolved+1;
  
  while (SNP<TotalSNPs)
  {
 
   if (G->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) 
   {
    distance=Pos->GetDistance(LastResolved, SNP);
	if ((SNP-LastResolved-1)==gap)
	{
       NextHet=SNP+1;
	   while (NextHet<TotalSNPs && G->GetDiplotype(NextHet).IsHomozygous(MajorAllele[NextHet]))
		   NextHet++;
	   NextHet--;
	  if (LastLastResolved==TotalSNPs) 
	   LastLastResolved=LastResolved;
	
	Phase=AssignPhaseLongHaps (LastResolved, SNP, MajorAllele, G, LastLastResolved, NextHet);
	   IsAnOrderedPhase=G->IsMajorMajor(MajorAllele[LastResolved], MajorAllele[SNP], G->GetDiplotype(LastResolved), G->GetDiplotype(SNP));
   if ((UseMarkers && G->IsMarked(SNP)) || !UseMarkers) 
   if ((Phase==1 && !IsAnOrderedPhase) || (Phase==2 && IsAnOrderedPhase)) 
   {
    G->ChangeAlleles(SNP);
   // update phases
	
   for (SNPPos SNP2=(SNP+1);SNP2<(TotalSNPs-1);SNP2++)
   if (G->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2])) 
    G->ChangeAlleles(SNP2);
	   
   }//if changed
	}//for this gap
	LastLastResolved=LastResolved;
   LastResolved=SNP;
   } //end for each hetero SNP
   SNP++;
  } // for each SNP
  
 IndGenotype=GetNext(IndGenotype);
} // end for each individual
} // end for each gap


cout << "\nReconstruction has finished";
}

/*____________________________________________________________ */



};  // Fin del Namespace

#endif

/* Fin Fichero: IncHAP.h */
