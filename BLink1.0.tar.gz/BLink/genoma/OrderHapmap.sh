dircode="/home/mabad/genoma"
if [ $# -ne 4 ]
then
echo This macro needs four arguments: the first with the directory where the data files reside, the second with the name of the population -CEU, YRI, CHB, JPT- and the third and four with the name of month and the year respectively
exit 0
stop
fi
cd $1
echo Order chromosomes 
chromosome="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
# chromosome="2"
for a in $chromosome
do
echo $a 
inputfile=$1"chromosome"$a"_$2$3$4.gen"
$dircode/OrderPositions $inputfile 
echo Converted to dhap format
done
