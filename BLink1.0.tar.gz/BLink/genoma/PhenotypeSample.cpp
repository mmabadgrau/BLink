/* File: PhenotypeSample.cpp */


#ifndef __PhenotypeSample_cpp__
#define __PhenotypeSample_cpp__



#include "PhenotypeSample.h"


//using namespace UTILS;


namespace BIOS {

 

/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


//



/*___________________________________________________________ */
/*
Phenotype list<Phenotype>::ReadElement (ifstream* source, unsigned long int size)
{
	BIOS::PhenotypeSample::ReadElement(source, size);
}
*/
/*___________________________________________________________ */

template <> Phenotype list<Phenotype>::ReadElement (ifstream* source, char* tokens)
{
	Phenotype P;
	Phenotype::PhenotypeS pS;
	char *line;
	line=CaptureLine(source);
	sscanf(line, "%d%d%d%d%d%d%d", &(pS.Pedigree), &(pS.Code), &(pS.Father), &(pS.Mother), 
	&(pS.Gender), &(pS.Affectation), &(pS.Code2));
	P.SetPhenotype(pS);
	delete line;
	return P;
};
/*___________________________________________________________ */
/*
Phenotype PhenotypeSample::ReadElement (ifstream* source, char* tokens)
{
return list<Phenotype>::ReadElement (source, tokens); 
};

/*___________________________________________________________ */

///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

PhenotypeSample::PhenotypeSample (char* filename):Container<Phenotype, list>(filename)
{
}
/*____________________________________________________________ */

PhenotypeSample* PhenotypeSample::copyElementsWithPositionsIn(intList* positions, bool inThis)
{
Container<Phenotype, list>* res= this->Container<Phenotype, list>::copyElementsWithPositionsIn(positions, inThis);
PhenotypeSample* result=new PhenotypeSample(*res);
zap(res);
return result;
}

/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetRelative(IndCategory ic, NodePointer const i)
{
 unsigned int SizeP=GetSize();

 try
 {
  if (i==NULL) 
    throw NullValue();

  
	Phenotype::PhenotypeS ind = GetElement(i).GetPhenotype(), ind2;
	NodePointer p = GetFirst();
	unsigned int pos=0;
	while (p!=NULL) 
	{
    if (p!=i)
	{
	ind2=GetElement(p).GetPhenotype();
	switch (ic)
	{
	case father: 
	if	((ind2.Code == ind.Father || ind2.Code == ind.Mother) && ind2.Gender==1 && ind.Pedigree == ind2.Pedigree)
	 return p;
	break;
	case mother:
	if	((ind2.Code == ind.Father || ind2.Code == ind.Mother) && ind2.Gender==2 && ind.Pedigree == ind2.Pedigree)
	 return p;
	break;
	case offspring:
	if	(((ind2.Father == ind.Code) || (ind2.Mother==ind.Code)) && (ind.Pedigree == ind2.Pedigree))
 	 return p;
	break;
	}
	}
    p=GetNext(p); 
    };

    throw NullValue();
 }
 catch (NullValue nv) 
{
 nv.PrintMessage("GetRelative");
}     
}

/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetFather(NodePointer const i)
{

return GetRelative(father, i);
}



/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetMother(NodePointer const i)
{
return GetRelative(mother, i);
};

/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetFirstChild(NodePointer const i)
{
return GetRelative(offspring, i);  
}

/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetNextSib(NodePointer const i, NodePointer const parent)
{
try
{
  if (i==NULL) 
    throw NullValue();
}
 catch (NullValue nv) 
{
 nv.PrintMessage();
}     

  NodePointer p=GetFirstChild(parent);
  IndPos Position=GetPos(p);
  Phenotype::PhenotypeS Ind=GetElement(i).GetPhenotype(), Ind2, Parent=GetElement(parent).GetPhenotype(); 
     
	p = GetNext(p);
	Position++;
	while (p!=NULL)
	{
	// if sibs
	Ind2=GetElement(p).GetPhenotype();
	if	(
		 ((Ind.Father==Ind2.Father && Ind2.Father==Parent.Code) || 
		  (Ind.Mother==Ind2.Mother && Ind2.Mother==Parent.Code))
		&& (Ind2.Pedigree == Ind.Pedigree) && (Ind2.Pedigree == Parent.Pedigree)

		)
		return p;
	Position=Position+1;
    p=GetNext(p);
    };

	 return p;


}

/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetCouple(NodePointer const p, NodePointer const pChild)
{

Phenotype::PhenotypeS IndAdult=GetElement(p).GetPhenotype(), IndChild=GetElement(pChild).GetPhenotype();
try
{
  if (p==NULL || pChild==NULL) 
    throw NullValue();

if (IndAdult.Pedigree==IndChild.Pedigree)
{
if (IndAdult.Gender==female && (IndAdult.Code==IndChild.Mother || IndAdult.Code==IndChild.Father))
return GetFather(pChild);
if (IndAdult.Gender==male && (IndAdult.Code==IndChild.Father || IndAdult.Code==IndChild.Mother))
return GetMother(pChild);
}

 cout <<"Individual code " << IndChild.Code << "/" << IndChild.Pedigree 
			<< " is not a child of individual code " << IndAdult.Code <<"/" << IndAdult.Pedigree;
	
		throw NullValue ();

}

 catch (NullValue nv) 
{
 nv.PrintMessage();
}     
	
}
/*____________________________________________________________ */

PhenotypeSample::NodePointer PhenotypeSample::GetCouple(NodePointer const p)
{
NodePointer pChild=GetFirstChild(p);
return GetCouple(p, pChild);
}
 

/*____________________________________________________________ */

string PhenotypeSample::PrintPhenotype (NodePointer p)
{
return  GetElement(p).PrintPhenotype();

}
/*____________________________________________________________ */

void  PhenotypeSample::PrintPhenotypes ()
{
NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 

  while (IndPhenotype!=NULL)
  {
   cout <<PrintPhenotype(IndPhenotype);
   cout <<"\n";
   IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
}
/*____________________________________________________________ */

IndPos PhenotypeSample::GetTotalOffSpring ()
{
	 return GetTotalIndividuals(offspring);
}
/*____________________________________________________________ */

IndPos PhenotypeSample::GetTotalIndividuals (IndCategory ic)
{
IndPos Total=0;

Phenotype IndPhenotype;
NodePointer p=GetFirst();
Phenotype P;

while (p!=NULL)
  {
   P=GetElement(p);
   if ((ic==offspring && P.IsAChild ()) || (ic==parent && P.IsAParent ()) 
	 || (ic==everybody) || (ic==father && P.IsAFather()) || (ic==mother && P.IsAMother()))
	  Total++;

   p=GetNext(p);
  };
 


  return Total;
}
/*__________________________________________________________*/

void PhenotypeSample::SetMarked (bool *Marked, IndCategory ic, int genderN, int affectationN)
{
IndPos TotalInds=GetSize(), cont=0;
InitializeList(Marked, TotalInds, false);
NodePointer p=GetFirst();
Phenotype ph;
gender Gender;
affectation Affectation;
if (genderN!=everyGender) Gender=(gender)genderN;
if (affectationN!=allAffectation) Affectation=(affectation)affectationN;
while (p!=NULL)
{
ph=GetElement(p);
 switch (ic)
 {
 case offspring: 
    if (ph.IsAChild()) Marked[cont]=true;
    break;
 case father:
    if (ph.IsAFather()) Marked[cont]=true;
    break;
 case mother:
    if (ph.IsAMother()) Marked[cont]=true;
    break;
 case parent:
    if (ph.IsAParent()) Marked[cont]=true;
    break;
 case everybody:
    Marked[cont]=true;
    break;
 }

if (genderN!=everyGender && Marked[cont]==true)
 if (ph.phenotype.Gender!=Gender) Marked[cont]=false;
if (affectationN!=allAffectation && Marked[cont]==true)
 if (ph.phenotype.Affectation!=Affectation) Marked[cont]=false;
//cout <<"\nmarked " << cont << " is " << Marked[cont];

 p=GetNext(p);
 //cout <<"ind:" << cont;
 cont++;
}

}





};  // Fin del Namespace

#endif

/* Fin Fichero: PhenotypeSample.h */
