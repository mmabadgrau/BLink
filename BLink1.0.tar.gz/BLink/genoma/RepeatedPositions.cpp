/* File: RepeatedPositions.cpp */

#ifndef __RepeatedPositions_cpp__
#define __RepeatedPositions_cpp__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//





#include "RepeatedPositions.h"


//using namespace std;
//using namespace string;


namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
/*___________________________________________________________ */
/*
PosS RepeatedPositions::ReadElement (ifstream * is)
{
    unsigned long int size=20;
	struct PosS posS;
	sscanf(CaptureLine(is, size), "%f", posS.pos);
	return posS;
}
*/
///////////////////
//// public ////////
///////////////////
/*_______________________________________________________ */

RepeatedPositions::RepeatedPositions(char* filename):VirtualPositions(filename)
{
}

/*____________________________________________________________ */

void RepeatedPositions::CheckFilename(char* filename)
{
if (strncmp(strtok(filename+2, ".")-2, "poo", 3)!=0)
{
	cout <<"File pos is required";
	exit (0);
}
}

/*____________________________________________________________ */

void RepeatedPositions::CheckRepeated()
{

SNPPos TotalSNPs=GetTotalSNPs(), i=0;

bool PosList[TotalSNPs], *p=PosList;

NodePointer IndPosition=GetFirst();

double Pos, OldPos;

while (IndPosition!=NULL)
{
 Pos=GetElement(IndPosition)->pos;
 if (i>0 && (Pos==OldPos))
  PosList[i]=true;
 else PosList[i]=false;
 IndPosition=GetNext(IndPosition);   
 i++;
 OldPos=Pos;
}

this->Remove(PosList);

}
/*____________________________________________________________ */

void RepeatedPositions::PrintOrderedUnrepeatedPositions ()
 {

  //CheckRepeated();

  
  char* filepos2;

 if ((filepos2=new char[128])==NULL)
		 throw NoMemory();

 ChangeExtension (filename, filepos2, "pou\0");
 
 PrintPositions(filepos2);
 
 }


};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
