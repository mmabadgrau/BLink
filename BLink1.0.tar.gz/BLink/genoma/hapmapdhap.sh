cd /home/mar/genoma/data
echo computed dHAP                                 
echo chrom1
/home/mar/genoma/PhaseChecker chrom1.red dhap_red.acc 90 100
echo chrom2
/home/mar/genoma/PhaseChecker chrom2.red dhap_red.acc 90 100
echo chrom3
/home/mar/genoma/PhaseChecker chrom3.red dhap_red.acc 90 100
echo chrom4
/home/mar/genoma/PhaseChecker chrom4.red dhap_red.acc 90 100
echo chrom5
/home/mar/genoma/PhaseChecker chrom5.red dhap_red.acc 90 100
echo chrom6
/home/mar/genoma/PhaseChecker chrom6.red dhap_red.acc 90 100
echo chrom7
/home/mar/genoma/PhaseChecker chrom7.red dhap_red.acc 90 100
echo chrom8
/home/mar/genoma/PhaseChecker chrom8.red dhap_red.acc 90 100
echo chrom9
/home/mar/genoma/PhaseChecker chrom9.red dhap_red.acc 90 100
echo chrom10
/home/mar/genoma/PhaseChecker chrom10.red dhap_red.acc 90 100
echo chrom11
/home/mar/genoma/PhaseChecker chrom11.red dhap_red.acc 90 100
echo chrom12
/home/mar/genoma/PhaseChecker chrom12.red dhap_red.acc 90 100
echo chrom13
/home/mar/genoma/PhaseChecker chrom13.red dhap_red.acc 90 100
echo chrom14
/home/mar/genoma/PhaseChecker chrom14.red dhap_red.acc 90 100
echo chrom15
/home/mar/genoma/PhaseChecker chrom15.red dhap_red.acc 90 100
echo chrom16
/home/mar/genoma/PhaseChecker chrom16.red dhap_red.acc 90 100
echo chrom17
/home/mar/genoma/PhaseChecker chrom17.red dhap_red.acc 90 100
echo chrom18
/home/mar/genoma/PhaseChecker chrom18.red dhap_red.acc 90 100
echo chrom19
/home/mar/genoma/PhaseChecker chrom19.red dhap_red.acc 90 100
echo chrom20
/home/mar/genoma/PhaseChecker chrom20.red dhap_red.acc 90 100
echo chrom21
/home/mar/genoma/PhaseChecker chrom21.red dhap_red.acc 90 100
echo chrom22
/home/mar/genoma/PhaseChecker chrom22.red dhap_red.acc 90 100
echo chromX
/home/mar/genoma/PhaseChecker chromX.red dhap_red.acc 90 100
