/* File: block.h */


#ifndef __block_h__
#define __block_h__



namespace BIOS {


/************************/
/* block SNP*/
/************************/


/**
        @memo block

	@doc
        Definition:
        An array SampleValues of Size values

        Memory space: O(size). 

        @author Maria M. Abad
	@version 1.0
*/
	typedef struct Block{

      /**
      @memo Initial Pos of a block
      @doc  
      */
      SNPPos IniPos;

      /**
      @memo Last+1 pos of the block
      @doc 
      */
      SNPPos LastPos;


  bool operator>(Block & Source)
  {return IniPos>Source.IniPos;}
  bool operator<(Block & Source)
  {return IniPos<Source.IniPos;}

	};  // end structure block


ostream& operator<<(ostream& out, Block& p)
  {
out <<p.IniPos << "-" << p.LastPos<<"\n";
    return out;
  }

 class BlockList : public list<Block>{


protected:
    /** @name Implementation of class block
        @memo Private part.
    */

   bool * ListUsedSNPs;

   
	SNPPos TotalSNPs;
  
	float MaxWidth; 
     
	//void OrderBlockByPos();


//	void ReadElement (ifstream * source, unsigned long int size){};


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
/* PUBLIC FUNCTIONS (INTERFACE) */

   public:

	void WriteBlocks(char* filename);

	BlockList(char* filename);
BlockList();

};  // End of class block



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

 
template<> Block list<Block>::ReadElement (ifstream * source, char* tokens)
 {
struct Block block; 
char* genotypebuf=NULL;
genotypebuf=CaptureLine(source);
stringList* getVals=getList(genotypebuf, tokens);
block.IniPos=atoi(getVals->GetFirstElement().c_str());
block.LastPos=atoi(getVals->GetLastElement().c_str());
zap(getVals);
zaparr(genotypebuf);
return block;
};

 
 /*********************************************************************/
/*
void block::OrderBlockByPos()
{
	if (!IsEmpty())
	{
	SNPPos TotalBlocks=GetSize();
	Block TableBlocks[TotalBlocks];	
	NodePointer p=GetFirst();
	SNPPos i=0;
	while (p!=NULL)
	{
    TableBlocks[i]=GetElement(p);
	p=GetNext(p);
	i++;
	}
	qsort ((void*)TableBlocks, TotalBlocks, sizeof (struct Block), compareint);


p=GetFirst();
i=0;

while (p!=NULL)
{
 ReplaceNode(p, TableBlocks[i]);
 p=GetNext(p);
 i++;
}
	}

}
*/
///////////////////
//// public ////////
///////////////////
/*________________________________________________________________________________*/

BlockList::BlockList(char* filename):list<Block>(filename)
{
//List=NULL;
//GetInfo(filename);
};
/*________________________________________________________________________________*/

BlockList::BlockList():list<Block>()
{
//List=NULL;
//GetInfo(filename);
};


/**********************************/
void BlockList::WriteBlocks(char* filename)
{
  ofstream OutputFile; 

  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage(" block::WriteBlocks");
      }

NodePointer Pointer=GetFirst();
Block BlockC;
bool first, some;
double size=0, AverageSize, TotalBlocks=0;
while (Pointer!=NULL)
{
Block BlockC=GetElement(Pointer);
first=true;
size=0;
some=false;
for (unsigned long int i=BlockC.IniPos;i<=BlockC.LastPos;i++)
 if (ListUsedSNPs==NULL || ListUsedSNPs[i])
 {
        some=true;
	if (first==false)
	OutputFile << ' ';
    else first=false;
	OutputFile << i+1;
	size++;
}
if (some) OutputFile  <<  '\n';
 Pointer=GetNext(Pointer);
 AverageSize=AverageSize+size;
 TotalBlocks++;
};

OutputFile.close();

cout << "\nInformation about blocks has been saved in file " << filename <<"\n";
cout << "\nAverage block size: " << AverageSize/TotalBlocks <<"\n";
}




};  // End of Namespace

#endif

/* End of file: block.h */




