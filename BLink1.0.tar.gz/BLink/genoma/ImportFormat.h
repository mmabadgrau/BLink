/* File: ImportFormat.h */


#ifndef __ImportFormat_h__
#define __ImportFormat_h__


#include <string>


#include "Exceptions.h"
#include "SNP.cpp"



namespace BIOS {

/*____________________________________________________________ */

void ImportFromPHASE (char *filename, char* filename2, unsigned int size, SNPPos TotalSNPs)
{
	
ifstream InputFile; 
unsigned int i2;

cout <<"Importing from PHASE file " << filename << "\n";



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2, *cad3;
    if ((genotypebuf=new char[100*TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad2=new char[100*TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad3=new char[100*TotalSNPs])==NULL)
     throw NoMemory();


	 bool found=false;
	 cout <<"totalSNPS:" << TotalSNPs <<"\n";
	do
	{
		InputFile.getline (genotypebuf, 100*TotalSNPs);

	cad=strtok (genotypebuf," \t");
	if (cad!=NULL)
	if (*cad=='B')
	{
	sscanf (cad, "%s", cad2);
	cad=strtok (NULL," \t");
	sscanf (cad, "%s", cad3);
//if ((strcmp(cad2, "BEGIN\0")==0) && (strcmp (cad3, "BESTPAIRS1\0")==0))
if ((strcmp(cad2, "BEGIN\0")==0) && (strcmp (cad3, "GENOTYPES\0")==0))
		found = true;
	}		
	}
	while ((InputFile.peek()!=EOF) && (!found));



if (!found)
{
	cout << "Incompatible format for PHASE output";
	exit(0);
}



ofstream OutputFile;

OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

unsigned int alle;

unsigned short int *typ;
intList::NodePointer pL, pR;

if ((typ=new unsigned short int[TotalSNPs])==NULL)
 throw NoMemory();

intList* leftHap, *rightHap;
for (unsigned int i=0;i<size;i++)
{
        leftHap=new intList();
	rightHap=new intList();
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');

	for (unsigned short int side=0;side<2;side++)
	{
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	for (i2=0; i2<TotalSNPs; i2++)
	{
	if (i2==0)
     cad = strtok (genotypebuf," \t");
    else cad = strtok (NULL," \t");
	if (cad==NULL) cout <<"\nError in SNP " << i2;
	if ((*cad=='(') || (*cad==')') || (*cad=='[') || (*cad==']'))
		cad=cad+1;

	alle=atoi(cad);
        if (side==0) leftHap->insertElement(alle); else rightHap->insertElement(alle);
	} // for each SNP
	}
    OutputFile << i << " " << i << " 1 0 0 0 " << i;	//idFam, id, sex,affectation,father, mather, id2
    pL=leftHap->GetFirst();
    pR=rightHap->GetFirst();
    while (pL!=NULL)
    {	
     OutputFile << " " << leftHap->GetElement(pL) <<" " << rightHap->GetElement(pR);
     pL=leftHap->GetNext(pL); pR=rightHap->GetNext(pR);
     }
zap(leftHap);
zap(rightHap);
OutputFile <<"\n";
}// end for each size
InputFile.close();
OutputFile.close();
cout<< "\nresult has been recorded in file " << filename2 <<"\n";
}

/*____________________________________________________________ */
/*
void ImportFromPHASE (char *filename, char* filename2)
{
	
ifstream InputFile; 
unsigned int i2;

cout <<"Importing from PHASE file " << filename << "\n";



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2, *cad3;
    if ((genotypebuf=new char[100*TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad2=new char[100*TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad3=new char[100*TotalSNPs])==NULL)
     throw NoMemory();


	 bool found=false;
	 cout <<"totalSNPS:" << TotalSNPs <<"\n";
	do
	{
		InputFile.getline (genotypebuf, 100*TotalSNPs);

	cad=strtok (genotypebuf," \t");
	if (cad!=NULL)
	if (*cad=='B')
	{
	sscanf (cad, "%s", cad2);
	cad=strtok (NULL," \t");
	sscanf (cad, "%s", cad3);
if ((strcmp(cad2, "BEGIN\0")==0) && (strcmp (cad3, "BESTPAIRS1\0")==0))
		found = true;
	}		
	}
	while ((InputFile.peek()!=EOF) && (!found));



if (!found)
{
	cout << "Incompatible format for PHASE output";
	exit(0);
}



ofstream OutputFile;

OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

unsigned int alle;

unsigned short int *typ;
GenotypeSample Sample;
Sample=new GenotypeSample();
Genotype *IndGenotype=TheFirstGenotype;

if ((typ=new unsigned short int[TotalSNPs])==NULL)
 throw NoMemory();


for (int i=0; i<SizeP; i++)
{
//	if (IsAChild(i))
	{
		if (InputFile.peek()==EOF) 
	     throw EOFile();
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');

	for (unsigned short int side=0;side<2;side++)
	{
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	for (i2=0; i2<TotalSNPs; i2++)
	{
	if (i2==0)
     cad = strtok (genotypebuf," \t");
    else cad = strtok (NULL," \t");
	if (cad==NULL) cout <<"\nError in SNP " << i2;
	if ((*cad=='(') || (*cad==')') || (*cad=='[') || (*cad==']'))
		cad=cad+1;

	alle=atoi(cad);

   if (side==0)
   {
	typ[i2]=0;
	if (IsANonMissingSNP(IndGenotype, i2))
     if (IsHeterozygous(IndGenotype, i2)) 
	  typ[i2]=1;
	  else 
	   if (IsHomozygous1(IndGenotype, i2)) 
	    typ[i2]=2;
	   else 
		if (IsHomozygous2(IndGenotype, i2)) 
		 typ[i2]=3;
   }


if ((typ[i2]==2) || (typ[i2]==3))
if  (*((IndGenotype->Left)+i2) != (allele) alle)
{
	cout <<"inc at ind " << i << " SNP" << i2;
	alle=(unsigned int)*((IndGenotype->Left)+i2);
}
if ((typ[i2]==1) && (side==1))
if  (*((IndGenotype->Left)+i2) == (allele) alle)
{
	cout <<"inc2 at ind " << i << " SNP" << i2; 
	alle=(unsigned int)*((IndGenotype->Right)+i2);
}

	if (side==0)
    *((IndGenotype->Left)+i2) = (allele) alle; 
	else
    *((IndGenotype->Right)+i2) = (allele) alle; 
	}// end for each SNP
	}// end for each size
	}// end if a child
	if (i<(Size-1))
	IndGenotype=GetNext(IndGenotype);
}
InputFile.close();

}

*/

/*____________________________________________________________ */

void ImportFromSNPHAP (char *filename, char* filename2, unsigned int Size, SNPPos TotalSNPs)
{
ifstream InputFile; 
unsigned int i2;

cout <<"Importing from SNPHAP\n";




InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2;
    if ((genotypebuf=new char[8*TotalSNPs])==NULL)
     throw NoMemory();


//     unsigned long int pos;
	 bool found=false;

	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	
char alle;


ofstream OutputFile;

OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();
unsigned int i=0;

do
{
InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
//cout << genotypebuf <<"\n";
cad = strtok (genotypebuf,"(");
if (atoi(cad)>(i+1))
{
	OutputFile <<"\n";
	OutputFile <<"\n";
	i++;

}
i++;

for (int side=0; side<2; side++)
{
if (side==1)
{
InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
cad = strtok (genotypebuf,"(");
}
 cad = strtok (NULL,")");
 cad = strtok (NULL," ");
 for (i2=0; i2<TotalSNPs; i2++)
 {
  sscanf (cad+i2, "%c", &alle);
  OutputFile << alle; 
 }

 OutputFile <<"\n";
}

} 
while (i<Size);
// end for each individual
//exit(0);

InputFile.close();

delete genotypebuf;

}
/*____________________________________________________________ */
/*
void ImportFromSNPHAP (char *filename)
{

ifstream InputFile; 
unsigned int i2;

cout <<"Importing from SNPHAP\n";




InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2;
    if ((genotypebuf=new char[8*TotalSNPs])==NULL)
     throw NoMemory();
	//if ((cad=new char[10])==NULL)
    // throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


//     unsigned long int pos;
	 bool found=false;

	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');


char alle;

Genotype *IndGenotype=TheFirstGenotype;
Phenotype *IndPhenotype=TheFirstPhenotype;


Genotype::Size=Size;

	for (int i=0;i<Size;i++)
	 if (InputFile.peek()!=EOF)
	{
	if (IsAChild(IndPhenotype))
	{
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
    
	 cad = strtok (genotypebuf," \t");
	while ((atoi(cad)<=(i+1)) && (InputFile.peek()!=EOF))
	{
	 InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	 cad = strtok (genotypebuf," \t");
	}
    if (InputFile.peek()!=EOF)
	if (atoi(cad)==(i+1))
    {
	cad = strtok (NULL," \t"); // read haplotype number (1)
	cad = strtok (NULL," \n\t"); // read haplotype left strand
	
    for (i2=0; i2<TotalSNPs; i2++)
    {

	sscanf (cad, "%c", &alle);
    *(IndGenotype->Left)= (allele) ConvertAllele(alle); 
	}


	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	cad = strtok (genotypebuf," \t");
	cad = strtok (NULL," \t"); // read haplotype number (2)
	cad = strtok (NULL," \n\t"); // read haplotype right strand
    
	for (i2=0; i2<TotalSNPs; i2++)
    {
	sscanf (cad, "%c", &alle);
    *(IndGenotype->Right)= (allele) ConvertAllele(alle); 
	}
	}
	} // end if a child
	IndPhenotype=Phenotype::GetNext(IndPhenotype);
	IndGenotype=Genotype::GetNext(IndGenotype);
	} // end for each individual

InputFile.close();

delete genotypebuf, cad2, cad;

}
*/
/*____________________________________________________________ */

void ImportFromHTYPER (char *filename, char *filename2, unsigned int Size, SNPPos TotalSNPs, FormatType Algorithm)
{

	unsigned int i2;
ifstream InputFile; 



InputFile.open (filename, ifstream::in);
if (!InputFile || InputFile.peek()==EOF)
	throw ErrorFile();


	char *genotypebuf, *genotypebuf2, *cad;
    if ((genotypebuf=new char[8*TotalSNPs])==NULL)
     throw NoMemory();
    if ((genotypebuf2=new char[8*TotalSNPs])==NULL)
     throw NoMemory();


	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');

char alle;



ofstream OutputFile;

OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();
int cont=1;

	for (int i=0; i<Size; i++)
	{
	if (Algorithm==PLEM) 
	{
		InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
    	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
		cont=atoi(genotypebuf+strlen(genotypebuf)-1);
//	cout <<cont << "\n";

//cout <<genotypebuf << "\n";
//cout <<"len:" << strlen(genotypebuf) <<"\n";
	}
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
    for (int side=0; side<2; side++)
{
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
 	
	 for (i2=0; i2<TotalSNPs; i2++)
	{
 
  alle=genotypebuf[i2];
   OutputFile << alle; 

	}
 OutputFile << "\n"; 	
}	
	if (Algorithm==PLEM) 
	for (int c=1;c<cont;c++)
		{
			    	InputFile.getline (genotypebuf2, 8*TotalSNPs, '\n');
			    	InputFile.getline (genotypebuf2, 8*TotalSNPs, '\n');
			    	InputFile.getline (genotypebuf2, 8*TotalSNPs, '\n');

		}
	
	}
InputFile.close();
OutputFile.close();
delete genotypebuf, genotypebuf2;

}
/*____________________________________________________________ */
/*
void ImportFromHTYPER (char *filename)
{

cout <<"Importing from HTYPER at file " << filename << "\n";

	unsigned int i2;
ifstream InputFile; 



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();


	char *genotypebuf, *cad, *cad2;
    if ((genotypebuf=new char[8*TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


 //    unsigned long int pos;
	 bool found=false;

	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');

	Genotype *IndGenotype=TheFirstGenotype;
	Phenotype *IndPhenotype=TheFirstPhenotype;
	bool *hetero;
	if ((hetero=new bool[TotalSNPs])==NULL)
     throw NoMemory();

	for (int i=0; i<Size; i++)
	{

	if (IsAChild(i))
	{
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
	for (i2=0; i2<genotype::TotalSNPs; i2++)
	 if (IsHeterozygous(IndGenotype, i2))	// to prevent changes from homos to heteros
	 {
		 hetero[i2]=true;
	//	 cout << "pos " << i2 << " hetero for ind code  :" << i <<"\n";
	 }
	 else hetero[i2]=false;

	for (i2=0; i2<genotype::TotalSNPs; i2++)
	{
	 if (hetero[i2])
	 if (*(genotypebuf+i2)=='0')
	 *((IndGenotype->Left)+i2)= GetMajorAllele(i2); 
	 else
	 *((IndGenotype->Left)+i2)= GetMinorAllele(i2);
	 }
	
	
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	
    for (i2=0; i2<genotype::TotalSNPs; i2++)
	{
   if (hetero[i2])	
    if (*(genotypebuf+i2)=='0') // to prevent changes from homos to heteros
	 *((IndGenotype->Right)+i2)= GetMajorAllele(i2); 
	else
	 *((IndGenotype->Right)+i2)= GetMinorAllele(i2);
	}
	
	}
		IndGenotype=genotype::GetNext(IndGenotype);
		IndPhenotype=phenotype::GetNext(IndPhenotype);


}
InputFile.close();

delete genotypebuf, cad2, cad, hetero;

}
*/
/*____________________________________________________________ */

void ImportFromMSAMPLE (char *filename, char *filename2) //, const long int InitialPos, const unsigned int Length)
{
SNPPos TotalSNPs;
cout <<"Importing from MSAMPLE at file " << filename << "\n";

unsigned int i2, NonRepeated=0;

//unsigned long int RegionSize=0;
ifstream InputFile; 

InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *genotypebuf2, *genotypebuf3, *cad, *cad2, *oldcad;
	bool *ChosenPosition;


// this buffer will contain the positions and afterwards, genotypes
	// positions can require about 10 chars
    if ((genotypebuf3=new char[200])==NULL)
     throw NoMemory();
	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();
	if ((oldcad=new char[10])==NULL)
     throw NoMemory();
	 bool found=false;

     InputFile.getline (genotypebuf3, 200, '\n');

	 while  (InputFile.peek()!='s')
     InputFile.getline (genotypebuf3, 200, '\n');
     
	 InputFile.getline (genotypebuf3, 200, '\n');

	cad = strtok (genotypebuf3," \t");
	if (strcmp(cad, "segsites:")!=0)
	{
		cout <<"Error in file format. Line beginning with \"segsites:\" was expected";
		exit(0);
	}
	cad = strtok (NULL," \t");
	TotalSNPs=atoi(cad);

// this buffer will contain the positions and afterwards, genotypes
	// positions can require about 10 chars
    if ((genotypebuf=new char[100*TotalSNPs])==NULL)
     throw NoMemory();

	if ((genotypebuf2=new char[100*TotalSNPs])==NULL)
     throw NoMemory();


	if ((ChosenPosition=new bool[TotalSNPs])==NULL)
     throw NoMemory();

 for(unsigned int i=0;i<TotalSNPs;i++)
  ChosenPosition[i]=false;


char filename3[128];

ofstream OutputFile;

ChangeExtension (filename, filename3, "pou");

OutputFile.open (filename3, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

InputFile.getline (genotypebuf, 100*TotalSNPs, '\n'); // positions
//exit(0);

//cout <<genotypebuf << " ";

  cad = strtok (genotypebuf," \t");
 if (strncmp(cad, "prob:", 5)==0) // the line was prob:
  {
  InputFile.getline (genotypebuf, 100*TotalSNPs, '\n'); // positions
  cad = strtok (genotypebuf," \t");
 }

unsigned int WrittenPositions=0;
for (i2=0; i2<TotalSNPs; i2++)
{   
	cad = strtok (NULL," \t");

//cout <<cad << " ";
//exit(0);


//if ((i2>=InitialPos) && (WrittenPositions<Length))

 if (strcmp(cad, "n")==0) // no pos
  OutputFile << i2 << "\n";//????
 else
 {

	if ((i2==0) || (strcmp(cad, oldcad)!=0))
	{
	OutputFile << atof(cad) << "\n";
	strcpy(oldcad, cad);
	NonRepeated++;
	WrittenPositions++;
	ChosenPosition[i2]=true;
	}	 
}

}
OutputFile.close();

cout << "Position file " << filename3 << " has been generated\n";

// if (i2>=6)




OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

	 unsigned int cont;
	 unsigned int size=0;
	while  (InputFile.peek()!=EOF)

	{
    InputFile.getline (genotypebuf, 15+TotalSNPs, '\n');
	InputFile.getline (genotypebuf2, 15+TotalSNPs, '\n');

     size++;
     OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 int cont=0;
	 for (i2=0; i2<TotalSNPs; i2++)
   	   if (ChosenPosition[i2]==true)
	 {
	 if (*(genotypebuf+i2)=='0')
	 OutputFile << "1 "; 
	 else
	 OutputFile << "2 "; 
	 if (*(genotypebuf2+i2)=='0')
	 OutputFile << "1"; 
	 else
	 OutputFile << "2"; 
	 //if (cont<(Length-1))
      OutputFile << " "; 
//	 else
	 cont++;
	 }
	  OutputFile << "\n"; 

	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename << " has been saved in dHAP format at " << filename2 <<"\n";
//if (TotalSNPs>NonRepeated)
cout << "Final number of non-repeated SNPs " << WrittenPositions << "\n";

zap (genotypebuf);
zap(cad2);
zap(cad);
zap(genotypebuf2);
zap(ChosenPosition);
zap(genotypebuf3);

}
/*____________________________________________________________ */

void ImportFromCOSI (char *filename, char *filename2, SNPPos TotalSNPs) 
{
cout <<"Importing from COSI (Broad Institute) at file " << filename << "\n";
unsigned int i2, NonRepeated=0;

ifstream InputFile; 

InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf;
   if ((genotypebuf=new char[10+4*TotalSNPs])==NULL)
     throw NoMemory();

   
OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

	 unsigned int cont;
	 unsigned int size=0;
	while  (InputFile.peek()!=EOF)

	{
    InputFile.getline (genotypebuf, 10+4*TotalSNPs, '\n');
     size++;
     OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 int cont=0;
	 for (i2=0; i2<TotalSNPs; i2++)
   		 {
	 if (genotypebuf[i2*4]=='2')
	 OutputFile << "1 "; 
	 else
	 OutputFile << "2 "; 
	 if (genotypebuf[i2*4+2]=='2')
	 OutputFile << "1"; 
	 else
	 OutputFile << "2"; 
     OutputFile << " "; 
	 cont++;
	 }
	  OutputFile << "\n"; 

	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename << " has been saved in dHAP format at " << filename2 <<"\n";
cout <<"There were " << size <<" individuals and " << TotalSNPs <<" SNPs.\n";

zap (genotypebuf);


}
/*____________________________________________________________ */

void ImportFromHAP (char *filename, char *filename2, SNPPos TotalSNPs) 
{
cout <<"Importing from COSI (Broad Institute) at file " << filename << "\n";

unsigned int i2, NonRepeated=0;

//unsigned long int RegionSize=0;
ifstream InputFile; 

InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *genotypebuf2;
   if ((genotypebuf=new char[10+TotalSNPs])==NULL)
     throw NoMemory();

	if ((genotypebuf2=new char[10+TotalSNPs])==NULL)
     throw NoMemory();

   
OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

	 unsigned int cont;
	 unsigned int size=0;
	while  (InputFile.peek()!=EOF)

	{
    InputFile.getline (genotypebuf, 10+TotalSNPs, '\n');
	InputFile.getline (genotypebuf2, 10+TotalSNPs, '\n');

     size++;
     OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 int cont=0;
	 for (i2=0; i2<TotalSNPs; i2++)
   		 {
	 if (genotypebuf[i2]=='2')
	 OutputFile << "1 "; 
	 else
	 OutputFile << "2 "; 
	 if (genotypebuf2[i2]=='2')
	 OutputFile << "1"; 
	 else
	 OutputFile << "2"; 
     OutputFile << " "; 
	 cont++;
	 }
	  OutputFile << "\n"; 

	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename << " has been saved in dHAP format at " << filename2 <<"\n";

zap (genotypebuf);
zap(genotypebuf2);


}
/*____________________________________________________________ */

void ImportFromML (char *filename, char *filename2, SNPPos TotalSNPs) 
{
cout <<"Importing from MLT at file " << filename << "\n";

stringSample* source=new stringSample(filename);


if (TotalSNPs!=source->GetFirstElement()->GetSize())
{
cout <<"Error in ImportFromMLT, TotalSNPs is " << TotalSNPs << " while source file has " << source->GetFirstElement()->GetSize() << " SNPs";
}

stringSample::NodePointer p=source->GetFirst();
OutputFile.open (filename2, ifstream::out);
int size=0;
stringList* row=NULL;
while (p!=NULL)
	{
size++;
    row=source->GetElement(p);
     OutputFile << size << " " << size << " 1 0 0 0 " << size;	//idFam, id, sex,affectation,father, mather, id
	
	
for (int i2=0; i2<TotalSNPs; i2++)
   		 {
if (row->GetElement(i2).length()!=1)
{
cout <<"Error in ImportFromML in source file";
end();
}
switch (row->GetElement(i2)[0])
{
case '0':  OutputFile << " 1 2"; break;
case '1':  OutputFile << " 1 1"; break;
case '2':  OutputFile << " 2 2"; break;
case '?':  OutputFile << " 0 0"; break;
default: 
cout <<"Error 2 in ImportFromMLT in source file";
end();
}
	
	 }
	  OutputFile << "\n"; 
p=source->GetNext(p);
	}; // end while
OutputFile.close();
delete(source);
cout << "File " << filename << " has been saved in Makeped format at " << filename2 <<"\n";
}
/*____________________________________________________________ */

void ImportFromMLC (char *filename, char *filename2, SNPPos TotalSNPs) 
{
cout <<"Importing from MLC at file " << filename << "\n";

stringSample* source=new stringSample(filename);


if (TotalSNPs!=source->GetFirstElement()->GetSize()-1)
{
cout <<"Error in ImportFromMLT, TotalSNPs is " << TotalSNPs << " while source file has " << source->GetFirstElement()->GetSize()-1 << " SNPs";
}

stringSample::NodePointer p=source->GetFirst();
OutputFile.open (filename2, ifstream::out);
int size=0;
stringList* row=NULL;
while (p!=NULL)
	{
size++;
    row=source->GetElement(p);
     OutputFile << size << " " << size << " 1 " << row->GetLastElement() <<" 0 0 " << size;	//idFam, id, sex,affectation,father, mather, id
	
	
for (int i2=0; i2<TotalSNPs; i2++)
   		 {
if (row->GetElement(i2).length()!=1)
{
cout <<"Error in ImportFromMLC in source file";
end();
}
switch (row->GetElement(i2)[0])
{
case '0':  OutputFile << " 1 2"; break;
case '1':  OutputFile << " 1 1"; break;
case '2':  OutputFile << " 2 2"; break;
case '?':  OutputFile << " 0 0"; break;
default: 
cout <<"Error 2 in ImportFromMLC in source file";
end();
}
	
	 }
	  OutputFile << "\n"; 
p=source->GetNext(p);
	}; // end while
OutputFile.close();
delete(source);
cout << "File " << filename << " has been saved in Makeped format at " << filename2 <<"\n";
}
/*____________________________________________________________ */

void ImportFromHUDSON (char *filename)
{
// a first line must be introduced with the total nmber of SNPs
// lst two lines must be removed
	/*
cout <<"Importing from HUDSON at file " << filename << "\n";


unsigned int i2;
ifstream InputFile; 




InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *genotypebuf2, *cad, *cad2;
    if ((genotypebuf=new char[100000])==NULL)
     throw NoMemory();
	if ((genotypebuf2=new char[100000])==NULL)
     throw NoMemory();
	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


 //    unsigned long int pos;
	 bool found=false;
	 unsigned long int TotalSNPs;

   	InputFile.getline (genotypebuf, 200, '\n');
	cad = strtok (genotypebuf," \t");
//	cad = strtok (NULL," \t");
	TotalSNPs=atoi(cad);



char *filename2;

ofstream OutputFile;

if ((filename2=new char[64])==NULL)
 throw NoMemory();

filename2=strtok(filename, ".");

strncat(filename2, ".pos\0", 4);//


OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

  cad = strtok (genotypebuf," \t");
  for (i2=0; i2<TotalSNPs; i2++)
   OutputFile << i2 << "\n";


OutputFile.close();

cout << "Position file " << filename2 << " has been generated\n";




filename2=strtok(filename, ".");

strncat(filename2, ".txt\0", 4);//


OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


	 unsigned int size=0;

	 
	while  (InputFile.peek()!=EOF)
	{
    InputFile.getline (genotypebuf, 200, '\n'); // number
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
    InputFile.getline (genotypebuf2, 200, '\n'); // number
	InputFile.getline (genotypebuf2, 8*TotalSNPs, '\n');

	size++;

    OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 for (i2=0; i2<TotalSNPs; i2++)
	 {
	 OutputFile << ConvertAllele(*(genotypebuf+i2)) << " "; 
 	 OutputFile << ConvertAllele(*(genotypebuf2+i2)); 
	 if (i2<(TotalSNPs-1))
      OutputFile << " "; 
	 else
	  OutputFile << "\n"; 
	 }
	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename2 << " has been saved in dHAP format\n";


delete genotypebuf, cad2, cad, genotypebuf2, filename, filename2;
*/
}
/*____________________________________________________________ */




};  // Fin del Namespace

#endif
/* Fin Fichero: ImportFormat.h */
