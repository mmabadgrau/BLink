echo MAF>=0, add 1 to all haps 
echo all individual
./PhaseResolver data/genotypes_chr22.gen 11764 90 1 2 1 1 1700000 1600000 50000 0
echo only parents 
./PhaseResolver data/genotypes_chr22.gen 11764 90 1 0 1 1 1700000 1600000 50000 0
echo only children
./PhaseResolver data/genotypes_chr22.gen 11764 90 1 1 1 1 1700000 1600000 50000 0
