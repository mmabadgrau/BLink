/* File: Genotype.h */


#ifndef __Genotype_h__
#define __Genotype_h__

//#include <string.h>
//#include <cstdio>
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include "../commonc++/list.h"//


#include "Diplotype.h"

#include "Exceptions.h"

//using namespace UTILS;


namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/

 
class Genotype {


private:
    /** @name Implementation of class Genotype
        @memo Private part.
    */

	Diplotype* DiplotypeArray;

	SNPPos TotalSNPs;

 //  char* line;
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

void CheckRangeSNP(SNPPos SNP, char* message);

Diplotype* copy (Diplotype * DiplotypeArraySource);

		/* PUBLIC FUNCTIONS (INTERFACE) */

public:



      /** @name Operations on Genotype 
        @memo Operations on a Genotype 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
Genotype();
	
Genotype(SNPPos TotalSNPs);

Genotype (const Genotype& Source);

	
Genotype(const Diplotype::DiplotypeS* SourceList, SNPPos TotalSNPs);

Genotype(const Genotype & Source, list<SNPPos> *Sampling);

      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
~Genotype ();

      /**
         @memo Assignation
         @param g Genotype to copy.
         @return Reference to the receptor Genotype.
	 @doc
           Copy the Genotype in the receptor Genotype.
           Time complexity O(1).

      */
Genotype& operator=(const Genotype& g);




      /**
         @memo Is equal
         @param g: Genotype to compare with.
	 @return
           Return true if all the Genotype is the same, false otherwise.
         @doc Time complexity O(1).

      */
bool operator==(const Genotype & g){cout <<"Not implemented yet"; exit(0);};;
;
      /**
         @memo Is different
         @param g, position: Genotype to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
bool operator!=(const Genotype & g);

SNPPos GetTotalSNPs();
   
void OrderSNPs (allele * MajorAllele);

void OrderMajorFirst (allele * MajorAllele);

allele GetLeftAllele (SNPPos position);

allele GetRightAllele (SNPPos position);

bool IsEqual(Genotype g, SNPPos position);

Diplotype* GetGenotype ();

//void LinkGenotype (NodePointer First, NodePointer Second);
	  
bool IsHomozygousHomozygous (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous1Homozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous2Homozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous1Homozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous2Homozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous1Heterozygous (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHeterozygousHomozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous2Heterozygous (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHeterozygousHomozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygousHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHeterozygousHomozygous (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHeterozygousHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsMissingMissing (const SNPPos position, SNPPos position2);      

bool IsNotMissingNotMissing (const SNPPos position, SNPPos position2);      

bool IsHomozygous1Missing (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsMissingHomozygous1 (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHomozygous2Missing (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsMissingHomozygous2 (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsHeterozygousMissing (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsMissingHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele);      

bool IsPhaseKnown (const SNPPos SNP1, const SNPPos SNP2, allele* MajorAllele);      

bool HaveTheSameHomoPos(Genotype OtherGenotype, SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele);

SNPPos IsMajorMajor (allele MajorAllele1, allele MajorAllele2, Diplotype D1, Diplotype D2);      

SNPPos GetTotalHeterozygousPos(allele* MajorAllele);

void CountHaps (IndPos* Haps, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele); 

void CountPhasedHaps (IndPos* Haps, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele); 

SNPPos GetFirstHeterozygous (allele* MajorAllele);      

void ChangeAlleles(SNPPos SNP);

void MarkAlleles(SNPPos SNP);

bool IsMarked(SNPPos SNP);

void OrderRandomly(allele * MajorAllele);

 
 	  /**
         @memo Increase the counter of the total number of known haplotypes between two positions.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param IndGenotype: individual whose haplotype is going to be checked
         @param FirstSNP, LastSNP: the two loci
     */
     
void CountPairwiseHaps (frequencies comb, SNPPos FirstSNP, SNPPos LastSNP, allele *MajorAllele);

unsigned short int CountPhasedHap (allele* Hap, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele);

void SetDiplotype (Diplotype Dip, SNPPos SNP);

void SetAlleles(allele Left, allele Right, SNPPos SNP);

string printSNP(SNPPos SNP, bool markUnphased=false);

string printSNP(SNPPos SNP, HaplotypeType h);

string print(SNPPos first=0,SNPPos last=0, bool markUnphased=false);

string print(HaplotypeType h);

Diplotype GetDiplotype(SNPPos SNP);

SNPPos GetKnownHap (const SNPPos SNP1, const SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele);      

SNPPos GetPhasedHap (const SNPPos SNP1, const SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele);      

SNPPos GetHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode);      

SNPPos GetAB (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode);      

SNPPos GetAb (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode);      

SNPPos GetaB (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode);      

SNPPos Getab (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode);  

bool CanBeSolved (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele);      
    
//void LinkGenotype (Genotype* First, Genotype* Second);

//NodePointer GetFirstRelative ();

//NodePointer GetSecondRelative ();


		bool  operator>(const Genotype & ge){cout <<"Not implemented yet"; exit(0);};;

		bool  operator<(const Genotype & ge){cout <<"Not implemented yet"; exit(0);};;


};  // End of class Genotype


};  // End of Namespace

#endif

/* End of file: Genotype.h */




