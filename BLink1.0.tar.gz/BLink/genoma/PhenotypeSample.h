/* File: PhenotypeSample.h */


#ifndef __PhenotypeSample_h__
#define __PhenotypeSample_h__



#include "Phenotype.cpp"



//using namespace UTILS;


namespace BIOS {

  /**
      @memo Declaration of type of individual
      @doc It can have one of {0,1} values. 0 for parent, 1 for children, 2 for everybody.
      */



	 /**
      @memo typefile
      @doc It represents the type of file, phase or TDT
      */


/************************/
/* PhenotypeSample DEFINITION */
/************************/


/**
        @memo PhenotypeSample for SNPs

	@doc
        Definition:
        A set of PhenotypeSample's features for each individual

        Memory space: O(SizeP), which SizeP being the number of individuals in the sample

    @author Maria M. Abad
	@version 1.0
*/


	class PhenotypeSample: public Container<Phenotype, list>  {

  protected:
    /** @name Implementation of class PhenotypeSample
        @memo Private part.
    */
 
	  
    /**
       @memo if there is PhenotypeSample information in the sample
       @doc  boolean, 1: yes, 0, no
    */


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

/////////////////////////////////////////////

//void ReadPhenotype (ifstream*  source, SNPPos TotalSNPs, unsigned short int ReduceSample, unsigned int SizeP);

/////////////////////////
//Phenotype ReadElement (ifstream* source, char* tokens);


      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:

//	 PhenotypeSample();
      /**
         @memo Destructor
	 @doc
           Deallocate memory used by PhenotypeSample.
           Time complexity O(1).

      */
      ~PhenotypeSample (){};
//////////////////////////////////////////////


PhenotypeSample():Container<Phenotype, list>(){};

PhenotypeSample(PhenotypeSample & source):Container<Phenotype, list>(source){};

PhenotypeSample(Container<Phenotype, list> & source):Container<Phenotype, list>(source){};


  /////////////////////////////////////////////
      /**
         @memo Constructor from input buffer
         @param file: file position in which is the PhenotypeSample who will be copy
         @param origen: PhenotypeSample to read
         @doc
           Read an PhenotypeSample
           Time complexity in time O(1).
        */
		  PhenotypeSample (char* filename);//:Container<Phenotype, list>(filename){}; //, const unsigned int InputSizeP, const SNPPos TotalSNPs, unsigned short int ReduceSample);

	    /////////////////////////////////////////////
      /**
         @memo Constructor from input buffer
         @param file: file position in which is the PhenotypeSample who will be copy
         @param origen: PhenotypeSample to read
         @doc
           Read an PhenotypeSample
           Time complexity in time O(1).
        */
//	  PhenotypeSample (char* filename);


     // PhenotypeSample (const PhenotypeSample & origen, istream* file, const typefile tf);

///////////////////////////////////////////////////
      /**
         @memo Assignation
         @param ind: PhenotypeSample to copy.
         @return Reference to the receptor PhenotypeSample.
	 @doc
           Copy the PhenotypeSample in the receptor PhenotypeSample.
           Time complexity O(1).

      */
      PhenotypeSample& operator=(const PhenotypeSample & source);
////////////////////////////////////////////////////
   
      /**
         @memo Is equal
         @param g: PhenotypeSample to compare with.
	 @return
           Return true if the SNP is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const PhenotypeSample & source);
      /**
         @memo Is different
         @param g: PhenotypeSample to cmpare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const PhenotypeSample & source);

 	
	 NodePointer GetRelative(IndCategory ic, NodePointer const i);

		/**
         @memo Obtain the position of the PhenotypeSample of the father.
         @param The pointer to the current individual's PhenotypeSample
         @return return the position for the father
         Time complexity O(1)
		**/


	 NodePointer GetFather(NodePointer const i);

	
		/**
         @memo Obtain the position of the PhenotypeSample of the mother.
         @param The pointer to the current individual's PhenotypeSample
         @return return the position for the mother
         Time complexity O(1)
		**/

	NodePointer GetMother(NodePointer const i);

				/**
         @memo Obtain the position of the PhenotypeSample of his/her first couple.
         @param The pointer to the current individual's PhenotypeSample
         @return return the position for the mother
         Time complexity O(1)
		**/

	NodePointer GetCouple(NodePointer const i, NodePointer const pChild);

	NodePointer GetCouple(NodePointer const p);


				/**
         @memo Obtain the next sib with common parent
         @param The pointer to the current individual's PhenotypeSample
         @return return the position for the next sib
         Time complexity O(1)
		**/

	NodePointer GetNextSib(NodePointer const i, NodePointer const parent);

       
		   /**
         @memo Obtain the first child of a parent.
         @param The parent position
         @return return the position of the child
         Time complexity O(TotalSize)
		*/
	
	NodePointer GetFirstChild(NodePointer const i);

    
		   /**
         @memo Obtain the number of offspring in the sample 
         @return the size of a sample
         @doc Return the number of offpring phenotypes in the sample. 
         Time complexity O(Size)

      */
    IndPos GetTotalOffSpring ();          

  		   /**
         @memo Obtain the number of individual of ic category in the sample 
         @return the size of a sample
         @doc Return the number of offpring phenotypes in the sample. 
         Time complexity O(Size)

      */
    IndPos GetTotalIndividuals (IndCategory inc);          



		  /**
         @memo Print the PhenotypeSample for an individual.
         @param Position: Position of this individual in the sample
         Time complexity O(1)

      */
	
	string PrintPhenotype (NodePointer p);

	
	void SetMarked (bool *Marked, IndCategory ic, int gender=everyGender, int affectation=allAffectation);

	
	void  PrintPhenotypes ();

PhenotypeSample* copyElementsWithPositionsIn(intList* positions, bool inThis=true);


};  // End of class PhenotypeSample

typedef PhenotypeSample::NodePointer PhenotypePointer;



};  // Fin del Namespace

#endif

/* Fin Fichero: PhenotypeSample.h */
