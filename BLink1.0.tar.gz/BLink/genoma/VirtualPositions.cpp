/* File: VirtualPositions.h */

#ifndef __VirtualPositions_cpp__
#define __VirtualPositions_cpp__


#include "VirtualPositions.h"


namespace BIOS {



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

/*___________________________________________________________ */

 template<> PosS* list<PosS*>::ReadElement (ifstream * is, char* tokens)
{
  	PosS* posS=new PosS();
	char *line;
//cout << *is;
	line=CaptureLine(is);

//cout <<"v" << line;
//char st[20];
//sscanf(line, "%s", &st);
//cout << "bf" << st << "aft";
	sscanf(line, "%lf", &posS->pos);
	delete line;

	return posS;
}
/*___________________________________________________________ */

 PosS* VirtualPositions::ReadElement (ifstream * is, char* tokens)
{
PosS* val;
val=ListOfPointers<PosS>::ReadElement(is, tokens);
	 return val;
}
/*____________________________________________________________ */

	  PosS* VirtualPositions::GetExtremeElement(bool max)//{};

//  template<> PosS list<PosS>::GetExtremeElement(bool max)
  {
    // it returns a pointer to the element in the list which has the closest upper value than argument
  cout <<"Not implemented yet";
  exit(0);
 //   PosS posS;
   // return posS;
  };

/*____________________________________________________________ */

void VirtualPositions::SetFilePos ()
{
SNPPos i=0;
NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
IndPosition->element->filepos=i;
//cout <<"pos:" <<  IndPosition->element->filepos;
IndPosition=GetNext(IndPosition);
i++;
}
}

///////////////////
//// public ////////
///////////////////
/*____________________________________________________________ */
/*
VirtualPositions::VirtualPositions()
{
}
*/
/*____________________________________________________________ */

void VirtualPositions::addRSNumbers()
{
	list<string>* RSList=new list<string>(fileRS);
	list<string>::NodePointer p=RSList->GetFirst();
	NodePointer IndPosition=GetFirst();

	if (RSList->GetSize()!=GetSize())
	{
		cout <<"Error, different size in rs file";
		end();
	}
	while (p!=NULL)
	{
IndPosition->element->rsNumber=string(RSList->GetElement(p));
IndPosition=GetNext(IndPosition);
p=RSList->GetNext(p);
	}
}
/*____________________________________________________________ */

VirtualPositions::VirtualPositions(char* filen):ListOfPointers<PosS>()
{
//
//exit(0);
strcpy(filename, filen);
CheckFilename(filen);

GetInfo(filen, "\t \n"); 
SetFilePos();
ChangeExtension(filename, fileRS, "rs");
if (existFile(fileRS))
 addRSNumbers();
//cout << print();
}

/*____________________________________________________________ */

void VirtualPositions::PrintPositions (char* filename)
 {


  FILE * OutputFile; 
  
  try
{
  OutputFile=fopen (filename, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
fprintf(OutputFile, "%10.1f\n", (GetElement(IndPosition))->pos);
IndPosition=GetNext(IndPosition);
}
  
 fclose(OutputFile);

cout <<"File " << filename << " has been written.\n";
 }
/*____________________________________________________________ */

void VirtualPositions::PrintRSNumbers (char* filename)
 {


  FILE * OutputFile; 
  
  try
{
  OutputFile=fopen (filename, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
fprintf(OutputFile, "%s\n", (GetElement(IndPosition))->rsNumber.c_str());
IndPosition=GetNext(IndPosition);
}
  
 fclose(OutputFile);

cout <<"File " << filename << " has been written.\n";
 }
/*____________________________________________________________ */

//SNPPos list<SNPPos>::ReadElement (ifstream * is, unsigned long int size){};
/*____________________________________________________________ */

list<SNPPos>* VirtualPositions::GetOnlyFilePos ()
 {
list<SNPPos>* FP;

FP=new list<SNPPos>();
//FP->List=NULL;
NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
FP->insertElement(GetElement(IndPosition)->filepos);
IndPosition=GetNext(IndPosition);
}
return FP; 
}

/*____________________________________________________________ */

SNPPos VirtualPositions::GetTotalSNPs()
{
 return GetSize();
}
/*__________________________________________________________*/

void VirtualPositions::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}
/*____________________________________________________________ */

double VirtualPositions::GetPosition(SNPPos SNP)
{
	return GetPosition(GetNode(SNP));
}
/*____________________________________________________________ */

double VirtualPositions::GetPosition(VirtualPositions::NodePointer p1)
{
	return GetElement(p1)->pos;
}

/*____________________________________________________________ */

string VirtualPositions::PrintPosition(SNPPos SNP, int integerPart, int decimalPart)
{

return PrintPosition(GetNode(SNP), integerPart, decimalPart);


}
/*____________________________________________________________ */

string VirtualPositions::PrintPosition(VirtualPositions::NodePointer p, int integerPart, int decimalPart)
{

return tos(GetElement(p)->pos, integerPart, decimalPart);


}

/*____________________________________________________________ */

string VirtualPositions::getRSNumber(SNPPos SNP)
{

return getRSNumber(GetNode(SNP));


}
/*____________________________________________________________ */

string VirtualPositions::getRSNumber(VirtualPositions::NodePointer p)
{

return GetElement(p)->rsNumber;


}
/*____________________________________________________________ */

void VirtualPositions::SNPSampling (list<SNPPos> *Sampling)
{
	VirtualPositions* sample2;
	sample2=new VirtualPositions();
    PosS *newpos;
	list<SNPPos>::NodePointer p=Sampling->GetFirst();
	while (p!=NULL)
	{
     newpos=GetElement(Sampling->GetElement(p));
	 sample2->insertElement(newpos);
	 p=Sampling->GetNext(p);
	}
      destroy(List);
      copy (sample2->List);
zap(sample2);
}

/*____________________________________________________________ */

void VirtualPositions::ChangeUnits (SNPPos factor)
{
	VirtualPositions* sample2;
	sample2=new VirtualPositions();
    PosS* newpos;

    NodePointer p=GetFirst();
	while (p!=NULL)
	{
     newpos=GetElement(p);
	 newpos->pos=newpos->pos*factor;
	 sample2->insertElement(newpos);
	 p=GetNext(p);
	}
    *this=*sample2;
}

};  // Fin del Namespace

#endif

/* Fin Fichero: VirtualPositions.cpp */
