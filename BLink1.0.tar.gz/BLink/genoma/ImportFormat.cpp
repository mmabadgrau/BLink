  /**
    * @file ImportFormat.cpp
    * @brief Program to Import formats in genotype files
	* @example ImportFormat PHASE chrom1.red chrom1PHASE.inp 
	* convert a file called chrom1.red in our format to PHASE format. The target file will be
    * called chrom1PHASE.inp. 
    */


#include <iostream>
#include <cassert>
#include <fstream>


#include "../commonc++/Fachade.h"
#include "ImportFormat.h"
#include "Positions.h"


/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

unsigned int TotalIndividuals=0;


     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " PHASE/PHASERECOMB/SNPHAP/HTYPER/PLEM/MS/COSI/ML/MLC " << " <source file> " 
			 << " <target file>" <<"<size (individuals)>"  << endl;
        exit(-1);
        }//<< "Total individuals>"
     char filename[128], filename2[128], filepos[128], Alg[20];

	 
     strcpy (Alg,argv[1]);
	 FormatType Algorithm=GetFormatType (Alg);

	 strcpy(filename, argv[2]);
	 strcpy(filename2, argv[3]);
	 /*
	 else 
	 {
		 char ext[20];
		 sprintf(ext, "output%s", Algorithm);
		 ChangeExtension (filename, filename2, ext);
	 }
*/

	 if (argc==5) TotalIndividuals=atoi(argv[4]);
     else
     if (Algorithm<4)
	 {
		 cout <<"\nThe number of individuals is required as argument";
		exit(0);
	 }

CheckFile(filename);

SNPPos TotalSNPs;
if (Algorithm!=MS)
{
ChangeExtension (filename, filepos, "pou");
Positions* p;
p=new Positions(filepos);
TotalSNPs=p->VirtualPositions::GetTotalSNPs();
delete p;
}
switch (Algorithm)
{
case PHASE:  //  PHASE
case PHASERECOMB:
ImportFromPHASE(filename, filename2, TotalIndividuals, TotalSNPs);
break;
case SNPHAP: // SNPHAP
ImportFromSNPHAP (filename, filename2, TotalIndividuals, TotalSNPs);
break;
case HTYPER: // HTYPER
case PLEM:
ImportFromHTYPER (filename, filename2, TotalIndividuals, TotalSNPs, Algorithm);
break;
case MS: // MSAMPLE
ImportFromMSAMPLE (filename, filename2);//, InitialPos, Length);
break;
case COSI: // COSI
ImportFromCOSI (filename, filename2, TotalSNPs);
break;
case HAP: // HAP
	ImportFromHAP (filename, filename2, TotalSNPs);
break;
case ML: // ML
ImportFromML (filename, filename2, TotalSNPs);
break;
case MLC: // ML
ImportFromMLC (filename, filename2, TotalSNPs);
break;
}
}


