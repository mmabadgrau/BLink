dircode="/home/faculty/mabad/genoma"
if [ $# -ne 3 ]
then
echo This macro needs three arguments: the first with the directory where hapmap files reside and the second and third with the name of month and the year respectively
stop
fi
cd $1
cd $1
echo Change to a subdirectory of the genoma fold
cp $dircode/pedigree.txt $1
echo Convert to ped format
chromosome="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
# chromosome="2"
for a in $chromosome
do
# echo $a 
inputfile="genotypes_chr"$a"_txt_gz.txt"
outputfile="chromosome"$a$2$3".txt"
originalfile="genotypes_chr"$a".txt.gz"
mv $originalfile $inputfile
$dircode/hapmap $inputfile 90 $outputfile
echo Converted to dhap format
done
