
#include <fstream>
#include <string>
#include <stdio.h>//
#include <iostream>//
#include <cassert>//
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//
#include <ctime>//
#include <malloc.h>//
#include <fstream>//
#include <math.h>

#include "../commonc++/basic.h"

#include "Exceptions.h"
#include "SNP.h"
#include "Tables2x2.h"

using namespace UTILS;
using namespace BIOS;

int main (int argc, char *argv[])
{
 if(argc<6)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <n(AB)> " << " <n(Ab)>" << " <n(aB)>" << " <n(ab)>" << "<type (0:D/1:DPrime/2:AbsDPrime)>"
			 << endl;
        exit(-1);
        }
    
Table2x2 T2x2;
	 
	 double nAB=atoi(argv[1]);
	 double nAb=atoi(argv[2]); 
	 double naB=atoi(argv[3]); 
	 double nab=atoi(argv[4]);
	 int type=atoi(argv[5]);
	 double fA=(nAB+nAb)/(nAB+nAb+naB+nab);
	 double fB=(nAB+naB)/(nAB+nAb+naB+nab);
	 int size;
 
struct FreqAndVal*List; 

switch (type)
{
case 0: cout << "D:\n"; size=201; List=T2x2.GetDDistribution(fA, fB, nAB, nAb, naB, nab, 0); break;
case 1: cout << "DPrime:\n"; size=201; List=T2x2.GetDPrimeDistribution(fA, fB, nAB, nAb, naB, nab, 0); break;
case 2: cout << "AbsDPrime:\n"; size=101; List=T2x2.GetAbsDPrimeDistribution(fA, fB, nAB, nAb, naB, nab, 0); break;
default:break;
}

for (int i=0;i<size;i++)
{
cout << List[i].value << ", " << List[i].frequency <<"\n";
}




}
