/* File: individual.h */

#ifndef __individual_h__
#define __individual_h__

#include <string>


#include "Exceptions.h"



#include "genotype.h"
#include "phenotype.h"

namespace SNP {

#define  maxint  32767//


   

//   const short unsigned int male=1;
//   const short unsigned int female=2;
//   const short unsigned int unaffected=0;
//   const short unsigned int affected=2;


/************************/
/* individual DEFINITION */
/************************/


/**
        @memo individual for SNPs

	@doc
        Definition:
        A set of phenotype's features and genotypes for an individual

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in the sample
        Each individual in a sample has been genotyped for the same TotalSNPs SNPs.

        @author Maria M. Abad
	@version 1.0
*/

	 class individual: public phenotype, public genotype 
	 {

  protected:
    /** @name Implementation of class individual
        @memo Private part.
    */

  typedef enum LDType {Known=0, Complete=1, Infered=2}; // LD from known haplotypes, max and min respectively

  typedef enum RedType {Proyect=0, Select=1, None=3}; 

        
//	 typefile tf;




/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

 
  public:


		  
		  /**
         @memo Creates a new individual objet with the phase resolved.
         @param Origen: the origianl individual object 
         Time complexity O(TotalSNPs*Size*Size)

      */
	  individual* ResolvePhase (individual* Origen);   
	  


	  

      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */
	/*  void WriteResults (char* filename);   
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by individual.
           Time complexity O(1).

      */
	  ~individual ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
	  individual(const unsigned int TotalSNPs, const unsigned int Size, bool ExistPhenotype);


  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

	individual(const individual& origen); 
	
//	  individual(const phenotype& porigen, const genotype& gorigen, IndCategory ic);

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		individual(char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, bool ExistPhenotype); 




 /**
         @memo Resolve the phase between two consequtive heterozygous position for an individual.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param ForPhase: pointer to the genotypes of all individuals
         @param FirstSNP, LastSNP: the two loci
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
	     @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
*/

/**
         @memo Obtain the most frequent allele for a SNP.
         @param SNP: position 
		 @ return: allele value
*/

		 allele GetMajorAllele(unsigned int SNP);

/**
         @memo Obtain the less frequent allele for a SNP.
         @param SNP: position 
		 @ return: allele value
*/

		 allele GetMinorAllele(unsigned int SNP);


	  
	  				   /**
         @memo Obtain the first child of a parent homozygous at SNP.
         @param The parent position
         @return return the position of the child
         Time complexity O(TotalSNPs)
		*/
	
		int  GetChildHomozygous(unsigned int i, unsigned int SNP);

						   /**
         @memo Obtain the first child of a parent homozygous at SNP1 and SNP2.
         @param The parent position
         @return return the position of the child
         Time complexity O(TotalSNPs)
		*/
	
		int  GetChildHomozygousHomozygous(unsigned int i, unsigned int SNP1, unsigned int SNP2);




		 /**
         @memo Resolve phase for every pair of consecutive heterozygous positions for every individual in the sample
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
*/

		void ChangeIds (char *filename);


/**
         @memo Order all the SNPs genotypes in the sample.so when a genotype for a individual is
		 heterozygous, the one in the Left positions must be the Major allele.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
*/



		unsigned int FindFirstHeterozygous(unsigned int IndCode);



};  // End of class individual



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

individual::individual(const unsigned int TotalSNPs, const unsigned int Size, bool ExistPhenotype): 
phenotype(Size, ExistPhenotype), genotype(TotalSNPs, Size) 
{
};

/*____________________________________________________________ */


individual::individual(const individual& origen): phenotype(origen), genotype(origen) 
{
cout << "Computing major and minor alleles ...\n";


try {
	if (SizeP!=origen.SizeP) cout <<"Error1";
	if (genotype::TotalSNPs!=origen.genotype::TotalSNPs) cout <<"Error2";
	if (phenotype::TotalSNPs!=origen.phenotype::TotalSNPs) cout <<"Error3";



  }
catch (NoMemory no) {
  no.PrintMessage();
  }

  cout << "Computation of major and minor alleles has finished\n";
//exit(0);
};

/*____________________________________________________________ */

individual::individual(char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, bool ExistPhenotype): 
phenotype(filename, InputSize, InputTotalSNPs, ExistPhenotype), genotype(filename, InputTotalSNPs, InputSize, MajorAllele, MinorAllele) 
{



};





/* ____________________________________________*/
unsigned int individual::FindFirstHeterozygous(unsigned int IndCode)
{
// return TotalSNPs if there is not any heterozygous position
unsigned int SNP=0;
Genotype* IndGenotype=GetGenotype(IndCode);
while ((!IsHeterozygous (IndGenotype, SNP))  && (SNP<genotype::TotalSNPs))
   {
   SNP++;
}
return SNP;
}



/*____________________________________________________________ */

int  individual::GetChildHomozygous(unsigned int i, unsigned int SNP)
{
bool found=false;
int child=GetFirstChild(i);
Genotype *GenotypeChild;
if (child<0)
 return -1;

do
{
if (IsHomozygous(GenotypeChild, SNP))
 found=true;
if (!found)
 child=GetNextSib(child, GetPhenotype(i));
}
while ((child>=0) && (!found));

if (found) return child; else return -1;

}
/*____________________________________________________________ */

int  individual::GetChildHomozygousHomozygous(unsigned int i, unsigned int SNP, unsigned int SNP2)
{
bool found=false;
int child=GetFirstChild(i);
Genotype *GenotypeChild;
if (child<0)
 return -1;

do
{
if (IsHomozygous(GenotypeChild, SNP) && IsHomozygous(GenotypeChild, SNP2))
 found=true;
if (!found)
 child=GetNextSib(child, GetPhenotype(i));
}
while ((child>=0) && (!found));

if (found) return child; else return -1;

}









};  // Fin del Namespace

#endif

/* Fin Fichero: individual.h */
