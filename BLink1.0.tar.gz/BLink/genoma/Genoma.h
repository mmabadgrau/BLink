/* File: Genoma.h */


#ifndef __Genoma_h__
#define __Genoma_h__

//#include <string.h>
//#include <cstdio>

#include "../commonc++/list.h"

#include "../commonc++/basic.h"
#include "SNP.h"
#include "Diplotype.h"
#include "Positions.h"
#include "PairGenotype.h"
#include "TrioGenotype.h"
#include "Trio.cpp"


namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genoma for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Genoma {


protected:

    /** @name Implementation of class Genoma
        @memo Private part.
    */
      /**
      @memo A pointer to the list of left alleles
      @doc  Each left allele contains a value {0,1,2,3,4}
      */

	  //typedef list<Diplotype> *DL;
	  
	  //DL DiplotypeList;

         
IndCategory ic;
PairGenotype *PG;
Genotype* genotype;
char*line;
      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

      void CheckRangeSNP(SNPPos SNP);

      void OrderSNPs ();

  	  void PrintCompleteGenoma();




		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on Genoma 
        @memo Operations on a Genoma 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  Genoma();


      /**
         @memo Copy constructor
         @param destino: Genoma where will be copy
         @param origen: Genoma to copy
         @doc
           Make a copy of Genoma
           Time complexity in time O(1).
        */
		  Genoma (Genoma* Source);
	
		  Genoma (Trio & trio, IndCategory i);

		  Genoma (Genotype * G, Phenotype  P, TrioGenotype & TrioG);


		        /**
         @memo Copy constructor
         @param destino: Genoma where will be copy
         @param origen: Genoma to copy
         @doc
           Make a copy of Genoma
           Time complexity in time O(1).
        */
	
		  //Genoma (Genoma& Source, unsigned int *Sampling);



      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
      ~Genoma ();
   
	  SNPPos GetHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele * MajoraAllele, bool IsPartiallySolved);      

	  bool CanBeInferred (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele);      

	  bool CanBePartiallySolved (SNPPos SNP1, SNPPos SNP2, allele * MajorAllele, bool IsPartiallySolved);      

	  void SetLeftRight (SNPPos SNP, allele MajorAllele, Diplotype & Dip);      

	  SNPPos GetInferredHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele);

	  SNPPos GetPartiallySolved (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele * MajorAllele, bool IsPartiallySolved);      

	  Genoma (const Genotype & G, const Phenotype & P);

//	  SNPPos IsMajorMajor (allele MajorAllele1, allele MajorAllele2, Diplotype & D1, Diplotype & D2);      

	  bool CanBeSolved (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele, bool IsPartiallySolved);      

	  bool CanBeInferred (SNPPos SNP, allele MajorAllele);  
	  
	  bool MustBeChanged (SNPPos SNP, allele MajorAllele);      

	  void ChangeAlleles(SNPPos SNP);

	  void MarkAlleles(SNPPos SNP);

	  Diplotype GetDiplotype(SNPPos SNP);

	  GenotypeCode GetGenotypeCode(SNPPos SNP, SNPPos SNP2, allele* MajorAllele);

	  char* PrintGenotypeCode(SNPPos SNP, SNPPos SNP2, allele* MajorAllele);

	  IndCategory GetIndCategory() {return ic;};

};  // End of class Genoma


};  // End of Namespace

#endif

/* End of file: Genoma.h */




