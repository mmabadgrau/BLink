/* File: Genotype.cpp */


#ifndef __Genotype_cpp__
#define __Genotype_cpp__



#include "Genotype.h"

//using namespace UTILS;


namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

Diplotype* Genotype::copy (Diplotype * DiplotypeArraySource)
{
Diplotype* DiplotypeArrayTarget;

try
{
 if ((DiplotypeArrayTarget=new Diplotype [TotalSNPs])==NULL)
	throw NoMemory();
for (SNPPos i=0;i<TotalSNPs;i++)
 DiplotypeArrayTarget[i]=DiplotypeArraySource[i];
}
 catch (NoMemory ov) {ov.PrintMessage();}
return DiplotypeArrayTarget;
}


///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

Genotype::Genotype()
{
DiplotypeArray=NULL;
TotalSNPs=0;
}
/*____________________________________________________________ */

Genotype::Genotype(SNPPos TotalS)
{
TotalSNPs=TotalS;
try
{
 if ((DiplotypeArray=new Diplotype [TotalSNPs])==NULL)
	throw NoMemory();
}
 catch (NoMemory ov) {ov.PrintMessage();}

}

/*____________________________________________________________ */

Genotype::Genotype(const Genotype & Source)
{
TotalSNPs=Source.TotalSNPs;
DiplotypeArray=NULL;
DiplotypeArray=copy (Source.DiplotypeArray);
}
/*____________________________________________________________ */

Genotype::Genotype(const Genotype & Source, list<SNPPos> *Sampling)
{
DiplotypeArray=NULL;
TotalSNPs=Sampling->GetSize();
try
{
 if ((DiplotypeArray=new Diplotype [TotalSNPs])==NULL)
	throw NoMemory();
}
 catch (NoMemory ov) {ov.PrintMessage();}

 list<SNPPos>::NodePointer p=Sampling->GetFirst();
 int i=0;
 while (p!=NULL)
 {
 DiplotypeArray[i]=Source.DiplotypeArray[Sampling->GetElement(p)];

 p=Sampling->GetNext(p);
 i++;

 }
 
}
/*____________________________________________________________ */

Genotype& Genotype::operator=(const Genotype & Source)
{
  if (this!=&Source)  
  {
  TotalSNPs=Source.TotalSNPs;
  zaparr(DiplotypeArray);
  DiplotypeArray=copy (Source.DiplotypeArray);
  } 
  return *this;
}
/*____________________________________________________________ */

Genotype::~Genotype()
{
zaparr (DiplotypeArray);// we do not delete this list because we can have sampling
}
/*____________________________________________________________ */

SNPPos Genotype::IsMajorMajor (allele MajorAllele1, allele MajorAllele2, Diplotype D1, Diplotype D2)      
{
return (D1.GetLeftAllele()==MajorAllele1 && D2.GetLeftAllele()==MajorAllele2) 
		|| (D1.GetRightAllele()==MajorAllele1 && D2.GetRightAllele()==MajorAllele2); 
}
/*____________________________________________________________ */

SNPPos Genotype::GetTotalSNPs()
{
return	TotalSNPs;
}
/*____________________________________________________________ */

SNPPos Genotype::GetTotalHeterozygousPos(allele* MajorAllele)
{
SNPPos total=0;
Diplotype D;
for (SNPPos i=0;i<TotalSNPs;i++)
{
 D=GetDiplotype(i);
 if (D.IsHeterozygous(MajorAllele[i]))
  total++;
}
return total;
}
/*____________________________________________________________ */
/*
void Genotype::MarkHeterozygousPos(bool* HeteroList, allele* MajorAllele)
{
SNPPos HeteroPos=GetTotalHeterozygousPos(MajorAllele);
if (sizeof (*HeteroList)!=TotalSNPs)
{
	cerror <<"In MazHeterozygousPos";
	exit(0);
}
Diplotype D;
for (SNPPos i=0;i<TotalSNPs;i++)
{
 D=GetDiplotype(i);
 if (D.IsHeterozygous(MajorAllele[i]))
  HeteroList[h]=true;
 else
  HeteroList[h]=false;
}
}
/*____________________________________________________________ */

void Genotype::OrderMajorFirst(allele * MajorAllele)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions
try
{
if (DiplotypeArray==NULL)
 throw NullValue();
for (SNPPos i=0; i<TotalSNPs;i++)
// cout << DiplotypeArray[i].print(); //
DiplotypeArray[i].OrderMajorFirst(MajorAllele[i]);
; //cout << "\n";
}
catch (NullValue nv)
{
		 nv.PrintMessage(" in Genotype::GetDiplotype");
}
}
/*____________________________________________________________ */

void Genotype::OrderRandomly(allele * MajorAllele)
{
	// for those heterozygous positions, rewrite alleles randomly

for (SNPPos i=0; i<TotalSNPs;i++)
 DiplotypeArray[i].OrderRandomly(MajorAllele[i]);

}
/*____________________________________________________________ */

void Genotype::ChangeAlleles(SNPPos SNP)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

 DiplotypeArray[SNP].ChangeAlleles();

}
/*____________________________________________________________ */

void Genotype::MarkAlleles(SNPPos SNP)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

 DiplotypeArray[SNP].MarkAlleles();

}
/*____________________________________________________________ */

bool Genotype::IsMarked(SNPPos SNP)
{

 return DiplotypeArray[SNP].IsMarked();

}
/*__________________________________________________________*/
void Genotype::CheckRangeSNP(SNPPos SNP, char* message=NULL)
{
SNPPos TotalSNPs=GetTotalSNPs();

try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP, message);}
}
/*__________________________________________________________*/
Diplotype Genotype::GetDiplotype(SNPPos SNP)
{
CheckRangeSNP(SNP, "getDiplotype");
//exit(0);
//cout <<"LL:"<< TotalSNPs;
//GetTotalSNPs();
//exit(0);
try
{
if (DiplotypeArray==NULL)
 throw NullValue();
return DiplotypeArray[SNP];
}
 catch (NullValue nv) {
		 nv.PrintMessage(" in Genotype::GetDiplotype");}

}
/*__________________________________________________________*/
void Genotype::SetAlleles(allele Left, allele Right, SNPPos SNP)
{
CheckRangeSNP(SNP, "SetAlleles");
DiplotypeArray[SNP].SetLeftAllele(Left);
DiplotypeArray[SNP].SetRightAllele(Right);
}
/*__________________________________________________________*/
void Genotype::SetDiplotype(Diplotype Dip, SNPPos SNP)
{
try
{
CheckRangeSNP(SNP, "SetDiplotype");
if (DiplotypeArray==NULL)
throw NullValue();
DiplotypeArray[SNP]=Dip;
}
catch (NullValue nv)
{
		 nv.PrintMessage(" in Genotype::SetDiplotype");
}
}
/*_____________________________________________________________*/

bool Genotype::HaveTheSameHomoPos(Genotype OtherGenotype, SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele)
{
// 
SNPPos TotalSNPs=GetTotalSNPs();
if (TotalPos!=sizeof(Pos) || TotalPos>TotalSNPs)
{
	cerr << "in HaveTheSameHomoPos";
	exit(0);
};

SNPPos i=0;
Diplotype OtherDip;
while (i<TotalPos)
{
 OtherDip=OtherGenotype.GetDiplotype(Pos[i]);
 if ((DiplotypeArray[Pos[i]].IsHomozygous1(MajorAllele[Pos[i]])==true && OtherDip.IsHomozygous1(MajorAllele[Pos[i]])==false)      
	 ||
	(DiplotypeArray[Pos[i]].IsHomozygous2(MajorAllele[Pos[i]])==true && OtherDip.IsHomozygous2(MajorAllele[Pos[i]])==false)) 
 return false;
 i++;
}
return true;
}
/*_____________________________________________________________*/

void Genotype::CountHaps (IndPos* Haps, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele) 
//If this is homo at all TotalPos positions at Pos except 1, the haplotype is counted.
//The haplotype is refered with its code "pos" (log2 of the number of haplotypes)
{
SNPPos pos1=0, pos2=0, cont=0;
bool KnownHap=true;
bool FoundHetero=false;
SNPPos TotalSNPs=GetTotalSNPs();
SNPPos i=0;
Diplotype D;


while (KnownHap==true && i<TotalPos)
{
D=GetDiplotype(Pos[i]);
if (D.IsAMissingSNP()) KnownHap=false;
if (D.IsHeterozygous(MajorAllele[Pos[i]]) && FoundHetero==true) KnownHap=false;
if (D.IsHeterozygous(MajorAllele[Pos[i]]) && FoundHetero==false) 
{
	FoundHetero=true;
	pos2=pos2+pow(2,TotalPos-i-1);
}
if (D.IsHomozygous2(MajorAllele[Pos[i]]))
{
	pos1=pos1+pow(2,TotalPos-i-1);
	pos2=pos2+pow(2,TotalPos-i-1);
}
i++;
}

if (pos1> (pow(TotalPos,2)-1)  || pos2> (pow(TotalPos,2)-1))
{
	cout <<"error in COunthaps";
	exit(0);
}
if (KnownHap==true) 
{
	Haps[pos1]++;
	Haps[pos2]++;
}
//cout <<"KnownHap:" << KnownHap <<"pos1:" << pos1 << "pos2:" << pos2 << "haps[0]:" << Haps[0];
};  
/*_____________________________________________________________*/

void Genotype::CountPhasedHaps (IndPos* Haps, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele) 
//The haplotype is always counted unless is missing.
//The haplotype is refered with its code "pos" (log2 of the number of haplotypes)
{
SNPPos pos1=0, pos2=0, cont=0;
bool KnownHap=true;
bool FoundHetero=false;
SNPPos TotalSNPs=GetTotalSNPs();
SNPPos i=0;
Diplotype D;


while (KnownHap==true && i<TotalPos)
{
D=GetDiplotype(Pos[i]);
if (D.IsAMissingSNP()) KnownHap=false;
//if (D.IsHeterozygous(MajorAllele[Pos[i]]) && FoundHetero==true) KnownHap=false;
else
{
if (D.GetLeftAllele()!=MajorAllele[Pos[i]]) 
	pos1=pos1+(unsigned int)pow(2,TotalPos-i-1);
if (D.GetRightAllele()!=MajorAllele[Pos[i]]) 
	pos2=pos2+(unsigned int)pow(2,TotalPos-i-1);
}
i++;
}

if (pos1> (pow(TotalPos,2)-1)  || pos2> (pow(TotalPos,2)-1))
{
	cout <<"error in Counthaps";
	exit(0);
}
if (KnownHap==true) 
{
	Haps[pos1]++;
	Haps[pos2]++;
}
//cout <<"KnownHap:" << KnownHap <<"pos1:" << pos1 << "pos2:" << pos2 << "haps[0]:" << Haps[0];
};  
/*_____________________________________________________________*/

unsigned short int Genotype::CountPhasedHap (allele* Hap, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele) 
//The haplotype is always counted unless is missing.
//The haplotype is refered with its code "pos" (log2 of the number of haplotypes)
// return 0, 1, 2 meaning the number of times the haplotype is in this genotype
{
SNPPos pos1=0, pos2=0, cont=0;
bool FoundHetero=false;
SNPPos TotalSNPs=GetTotalSNPs();
SNPPos i=0;
Diplotype D;
unsigned short int Left=1, Right=1;

while (Left==1 && Right==1 && i<TotalPos)
{
D=GetDiplotype(Pos[i]);
if (D.IsAMissingSNP() || (D.GetLeftAllele()!=Hap[i])) 
	Left=0;
if (D.IsAMissingSNP() || (D.GetRightAllele()!=Hap[i])) 
	Right=0;
i++;
}

return Left+Right;
//return 0;
//cout <<"KnownHap:" << KnownHap <<"pos1:" << pos1 << "pos2:" << pos2 << "haps[0]:" << Haps[0];
};  
/*____________________________________________________________ */

string Genotype::printSNP(SNPPos SNP, bool markUnphased)
{
char genline[10];
CheckRangeSNP(SNP, "PrintGenotype");
Diplotype D=DiplotypeArray[SNP];
strcpy(genline, D.print(markUnphased).c_str());
strcat(genline,"\0");
return string(genline);
}
/*____________________________________________________________ */

string Genotype::printSNP(SNPPos SNP, HaplotypeType h)
{
char line2[10];
CheckRangeSNP(SNP, "PrintHaplotype");
Diplotype D=DiplotypeArray[SNP];
strncpy(line2, "\0", 1);
strcat(line2, D.print(h).c_str());
string s=string(line2);
return s;
}
/*____________________________________________________________ */

string Genotype::print(SNPPos first, SNPPos last, bool markUnphased)
{
if (DiplotypeArray==NULL) return string("null diplotype list");
char *l;//exit(0);
	 if ((l=new char [TotalSNPs*6])==NULL)
	throw NoMemory();
if (last==0) last=TotalSNPs;

//char line[TotalSNPs*5], *p=line;
//strcpy(line, "\0");
//line[0]='\0';
for (SNPPos i=first;i<last;i++)
{
 if (i==first)  strcpy(l, printSNP(i, markUnphased).c_str());
 else strcat(l, printSNP(i, markUnphased).c_str());
 //strcat(line, " ");
}
string s=string(l);
zaparr(l);
return s;
}
/*____________________________________________________________ */

string Genotype::print(HaplotypeType h)
{
char *l;
	 if ((l=new char [TotalSNPs*5])==NULL)
	throw NoMemory();
	
strcpy(l, "\0");
for (SNPPos i=0;i<TotalSNPs;i++)
 strcat(l, print(i, h).c_str());
 string s=string(l);
 zaparr(l);
return s;
}
/*___________________________________________________*/

bool Genotype::IsHomozygous1Homozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH1H1");
CheckRangeSNP(position2, "IsH1H1b");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous1(MajorAllele[position]) && D2.IsHomozygous1(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous2Homozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH2H2");
CheckRangeSNP(position2, "IsH2H2b");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous2(MajorAllele[position]) && D2.IsHomozygous2(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous1Homozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH1H2");
CheckRangeSNP(position2, "IsH1H2b");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous1(MajorAllele[position]) && D2.IsHomozygous2(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous2Homozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH2H1");
CheckRangeSNP(position2, "IsH2H1b");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous2(MajorAllele[position]) && D2.IsHomozygous1(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygousHomozygous (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHH");
CheckRangeSNP(position2, "IsHHb");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous(MajorAllele[position]) && D2.IsHomozygous(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous1Heterozygous (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH1H");
CheckRangeSNP(position2, "IsH1Hb");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous1(MajorAllele[position]) && D2.IsHeterozygous(MajorAllele[position2]);
}
/*___________________________________________________*/

bool Genotype::IsHeterozygousHomozygous1 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHH1");
CheckRangeSNP(position2, "IsHH1");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHeterozygous(MajorAllele[position]) && D2.IsHomozygous1(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous2Heterozygous (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH2H");
CheckRangeSNP(position2, "IsH2H");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous2(MajorAllele[position]) && D2.IsHeterozygous(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHeterozygousHomozygous2 (SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHH2");
CheckRangeSNP(position2, "IsHH2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHeterozygous(MajorAllele[position]) && D2.IsHomozygous2(MajorAllele[position2]);
};

/*___________________________________________________*/

bool Genotype::IsHomozygousHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHH");
CheckRangeSNP(position2, "IsHHb");

return IsHomozygous1Heterozygous(position, position2, MajorAllele)
		|| IsHomozygous2Heterozygous(position, position2, MajorAllele);
};
/*___________________________________________________*/

bool Genotype::IsHeterozygousHomozygous (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHetH");
CheckRangeSNP(position2, "IsHetH2");

return IsHeterozygousHomozygous1(position, position2, MajorAllele)
		|| IsHeterozygousHomozygous2(position, position2, MajorAllele);
};
/*___________________________________________________*/

bool Genotype::IsHeterozygousHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHetHet");
CheckRangeSNP(position2, "IsHetHet2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHeterozygous(MajorAllele[position]) && D2.IsHeterozygous(MajorAllele[position2]);
};


/*___________________________________________________*/

bool Genotype::IsMissingMissing (const SNPPos position, SNPPos position2)      
{
CheckRangeSNP(position, "IsMisMis");
CheckRangeSNP(position2, "IsMisMis2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsAMissingSNP() && D2.IsAMissingSNP();
};

/*___________________________________________________*/

bool Genotype::IsNotMissingNotMissing (const SNPPos position, SNPPos position2)      
{
CheckRangeSNP(position, "IsNMisNMis");
CheckRangeSNP(position2, "IsNMisMis2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsANonMissingSNP() && D2.IsANonMissingSNP();
};

/*___________________________________________________*/

bool Genotype::IsHomozygous1Missing (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH1Mis");
CheckRangeSNP(position2, "IsH1Mis2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous1(MajorAllele[position]) && D2.IsAMissingSNP();
};
/*___________________________________________________*/

bool Genotype::IsMissingHomozygous1 (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsMisH1");
CheckRangeSNP(position2, "IsMisH12");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsAMissingSNP() && D2.IsHomozygous1(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHomozygous2Missing (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsH2Mis");
CheckRangeSNP(position2, "IsH2Mis2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHomozygous2(MajorAllele[position]) && D2.IsAMissingSNP();
};
/*___________________________________________________*/

bool Genotype::IsMissingHomozygous2 (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsMisH2");
CheckRangeSNP(position2, "IsMisH2b");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsAMissingSNP() && D2.IsHomozygous2(MajorAllele[position2]);
};
/*___________________________________________________*/

bool Genotype::IsHeterozygousMissing (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsHetMis");
CheckRangeSNP(position2, "IsHetMis2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsHeterozygous(MajorAllele[position]) && D2.IsAMissingSNP();
};
/*___________________________________________________*/

bool Genotype::IsMissingHeterozygous (const SNPPos position, SNPPos position2, allele* MajorAllele)      
{
CheckRangeSNP(position, "IsMisHet");
CheckRangeSNP(position2, "IsMisHet2");

Diplotype D=DiplotypeArray[position];
Diplotype D2=DiplotypeArray[position2];

return D.IsAMissingSNP() && D2.IsHeterozygous(MajorAllele[position2]);
};
/*___________________________________________________*/

allele Genotype::GetLeftAllele (const SNPPos position)      
{
CheckRangeSNP(position, "GetLeftAllele");

return DiplotypeArray[position].GetLeftAllele();
};
/*___________________________________________________*/

allele Genotype::GetRightAllele (const SNPPos position)      
{
CheckRangeSNP(position, "GetRighAllele");

return DiplotypeArray[position].GetRightAllele();
};
/*___________________________________________________*/

bool Genotype::IsPhaseKnown (const SNPPos SNP1, const SNPPos SNP2, allele* MajorAllele)      
{
CheckRangeSNP(SNP1, "IsPhaseKnown");
CheckRangeSNP(SNP2, "IsPhaseKnown2");

Diplotype D1=DiplotypeArray[SNP1];
Diplotype D2=DiplotypeArray[SNP2];

return  IsNotMissingNotMissing(SNP1, SNP2) && (D1.IsHomozygous(MajorAllele[SNP1]) || D2.IsHomozygous(MajorAllele[SNP2]));
}
/*___________________________________________________*/

SNPPos Genotype::GetKnownHap (const SNPPos SNP1, const SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele)      
{
CheckRangeSNP(SNP1, "GetKnownHap");
CheckRangeSNP(SNP2, "GetKnownHap2");
SNPPos List[2];
List[0]=SNP1;
List[1]=SNP2;
IndPos Counters[4], total=0;
InitializeList(Counters, 4, (IndPos)0);

CountHaps(Counters, List,  2, MajorAllele);
if (IsMajor1 && IsMajor2) total= Counters[0];
else
if (IsMajor1 && !IsMajor2) total= Counters[1];
else
if (!IsMajor1 && IsMajor2) total= Counters[2];
else
if (!IsMajor1 && !IsMajor2) total= Counters[3];
else
{
	cout <<"error en GetKnownHap";
	exit(0);
}

return total;


}
/*___________________________________________________*/

SNPPos Genotype::GetPhasedHap (const SNPPos SNP1, const SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele)      
{
CheckRangeSNP(SNP1, "GetPhasedHap");
CheckRangeSNP(SNP2, "GetPhasedHap2");
SNPPos List[2];
List[0]=SNP1;
List[1]=SNP2;
IndPos Counters[4], total=0;
InitializeList(Counters, 4, (IndPos)0);

CountPhasedHaps(Counters, List,  2, MajorAllele);
if (IsMajor1 && IsMajor2) total= Counters[0];
else
if (IsMajor1 && !IsMajor2) total= Counters[1];
else
if (!IsMajor1 && IsMajor2) total= Counters[2];
else
if (!IsMajor1 && !IsMajor2) total= Counters[3];
else
{
	cout <<"error en GetPhasedHap";
	exit(0);
}

return total;
}
/*___________________________________________________*/

SNPPos Genotype::GetHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode)      
{
CheckRangeSNP(SNP1, "GetHap");
CheckRangeSNP(SNP2, "GetHap2");
SNPPos Total=0;
Diplotype D=DiplotypeArray[SNP1];
Diplotype D2=DiplotypeArray[SNP2];
if (IsNotMissingNotMissing(SNP1, SNP2)) 
 if (IsPhaseKnown(SNP1, SNP2, MajorAllele)==true) 
 Total=GetKnownHap(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele);
 else if (AlleleOrderMode==LeftRight)
  Total=GetPhasedHap(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele);
return Total;
};

/*___________________________________________________*/

SNPPos Genotype::GetAB (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode)      
{
	CheckRangeSNP(SNP1, "GetAB");
	CheckRangeSNP(SNP2, "GetAB2");

	return GetHap(SNP1, SNP2, true, true, MajorAllele, AlleleOrderMode);
}
/*___________________________________________________*/

SNPPos Genotype::GetAb (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode)      
{
	CheckRangeSNP(SNP1, "GetAb");

	CheckRangeSNP(SNP2, "GetAb2");

	return GetHap(SNP1, SNP2, true, false, MajorAllele, AlleleOrderMode);
}/*___________________________________________________*/

SNPPos Genotype::GetaB (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode)      
{
CheckRangeSNP(SNP1, "GetaB");

CheckRangeSNP(SNP2, "GetaB2");

return GetHap(SNP1, SNP2, false, true, MajorAllele, AlleleOrderMode);
}/*___________________________________________________*/

SNPPos Genotype::Getab (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele *MajorAllele, AlleleOrderType AlleleOrderMode)      
{
	CheckRangeSNP(SNP1, "Getab");

	CheckRangeSNP(SNP2, "Getab2");

	return GetHap(SNP1, SNP2, false, false, MajorAllele, AlleleOrderMode);
}

/*____________________________________________________________ */

Diplotype* Genotype::GetGenotype ()
{
	return DiplotypeArray;
}
/*___________________________________________________*/

bool Genotype::CanBeSolved (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele)      
{
	return IsPhaseKnown(SNP1, SNP2, MajorAllele);
}

/*___________________________________________________*/

SNPPos Genotype::GetFirstHeterozygous (allele* MajorAllele)      
{
	SNPPos TotalSNPs=GetTotalSNPs(), SNP=0;
	while (SNP<TotalSNPs)
	{
		if (GetDiplotype(SNP).IsHeterozygous (MajorAllele[SNP]))
			return SNP;
		 SNP++;
	}
	return SNP;
}
/*____________________________________________________________ */
/*
bool  Genotype::operator>(const Genotype & ge)
{
	Diplotype * targetDip=GetGenotype();
	for (int i=0;i<TotalSNPs;i++)
	{
     if (DiplotypeArray[i]>targetDip[i])
		 return true;
     if (DiplotypeArray[i]<targetDip[i])
		 return false;
	}
return false;
}
/*____________________________________________________________ */
/*
bool  Genotype::operator<(const Genotype & ge)
{
	Diplotype * targetDip=GetGenotype();
	for (int i=0;i<TotalSNPs;i++)
	{
     if (DiplotypeArray[i]<targetDip[i])
		 return true;
     if (DiplotypeArray[i]>targetDip[i])
		 return false;
	}
return false;
}
/*____________________________________________________________ */
/*
bool  Genotype::operator==(const Genotype & ge)
{
	Diplotype * targetDip=GetGenotype();
	for (int i=0;i<TotalSNPs;i++)
	{
     if (DiplotypeArray[i]>targetDip[i])
		 return false;
     if (DiplotypeArray[i]<targetDip[i])
		 return false;
	}
return true;
}
/*___________________________________________________*/

};  // End of Namespace

#endif

/* End of file: Genotype.h */




