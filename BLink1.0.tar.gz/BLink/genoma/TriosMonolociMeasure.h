/* File: TriosMonolociMeasure.h */


#ifndef __TriosMonolociMeasure_h__
#define __TriosMonolociMeasure_h__

//#include <string.h>
//#include <cstdio>

#include "../commonc++/list.h"

#include "Positions.h"
#include "Tables2x2.h"


namespace BIOS {


/************************/
/* SNP'S MonolociMeasure DEFINITION */
/************************/


/**
        @memo MonolociMeasure for SNPs

	@doc
        Definition:
        Is required because trio sample can complete missing information, while not in genotype sample

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
 class TriosMonolociMeasure: MonolociMeasure<TrioSample> {


private:

    /** @name Implementation of class MonolociMeasure
        @memo Private part.
    */


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on MonolociMeasure 
        @memo Operations on a MonolociMeasure 
    */
		  TriosMonolociMeasure(TrioSample * samp, const BayesType & Bay, const IndCategory & i): MonolociMeasure<TrioSample>(samp, Bay, i){};
		  //cout <<"\ntam:" <<sample->PhenotypeSample::GetSize();};


	double GetTotalFreqAllele(const SNPPos & SNP1, const bool IsMajor);


};  // End of class MonolociMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

double TriosMonolociMeasure::GetTotalFreqAllele(const SNPPos & SNP, const bool IsMajor=true)
{
 IndPos TotalInds=sample->GenotypeSample::GetSize();
 bool *Marked;
 
 Marked=Initialize(TotalInds, true);
 sample->SetMarked(Marked, ic);
 double Total=sample->TrioSample::GetTotalAllele(SNP, IsMajor, ic);
 double Total2=sample->TrioSample::GetTotalAllele(SNP, !IsMajor, ic);

 // try
 {
//	 if ((Total+Total2)==0)
	 {
//		 cout <<"SNP:" << SNP <<", ic:" << ic <<"Total:" << Total;
//		 throw ZeroValue();
	 }
 }
 
//catch (ZeroValue nv) {
 //       nv.PrintMessage(" MonolociMeasure::GetTotalFreqAllele");
 //     }

 Total=AddBayesAllele(Total, Bayes);
 Total2=AddBayesAllele(Total2, Bayes);
 
 //cout <<"\nT:" << Total/(Total+Total2);
 delete Marked;
 if ((Total+Total2)>0)
 return Total/(Total+Total2);
 else return 0;
}



};  // End of Namespace

#endif

/* End of file: MonolociMeasure.h */




