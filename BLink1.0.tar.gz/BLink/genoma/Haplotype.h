/* File: Haplotype.h */


#ifndef __Haplotype_h__
#define __Haplotype_h__

//#include <string.h>
//#include <cstdio>
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include <../commonc++/list.h>//


#include "Diplotype.h"

#include "Exceptions.h"

using namespace UTILS;


namespace BIOS {


/************************/
/* SNP'S Haplotype DEFINITION */
/************************/


/**
        @memo Haplotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/

 
class Haplotype {


private:
    /** @name Implementation of class Haplotype
        @memo Private part.
    */

	allele * LeftHaplotype, * RightHaplotype;

	SNPPos TotalSNPs;

/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

void CheckRangeSNP(SNPPos SNP, char* message);

void copyLeft (allele * SourceHap);

void copyRight (allele * SourceHap);


		/* PUBLIC FUNCTIONS (INTERFACE) */

public:



      /** @name Operations on Haplotype 
        @memo Operations on a Haplotype 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
Haplotype();
	
Haplotype(SNPPos TotalSNPs);

Haplotype (const Haplotype& Source);

	
Haplotype(allele* LeftSource, allele* RightSource, SNPPos TotalS);


      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
~Haplotype ();

      /**
         @memo Assignation
         @param g Haplotype to copy.
         @return Reference to the receptor Haplotype.
	 @doc
           Copy the Haplotype in the receptor Haplotype.
           Time complexity O(1).

      */
Haplotype& operator=(const Haplotype& g);




      /**
         @memo Is equal
         @param g: Haplotype to compare with.
	 @return
           Return true if all the Haplotype is the same, false otherwise.
         @doc Time complexity O(1).

      */
bool operator==(const Haplotype & h);
      /**
         @memo Is different
         @param g, position: Haplotype to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
bool operator!=(const Haplotype & h);

SNPPos GetTotalSNPs();

Diplotype GetDiplotype(SNPPos SNP);
    
bool IsleftLeft(const Haplotype & source);

SNPPos GetDifferentPos(const Haplotype & source);

SNPPos GetSwitchErrors(Haplotype* TrueH);

SNPPos GetStErrors(Haplotype* TrueH);

SNPPos GetUnknown(Haplotype* TrueH);

SNPPos GetUnsolved(Haplotype* TrueH);

SNPPos GetHomozygous(Haplotype* TrueH);


};  // End of class Haplotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


/*_____________________________________________________________*/

void Haplotype::copyLeft (allele * SourceHap)
{
try
{
 if (LeftHaplotype!=NULL) delete LeftHaplotype;
 if ((LeftHaplotype=new allele [TotalSNPs])==NULL)
	throw NoMemory();
}
 catch (NoMemory ov) {ov.PrintMessage();}

for (SNPPos i=0;i<TotalSNPs;i++)
 LeftHaplotype[i]=SourceHap[i];
}

/*_____________________________________________________________*/

void Haplotype::copyRight (allele * SourceHap)
{
try
{
 if (RightHaplotype!=NULL) delete RightHaplotype;
 if ((RightHaplotype=new allele [TotalSNPs])==NULL)
	throw NoMemory();
}
 catch (NoMemory ov) {ov.PrintMessage();}

for (SNPPos i=0;i<TotalSNPs;i++)
 RightHaplotype[i]=SourceHap[i];
}
///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

Haplotype::Haplotype()
{
LeftHaplotype=NULL;
RightHaplotype=NULL;
TotalSNPs=0;
}
/*____________________________________________________________ */

Haplotype::Haplotype(SNPPos TotalS)
{
TotalSNPs=TotalS;
try
{
 if ((LeftHaplotype=new allele [TotalSNPs])==NULL)
	throw NoMemory();
  if ((RightHaplotype=new allele [TotalSNPs])==NULL)
	throw NoMemory();

}
 catch (NoMemory ov) {ov.PrintMessage();}

}
/*____________________________________________________________ */

Haplotype::Haplotype(const Haplotype & Source)
{
LeftHaplotype=NULL;
RightHaplotype=NULL;
TotalSNPs=Source.TotalSNPs;
copyLeft (Source.LeftHaplotype);
copyRight (Source.RightHaplotype);
}
/*____________________________________________________________ */

Haplotype::Haplotype(allele* LeftSource, allele* RightSource, SNPPos TotalS)
{
LeftHaplotype=NULL;
RightHaplotype=NULL;
TotalSNPs=TotalS;
copyLeft (LeftSource);
copyRight (RightSource);
}
/*____________________________________________________________ */

Haplotype& Haplotype::operator=(const Haplotype & Source)
{
  if (this!=&Source)  
  {
  TotalSNPs=Source.TotalSNPs;
  LeftHaplotype=NULL;
  RightHaplotype=NULL;
  copyLeft (Source.LeftHaplotype);
  copyRight (Source.RightHaplotype);
  } 
  return *this;
}
/*____________________________________________________________ */

Haplotype::~Haplotype()
{
delete LeftHaplotype;// we do not delete this list because we can have sampling
delete RightHaplotype;
}

/*____________________________________________________________ */

SNPPos Haplotype::GetTotalSNPs()
{
return	TotalSNPs;
}

/*__________________________________________________________*/
void Haplotype::CheckRangeSNP(SNPPos SNP, char* message=NULL)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP, message);}

}

/*___________________________________________________*/

bool Haplotype::operator==(const Haplotype & source)
{
SNPPos cont=0;

bool IsLeft=true, IsRight=true;

while (cont<TotalSNPs && (IsLeft || IsRight))
{
  if ((int)LeftHaplotype[cont]>0 && ((int)source.LeftHaplotype[cont]>0 || (int)source.RightHaplotype[cont]>0))
 {
  if (LeftHaplotype[cont]!=source.LeftHaplotype[cont])
	IsLeft=false;  
	  
  if (LeftHaplotype[cont]!=source.RightHaplotype[cont]) 
    IsRight=false;

  if (!IsLeft && !IsRight) return false;
 }
 cont++;
}
return true;
}
/*___________________________________________________*/

bool Haplotype::operator!=(const Haplotype & source)
{
	return !(*this==source);
}
/*___________________________________________________*/

bool Haplotype::IsleftLeft(const Haplotype & source)
{
SNPPos cont=0;

bool IsLeft=true, IsRight=true;

while (cont<TotalSNPs && (IsLeft || IsRight))
{
 if (LeftHaplotype[cont]>0 && (source.LeftHaplotype[cont]>0 || source.RightHaplotype[cont]>0))
 {
  if (LeftHaplotype[cont]!=source.LeftHaplotype[cont])
	IsLeft=false;  
	  
  if (LeftHaplotype[cont]!=source.RightHaplotype[cont]) 
    IsRight=false;

  if (!IsLeft && IsRight) return false;
 }
 cont++;
}
return true;
}
/*___________________________________________________*/

SNPPos Haplotype::GetDifferentPos(const Haplotype & source)
{
SNPPos cont=0;

bool IsLeft=true, IsRight=true;
while (cont<TotalSNPs && (IsLeft || IsRight))
{
	
 if ((LeftHaplotype[cont]>0)  && (source.LeftHaplotype[cont]>0 || source.RightHaplotype[cont]>0))
  { 
	 
  if (LeftHaplotype[cont]!=source.LeftHaplotype[cont])
	IsLeft=false;  
	  
  if (LeftHaplotype[cont]!=source.RightHaplotype[cont]) 
    IsRight=false;

  if (!IsLeft && !IsRight) return cont;
 }
  cont++;

}
return cont;
}


/*_________________________________________________________________________*/

SNPPos Haplotype::GetSwitchErrors(Haplotype* TrueH)
{

Haplotype * H2, * TrueH2;
SNPPos SNP=1+GetDifferentPos(*TrueH), errors=0;
while (SNP<TotalSNPs)
{
 H2=new Haplotype(&(LeftHaplotype[SNP]), &(RightHaplotype[SNP]), TotalSNPs-SNP);
 TrueH2=new Haplotype(&(TrueH->LeftHaplotype[SNP]), &(TrueH->RightHaplotype[SNP]), TotalSNPs-SNP);
 SNP=SNP+1+H2->GetDifferentPos(*TrueH2);
 errors++;
}
return errors;
}
/*_________________________________________________________________________*/

SNPPos Haplotype::GetStErrors(Haplotype* TrueH)
{
SNPPos Errors=0, LeftErrors=0, RightErrors=0;
for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
{
 if (LeftHaplotype[SNP]>0 && TrueH->LeftHaplotype[SNP]>0)
  if (LeftHaplotype[SNP]!=TrueH->LeftHaplotype[SNP])
	LeftErrors++;  
 if (LeftHaplotype[SNP]>0 && TrueH->RightHaplotype[SNP]>0)
  if (LeftHaplotype[SNP]!=TrueH->RightHaplotype[SNP])
	RightErrors++;  
}
return mini(LeftErrors, RightErrors);
}
/*_________________________________________________________________________*/

SNPPos Haplotype::GetUnknown(Haplotype* TrueH)
{
SNPPos Unknown=0;
for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
{
 if (TrueH->LeftHaplotype[SNP]<=0)
	Unknown++;  
}
return Unknown;
}
/*_________________________________________________________________________*/

SNPPos Haplotype::GetHomozygous(Haplotype* TrueH)
{
SNPPos Homo=0;
for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
{
 if (TrueH->LeftHaplotype[SNP]==TrueH->RightHaplotype[SNP] && TrueH->LeftHaplotype[SNP]!=0)
	Homo++;  
}
return Homo;
}
/*_________________________________________________________________________*/

SNPPos Haplotype::GetUnsolved(Haplotype* TrueH)
{
SNPPos Unsolved=0;
for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
{
 if (TrueH->LeftHaplotype[SNP]>0 && LeftHaplotype[SNP]<0)
	Unsolved++;  
}
return Unsolved;
}
};  // End of Namespace

#endif

/* End of file: Haplotype.h */




