cd /home/mar/genoma/data
echo compute dHap                                 
echo Crohn
/home/mar/genoma/PhaseChecker crohn.txt dhap_others.acc 387 103
echo chrom2
/home/mar/genoma/PhaseChecker coalescent dhap_all.acc 90 27029
echo chrom3
/home/mar/genoma/PhaseChecker migration dhap_all.acc 90 2914
echo chrom4
/home/mar/genoma/PhaseChecker crossover dhap_all.acc 90 19481
echo chrom5
/home/mar/genoma/PhaseChecker random dhap_all.acc 90 20390
echo chrom6
/home/mar/genoma/PhaseChecker chrom6.ord dhap_all.acc 90 16077
echo chrom7
/home/mar/genoma/PhaseChecker chrom7.ord dhap_all.acc 90 16630
echo chrom8
/home/mar/genoma/PhaseChecker chrom8.ord dhap_all.acc 90 1900
echo chrom9
/home/mar/genoma/PhaseChecker chrom9.ord dhap_all.acc 90 23084
echo chrom10
/home/mar/genoma/PhaseChecker chrom10.ord dhap_all.acc 90 10107
echo chrom11
/home/mar/genoma/PhaseChecker chrom11.ord dhap_all.acc 90 15736
echo chrom12
/home/mar/genoma/PhaseChecker chrom12.ord dhap_all.acc 90 19583
echo chrom13
/home/mar/genoma/PhaseChecker chrom13.ord dhap_all.acc 90 9267
echo chrom14
/home/mar/genoma/PhaseChecker chrom14.ord dhap_all.acc 90 10488
echo chrom15
/home/mar/genoma/PhaseChecker chrom15.ord dhap_all.acc 90 9167
echo chrom16
/home/mar/genoma/PhaseChecker chrom16.ord dhap_all.acc 90 8418
echo chrom17
/home/mar/genoma/PhaseChecker chrom17.ord dhap_all.acc 90 8114
echo chrom18
/home/mar/genoma/PhaseChecker chrom18.ord dhap_all.acc 90 18934
echo chrom19
/home/mar/genoma/PhaseChecker chrom19.ord dhap_all.acc 90 5282
echo chrom20
/home/mar/genoma/PhaseChecker chrom20.ord dhap_all.acc 90 708
echo chrom21
/home/mar/genoma/PhaseChecker chrom21.ord dhap_all.acc 90 740
echo chrom22
/home/mar/genoma/PhaseChecker chrom22.ord dhap_all.acc 90 6487
echo chromX
/home/mar/genoma/PhaseChecker chromX.ord dhap_all.acc 90 1467
