/* File: TrioSample.h */


#ifndef __TrioSample_h__
#define __TrioSample_h__

//#include <string.h>
//#include <cstdio>


#include "FachadeGenoma.h"
//#include "GenomaSample.cpp"

//#include "CoupleGenotype.h"
namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class TrioSample: public GenomaSample {

	public:
   	list<Trio> *TrioList;
	int* inconsistencies, *nonHeteroParents, *parentsNotInHWE, *childrenNotInHWE;

	protected:
    /** @name Implementation of class TrioSample
        @memo Private part.
    */
    	IndCategory ic;
	char * line;
	bool CompleteMissing;	


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

	     void CreateTrioList ();
             void InitializeTrioSample(AlleleOrderType AlleleOrderMode);

		/* PUBLIC FUNCTIONS (INTERFACE) */
      public:

      /** @name Operations on TrioSample 
        @memo Operations on a TrioSample 
    */
		  TrioSample (PhenotypeSample& SourceP, GenotypeSample& SourceG, AlleleOrderType AlleleOrderMod);
		  TrioSample (TrioSample& source, list<IndPos> *Sampling, AlleleOrderType AlleleOrderMode);
		  TrioSample(char* filename, IndCategory ic, AlleleOrderType AlleleOrderMode, bool CompleteMiss); // ic is only to setup major allele, if never is used a different ic, i should be removed
		  TrioSample(char* filename, AlleleOrderType AlleleOrderMode); // ic is only to setup major allele, if never is used a different ic, i should be removed
		  ~TrioSample (){zap(TrioList); zap(line); zaparr(inconsistencies);zaparr(nonHeteroParents); zaparr(parentsNotInHWE); zaparr(childrenNotInHWE);};
		  allele getMajorAllele (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		  allele getMinorAllele (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		void PrintTrios (char* filename);
		void CheckInconsistenciesFromParents ();
		void CompleteMissingFromParents ();
		SNPPos GetTotalType (SNPPos SNP, IndCategory ic, GenotypeType type, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalHomozygous1 (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalHomozygous2 (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalHeterozygous (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalMissing (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalNonMissing (SNPPos SNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool IsPartiallySolved, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetTotalAllele (SNPPos SNP, bool IsMajor, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetHap (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool IsMajor1, bool IsMajor2, bool IsPartiallySolved, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation);	
		SNPPos Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		SNPPos GetAllelePair(SNPPos SNP1, SNPPos SNP2, IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		void CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic, int gender=everyGender, int affectation=allAffectation);
		IndPos GetTotalTrios();
		void OrderLeftRight ();
		void PrintSampleReducedFormat(char* filename, bool PrintPhenotypes, IndCategory ic, SNPPos SNP);
		char* PrintGenotypeCode(list<Trio>::NodePointer TrioPos, IndCategory ic, SNPPos SNP, IndCategory ic2=everybody, int gender=everyGender, int affectation=allAffectation);
		void ResolvePhase (PhaseType PhaseMode);
	void CheckParentsHWE ();
	void CheckChildrenHWE ();
};  // End of class TrioSample


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////
 /*____________________________________________________________ */

void TrioSample::InitializeTrioSample (AlleleOrderType AlleleOrderMode)
{
CheckInconsistenciesFromParents();
if (CompleteMissing) CompleteMissingFromParents();
//exit(0);
 IndPos TotalInds=PhenotypeSample::GetSize();
 //bool Marked[TotalInds];
 setMarked(ic);
 SetMajorAllele(Marked);	

 //exit(0);
 switch (AlleleOrderMode)
 {
 case NotChanged: break;
 case MajorFirst: break; // already done in GenotypeSample
 case LeftRight: OrderLeftRight(); break;
 };			
}
/*____________________________________________________________ */

void TrioSample::CreateTrioList ()
{
 Trio T;
 TrioList=new list<Trio>();
 GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
 PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
 while (IndGenotype!=NULL && IndPhenotype!=NULL)
  {
   if (IndPhenotype->element.IsAFather())
   {
   T=GetTrioMembers(IndPhenotype, IndGenotype);
   TrioList->insertElement(T);
   }
   IndGenotype=GenotypeSample::GetNext(IndGenotype);
   IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 }
}
/*__________________________________________________________________*/

void TrioSample::OrderLeftRight ()
{
  list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
  Genoma* G;
  SNPPos TotalSNPs=GetTotalSNPs();

while (TrioPos!=NULL)
  {
   for (unsigned short int i=0;i<3;i++)
   {	 
   G=new Genoma(TrioPos->element, (IndCategory)i);
   for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
   {
    if (G->CanBeInferred(SNP, MajorAllele[SNP]))
	{
  	 if (G->MustBeChanged(SNP, MajorAllele[SNP]))
	  G->ChangeAlleles(SNP);
	}
	else
     if (!(G->GetDiplotype(SNP)).IsHomozygous(MajorAllele[SNP])) 
		 G->MarkAlleles(SNP);
   }
   }
   TrioPos=TrioList->GetNext(TrioPos);
  }
    cout <<"Sorting left right has finished\n";

}
///////////////////
//// public ////////
///////////////////

TrioSample::TrioSample(char* filename, IndCategory i=parent, AlleleOrderType AlleleOrderMode=MajorFirst, bool CompleteMis=true): GenomaSample(filename, i, AlleleOrderMode) 
{
 line=NULL;
 TrioList=NULL;
 ic=i;
 CompleteMissing=CompleteMis;
 CreateTrioList();
 InitializeTrioSample(AlleleOrderMode);
}
/*____________________________________________________________ */

TrioSample::TrioSample(char* filename, AlleleOrderType AlleleOrderMode=MajorFirst):GenomaSample(filename, everybody, AlleleOrderMode)  
{
line=NULL;
TrioList=NULL;
ic=parent;
CompleteMissing=true;
inconsistencies=NULL;
nonHeteroParents=NULL;
parentsNotInHWE=NULL;
childrenNotInHWE=NULL;
CreateTrioList();
InitializeTrioSample(AlleleOrderMode);
}

/*____________________________________________________________ */
/*
TrioSample::TrioSample (TrioSample& source, list<IndPos> *Sampling=NULL, AlleleOrderType AlleleOrderMode=MajorFirst) //: GenomaSample(source, Sampling, IndPos)
{
if (Sampling==NULL) 
{
 GenomaSample(source, NULL);
 CreateTrioList();
 InitializeTrioSample(AlleleOrderMode);
}
else
{
 list<IndPos>::NodePointer p=Sampling->GetFirst();
 GenomaSample();
 Trio T;
 while (p!=NULL)
 {
  T=source.TrioList->GetPointerToElement(source.TrioList->GetNode(Sampling->GetElement(p)));
  GenotypeSample::InsertElement(GenotypeSample::GetPointerToElement(T.GetFatherGenotype()));
  PhenotypeSample::InsertElement(PhenotypeSample::GetElement(T.GetFatherPhenotype()));
  GenotypeSample::InsertElement(GenotypeSample::GetPointerToElement(T.GetMotherGenotype()));
  PhenotypeSample::InsertElement(PhenotypeSample::GetElement(T.GetMotherPhenotype()));
  GenotypeSample::InsertElement(GenotypeSample::GetPointerToElement(T.GetChildGenotype()));
  PhenotypeSample::InsertElement(PhenotypeSample::GetElement(T.GetChildPhenotype()));
  p=Sampling->GetNext(p);
 }
 CreateTrioList();
 IndPos TotalInds=PhenotypeSample::GetSize();
 bool *Marked;
 Marked=Initialize(TotalInds, false);
 SetMarked(Marked, parent);
 SetMajorAllele(Marked);				
 delete Marked;
};

}
/*____________________________________________________________ */

TrioSample::TrioSample (PhenotypeSample& SourceP, GenotypeSample& SourceG, AlleleOrderType AlleleOrderMode=MajorFirst): GenomaSample(SourceP, SourceG)
{
line=NULL;
TrioList=NULL;
// AlleleOrderMode=AlleleOrderMod;
// GS=new GenomaSample(SourceP, SourceG);
 CreateTrioList();
 InitializeTrioSample(AlleleOrderMode);
}
/*____________________________________________________________ */

void TrioSample::CheckParentsHWE ()
{
SNPPos TotalSNPs=GetTotalSNPs();
double observed[2], expected[2];
parentsNotInHWE=Initialize(TotalSNPs, 0);
for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
{
observed[0]=GetTotalAllele (SNP, true, father);
observed[1]=GetTotalAllele (SNP, true, mother);
expected[0]=(observed[0]+observed[1])/(double)2;
expected[1]=(observed[0]+observed[1])/(double)2;
if (chiTest(observed, expected, 1)<0.05) parentsNotInHWE[SNP]=1;
}
}
/*____________________________________________________________ */

void TrioSample::CheckChildrenHWE ()
{
SNPPos TotalSNPs=GetTotalSNPs();
double observed[3], expected[3], allele[2];
childrenNotInHWE=Initialize(TotalSNPs, 0);
double allele1, allele2, total1, total2;
for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
if (parentsNotInHWE==NULL || parentsNotInHWE[SNP]==0)
{
observed[0]=GetTotalHomozygous1 (SNP, offspring);
observed[1]=GetTotalHomozygous2 (SNP, offspring);
observed[2]=GetTotalHeterozygous (SNP, offspring);
total1=observed[0]+observed[1]+observed[2];
allele[0]=GetTotalAllele (SNP, true, parent);
allele[1]=GetTotalAllele (SNP, false, parent);
total2=allele[0]+allele[1];
expected[0]=total1*std::pow(allele[0]/total2,2);
expected[1]=total1*std::pow(allele[1]/total2,2);
expected[2]=total1*(allele[0]/total2)*(allele[1]/total2)*2;
if (chiTest(observed, expected, 2)<0.05) childrenNotInHWE[SNP]=1;
}
else childrenNotInHWE[SNP]=2;
}
/*____________________________________________________________ */

void TrioSample::CheckInconsistenciesFromParents ()
{
cout << "Checking inconsistencies from parents...\n";

SNPPos TotalSNPs=GetTotalSNPs();

inconsistencies=Initialize(TotalSNPs, 0);
nonHeteroParents=Initialize(TotalSNPs, 0);
CheckParentsHWE();
CheckChildrenHWE();
IndPos Pos=0;	

list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
CoupleGenotype*couplegenotype;
Trio *T;
int totalInconsistencies=0;
int totalHetero=0, total=0;
while (TrioPos!=NULL)
{

T=&TrioPos->element;
couplegenotype=new CoupleGenotype(T->GetFatherGenotype()->element, T->GetMotherGenotype()->element);
for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
{
if (!T->GetFatherGenotype()->element->GetDiplotype(SNP).IsAMissingSNP() &&
!T->GetMotherGenotype()->element->GetDiplotype(SNP).IsAMissingSNP() &&
!T->GetChildGenotype()->element->GetDiplotype(SNP).IsAMissingSNP())
{
 if (!T->GetFatherGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP]))
{ nonHeteroParents[SNP]++; total++;}
 if (!T->GetMotherGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) {nonHeteroParents[SNP]++; total++;}
}
 if (T->GetFatherGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP]) ||
T->GetMotherGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP]) ||
T->GetChildGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP]))
totalHetero++;// no sense, I think we should count trios with at least one parent homozygous
if (
	 ((couplegenotype->IsHomozygous1Heterozygous (SNP, MajorAllele)) && (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous2(MajorAllele[SNP])))
	  ||
	  ((couplegenotype->IsHomozygous2Heterozygous(SNP, MajorAllele)) && (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous1(MajorAllele[SNP]))) 
	  ||
	  ((couplegenotype->IsHomozygous1Homozygous1 (SNP, MajorAllele)) &&  (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])))
          ||
	  ((couplegenotype->IsHomozygous2Homozygous2 (SNP, MajorAllele)) &&  (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])))
          ||
	  ((couplegenotype->IsHomozygous1Homozygous2 (SNP, MajorAllele)) && ((T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous1(MajorAllele[SNP])) || (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous2(MajorAllele[SNP]))))		  
     )
		     	{
			/*
				cout <<"\nInconsistence at ind " 
				<< Pos+1 << " SNP " << SNP+1 << " val file: " 
				
				<< T->GetChildGenotype()->element->GetLeftAllele(SNP) <<T->GetChildGenotype()->element->GetRightAllele(SNP) 
				<< "( " ;
				cout << T->GetChildPhenotype()->element.PrintPhenotype() ;
				cout << ") with parents "; 
				cout << T->GetFatherPhenotype()->element.PrintPhenotype() ;
				cout << " and " ;
				cout << T->GetMotherPhenotype()->element.PrintPhenotype() ;
				cout 
 				<< " with father "
				<< T->GetFatherGenotype()->element->GetLeftAllele(SNP) 
				<< T->GetFatherGenotype()->element->GetRightAllele(SNP) 
				<< " and mother " 
				<< T->GetMotherGenotype()->element->GetLeftAllele(SNP) 
				<< T->GetMotherGenotype()->element->GetRightAllele(SNP) ; 
*/
totalInconsistencies++;
inconsistencies[SNP]++;				
};
if (
	   ((couplegenotype->IsHomozygous1Homozygous1 (SNP, MajorAllele)) && (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous2(MajorAllele[SNP]))) 
          ||
	  ((couplegenotype->IsHomozygous2Homozygous2 (SNP, MajorAllele)) && (T->GetChildGenotype()->element->GetDiplotype(SNP).IsHomozygous1(MajorAllele[SNP])))
     )
		     	{
totalInconsistencies+2;
inconsistencies[SNP]+2;			
};
};
  
 TrioPos=TrioList->GetNext(TrioPos);
 Pos++;
}
cout <<"\nInconsistencies have been checked from parents, and " << totalInconsistencies <<" out of " << total <<" non hetero parents have been found\n";
}
/*____________________________________________________________ */

void TrioSample::CompleteMissingFromParents ()
{
cout << "\nCompleting missing from parents...";
SNPPos TotalSNPs=GetTotalSNPs();	
list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
CoupleGenotype*couplegenotype;
Trio *T;
allele MinorAllele;
while (TrioPos!=NULL)
{
 T=&TrioPos->element;
 couplegenotype=new CoupleGenotype(T->GetFatherGenotype()->element, T->GetMotherGenotype()->element);

 for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
  if (T->GetChildGenotype()->element->GetDiplotype(SNP).IsAMissingSNP())
   {
    if (T->GetFatherGenotype()->element->GetDiplotype(SNP).IsHomozygous2 (MajorAllele[SNP]))
		   MinorAllele=T->GetFatherGenotype()->element->GetLeftAllele(SNP);
	else
    if (T->GetMotherGenotype()->element->GetDiplotype(SNP).IsHomozygous2 (MajorAllele[SNP]))
		   MinorAllele=T->GetMotherGenotype()->element->GetLeftAllele(SNP);
   
	if (couplegenotype->IsHomozygous1Homozygous1 (SNP, MajorAllele)) 
	   T->GetChildGenotype()->element->SetAlleles(MajorAllele[SNP], MajorAllele[SNP], SNP);

    if (couplegenotype->IsHomozygous2Homozygous2 (SNP, MajorAllele)) 
	   T->GetChildGenotype()->element->SetAlleles(MinorAllele, MinorAllele, SNP);

    if (couplegenotype->IsHomozygous1Homozygous2 (SNP, MajorAllele)) 
       T->GetChildGenotype()->element->SetAlleles(MajorAllele[SNP], MinorAllele, SNP);

  } // end for each missing SNP
 TrioPos=TrioList->GetNext(TrioPos);
} // end for each individual
cout <<"\nMissing data have been completed from parents\n";
}

/*__________________________________________________________*/

SNPPos TrioSample::GetTotalType (SNPPos SNP, IndCategory ic, GenotypeType type, int gender, int affectation)
{
bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
return GenotypeSample::GetTotalType(SNP, type, Marked);
}
/*___________________________________________________________*/

SNPPos TrioSample::GetTotalHomozygous1 (SNPPos SNP, IndCategory ic, int gender, int affectation)
{
	return GetTotalType (SNP, ic, homozygous1, gender, affectation);
}
/*___________________________________________________________*/

SNPPos TrioSample::GetTotalHomozygous2 (SNPPos SNP, IndCategory ic, int gender, int affectation)
{
	return GetTotalType (SNP, ic, homozygous2, gender, affectation);
}
/*___________________________________________________________*/

SNPPos TrioSample::GetTotalHeterozygous (SNPPos SNP, IndCategory ic, int gender, int affectation)
{
	return GetTotalType (SNP, ic, heterozygous, gender, affectation);
}
/*___________________________________________________________*/

SNPPos TrioSample::GetTotalMissing (SNPPos SNP, IndCategory ic, int gender, int affectation)
{
	return GetTotalType (SNP, ic, missing, gender, affectation);
}
/*___________________________________________________________*/

SNPPos TrioSample::GetTotalNonMissing (SNPPos SNP, IndCategory ic, int gender, int affectation)
{
	return GetTotalHomozygous1 (SNP, ic, gender, affectation)+GetTotalHomozygous2(SNP, ic)+GetTotalHeterozygous(SNP, ic, gender, affectation);
}
/*__________________________________________________________*/

SNPPos TrioSample::GetTotalAllele (SNPPos SNP, bool IsMajor, IndCategory ic, int gender, int affectation)
{
//bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
//for (int i=0;i<GetTotalSNPs();i++)
//cout <<"\n" << Marked[i];
//cout <<"total al:" << GenotypeSample::GetTotalAllele(SNP, false, Marked);
//end();
return GenotypeSample::GetTotalAllele(SNP, IsMajor, Marked);
}
/*__________________________________________________________*/

SNPPos TrioSample::GetTotalTrios ()
{
return TrioList->GetSize();
}
/*____________________________________________________________ */

SNPPos TrioSample::GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody, int gender, int affectation)
{
//bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
return GenotypeSample::GetDoubleHeterozygous(FirstSNP, LastSNP, Marked);
}
/*____________________________________________________________ */

SNPPos TrioSample::GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody, bool IsPartiallySolved=false, int gender, int affectation)
{
//bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
IndPos TotalInds=0;
TotalInds=GenotypeSample::GetUnsolvedDoubleHeterozygous(FirstSNP, LastSNP, Marked);

list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
Genoma* G;

while (TrioPos!=NULL)
{
for (int i=0; i<=2; i++)
{
if (ic==(IndCategory)i || ic==everybody || (ic==parent && i<2))
{
	G=new Genoma(TrioPos->element, (IndCategory)i);
	if (G->CanBeInferred(FirstSNP, LastSNP, MajorAllele) || G->CanBePartiallySolved(FirstSNP, LastSNP, MajorAllele, IsPartiallySolved))
	TotalInds--;
	delete G;

}
}
TrioPos=TrioList->GetNext(TrioPos);
}

return TotalInds;

}
/*____________________________________________________________ */

SNPPos TrioSample::GetHap (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody, bool IsMajor1=true, bool IsMajor2=true, bool IsPartiallySolved=false, int gender, int affectation)
{
//bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
IndPos TotalInds=GenotypeSample::GetHap(FirstSNP, LastSNP, IsMajor1, IsMajor2, Marked);

list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
Genoma* G;

while (TrioPos!=NULL)
{
for (int i=0; i<=2; i++)
{
if (ic==(IndCategory)i || ic==everybody || (ic==parent && i<2))
{
 G=new Genoma(TrioPos->element, (IndCategory)i);
 TotalInds=TotalInds+G->GetHap(FirstSNP, LastSNP, IsMajor1, IsMajor2, MajorAllele, IsPartiallySolved);	
 delete G;
}
}
TrioPos=TrioList->GetNext(TrioPos);
}
return TotalInds;
}
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, true, true);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, true, false);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, false, true);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, false, false);
};  
/*____________________________________________________________ */

void TrioSample::CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic=parent, int gender, int affectation)
{
//bool Marked[PhenotypeSample::GetSize()];
setMarked(ic, gender, affectation);
return GenotypeSample::CountAlleles(SNP, Basis, Marked);

}
/*____________________________________________________________ */

allele TrioSample::getMajorAllele (SNPPos SNP, IndCategory ic=parent, int gender, int affectation)
{
//cout <<GenomaSample::getMajorAllele(SNP, ic) <<"";

return GenomaSample::getMajorAllele(SNP, ic, gender, affectation);
}
/*____________________________________________________________ */

allele TrioSample::getMinorAllele (SNPPos SNP, IndCategory ic=parent, int gender, int affectation)
{
//cout <<GenomaSample::getMinorAllele(SNP, ic) <<"\n";
return GenomaSample::getMinorAllele(SNP, ic, gender, affectation);
}

/*____________________________________________________________ */
/*
void TrioSample::PrintTrios (char* filename)
 {

  list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
  Genotype* genotype;
  Phenotype phenotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 

  SNPPos TotalSNPs=GetTotalSNPs();

while (TrioPos!=NULL)
  {
   OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetFatherPhenotype()).PrintPhenotype();
   OutputFile << " ";
   OutputFile << GenotypeSample::GetElement(TrioPos->element.GetFatherGenotype())->print();
   OutputFile <<"\n";

   OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetMotherPhenotype()).PrintPhenotype();
   OutputFile << " ";
   OutputFile << GenotypeSample::GetElement(TrioPos->element.GetMotherGenotype())->print();
   OutputFile <<"\n";
   
   OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetChildPhenotype()).PrintPhenotype();
   OutputFile << " ";
   OutputFile << GenotypeSample::GetElement(TrioPos->element.GetChildGenotype())->print();
   OutputFile <<"\n";
   
   TrioPos=TrioList->GetNext(TrioPos);
  }
  OutputFile.close();

cout << "\nInformation about trios has been saved in file " << filename <<"\n";

  }
/*____________________________________________________________ */

char* TrioSample::PrintGenotypeCode(list<Trio>::NodePointer TrioPos, IndCategory ic, SNPPos SNP, IndCategory ic2, int gender, int affectation)
{
	SNPPos TotalSNPs=GetTotalSNPs();

	if ((line=new char [TotalSNPs*6])==NULL)
	throw NoMemory();
	Genoma* G;
	G=new Genoma(TrioPos->element, ic);
    strcpy(line, "\0"); 
    for (SNPPos SNP2=SNP+1;SNP2<TotalSNPs;SNP2++)
     if (GetTotalAllele(SNP2, false, ic2, gender, affectation)>0) 
     strcat(line, G->PrintGenotypeCode(SNP, SNP2, MajorAllele));
	return line;
}
/*____________________________________________________________ */

void TrioSample::PrintSampleReducedFormat(char* filename, bool PrintPhenotypes=true, IndCategory ic=everybody, SNPPos SNP1=0)
{
  list<Trio>::NodePointer TrioPos=TrioList->GetFirst();
  Genotype* genotype;
  Phenotype phenotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 
  SNPPos TotalSNPs=GetTotalSNPs();
  
  for (SNPPos SNP=SNP1+1;SNP<TotalSNPs;SNP++)
   if (GetTotalAllele(SNP, false, ic)>0) 
   OutputFile << "SNPs" << SNP1+1 << "-" << SNP+1 <<" ";
  OutputFile <<"\n";

   while (TrioPos!=NULL)
   {
	   
   if (ic==parent || ic==father || ic==everybody)
   {
	if (PrintPhenotypes) OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetFatherPhenotype()).PrintPhenotype() << " ";
    OutputFile << PrintGenotypeCode(TrioPos, father, SNP1, ic) << "\n";
   }
   if (ic==parent || ic==mother || ic==everybody)
   {
	if (PrintPhenotypes) OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetMotherPhenotype()).PrintPhenotype() << " ";
    OutputFile << PrintGenotypeCode(TrioPos, mother, SNP1, ic) << "\n";
   }
   if (ic==offspring || ic==everybody)
   {
	 if (PrintPhenotypes) OutputFile << PhenotypeSample::GetElement(TrioPos->element.GetChildPhenotype()).PrintPhenotype() << " ";
     OutputFile << PrintGenotypeCode(TrioPos, offspring, SNP1, ic) << "\n";
   }
   
   TrioPos=TrioList->GetNext(TrioPos);
  }
 OutputFile.close();
 }


};
// End of Namespace

#endif

/* End of file: TrioSample.h */




