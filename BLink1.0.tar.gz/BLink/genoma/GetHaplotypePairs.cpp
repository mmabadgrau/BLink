/**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "SNP.h"

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"



char line[300];
/*______________________________________________________________*/
 

char* PrintHeading()
{
char* p=line;
strcpy(line, "First SNP\tPosition\tSecond SNP\tPosition\tn(A)\tn(B)\tn(HH) (individuals)\tn(AB)\tn(Ab)\tn(aB)\tn(ab)\n");
return p;
}

/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

char line[100];
if(argc<5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " << " <MAF> "  << " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium>" 
		<< " ic (father=0, mother=1, offspring=2, everybody=3, parent=4)" << "< Pairwise phase (0: standard phase/1: with partially solved)>" << endl;
        exit(-1);
        }
    
  char filename[256], filepos[256], filename2[256], filenameReduced[256];
  strcpy (filename, argv[1]);
  float MAF=atof(argv[2]);
  BayesType BayesMode=(BayesType) atoi(argv[3]);
  IndCategory ic= (IndCategory) atoi(argv[4]);
  bool IsPartiallySolved=atoi(argv[5]);
  SNPPos size=1000;
  unsigned int nHH;
  double upperbound, lowerbound;

  ChangeExtension (filename, filename2, "pm");

try
{
  OutputFile.open (filename2, ofstream::out);
  if (!OutputFile) throw ErrorFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
TrioSample *ts;
//GenomaSample *gs;
Positions* Pos;
Table2x2 T2x2;
ChangeExtension (filename, filepos, "pou");

Pos=new Positions (filepos);

ts=new TrioSample (filename, ic);

ChangeExtension (filename, filenameReduced, "red");
ts->WriteResults(filenameReduced, true, ic, (SNPPos)0, (SNPPos)100);//last number is the SNP to be printed
OutputFile << "file source:" << filename <<", Bayes type:" << BayesMode << ", IndCategory:" << ic <<", Used partial phase:" << IsPartiallySolved <<"\n";
OutputFile << PrintHeading();
double fAB, fA, fB, DPrime, MaxDPrime;
SNPPos SNP2, TotalSNPs=ts->GetTotalSNPs(), total;

PairwiseMeasure<TrioSample> *PM;
MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(ts, (BayesType)0, ic);

IndPos TotalABab=0, TotalABAbab=0, TotalABaBab=0, TotalAbABaB=0;

for (SNPPos SNP=0; SNP<(TotalSNPs);SNP++)

//for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 if (MM.GetTotalFreqAllele(SNP, false)>MAF) 
 {
 cout <<"\nsnp:" << SNP+1;
 //for (SNPPos SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
for (SNPPos SNP2=0; SNP2<TotalSNPs;SNP2++)
if (SNP2!=SNP)
if (ts->GetTotalAllele(SNP, true, ic)<ts->GetTotalAllele(SNP2, true, ic))
//if (fabs(ts->GetTotalAllele(SNP, true, ic)-ts->GetTotalAllele(SNP2, true, ic))<2.0)
 if (MM.GetTotalFreqAllele(SNP2, false)>MAF)
 {
 PM = new PairwiseMeasure<TrioSample>(SNP, SNP2, ts, BayesMode, ic, IsPartiallySolved);
 
 fA=PM->GetfA();
 fB=PM->GetfB();
 fAB=PM->GetfAB();
 DPrime=T2x2.GetDPrime(fAB, fA, fB);
 OutputFile 
	 << SNP+1 << ", " << Pos->PrintPosition(SNP)  << ", ";
 OutputFile
	 << SNP2+1 << ", " << Pos->PrintPosition(SNP2)  << ", " 
   	 << PM->GetfA() << ", " 
   	 << PM->GetfB() << ", " 
	 << ts->GetUnsolvedDoubleHeterozygous(SNP, SNP2, ic, IsPartiallySolved) << ", "
	 << PM->GetnAB() <<", "
 	 << PM->GetnAb() <<", "
	 << PM->GetnaB() <<", "
	 << PM->Getnab() <<"\n";
 if ((PM->GetnAB()==0 && PM->Getnab()==0) || (PM->GetnAb()==0 && PM->GetnaB()==0))  
  TotalABab++;
 else
 if (PM->GetnaB()==0)  
  TotalABAbab++;
 else
 if (PM->GetnAb()==0)  
  TotalABaBab++;
 else
 if (PM->Getnab()==0)  
  TotalAbABaB++;



  } // end for each SNP2 a real SNP
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise measures has been saved in file " << filename2 <<"\n";
 
 cout <<"\nAB-ab:" << TotalABab;
 cout <<"\nAB-Ab-ab:" << TotalABAbab;
 cout <<"\nAB-aB-ab:" << TotalABaBab;
 cout <<"\nAb-AB-aB:" << TotalAbABaB;

 OutputFile.close();

   return 0;

};

