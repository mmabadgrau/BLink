
#ifndef __basicOld_h__
#define __basicOld_h__


#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
#include <math.h>
#include <stdio.h>//
#include "ExceptionsBasic.h"

#define  maxint  32767//
#define maxreal  1.7E+38//
#define zero 0.1E-10 //

namespace UTILS {
/////////
template <class T> T sum (T* array, unsigned int length)
{
T total=0;
for (int i=0; i<length;i++)
 total=total+array[i];
return total;
}    
/////////
template <class T> void change (T & val1, T & val2)
{
T s;
s=val1;
val1=val2;
val2=s;
}       
/////////
/*---------------------------------------------------------------*/

template <class T>
T * Initialize(unsigned long int size, T val)
{
T * x;
try
{
if ((x = new T [size])==NULL) //
 throw NoMemory();
}
catch (NoMemory NM) {
        NM.PrintMessage();  }

InitializeList(x, size, val);
return (x);
}
/*---------------------------------------------------------------*/

template <class T>
void InitializeList(T* list, unsigned long int size, T val)
{
for (unsigned long int i=0;i<size;i++)
 list[i]=val;
}

/*---------------------------------------------------------------*/

template <class T> bool IsOne (T value)
{
double val=(double) value;
if ((val>=(1.0-zero)) && (val<=(1.0+zero)))
return true;
else return false;
}                                                   
///////
bool ExistFile (char* namefile)
{
struct stat fs;
if (stat(namefile, &fs)==0) return (true); else return (false);
}
/*---------------------------------------------------------------*/
bool IsAZero(unsigned int column, unsigned int pos) 
{
// this function returns 0 if pos has a 0 at column or 1 if it has a 1 at column, considering
// a basis2 table with TotalColumns (i.e., 2^TotalColumns positions)
//cout <<"pos:" << pos <<", column:" << column;
	int min= (pos/(int)pow(2,column+1))*(int)pow(2,column+1);
//	cout <<"min:" << min;
	//(pos%(2^column-1));
	int max= min+(int)pow(2,column);
//	cout <<"max:" << max;
	if ((pos>=min) && (pos<max))
		return true; 
	else return false;
}
/*---------------------------------------------------------------*/

	int comparedouble(const void *arg1, const void *arg2)
	{
         if(*(double *)arg1 < *(double *)arg2) return -1;
   else if(*(double *)arg1 > *(double *)arg2) return 1;
   else return 0;
	}
/*---------------------------------------------------------------*/

	int comparechar(const void *arg1, const void *arg2)
	{
         if(*(char *)arg1 < *(char *)arg2) return -1;
   else if(*(char *)arg1 > *(char *)arg2) return 1;
   else return 0;
	}	
/*---------------------------------------------------------------*/

int compareint (const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}


/*---------------------------------------------------------------*/
unsigned int GetNumberOfColumns (char* filename)
{
ifstream InputFile; 
char * cad, * genotypebuf;

unsigned int maxN=20000;

try
{
if ((genotypebuf=new char[maxN*4])==NULL)
 throw NoMemory();
if ((cad=new char[maxN*4])==NULL)
 throw NoMemory();



 InputFile.open (filename, ifstream::in);

 if (InputFile.peek()==EOF)
  throw EmptyFile();	

 InputFile.getline (genotypebuf, maxN*4, '\n');

 InputFile.close();

}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
	EFile.PrintMessage(filename);}
catch (NoMemory NM) {
        NM.PrintMessage();  }


unsigned int Columns=0;

	cad = strtok (genotypebuf," \t");

	do
	{
     cad = strtok (NULL," \t");
	 Columns++;
	}
	 while (cad!=NULL);

	delete cad, genotypebuf;

return Columns;
}
////////
// Put an assert to check if x is NULL, this is to catch
// program "logic" errors early. Even though delete works
// fine with NULL by using assert you are actually catching
// "bad code" very early

// Defining Zap using templates
// Use zap instead of delete as this will be very clean
template <class T>
inline void zap(T & x)
{
        assert(x != NULL);
        delete x;
        x = NULL;
}
// In C++ the reason there are 2 forms of the delete operator is because
// there is no way for C++ to tell the difference between a pointer to
// an object and a pointer to an array of objects. The delete operator
// relies on the programmer using "[]" to tell the two apart.
// Hence, we need to define zaparr function below.
// To delete array of pointers
template <class T>
inline void zaparr(T & x)
{
        assert(x != NULL);
        delete [] x;
        x = NULL;
}

/*---------------------------------------------------------------*/
int median(int * ip, int  size)
{
	if ((size % 2) != 0)
		return ip[size / 2];
	else
		return (ip[size / 2 - 1] + 
				ip[size / 2]) / 2; // it is not exact, because sometimes we can have an interval and the median is undetermined
	// here we get the floor value
}
/*---------------------------------------------------------------*/
double median(double * ip, int  size)
{
int lower=size;
int upper=0;
double val=ip[size / 2];
for (int i=0;i<size;i++)
{
if ((ip[i]==val) && (lower==size))
 lower=i;
if (ip[i]==val) upper=i;
}
return ip[lower]+(ip[upper]-ip[lower])*(double)(val-lower)/(double)(upper-lower);
}
/*---------------------------------------------------------------*/

double percentile(double * ip, int  size, int perc)
{
int lower=size;
int upper=0;
double val=ip[(int) floor (size * perc/(double)100)];
for (int i=0;i<size;i++)
{
if ((ip[i]==val) && (lower==size))
 lower=i;
if (ip[i]==val) upper=i;
}
if (upper>lower)
return ip[lower]+(ip[upper]-ip[lower])*(double)(val-lower)/(double)(upper-lower);
else return ip[lower];
}

/*---------------------------------------------------------------*/
template <class T> T maxi(T a, T b)//
{//
if (a >= b)//
return (a);//
else return (b);//
}//
/*---------------------------------------------------------------*/
template <class T> T mini(T a, T b)//
{//
if (a <= b)//
return (a);//
else return (b);//
}//
/*---------------------------------------------------------------*/
template <class T> T GetExtreme(T* array, unsigned long int size, bool IsMax=true)//
{//
return array[GetExtremePos(array, size, IsMax)];
}//
/*---------------------------------------------------------------*/
template <class T> unsigned long int GetExtremePos(T* array, unsigned long int size, bool IsMax=true)//
{//
T Extreme=array[0];
unsigned long int ExtremePos=0;

for (unsigned long int i=1;i<size;i++)
 if ((array[i]>Extreme && IsMax==true) || (array[i]<Extreme && IsMax==false))
 {
	 Extreme=array[i];
	 ExtremePos=i;
 }
return (ExtremePos);
}//
/*---------------------------------------------------------------*/
template <class T> unsigned long int GetMax(T* array, unsigned long int size)//
{
	return GetExtreme(array, size, true);
}
/*---------------------------------------------------------------*/
template <class T> unsigned long int GetMin(T* array, unsigned long int size)//
{
	return GetExtreme(array, size, false);
}
/*---------------------------------------------------------------*/
template <class T> unsigned long int GetMaxPos(T* array, unsigned long int size)//
{
	return GetExtremePos(array, size, true);
}
/*---------------------------------------------------------------*/
template <class T> unsigned long int GetMinPos(T* array, unsigned long int size)//
{
	return GetExtremePos(array, size, false);
}
/*---------------------------------------------------------------*/
void ChangeExtension (char* FileSource, char*FileTarget, char* Extension)
{
         strcpy (FileTarget, FileSource);
		 FileTarget=strtok(FileTarget+2, ".")-2;
         strcat (FileTarget, ".\0");
		 strcat (FileTarget, Extension);
		 strcat (FileTarget, "\0");
}
/*---------------------------------------------------------------*/
bool HasThisExtension (char* FileSource, char* Extension, unsigned short int ExtensionLength)
{
 int pos;
 for (int i=0;i<strlen(FileSource);i++)
	 if (FileSource[i]=='.')
		 pos=i;
char * p=&FileSource[pos+1];
if (strncmp(p, Extension, ExtensionLength)==0) return true; else return false;

}
/*---------------------------------------------------------------*/
void CaptureLine (ifstream * source, char* genotypebuf, unsigned long int & size)
{/*
	if (size>100)
	while (source->peek()!=EOF) 
	{
source->getline (genotypebuf, size, '\n');
cout << genotypebuf <<"\n";
	}
	else
	*/
source->getline (genotypebuf, size, '\n');


}
/*---------------------------------------------------------------*/
unsigned long int GetLineLength (char * FileName)
{
ifstream  InputFile;
cout <<"Filename: " << FileName;
try
{
 if (!ExistFile(FileName))
	 throw ErrorFile();
 InputFile.open (FileName, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(FileName);
   }
	char c; 
	unsigned long int i=0;
	do
	{
	 InputFile.get (c);
	 i++;
	} 
	while (c!='\n' && c!=EOF);

	InputFile.close();
	return i;
}
/*____________________________________________________________ */

void OpenOutput(char* filename, ofstream* OutputFile)
{
  try
{
	  OutputFile->open (filename, ifstream::out);
	 if (!*OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
}
}
// end namespace
#endif
