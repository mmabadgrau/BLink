/* File: block.h */


#ifndef __block_h__
#define __block_h__

//#include <string.h>
//#include <cstdio>

#include "Exceptions.h"

#include "../commonc++/list.h"

using namespace UTILS;

namespace BIOS {


/************************/
/* block SNP*/
/************************/


/**
        @memo block

	@doc
        Definition:
        An array SampleValues of Size values

        Memory space: O(size). 

        @author Maria M. Abad
	@version 1.0
*/
	typedef struct Block{

      /**
      @memo Initial Pos of a block
      @doc  
      */
      SNPPos IniPos;

      /**
      @memo Last+1 pos of the block
      @doc 
      */
      SNPPos LastPos;

	};  // end structure block


 class block : public list<Block>{


protected:
    /** @name Implementation of class block
        @memo Private part.
    */

   bool * ListUsedSNPs;

   
	SNPPos TotalSNPs;
  
	float MaxWidth; 
     
	void OrderBlockByPos();


//	void ReadElement (ifstream * source, unsigned long int size){};


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
/* PUBLIC FUNCTIONS (INTERFACE) */

   public:

	void WriteBlocks(char* filename);

	block(char* filename);


};  // End of class block



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

 
 Block list<Block>::ReadElement (ifstream * source, unsigned long int size)
 {
	struct Block block; 


	char genotypebuf[size], cad2[10]; 
	CaptureLine(source, genotypebuf, size);
//	cout <<"\n" << genotypebuf;
//	exit(0);
	char *cad;
	cad = strtok (genotypebuf," \t\0");
//	cout <<"cad:" << cad;
//	strcpy(cad2, "\0");
//	sscanf (cad, "%s", cad2);
	block.IniPos=atoi(cad);
	while (cad!=NULL)
	{
 	 strcpy(cad2, cad);
     cad = strtok (NULL," \t\n\0");
	}
    block.LastPos=atoi(cad2);
//exit(0);
	return block;

 };

 
 /*********************************************************************/
void block::OrderBlockByPos()
{
	if (!IsEmpty())
	{
	SNPPos TotalBlocks=GetSize();
	Block TableBlocks[TotalBlocks];
	NodePointer p=GetFirst();
	SNPPos i=0;
	while (p!=NULL)
	{
    TableBlocks[i]=GetElement(p);
	p=GetNext(p);
	i++;
	}
	qsort ((void*)TableBlocks, TotalBlocks, sizeof (struct Block), compareint);


p=GetFirst();
i=0;

while (p!=NULL)
{
 ReplaceNode(p, TableBlocks[i]);
 p=GetNext(p);
 i++;
}
	}

}
///////////////////
//// public ////////
///////////////////
/*________________________________________________________________________________*/

block::block(char* filename):list<Block>()
{
List=NULL;
GetInfo(filename);
};
/**********************************/
void block::WriteBlocks(char* filename)
{
  ofstream OutputFile; 

  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage(" block::WriteBlocks");
      }

NodePointer Pointer=GetFirst();
Block BlockC;
bool first;
double size=0, AverageSize, TotalBlocks=0;
while (Pointer!=NULL)
{
Block BlockC=GetElement(Pointer);
first=true;
size=0;
for (unsigned long int i=BlockC.IniPos;i<=BlockC.LastPos;i++)
 if (ListUsedSNPs==NULL || ListUsedSNPs[i])
 {
	if (first==false)
	OutputFile << ' ';
    else first=false;
	OutputFile << i+1;
	size++;
}
 OutputFile  <<  '\n';
 Pointer=GetNext(Pointer);
 AverageSize=AverageSize+size;
 TotalBlocks++;
};

OutputFile.close();

cout << "\nInformation about blocks has been saved in file " << filename <<"\n";
cout << "\nAverage block size: " << AverageSize/TotalBlocks <<"\n";
}


};  // End of Namespace

#endif

/* End of file: block.h */




