echo Introduce month, year, sample and object subdirectory as arguments 
echo Convert to gen format
cd $4
chromosome="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
#chromosome="18"
for a in $chromosome
do
# echo $a 
inputfile="genotypes_chr"$a"_"$3"_txt_gz.txt"
outputfile="chromosome"$a"_"$3$1$2".txt"
# originalfile="genotypes_chr"$a"_"$3".txt.gz"
#gunzip $originalfile
mv pedigree$3.txt pedigree.txt
/home/faculty/mabad/genoma/hapmap $inputfile 90 $outputfile
mv pedigree.txt pedigree$3.txt
echo Converted to dhap format
 echo  "Converted file " 
echo  $inputfile
echo  " in " 
 echo $outputfile
done
