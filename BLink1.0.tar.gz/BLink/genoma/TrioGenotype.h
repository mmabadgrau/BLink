/* File: TrioGenotype.h */


#ifndef __TrioGenotype_h__
#define __TrioGenotype_h__


#include "Genotype.cpp"
#include "GenotypeSample.cpp"


namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo GenotypePointer for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class TrioGenotype {


public:
    /** @name Implementation of class GenotypePointer
        @memo Private part.
    */
	

	GenotypePointer FatherGenotype, MotherGenotype, ChildGenotype;

	char line[100];	
   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on GenotypePointer 
        @memo Operations on a GenotypePointer 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */


		TrioGenotype();

		TrioGenotype (GenotypePointer FatherGenotype, GenotypePointer MotherGenotype, GenotypePointer ChildGenotype);


      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
//      ~TrioGenotype ();

//	  bool IsComplete (SNPPos SNP1, SNPPos SNP2);

//	  bool IsHeterozygous (SNPPos SNP1, SNPPos SNP2, allele * MajorAllele);      

	  GenotypePointer GetFatherGenotype ();

	  GenotypePointer GetMotherGenotype ();

	  GenotypePointer GetChildGenotype ();

	  void SetFatherGenotype (GenotypePointer genotype);

	  void SetMotherGenotype (GenotypePointer genotype);

	  void SetChildGenotype (GenotypePointer genotype);


	  string PrintGenotype(SNPPos SNP);

};  // End of class GenotypePointer



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

TrioGenotype::TrioGenotype ()
{

}

/*____________________________________________________________ */

TrioGenotype::TrioGenotype (GenotypePointer  FatherG, GenotypePointer  MotherG, GenotypePointer  ChildG)
{
try
{
if (FatherG==NULL || MotherG==NULL || ChildG==NULL)
 throw NullValue();
}
 catch (NullValue ov) {ov.PrintMessage(" TrioGenotype::constructor");}

FatherGenotype=FatherG;
MotherGenotype=MotherG;
ChildGenotype=ChildG;
}
/*____________________________________________________________ */
/*
string TrioGenotype::PrintGenotype (SNPPos SNP)
{
char l[this->FatherGenotype->element->GetTotalSNPs()*9];
strcpy(l,"\0");
strcat(l, FatherGenotype->element->print(SNP).c_str());
strcat(l, MotherGenotype->element->print(SNP).c_str());
strcat(l, ChildGenotype->element->print(SNP).c_str());
return string(l);
}
/*____________________________________________________________ */

GenotypePointer TrioGenotype::GetFatherGenotype ()
{
	return FatherGenotype;
}
/*____________________________________________________________ */

GenotypePointer TrioGenotype::GetMotherGenotype ()
{
	return MotherGenotype;
}
/*____________________________________________________________ */

void TrioGenotype::SetFatherGenotype (GenotypePointer genotype)
{
FatherGenotype=genotype;
}
/*____________________________________________________________ */

void TrioGenotype::SetMotherGenotype (GenotypePointer genotype)
{
MotherGenotype=genotype;
}/*____________________________________________________________ */

void TrioGenotype::SetChildGenotype (GenotypePointer genotype)
{
ChildGenotype=genotype;
}
/*____________________________________________________________ */

GenotypePointer TrioGenotype::GetChildGenotype ()
{
	return ChildGenotype;
}

/*___________________________________________________*/
/*
bool TrioGenotype::IsComplete (SNPPos SNP1, SNPPos SNP2)      
{
	return ChildGenotype->GetDiplotype(SNP1).IsANonMissingSNP()	&& ChildGenotype->GetDiplotype(SNP2).IsANonMissingSNP() &&
		   FatherGenotype->GetDiplotype(SNP1).IsANonMissingSNP() && FatherGenotype->GetDiplotype(SNP2).IsANonMissingSNP() &&
		   MotherGenotype->GetDiplotype(SNP1).IsANonMissingSNP() && MotherGenotype->GetDiplotype(SNP2).IsANonMissingSNP();
}
/*___________________________________________________*/
/*
bool TrioGenotype::IsHeterozygous (SNPPos SNP1, SNPPos SNP2, allele * MajorAllele)      
{
	return ChildGenotype->GetDiplotype(SNP1).IsHeterozygous(MajorAllele[SNP1]) && ChildGenotype->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2]) &&
		   FatherGenotype->GetDiplotype(SNP1).IsHeterozygous(MajorAllele[SNP1]) && FatherGenotype->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2]) &&
		   MotherGenotype->GetDiplotype(SNP1).IsHeterozygous(MajorAllele[SNP1]) && MotherGenotype->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2]);
}
*/

/*______________________________________________________*/

ostream& operator<<(ostream& out,TrioGenotype& trio)
{

out << trio.FatherGenotype->element->print()<<"\n";
out <<" " << trio.MotherGenotype->element->print() <<"\n";
out <<" " << trio.ChildGenotype->element->print() <<"\n";

//out << trio.PrintGenotype(i);

return out;
  }

template<> ostream& operator<<(ostream& out, list<TrioGenotype>& l){};
};  // End of Namespace

#endif

/* End of file: GenotypePointer.h */




