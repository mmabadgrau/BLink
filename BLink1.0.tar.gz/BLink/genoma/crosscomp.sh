rm crosscomp
echo crosscomp
../ChangeFormat i MSAMPLE cross50 cross50.txt c 1 100 50
../ChangeFormat i MSAMPLE cross100 cross100.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross150 cross150.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross200 cross200.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross250 cross250.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross300 cross300.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross350 cross350.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross400 cross400.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross450 cross450.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross500 cross500.txt c 1 100 50
../ChangeFormat i MSAMPLE cross550 cross550.txt c 1 100 50 
../ChangeFormat i MSAMPLE cross600 cross600.txt c 1 100 50 
echo phase resolver
../PhaseResolver cross50.txt 100 50 1
../PhaseResolver cross100.txt 100 50 1
../PhaseResolver cross150.txt 100 50 1
../PhaseResolver cross200.txt 100 50 1
../PhaseResolver cross250.txt 100 50 1
../PhaseResolver cross300.txt 100 50 1
../PhaseResolver cross350.txt 100 50 1
../PhaseResolver cross400.txt 100 50 1
../PhaseResolver cross450.txt 100 50 1
../PhaseResolver cross500.txt 100 50 1
../PhaseResolver cross550.txt 100 50 1
../PhaseResolver cross600.txt 100 50 1
echo phase checker
../PhaseCheckerComparingSamples cross50.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross100.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross150.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross200.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross250.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross300.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross350.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross400.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross450.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross500.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross550.sal crosscomp 50 100 0
../PhaseCheckerComparingSamples cross600.sal crosscomp 50 100 0
