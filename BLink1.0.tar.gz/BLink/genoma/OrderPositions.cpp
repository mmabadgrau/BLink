 /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

#include "../commonc++/Fachade.h"
#include "SNP.cpp"

#include "UnorderedRepeatedPositions.cpp"
#include "RepeatedPositions.cpp"
#include "UnorderedRepeatedGenomaSample.cpp"
#include "RepeatedGenomaSample.cpp"





/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc!=2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <genoma filename> " << endl;
        exit(-1);
        }
     char filepos[128], filepos2[128], filepos3[128], orderedfile[128], file[128], orderedunrepeatedfile[128];

	 strcpy(file, argv[1]);
   
	ChangeExtension (file, filepos, "pos");
	ChangeExtension (file, filepos2, "poo");
	ChangeExtension (file, filepos3, "pou");
	ChangeExtension (file, orderedfile, "geo");
	ChangeExtension (file, orderedunrepeatedfile, "gou");

    list<SNPPos> *sampling=NULL, *sampling2=NULL;

	try{       
	
	// first order positions	
	UnorderedRepeatedPositions * positions1;
	positions1=new UnorderedRepeatedPositions (filepos);
	positions1->PrintRepeatedPositions();
	UnorderedRepeatedGenomaSample* sample;
	sample=new UnorderedRepeatedGenomaSample(file);
	sampling=positions1->GetOnlyFilePos();
	sample->SNPSampling(sampling);
	sample->PrintOrderedRepeatedGenoma(orderedfile);
	//	exit(0);
end();
	zap(sample);
	zap(sampling);
	zap(positions1);
	
	
	// second remove repeated positions
	RepeatedPositions* positions2=NULL;
	positions2=new RepeatedPositions (filepos2);
	positions2->PrintOrderedUnrepeatedPositions();
	RepeatedGenomaSample* sample2=NULL;
	sample2=new RepeatedGenomaSample(orderedfile);
	sampling2=positions2->GetOnlyFilePos();

	sample2->SNPSampling(sampling2);
	sample2->PrintOrderedUnrepeatedGenoma(orderedunrepeatedfile);
//	zap(sample2);
//	zap(sampling2);
//	zap(positions2);
	}
	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
 	 catch (MonoAllelic ma) {
		 ma.PrintMessage();}
 	 catch (NullValue nv) {
		 nv.PrintMessage();}
 	 catch (ZeroValue zv) {
		 zv.PrintMessage();}
  	 catch (UnsolvedPhase up) {
		 up.PrintMessage();}

   return 0;

}





