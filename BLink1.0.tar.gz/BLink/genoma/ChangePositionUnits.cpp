  /**
    * @file genoma.cpp
    * @brief Program for different geneomics computations
    * a file with the positions to be chosen must be in the 
	* same directory and with the same name than the input file and extension .posS
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "GenomaSample.h"

using namespace UTILS;



/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <file> "  << " <new file> " << "<factor>" << endl;
        exit(-1);
        }
     char filename[128], filename2[128];

	 strcpy(filename, argv[1]);
	 strcpy(filename2, argv[2]);

     SNPPos factor=atoi(argv[3]);



Positions * Pos, *Pos2;
Pos=new Positions (filename);

Pos->ChangeUnits(factor);
Pos->PrintPositions (filename2);

delete Pos;

	   return 0;

}





