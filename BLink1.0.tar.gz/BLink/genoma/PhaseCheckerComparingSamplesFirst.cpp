  /**
    * @file PhaseChecker.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "Haplotype.h"
//#include "PhaseResolver.h"



   
namespace BIOS
{
/*_________________________________________________________________________*/

SNPPos GetTotalSNPs(char* filename)
{
unsigned long int length=GetLineLength (filename), TotalSNPs=0; 
ifstream InputFile;
OpenInput(filename, &InputFile);
char line[length];
CaptureLine (&InputFile, line, length);
for (int i=0;i<length;i++)
 if (line[i]>='0' && line[i]<='4') TotalSNPs++;

InputFile.close();
return TotalSNPs;
}
/*_________________________________________________________________________*/

allele GetHap(ifstream* InputFile)
{
char c, b;
allele a;
InputFile->get(c);
if (c==' ' || c=='\t') InputFile->get(c);
if (c=='(' || c=='[') // only in PHASE and PHASERECOMB
{
  InputFile->get(c);
  InputFile->get(b);
}	 
if (c=='-') 
 {
  InputFile->get(c);
  a=(allele)-atoi(&c);
 }
else 
if (c=='A' || c=='G' || c=='T' || c=='C' || c=='?' || c=='N')
a=(allele)ConvertAllele(&c);
else
a=(allele)atoi(&c);
return a;
}
/*_________________________________________________________________________*/

SNPPos GetLineFirstHaplotype(char* filename, FormatType alg)
{
SNPPos line=0;
switch (alg)
{
case DHAP: 
case NR1: 
break;
case PHASE:
case PHASERECOMB: 
line=GetStringLinePosition(filename,"BEGIN BESTPAIRS1");
break;
case SNPHAP:
line=4;
break;
case HTYPER:
case PLEM:
line=6;
break;
}
return line;
}
/*_________________________________________________________________________*/

void JumpLine(ifstream* InputFile, FormatType alg, SNPPos  TotalSNPs)
{
char line[TotalSNPs*3];
SNPPos l=0;
switch (alg)
{
case DHAP: 
case NR1: 
case SNPHAP:
break;
case PHASE:
case PHASERECOMB: 
case HTYPER:
l=1;
break;
case PLEM:
l=3;
break;
}
for (int i=0;i<l;i++)
 NextLine(InputFile);
}
/*_________________________________________________________________________*/
/*
unsigned long int NextHapForPhase(ifstream* InputFile)
{

	char c; 
	do
	 InputFile->get (c);
 
	while (c!=',');
	 InputFile->get (c);
}
/*__________________________________________________________________________*/

void GetHaplotypes (char* filename, char* filenametrue, allele** HapLeft, allele**HapRight, allele**TrueHapLeft, allele**TrueHapRight, FormatType alg, SNPPos TotalIndividuals, SNPPos TotalSNPs)
{

ofstream OutputFile;
ifstream InputFile, InputFile2;
bool exist=true;

OpenInput(filename, &InputFile);
OpenInput( filenametrue, &InputFile2);

Haplotype *H, *TrueH;
char c;
IndPos IndError=0;
SNPPos SwitchError=0, StError=0, Unknown=0, Unsolved=0;

SNPPos line=GetLineFirstHaplotype(filename, alg);

for (SNPPos i=0;i<line;i++)
 NextLine(&InputFile);
for (IndPos i=0;i<TotalIndividuals; i++)
{
 JumpLine(&InputFile, alg, TotalSNPs);
// cout << GetLine(&InputFile, 100);
 for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
 {
 HapLeft[i][SNP]=GetHap(&InputFile);
 TrueHapLeft[i][SNP]=GetHap(&InputFile2);

 //if (i==1)
// cout <<"\n" << HapLeft[i][SNP] <<"-" << TrueHapLeft[i][SNP];
 }
 NextLine(&InputFile);
 NextLine(&InputFile2);
 // if (i==0)
 //cout << GetLine(&InputFile, 100);
 // exit(0);
 for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
 {
 HapRight[i][SNP]=GetHap(&InputFile);
 TrueHapRight[i][SNP]=GetHap(&InputFile2);

 //if (i==1)
 //cout <<"\n" << HapRight[SNP] <<"-" << TrueHapRight[SNP];
 }
 NextLine(&InputFile);
// if (i==0)
// cout << GetLine(&InputFile, 100);
 NextLine(&InputFile2);
 }// end for each individual
InputFile.close();
InputFile2.close();

}
/*__________________________________________________________________________*/

void ChangeAlleles (allele **HapLeft, allele **HapRight, allele **TrueHapLeft, allele **TrueHapRight, SNPPos TotalIndividuals, SNPPos TotalSNPs)
{
allele oneallele, otherallele;
SNPPos total1, total2;
for (SNPPos SNP=0;SNP<TotalSNPs; SNP++)
{
 oneallele=(allele)0; otherallele=(allele)0; total1=0; total2=0;
 for (IndPos i=0;i<TotalIndividuals; i++)
 {
  if (oneallele==0) { oneallele=TrueHapLeft[i][SNP]; total1=1;}
  if (TrueHapLeft[i][SNP]==oneallele) total1++; else {total2++; otherallele=TrueHapLeft[i][SNP];}
  if (TrueHapRight[i][SNP]==oneallele) total1++; else {total2++; otherallele=TrueHapRight[i][SNP];}
 }
  for (IndPos i=0;i<TotalIndividuals; i++)
  {
  if (HapLeft[SNP]==0) 
	  if (total1>=total2) HapLeft[i][SNP]=oneallele; else HapLeft[i][SNP]=otherallele;
  else
	  if (total1>=total2) HapLeft[i][SNP]=otherallele; else HapLeft[i][SNP]=oneallele;
  if (HapRight[SNP]==0) 
	  if (total1>=total2) HapRight[i][SNP]=oneallele; else HapRight[i][SNP]=otherallele;
  else
	  if (total1>=total2) HapRight[i][SNP]=otherallele; else HapRight[i][SNP]=oneallele;
  }
}

}
/*_________________________________________________________________________*/

void ComputeAccuracy(char* filename, char* filenametrue, char* fileaccuracy, FormatType alg)
{
ofstream OutputFile;
ifstream InputFile, InputFile2;
bool exist=false;
SNPPos TotalSNPs=GetTotalSNPs(filenametrue);
SNPPos TotalIndividuals=GetTotalLines(filenametrue)/2;

allele **HapLeft, **HapRight, **TrueHapLeft, **TrueHapRight;

HapLeft=new allele*[TotalIndividuals];
HapRight=new allele*[TotalIndividuals];
TrueHapLeft=new allele*[TotalIndividuals];
TrueHapRight=new allele*[TotalIndividuals];

for (IndPos i=0;i<TotalIndividuals;i++)
{
	HapLeft[i]=new allele [TotalSNPs];
	HapRight[i]=new allele [TotalSNPs];
	TrueHapLeft[i]=new allele [TotalSNPs];
	TrueHapRight[i]=new allele [TotalSNPs];
}

GetHaplotypes(filename, filenametrue, HapLeft, HapRight, TrueHapRight, TrueHapLeft, (FormatType)0, TotalIndividuals, TotalSNPs);

if (alg==PLEM || alg==HTYPER) ChangeAlleles(HapLeft, HapRight, TrueHapRight, TrueHapLeft, TotalIndividuals, TotalSNPs);

 //for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
 // cout <<"\n" << HapRight[1][SNP] <<"-" << TrueHapRight[1][SNP];

if (ExistFile(fileaccuracy)==true) exist=true;

OpenOutputAdd(fileaccuracy, &OutputFile);

if (!exist) 
OutputFile << "dataset\tTotalSNPs\tTotalIndividuals\tIndividualAcc\tTotal Het Known\tTotal Het Solved\tTotal Switch Correct\tSwitch Accuracy\tTotal Standard Correct\tStandard Accuracy\n";
Haplotype *H, *TrueH;
char c;
IndPos IndError=0;
SNPPos SwitchError=0, StError=0, Unknown=0, Unsolved=0, Homo=0;


for (IndPos i=0;i<TotalIndividuals; i++)
{
 H=new Haplotype (HapLeft[i], HapRight[i], TotalSNPs);
 TrueH=new Haplotype(TrueHapLeft[i], TrueHapRight[i], TotalSNPs);
 if (*H!=*TrueH) IndError++;
 SwitchError=SwitchError+H->GetSwitchErrors(TrueH);
 StError=StError+H->GetStErrors(TrueH);
 Unknown=Unknown+H->GetUnknown(TrueH);
 Unsolved=Unsolved+H->GetUnsolved(TrueH); 
 Homo=Homo+H->GetHomozygous(TrueH);
}// end for each individual
OutputFile << filename << "\t" << TotalSNPs << "\t" << TotalIndividuals << "\t" << (TotalIndividuals-IndError)/(float)TotalIndividuals << "\t"
<< TotalIndividuals*(TotalSNPs-1)-Unknown-Homo << "\t" << TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo << "\t"
<< TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-SwitchError << "\t" << (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-SwitchError)/(double) (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo) << "\t"
<< TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-StError << "\t" << (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-StError)/(double) (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo) << "\n";

OutputFile.close();
//delete haps

}
} // end namespace



/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;



int main(int argc, char*argv[]) {

     if (argc<3) 
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <ficheroacc> " << " <phase algorithm>" << endl;
        exit(-1);
        }
char filename[128], filenametrue[128], filenameacc[128], filenametrue2[128];
        
strcpy(filename, argv[1]);

strcpy(filenameacc, argv[2]);

FormatType alg=(FormatType)0; // DHAP

if (argc>3)
{
 alg=(FormatType) atoi(argv[3]);
if (alg==HTYPER) cout <<"SS";
}

ChangeExtension (filename, filenametrue2, "truehaps");

sprintf (filenametrue, "../%s", filenametrue2);

ComputeAccuracy(filename, filenametrue, filenameacc, alg);
 
return 0;
}






