/* File: GenotypeSample.h */


#ifndef __OrderedGenotypeSample_h__
#define __OrderedGenotypeSample_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"
#include "orderedpositions.h"
#include "orderedgenotype.h"


using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class OrderedGenotypeSample: public list<OrderedGenotype>  {


protected:
    /** @name Implementation of class GenotypeSample
        @memo Private part.
    */

   	
	 /** @name Pointer to the list of the wild-type allele for every SNP
        @memo The wild-type will be the more frequent allele in the dataset
    */


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
   orderedpositions* pos;

  bool ExistPhenotypes;

/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */

	OrderedGenotype*  ReadElement (ifstream * source);




		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:


	  OrderedGenotypeSample (char &* filename,  orderedpositions &* pos, bool & ExistPhenotypes);

	  PrintOrderedUnrepeatedGenotypes(char * filename);

};  // End of class GenotypeSample



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

/////////// protected /////////////


/*___________________________________________________________ */

OrderedGenotypeSample*  OrderedGenotypeSample::ReadElement (ifstream * source)
{
	SNPPos TotalSNPs=pos->GetTotalSNPs(), size=TotalSNPs*4+40;

	try
	{
	
	Left[TotalSNPs], Right[TotalSNPs];	
	OrderedGenotype* targetGenotype;

	if ((targetGenotype=new OrderedGenotype())==NULL)
		throw NoMemory();



	ReadGenotypes (Left, Right, source, TotalSNPs, ExistPhenotype);

	Diplotype D;

	for (SNPPos i=0;i<TotalSNPs;i++)
	{
		D.Left=Left[i];
		D.Right=Right[i];
		targetPhenotype->InsertElement(D);
	}

	   
	}
	catch (NullValue nv) {nv.PrintMessage();}
	catch (NoMemory nm) {nm.PrintMessage();}

	return targetGenotype;
 }



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

OrderedGenotypeSample::OrderedGenotypeSample(orderedpositions * pos): list<OrderedGenotype>()
{
 // this->TheFirstGenotype=NULL;
  this->pos=pos;
}



/*____________________________________________________________ */

OrderedGenotypeSample::OrderedGenotypeSample (char &* filename,  orderedpositions &* pos, bool & ExistPhenotypes)
{

if (strncmp(strtok(filename+2, ".")-2, "geo", 3)!=0)
{
	cout <<"File geo is required";
	exit (0);
}

cout << "Reading genotypes ...\n";


GetInfo(filename);


cout << "Genotype reading has finished ...\n";


}
/*____________________________________________________________ */

GenotypeSample::PrintOrderedUnrepeatedGenotypes(char * filename)
{

	char filename2[256];

	ChangeExtension (filename, filename2, "gou");

  FILE * OutputFile; 
  
  try
{
  OutputFile=fopen (filename2, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

NodePointer IndPosition=GetFirst();
while (IndPosition!=NULL)
{
GenotypeSample->GetElement(IndPosition).PrintOrderedUnrepeatedGenotype();
OutputFile << "\n";
IndPosition=GetNext(IndPosition);
}
  
 fclose(OutputFile);

}



};  // End of Namespace

#endif

/* End of file: GenotypeSample.h */





