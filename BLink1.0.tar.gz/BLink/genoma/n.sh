make ChangeFormat
make PhaseChecker
make ReduceSample
make hapmap

