cd /home/mar/genoma/data 
echo convert to SNPHAP format
../ChangeFormat e SNPHAP crohn.txt crohnPHASE.inp 1 103 387
home/mar/haplotyper/haplotyper.1.0.LINUX/htyper CrohnForHap100 CrohnForHap100.out 103 100 10
../ChangeFormat i PHASE crohnPHASE.txt chrom1SNPHAP.out
../PhaseResolver crohnPHASE 387
../PhaseChecker  crohnPHASE 
