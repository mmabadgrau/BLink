  /**
    * @file GetLDDecay.cpp
    * @brief Program to compute the decay of LD as a function of physical distance
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"

using namespace std;

namespace BIOS 
	 {
char filename[128], filepos2[128], filepos3[128], fileSel[128], filename3[128];
IndCategory ic=everybody;
BayesType BayesMode=MLE;
bool IsPartiallySolved=false;
double MAF=0.0;
double MaximumDistance=0.0;
IndPos size=100;
SNPPos SlideSize=20000;
SNPPos SlideOverlap=10000;
AlleleOrderType AlleleOrderMode;
bool Selection=false;

// so average distances are 10, 20, 30, 40, ... kb
// which means 0-20, 10-30, 20-40, 30-50, 40-60, ... kb


/*_____________________________________________________________________________________________________________*/

void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "\nYou have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  <<"<max MaximumDistance>"
			<< " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium, 4: BayesDistanceUniform, 5: BayesDistanceSymmetric>" 
		<< "< phase (0: non changed/2: left right)>" 
		<<"<MAF>" << "<slide size (default 20000)>" << "<slide overlap (default 10000)>"  << "<selection file>" << endl;
        exit(-1);
        }


strcpy(filename, argv[1]);

if (argc>=3) MaximumDistance=atof(argv[2]);

if (argc>=4) BayesMode=(BayesType) atoi(argv[3]);

if (argc>=5) AlleleOrderMode=(AlleleOrderType) atoi(argv[4]);

if (argc>=6) MAF=atof(argv[5]);

if (argc>=7) SlideSize=atoi(argv[6]);

if (argc>=8) SlideOverlap=atoi(argv[7]);


if (SlideSize<SlideOverlap) 
{ 
	cout <<"SlideOverlap cannot be greater than slide size";
	exit(0);
}

if (argc==9) 
{
	strcpy(fileSel, argv[8]);
	Selection=true;
}


}

}
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
  
		 
double upperbound, lowerbound, MLDPrime;
SNPPos TotalSNPs, SNP3; 
GenomaSample *Sample, *Sample2;
Positions * Pos;
Table2x2 T2x2;

char filepos[128], filesw[128], ext[128];



if (BayesMode==MLE)
sprintf(ext, "MAF%2.1f-MLE.dec", MAF*100);
else
if (BayesMode==BDistanceUniform)
sprintf(ext, "MAF%2.1f-BDistanceUniform.dec", MAF*100);
else
if (BayesMode==BDistanceSymmetrical)
sprintf(ext, "MAF%2.1f-BDistanceSymmetrical.dec", MAF*100);





//sprintf(ext, "MAF%2.0lf%sdec", MAF*100, BayesMode);
ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, filesw, ext);


if (Selection)
sprintf(filesw, "%sExt%s", filesw, GetFilename(fileSel));
Pos=new Positions (filepos);
Sample=new GenomaSample (filename, AlleleOrderMode);

if (Selection) Sample2=new GenomaSample (fileSel, AlleleOrderMode);

TotalSNPs=Sample->GetTotalSNPs();
cout <<"TotalSNPS:" << TotalSNPs;
double TotalDistance=Pos->GetDistance(0, TotalSNPs-1);
cout <<"dist:" << Pos->GetDistance(0, TotalSNPs-1);
cout <<"first:";// << Pos->GetFirstElement() <<"--";// << Pos->GetLastElement();
if (MaximumDistance==0.0 || MaximumDistance>TotalDistance) 
 MaximumDistance=TotalDistance;
double fA, fB, fAB, DPrime, r2, D, YulesQ, rho;
PairwiseMeasure<GenomaSample> *PM;
SNPPos SlideGap=SlideSize-SlideOverlap;
SNPPos LastSNPInWindow, SNP=0, LastComparison, comparisons;
double pos, distance=SlideSize/(double)2, trueDistance;
ofstream OutputFile; 

OpenOutput(filesw, &OutputFile);
char line[1000];

OutputFile << "Average distance (kb)" << "\t" <<  "number of comparisons" << "\t" << "D\tDPrime\tr2\tYulesQ\trho" <<"\n";
MonolociMeasure<GenomaSample> MM = MonolociMeasure<GenomaSample>(Sample, (BayesType) 0, ic);
MonolociMeasure<GenomaSample> MM2 = MonolociMeasure<GenomaSample>(Sample2, (BayesType)0, ic);

Positions::NodePointer i=Pos->GetFirst();
try {
bool EndReached=false, OverDistance=false;
cout <<"\nMaximumDistance:" << MaximumDistance <<"\n";

do
{
if (distance>MaximumDistance) EndReached=true;
comparisons=0;
DPrime=0.0, lowerbound=0, upperbound=0, r2=0, MLDPrime=0.0, YulesQ=0.0, rho=0.0;
cout << "Distance: " << distance << "\n";
//PM = new PairwiseMeasure<GenomaSample>(3, 9, Sample, BayesMode, ic, IsPartiallySolved);

for (SNPPos SNP2=0; SNP2<(TotalSNPs-1);SNP2++) 
{
//	if (SNP2%100==0) cout << SNP2+1 << "\n";

 if (Sample->GetTotalMissing(SNP2, ic)==0) 
 if (MM.GetTotalFreqAllele(SNP2, false)>MAF) 
 if (!Selection || MM2.GetTotalFreqAllele(SNP2, false)>MAF) 
 {  
  SNP3=SNP2+1;
  OverDistance=false;
  do
   {
   trueDistance=Pos->GetDistance(SNP2, SNP3);
   if (trueDistance>(distance+SlideOverlap)) OverDistance=true;
   if (trueDistance>(distance-SlideOverlap) && trueDistance<=(distance+SlideOverlap))
   if (Sample->GetTotalMissing(SNP3, ic)==0) 
   if (MM.GetTotalFreqAllele(SNP3, false)>MAF) 
   if (!Selection || MM2.GetTotalFreqAllele(SNP3, false)>MAF) 
   {
	//   cout << SNP3+1 << "\n";

	if ((PM = new PairwiseMeasure<GenomaSample>(SNP2, SNP3, Sample, BayesMode, ic, trueDistance))==NULL)
		throw NoMemory();
	
	fA=PM->GetfA();
    fB=PM->GetfB();
    fAB=PM->GetfAB();
	DPrime=DPrime+T2x2.GetDPrime(fAB,fA,fB);
	r2=r2+T2x2.GetR2(fAB,fA,fB);
    D=D+T2x2.GetD(fAB, fA, fB); 
	YulesQ=YulesQ+T2x2.GetQ(fAB, fA, fB);
	rho=rho+T2x2.GetRho(fAB,fA,fB);
	comparisons++;
	delete PM;
   } // end for each SNP3 with freq>MAF 
   SNP3++;
   } // end for each pair with the right distance
  while (SNP3<TotalSNPs && OverDistance==false);
 } // end if freq>MAF
} // end for each SNP2
//cout << SNP+1 << "\n";
OutputFile << distance/(double)1000  << "\t" << comparisons << "\t";
if (comparisons>0)
sprintf(line, "%1.8lf\t%1.8lf\t%1.8lf\t%1.8lf\t%1.8lf\n", D/comparisons, DPrime/comparisons, r2/comparisons, YulesQ/comparisons, rho/comparisons);
else sprintf(line, "-\n");
OutputFile << line;
distance=distance+SlideGap;
//exit(0);
}
while (EndReached==false);
}
catch (OutOfRange ora) {ora.PrintMessage(SNP);}	 
catch (NonSNP ns) {ns.PrintMessage(SNP);}
catch (NullValue null) {null.PrintMessage();}
catch (NoMemory nm) {nm.PrintMessage();}
OutputFile.close();
 cout << "\nInformation about LD Decay has been saved in file " << filesw <<"\n";

delete Pos, Sample;
if (Selection) delete Sample2;
};








