/* File: PhaseResolver.h */

//#include <string>

//#include "Exceptions.h"
//#include "genoma.h"
#include "gamma.h"


#ifndef __PhaseResolver_h__
#define __PhaseResolver_h__

namespace SNP {

ofstream OutputFile;


/*_________________________________________________________________________*/
  bool genoma::IsResolved (Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP)
  {
   unsigned int TotalHeterozygous=0, LastHeterozygous, CurrentHeterozygous, distance=LastSNP-FirstSNP;
   for (int i=0;i<genotype::TotalSNPs;i++)
   {
	if ((i<=FirstSNP) && (IsHeterozygous(IndGenotype, i)))
		LastHeterozygous=i;
	if ((i>FirstSNP) && (i<LastSNP) && (IsHeterozygous(IndGenotype, i)))
	{
	 TotalHeterozygous++;
	 CurrentHeterozygous=i;
	}
   }
   if ((TotalHeterozygous==1) && ((CurrentHeterozygous-LastHeterozygous)>=distance))
   return false;
   else return true;
  }
/*_________________________________________________________________________*/

short unsigned int genoma::ObtenerBestPhase2 (unsigned int FirstHetero, unsigned int LastHetero, 
  Genotype* IndGenotypeRef, unsigned long int Ind)
// this function computes the number of 11 12 21 and 22 haplotypes existing
// in the dataset for those children with the same haplotypes for
// LeftHaplotype and RightHaplotype.
{
frequencies Frequencies;
sfrequencies Frequencies2;
Phenotype * IndPhenotype=TheFirstPhenotype;
Genotype * IndGenotype=TheFirstGenotype;
double MinimumDistance=10E6, distance;
unsigned int Center=(LastHetero-FirstHetero)/2;
short unsigned int Phase;
for (int i=0;i<Size;i++)
{
 distance=0; 
 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
  if (i!=Ind) 
   if (IsHomozygous (IndGenotype, FirstHetero) && IsHomozygous (IndGenotype, LastHetero)) 
   {
    for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
	 if (IsHomozygous(IndGenotypeRef, SNP))
     if ((IsHomozygous1 (IndGenotype, SNP) && IsHomozygous2 (IndGenotypeRef, SNP)) ||
		(IsHomozygous2 (IndGenotype, SNP) && IsHomozygous1 (IndGenotypeRef, SNP)))
	 {
		 SetFrequencies(Frequencies, SNP, Center);
         AdjustFrequencies(Known, Frequencies, Frequencies2); 
         distance=distance+2*GetLD(Frequencies2);
	 }
	 else if (IsHeterozygous(IndGenotype, SNP))
	 {
		 SetFrequencies(Frequencies, SNP, Center);
         AdjustFrequencies(Known, Frequencies, Frequencies2); 
         distance=distance+GetLD(Frequencies2);
	 }

	 if (distance<MinimumDistance)
	 {
	  MinimumDistance=distance;
	  if ((IsHomozygous1(IndGenotype, FirstHetero) && IsHomozygous1(IndGenotype, LastHetero)) ||
		  (IsHomozygous2(IndGenotype, FirstHetero) && IsHomozygous2(IndGenotype, LastHetero)))
		  Phase=1;
	  else Phase=2;
	 }
   }
 IndPhenotype=IndPhenotype->Next;
 IndGenotype=IndGenotype->Next;
}
return Phase;
}

/*_________________________________________________________________________*/

void genoma::EstimateMLEIP (double* comb, double * probs, double total)
{
	// Approximate MLE by IP

double probs2[4], t, denominator=(double)total+2*comb[4];

if (denominator==0) 
{
 throw ZeroValue();
 printf("error");
 exit(0);
}

 probs2[0]=(comb[0]+comb[4]*probs[0])/denominator; // AB
 probs2[1]=(comb[1]+comb[4]*(1-probs[0]))/denominator; // aB
 probs2[2]=(comb[2]+comb[4]*(1-probs[0]))/denominator; // Ab
 probs2[3]=(comb[3]+comb[4]*probs[0])/denominator; // ab

 t=probs2[0]+probs2[1]+probs2[2]+probs2[3];
if (fabs(1-t)>0.0001) cout << "ERR" << t;
 double epsilon=sqrt(probs2[0]*(1-probs2[0]))/(double)total;
 bool end=true;

 for (int i=0;i<4;i++)
 {
 if ((fabs(probs[i]-probs2[i])>= epsilon) 
	 || (fabs(probs[i]-probs2[i])>= 0.00005)) 
	 end=false;
 probs[i]=probs2[i];
 }
 
if (!end) EstimateMLE (comb, probs, total, 1000);
}

/*__________________________________________________________*/
bool genoma::IsLD (unsigned int *Frequencies)
{
	unsigned int n=0;
	double chi2, pvalue, Expected[4];
	
	for (int i=0;i<4;i++)
	 n=n+Frequencies[i];

	Expected[0]=(((double)Frequencies[0]+Frequencies[2])*(Frequencies[0]+Frequencies[1]))/n;
	Expected[1]=(((double)Frequencies[1]+Frequencies[0])*(Frequencies[1]+Frequencies[3]))/n;
	Expected[2]=(((double)Frequencies[2]+Frequencies[0])*(Frequencies[2]+Frequencies[3]))/n;
	Expected[3]=(((double)Frequencies[3]+Frequencies[1])*(Frequencies[3]+Frequencies[2]))/n;

	chi2=((pow(((double)Frequencies[0]-Expected[0]),2))/Expected[0])+((pow(((double)Frequencies[1]-Expected[1]),2))/Expected[1])+
		((pow(((double)Frequencies[2]-Expected[2]),2))/Expected[2])+((pow(((double)Frequencies[3]-Expected[3]),2))/Expected[3]);

    pvalue=(1-gammai(0.5, (double)chi2/2));

	if (pvalue<0.05) return true;
	else return false;
//	return true;

}
/*__________________________________________________________*/

unsigned int genoma::AssignPhase (unsigned int FirstHetero, unsigned int LastHetero, 
  Genotype* IndGenotype, int PreHetero)
{
frequencies Freqs;
unsigned int MajorPhase;
double total=0.0, denominatornew, numeratornew, oddratio, probs[4];

double* Frequencies=&Freqs[0];
if (haps==NULL)
{
GetHap(FirstHetero, LastHetero, Freqs);// AB, Ab, aB, ab and HH, only the first 5 positions are used
Frequencies=&Freqs[0];
}
else
Frequencies=haps[FirstHetero][LastHetero-FirstHetero-1];


//CopyFromHaps(Frequencies, FirstHetero, LastHetero);



for (int i=0;i<4;i++)
 total=total+Frequencies[i];

//for (int i=0;i<4;i++)
// probs[i]=Frequencies[i]/(double)total; // for IP or standard dhap


//initialization assuming HWE
probs[0]=GetTotalFreqAllele(FirstHetero,true,(IndCategory)2)*GetTotalFreqAllele(LastHetero,true,(IndCategory)2);
probs[1]=GetTotalFreqAllele(FirstHetero,true,(IndCategory)2)*GetTotalFreqAllele(LastHetero,false,(IndCategory)2);
probs[2]=GetTotalFreqAllele(FirstHetero,false,(IndCategory)2)*GetTotalFreqAllele(LastHetero,true,(IndCategory)2);
probs[3]=GetTotalFreqAllele(FirstHetero,false,(IndCategory)2)*GetTotalFreqAllele(LastHetero,false,(IndCategory)2);




EstimateMLE (Frequencies, &probs[0], total, 1000);


numeratornew=(probs[0]*probs[3]);
denominatornew=(probs[1]*probs[2]);//-numeratornew;//+H4;

oddratio=numeratornew-denominatornew;
  if (oddratio >= (double)0)
  MajorPhase=1;
else MajorPhase=2;



return MajorPhase;

//double maxi=0.0, mini=1.0, maxs, mins;

/*
unsigned int posmax=Frequencies[4];
double LDMin=GetLD(Min, Frequencies), 
LDMax=GetLD(Max, Frequencies), LDPred, LDReal=GetLD(Complete, Frequencies);
if (PreHetero>=0)
 LDPred=GetLD(Max, Frequencies);


if (LDMin>LDMax)
{
	double v=LDMin;
	LDMin=LDMax;
	LDMax=v;
	posmax=0;
}

Frequencies4[0]=Frequencies4[0]+posmax;
Frequencies4[1]=Frequencies4[1]+Frequencies4[4]-posmax;
Frequencies4[3]=Frequencies4[3]+posmax;
Frequencies4[2]=Frequencies4[2]+Frequencies4[4]-posmax;
*/

// ft=probs[0]*probs[3]+probs[1]*probs[2];

/*
double H=(GetTotalHeterozygous(ic, FirstHetero)+GetTotalHeterozygous(ic, LastHetero));
double HA2;

HA2=CountType(ic)-GetTotalHomozygous1(ic, FirstHetero) -1;


double HB2;

HB2=CountType(ic)-GetTotalHomozygous1(ic, LastHetero)-1;



double Ta=(double)GetTotalAllele(ic, FirstHetero, true)+GetTotalAllele(ic, FirstHetero, false);
double A=GetTotalAllele(ic, FirstHetero, true)/((double)Ta);
double a=GetTotalAllele(ic, FirstHetero, false)/((double)Ta);
double Tb=(double)GetTotalAllele(ic, LastHetero, true)+GetTotalAllele(ic, LastHetero, false);
double B=GetTotalAllele(ic, LastHetero, true)/((double)Tb);
double b=GetTotalAllele(ic, LastHetero, false)/((double)Tb);


*/




//numeratornew2=probs[0];

// denominatornew2=(A*B);//-numeratornew;//+H4;

//oddratio2=numeratornew2-denominatornew2;


} 
/*__________________________________________________________*/
void genoma::ReconstructHaplotypes2(unsigned short int **MajorPhase)
{
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype* IndGenotype=TheFirstGenotype;
int LastResolved;
unsigned short int Phase;
for (int i=0;i<SizeP;i++)
{
 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
 {
  LastResolved=-1;
  for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
  {
   if (IsHeterozygous(IndGenotype, SNP))
   {
if (MajorAllele[SNP]==MinorAllele[SNP])
throw MonoAllelic();
   Phase=MajorPhase[i][SNP];
   if (LastResolved!=-1)
   {
 //  if (SNP==21)
//   cout <<"\nphase:" <<Phase <<", major: " << MajorAllele[SNP]  <<", minor:"  << MinorAllele[SNP];

   if (*((IndGenotype->Left)+LastResolved)==MajorAllele[LastResolved])
	{
	   if (Phase==0)
	   {
	  *((IndGenotype->Right)+SNP)=(allele)5;
		   //cout <<"Phase not solved at ind " << i <<", between snp: " << LastResolved << " and SNP " << SNP << "\n";
		   //exit(0);
	   }
     if (Phase==1)
	 {
      (*((IndGenotype->Left)+SNP)=MajorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MinorAllele[SNP]);
	  }
	 if (Phase==2)
	 {
      (*((IndGenotype->Left)+SNP)=MinorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MajorAllele[SNP]);
	 }
	}
     else // left last hetero SNP was phased as a 2
     {
	 if (Phase==0)
	   {
	  *((IndGenotype->Right)+SNP)=(allele)5;
//		   cout <<"Phase not solved at ind " << i <<", between snp: " << LastResolved << " and SNP " << SNP << "\n";
//		   exit(0);
	   }
     if (Phase==1)
	 {
      (*((IndGenotype->Left)+SNP)=MinorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MajorAllele[SNP]);
	 }
	 if (Phase==2)
	 {
      (*((IndGenotype->Left)+SNP)=MajorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MinorAllele[SNP]);
	 }
	}
        } // end lastresolved!=-1
	LastResolved=SNP;
   } // end for each heterozygous SNP
  } // end for each SNP
 } // end if type
 IndGenotype=genotype::GetNext(IndGenotype);
 IndPhenotype=phenotype::GetNext(IndPhenotype);
} // end for each individual
}
/*__________________________________________________________*/
void genoma::ReconstructHaplotypes(unsigned short int *MajorPhase, Genotype *IndGenotype)
{
int LastResolved;
unsigned short int Phase;
  LastResolved=-1;
  for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
  {
   if (IsHeterozygous(IndGenotype, SNP))
   {
if (MajorAllele[SNP]==MinorAllele[SNP])
throw MonoAllelic();
   Phase=MajorPhase[SNP];
   if (LastResolved!=-1)
   {
   if (*((IndGenotype->Left)+LastResolved)==MajorAllele[LastResolved])
	{
	   if (Phase==0)
	   {
	  *((IndGenotype->Right)+SNP)=(allele)5;
		   //cout <<"Phase not solved at ind " << i <<", between snp: " << LastResolved << " and SNP " << SNP << "\n";
		   //exit(0);
	   }
     if (Phase==1)
	 {
      (*((IndGenotype->Left)+SNP)=MajorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MinorAllele[SNP]);
	  }
	 if (Phase==2)
	 {
      (*((IndGenotype->Left)+SNP)=MinorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MajorAllele[SNP]);
	 }
	}
     else // left last hetero SNP was phased as a 2
     {
	 if (Phase==0)
	   {
	  *((IndGenotype->Right)+SNP)=(allele)5;
//		   cout <<"Phase not solved at ind " << i <<", between snp: " << LastResolved << " and SNP " << SNP << "\n";
//		   exit(0);
	   }
     if (Phase==1)
	 {
      (*((IndGenotype->Left)+SNP)=MinorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MajorAllele[SNP]);
	 }
	 if (Phase==2)
	 {
      (*((IndGenotype->Left)+SNP)=MajorAllele[SNP]);
	  (*((IndGenotype->Right)+SNP)=MinorAllele[SNP]);
	 }
	}
        } // end lastresolved!=-1
	LastResolved=SNP;
   } // end for each heterozygous SNP
  } // end for each SNP
}
 /*____________________________________________________________ */

void genoma::ResolvePhase ()
{
OrderSNPs();
unsigned short int *MajorPhase;
int LastResolved, PreResolved;
cout << "\nReconstructing haplotypes...";

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype* IndGenotype=TheFirstGenotype;


 OutputFile.open ("IP.csv", ifstream::out);
 
 if (!OutputFile)
	 throw ErrorFile();


 if ((MajorPhase=new unsigned short int [genotype::TotalSNPs])==NULL)
  throw NoMemory();


/*
unsigned short int *PairwiseF;
if ((PairwiseF=new unsigned short int [genotype::TotalSNPs-1])==NULL)
throw NoMemory();
unsigned int cont=0;
// compute pairwise frequencies
 for (int SNP=0;SNP<(genotype::TotalSNPs-1);SNP++)
   PairwiseF[SNP]=AssignPhase (SNP, SNP+1, ic);
 */
//for (int dist=1;dist<genotype::TotalSNPs;dist++)
//{
IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++)
{

 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
 {
 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
  MajorPhase[SNP]=0;

 //LastResolved=-1; 
LastResolved=FindFirstHeterozygous(i);

 PreResolved=-1;
 for (int SNP=LastResolved+1;SNP<genotype::TotalSNPs;SNP++)
  if (IsHeterozygous(IndGenotype, SNP)) 
  {

   MajorPhase[SNP]=AssignPhase (LastResolved, SNP, IndGenotype, PreResolved);//PreResolved is not used in AssignPhase
   if (MajorPhase[SNP]==0) cout <<"phase a 0 en " << SNP <<" de ind " <<i;
   PreResolved=LastResolved;
   LastResolved=SNP;
 } //end for each hetero SNP
  ReconstructHaplotypes(MajorPhase, IndGenotype);
// exit(0);

 } // for each child


 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;

} // end for each individual
//} // for each distance



delete MajorPhase;
cout << "\nReconstruction has finished";
//delete PairwiseF;
OutputFile.close();
  }
 /*____________________________________________________________ */
/*
//do not do anything
  void genoma::ResolvePhaseAll ()
{
unsigned int MajorPhase;

// Resolve phase for every pair of consecutive SNP
OrderSNPs();


Genotype* IndGenotype=TheFirstGenotype;

 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
    MajorPhase=AssignPhase (SNP, SNP+1, IndGenotype, SNP-1);
  }


*/
/*____________________________________________________________ */



};  // Fin del Namespace

#endif

/* Fin Fichero: PhaseResolver.h */
