rm(list=ls())
#############################################################
################## Function GetErrorProb ####################
#############################################################
# It checks if a value can be a probability
GetErrorProb<-function (prob) 
{
ifelse ((prob<0 || prob >1), FALSE, TRUE)
}
#############################################################
################## Function GetDMax #########################
#############################################################

GetDMax<-function(VectorGenotype) 
{
D=GetD(VectorGenotype)
fA=GetfA(VectorGenotype)
fB=GetfB(VectorGenotype)
ifelse(D<0,-(min(fA*fB,(1-fA)*(1-fB))),min(fA*(1-fB),(1-fA)*fB))
}


#######################################################
################## Function GetfA #####################
#######################################################
# It computes major allele frequency fA from a sample with the 11 values of
# genotype frequencies at VectorGenotype

# 1: p(AB/AB), 
# 2: p(AB/Ab),
# 3: p(AB/aB), 
# 4: p(AB/ab), 
# 5: p(Ab/Ab), 
# 6: p(Ab/aB), 
# 7: p(Ab/ab), 
# 8: p(aB/aB), 
# 9: p(aB/ab) and
# 10: p(ab/ab).
# 11: pUnknown

GetfA<-function(VectorGenotype) 
{
numerator<-VectorGenotype[3]+ 
		   VectorGenotype[4]+
		   VectorGenotype[6]+
		   VectorGenotype[7]+
		   VectorGenotype[11]+
		   max(2*VectorGenotype[1]+2*VectorGenotype[2]+2*VectorGenotype[5],
               2*VectorGenotype[8]+2*VectorGenotype[9]+2*VectorGenotype[10])
denominator<-2*sum(VectorGenotype)
numerator/denominator
}
#######################################################
################## Function GetfB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 11 values of
# genotype frequencies at VectorGenotype

# 1: p(AB/AB), 
# 2: p(AB/Ab),
# 3: p(AB/aB), 
# 4: p(AB/ab), 
# 5: p(Ab/Ab), 
# 6: p(Ab/aB), 
# 7: p(Ab/ab), 
# 8: p(aB/aB), 
# 9: p(aB/ab) and
# 10: p(ab/ab).
# 11: pUnknown

GetfB<-function(VectorGenotype) 
{
numerator<-VectorGenotype[2]+ 
		   VectorGenotype[4]+
		   VectorGenotype[6]+
		   VectorGenotype[9]+
		   VectorGenotype[11]+
		   max(2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8],
               2*VectorGenotype[5]+2*VectorGenotype[7]+2*VectorGenotype[10])
denominator<-2*sum(VectorGenotype)
numerator/denominator
}
#######################################################
################## Function GetnAB ##################
#######################################################
# It computes nAB, i.e., the absolute frequency of haplotype AB from a population
# with genotype frequencies at VectorGenotypes, 
# This function is used in this program when the EM algorithm is used to compute
# fAB values. 


GetnAB<-function(VectorGenotype) 
{

# 1: p(AB/AB), 
# 2: p(AB/Ab),
# 3: p(AB/aB), 
# 4: p(AB/ab), 
# 5: p(Ab/Ab), 
# 6: p(Ab/aB), 
# 7: p(Ab/ab), 
# 8: p(aB/aB), 
# 9: p(aB/ab) and
# 10: p(ab/ab).
# 11: pUnknown


if ((2*VectorGenotype[1]+2*VectorGenotype[2]+2*VectorGenotype[5])> (2*VectorGenotype[8]+2*VectorGenotype[9]+2*VectorGenotype[10]))
{
 if ((2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8]) > (2*VectorGenotype[5]+2*VectorGenotype[7]+2*VectorGenotype[10]))
  nAB=2*VectorGenotype[1]+VectorGenotype[2]+VectorGenotype[3]+VectorGenotype[4]
 else # Ab
   nAB=VectorGenotype[2]+2*VectorGenotype[5]+VectorGenotype[6]+VectorGenotype[7]
}
else
 if ((2*VectorGenotype[1]+2*VectorGenotype[3]+2*VectorGenotype[8]) > (2*VectorGenotype[5]+2*VectorGenotype[7]+2*VectorGenotype[10]))
  nAB=VectorGenotype[3]+VectorGenotype[6]+2*VectorGenotype[8]+VectorGenotype[9] #aB
 else #ab
   nAB=VectorGenotype[4]+2*VectorGenotype[7]+VectorGenotype[9]+2*VectorGenotype[10]
nAB
}
#######################################################
################## Function GetfAB ####################
#######################################################
# It computes sample relative frequency of haplotype AB, given genotypes for the
# sample in VectorGenotypes and using EM.


GetfAB<-function(VectorGenotype) 
{
nAB=GetnAB(VectorGenotype)
fA=GetfA(VectorGenotype)
fB=GetfB(VectorGenotype)
nHH=VectorGenotype[11]
total=(sum(VectorGenotype)-nHH)*2
if (total==0)
stop("no known haps")
if (nHH>0)
fAB<-EstimateMLE(nAB, nHH, fA*fB, total, fA, fB)
else fAB=nAB/total
fAB
}
#######################################################
################## Function GetD ######################
#######################################################
# It estimates D from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# D is computed as Estf(AB)-Estf(A)*Estf(B)

 GetD<-function(VectorGenotype)
 GetfAB(VectorGenotype)-GetfA(VectorGenotype)*GetfB(VectorGenotype)

#######################################################
################## Function EstimateMLE ###############
#######################################################
# It computes relative frequency of haplotypes AB using EM algorithm.
# Input values are the number of AB haplotypes, in nABknown, the number
# of individuals heterozygotic at both loci, in nHH, non-phased relative frequency
# of haplotype AB in the sample, major allele frequency for locus a in the sample, fA
# and major allele frequency for locus a in the sample, fB.


EstimateMLE <-function(nABKnown, nHH, fAB, total, fA, fB)
{
first<-TRUE
fABNew<-fAB
loop<-1
while ((first==TRUE) || ((abs(fAB-fABNew)>0.00005) && (loop<=1000)))
{
first<-FALSE
fAB<-fABNew
fAb<-fA-fAB
faB<-fB-fAB
fab<-1-fAB-fAb-faB

denominator<-fAB*fab+fAb*faB

if (denominator==0) 
{
write (fAB, "")
write (fAb, "")
write (faB, "")
write (fab, "")
write (fA, "")
write (fB, "")  
write (total, "")
write (nABKnown, "")
write (nHH, "")
 stop ("denominator is zero")
 }
 
PhaseFrequencies<-(fAB*fab)/denominator
 

fABNew<-(nABKnown+nHH*PhaseFrequencies)/(total+2*nHH) #// AB

loop<-loop+1
}
fABNew
}
#######################################################
################## Function GetDPrime ######################
#######################################################
# It estimates D from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# D is computed as Estf(AB)-Estf(A)*Estf(B)

GetDPrime<-function(VectorGenotype)
{
D=GetD(VectorGenotype)
DMax=GetDMax(VectorGenotype)
if (DMax!=0)
{
if ((abs(D)-abs(DMax))>0.00001)
{
write (PrintGenotypes(VectorGenotypes),"")
write ("D:","")
write (D,"")
write ("DMax:", "")
write (DMax,"")
stop("error in GetDPrime")
}
else D/DMax
}
else 1
}
#######################################################
################## Function Getr2 ######################
#######################################################
# It estimates r2 from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# r2 is computed as Estf(AB)-Estf(A)*Estf(B)

Getr2<-function(VectorGenotype)
{
D2=GetD(VectorGenotype)^2
fA=GetfA(VectorGenotype)
fB=GetfB(VectorGenotype)
Den=fA*(1-fA)*fB*(1-fB)
if (Den!=0)
{
if ((D2-Den)>0.00001)
{
write (PrintGenotypes(VectorGenotypes),"")
write ("D^2:","")
write (D2,"")
write ("Den:", "")
write (Den,"")
stop("error in Getr2")
}
else D2/Den
}
else 0
}

#######################################################
################## Function GetBootDPrime ######################
#######################################################

 GetBootDPrime<-function(data, bootsample)
 {
  VectorGenotype<-c(1:11)*0
  for (i in 1:length(bootsample))
   if (data[bootsample[i]]>0)
   VectorGenotype[data[bootsample[i]]]=VectorGenotype[data[bootsample[i]]]+1
 
  GetDPrime(VectorGenotype)
}
#######################################################
################## Function GetBootr2 #################
#######################################################

 GetBootr2<-function(data, bootsample)
 {
  VectorGenotype<-c(1:11)*0
  for (i in 1:length(bootsample))
   if (data[bootsample[i]]>0)
   VectorGenotype[data[bootsample[i]]]=VectorGenotype[data[bootsample[i]]]+1
 
  Getr2(VectorGenotype)
}

#######################################################
################## Function PrintGenotypes ############
#######################################################
# It prints genotype absolute frequencies in a sample.
# It was used only for testing.
PrintGenotypes<-function(VectorGenotypes)
{
for (i in 1:11)
 write (VectorGenotypes[i],"")
}
######################################################
################## Function GetGenotypes ############
#######################################################
# It prints genotype absolute frequencies in a sample.
# It was used only for testing.
GetGenotypes<-function(data)
{
 VectorGenotype<-c(1:11)*0
 for (i in 1:length(data))
  if (data[i]>0)
   VectorGenotype[data[i]]=VectorGenotype[data[i]]+1
 VectorGenotype
}
###############################################################################################
######################################### Main program ########################################
###############################################################################################

# 1: n(AB/AB), 
# 2: n(AB/Ab),
# 3: n(AB/aB), 
# 4: n(AB/ab), 
# 5: n(Ab/Ab), 
# 6: n(Ab/aB), 
# 7: n(Ab/ab), 
# 8: n(aB/aB), 
# 9: n(aB/ab) and
# 10: n(ab/ab).
# 11: nUnknown
r2=1
DP=2
type=r2
type=DP
size=1000
filename="/home/mabad/R/SNP10DPrime.CI"
data=read.table("/home/mabad/genoma/chrom22SNP10.red", header=TRUE)
TotalSNPs=length(data[1,])
inds=length(data[,1])
library("boot")

if (type==DP)
cat (", DPrime, Lower, Upper\n", file=filename, append=FALSE) else
cat (", r2, Lower, Upper\n", file=filename, append=FALSE) 


for (i in 1:TotalSNPs)
{
write ("SNP ","")
write (i,"")
#write(data[[i]],"")
i2<-as.character(i)
name=paste("SNP",i2)
VectorGenotypes=GetGenotypes(data[[i]])
if (type==DP)
{
write (GetDPrime(VectorGenotypes),"")
b=boot(data[[i]], GetBootDPrime, size)
}
else 
{
write (Getr2(VectorGenotypes),"")
b=boot(data[[i]], GetBootr2, size)
}

#print.boot(b)
results=boot.ci(b, type="basic")
write (results$basic,"")
if (type==DP)
cat (paste(i2,", ", GetDPrime(VectorGenotypes),", ", results$basic[4], ", ", results$basic[5], "\n") , file=filename,append=TRUE)
else
cat (paste(i2,", ", Getr2(VectorGenotypes),", ", results$basic[4], ", ", results$basic[5], "\n") , file=filename,append=TRUE)
}


