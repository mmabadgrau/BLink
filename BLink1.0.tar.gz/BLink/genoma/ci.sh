#./GetConfidenceIntervalsUnrelated data/crossover.gou 0 0 2 0 90
#mv data/crossover.ci data/crossoverMLE.ci
#./GetConfidenceIntervalsUnrelated  data/crossover.gou 0 4 2 0 90
#mv data/crossover.ci data/crossoverBDistanceAlpha4.ci
#./GetConfidenceIntervalsUnrelated data/crossover10.gou 0 0 2 0 90
#mv data/crossover10.ci data/crossover10MLE.ci
#./GetConfidenceIntervalsUnrelated data/crossover10.gou 0 4 2 0 90
#mv data/crossover10.ci data/crossover10BDistanceAlpha4.ci
./GetConfidenceIntervalsUnrelated data/crossover5.gou 0 0 2 0 90
mv data/crossover5.ci data/crossover5MLE.ci
./GetConfidenceIntervalsUnrelated data/crossover5.gou 0 4 2 0 90
mv data/crossover5.ci data/crossover5BDistanceAlpha4.ci
./GetConfidenceIntervalsUnrelated data/crossover5-60.gou 0 0 2 0 90
mv data/crossover5-60.ci data/crossover5-60MLE.ci
./GetConfidenceIntervalsUnrelated data/crossover5-60.gou 0 4 2 0 90
mv data/crossover5-60.ci data/crossover5-60BDistanceAlpha4.ci
./GetConfidenceIntervalsUnrelated data/crossover5-120.gou 0 0 2 0 90
mv data/crossover5-120.ci data/crossover5-120MLE.ci
./GetConfidenceIntervalsUnrelated data/crossover5-120.gou 0 4 2 0 90
mv data/crossover5-120.ci data/crossover5-120BDistanceAlpha4.ci
./GetConfidenceIntervalsUnrelated data/crossover10-60.gou 0 0 2 0 90
mv data/crossover10-60.ci data/crossover10-60MLE.ci
./GetConfidenceIntervalsUnrelated data/crossover10-60.gou 0 4 2 0 90
mv data/crossover10-60.ci data/crossover10-60BDistanceAlpha4.ci
./GetConfidenceIntervalsUnrelated data/crossover10-120.gou 0 0 2 0 90 
mv data/crossover10-120.ci data/crossover10-120MLE.ci
./GetConfidenceIntervalsUnrelated data/crossover10-120.gou 0 4 2 0 90
mv data/crossover10-120.ci data/crossover10-120BDistanceAlpha4.ci

