/* File: ChangeFormat.h */


#ifndef __ChangeFormat_h__
#define __ChangeFormat_h__


#include <string>


#include "Exceptions.h"



#include "genoma.h"



namespace SNP {

/*____________________________________________________________ */

void genoma::ExportForPHASE (char *filename, long int InitialPos, unsigned int Length)
{
ofstream OutputFile; 
unsigned int i, i2;

cout <<"Exporting to PHASE\n";

unsigned int last;
if (InitialPos==-1) 
{
last=genotype::TotalSNPs-1;
Length=genotype::TotalSNPs;
} 
else
last=InitialPos+Length-1;


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


OutputFile << GetTotalOffSpring() << "\n";

OutputFile << Length << "\n";

OutputFile << "P" << ' ';


//if (Pos->IsUnordered())
// throw UnorderedPos();

position* InitialPosition=TheFirstPosition;

for (i=0; i<genotype::TotalSNPs;i++)
  if ((InitialPos==-1) || ((InitialPos<=i)  && (last>=i)))

{
  OutputFile << InitialPosition->pos;
	  if (i==last)
	OutputFile << "\n";
   else OutputFile << ' ';
  InitialPosition=InitialPosition->Next;
}
for (i=0; i<genotype::TotalSNPs;i++)
 if ((InitialPos==-1) || ((InitialPos<=i)  && (last>=i)))

 OutputFile << "S";

OutputFile << "\n";

Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

//int counter=0;

unsigned short int *random;

if ((random=new unsigned short int[genotype::TotalSNPs])==NULL)
     throw NoMemory();

for (i=0; i<Size;i++)
{
	if (IsAChild (IndPhenotype))
	{
//		counter++;
 OutputFile << "#" << i << "\n";
 for (i2=0; i2<genotype::TotalSNPs;i2++)
  if ((InitialPos==-1) || ((InitialPos<=i2)  && (last>=i2)))
 {
 random[i2]=rand() % (2);
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "?";
  else 
   if (IsHomozygous(IndGenotype,i2))
    OutputFile << *(IndGenotype->Left+i2);
   else if (random[i2]==0)
    OutputFile << MajorAllele[i2];
   else
    OutputFile << MinorAllele[i2];
 if (i2==last)
	  OutputFile << "\n";
  else OutputFile << " ";
 }
 for (i2=0; i2<genotype::TotalSNPs;i2++)
  if ((InitialPos==-1) || ((InitialPos<=i2)  && (last>=i2)))
 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "?";
 else 
   if (IsHomozygous(IndGenotype,i2))
    OutputFile << *(IndGenotype->Right+i2);
   else if (random[i2]==0)
    OutputFile << MinorAllele[i2];
   else
    OutputFile << MajorAllele[i2];
 if (i2==last)
	  OutputFile << "\n";
  else OutputFile << " ";
 }
 }
  IndGenotype=IndGenotype->Next;
  IndPhenotype=IndPhenotype->Next;

}

OutputFile.close();
delete random;

}


/*____________________________________________________________ */

void genoma::ExportForHTYPER (char *filename, long int InitialPos, unsigned int Length)
{
ofstream OutputFile; 

cout <<"Exporting to HTYPER\n";


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;


for (int i=0; i<Size;i++)
{
	if (IsAChild(IndPhenotype))
	{

	for (int i2=0; i2<genotype::TotalSNPs;i2++)
		if ((InitialPos==-1) || ((InitialPos<=(i2+1))  && ((InitialPos+Length)>(i2+1))))
 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "3";
 if (IsHeterozygous (IndGenotype, i2))
  OutputFile << "0";
 if (IsHomozygous1 (IndGenotype, i2))
  OutputFile << "1";
 if (IsHomozygous2 (IndGenotype, i2))
  OutputFile << "2";
 }
   OutputFile << "\n";
	}
	IndGenotype=genotype::GetNext(IndGenotype);
	IndPhenotype=phenotype::GetNext(IndPhenotype);
}

OutputFile.close();
}
/*____________________________________________________________ */

void genoma::ExportForSNPHAP (char *filename, long int InitialPos, unsigned int Length)
{

cout <<"Exporting to SNPHAP\n";
cout <<"From position " << InitialPos << " until position " << InitialPos+Length-1 <<"\n";
ofstream OutputFile;
unsigned int i2; 


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

unsigned int last;
if (InitialPos==-1) last=genotype::TotalSNPs-1;
else
last=InitialPos+Length-1;

for (int i=0; i<Size;i++)
{
if (IsAChild(IndPhenotype))
	{
 OutputFile << i+1 << " ";
 for (i2=0; i2<genotype::TotalSNPs;i2++)
	 		if ((InitialPos==-1) || ((InitialPos<=(i2+1))  && ((InitialPos+Length)>(i2+1))))

 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "? ?";
 else 
 {
OutputFile << UnconvertAllele(*(IndGenotype->Left+i2)) <<" ";
OutputFile << UnconvertAllele(*(IndGenotype->Right+i2));
}
 if (i2==last)
	  OutputFile << "\n";
  else OutputFile << " ";
 }
	}

  IndGenotype=IndGenotype->Next;
  IndPhenotype=IndPhenotype->Next;

}

OutputFile.close();
}
/*____________________________________________________________ */

void genoma::ExportForBN (char *filename, long int InitialPos, unsigned int Length)
{

cout <<"Exporting to BN\n";

ofstream OutputFile;
unsigned int i2; 


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;


for (int i=0; i<Size;i++)
{
	// left haplotype
 for (i2=0; i2<genotype::TotalSNPs;i2++)
		if ((InitialPos==-1) || ((InitialPos<=(i2+1))  && ((InitialPos+Length)>(i2+1))))

 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "0, ";
 else 
 {
	 if (*(IndGenotype->Left+i2)==MajorAllele[i2])
		OutputFile <<"1, ";
	 else
		OutputFile <<"2, ";
}
 }

 OutputFile << IndPhenotype->Affectation << "\n";


 // right haplotype
 for (i2=0; i2<genotype::TotalSNPs;i2++)
 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "0, ";
 else 
 {
 if (*(IndGenotype->Right+i2)==MajorAllele[i2])
		OutputFile <<"1, ";
	 else
		OutputFile <<"2, ";
}
 }
 OutputFile << IndPhenotype->Affectation << "\n";

  IndGenotype=IndGenotype->Next;
  IndPhenotype=IndPhenotype->Next;

}

OutputFile.close();
}
/*____________________________________________________________ */

void genoma::ExportForHAPLOVIEW (char *filename, long int InitialPos, unsigned int Length)
{
unsigned int FatherCode2, MotherCode2;
cout <<"\nExporting to HAPLOVIEW\n";
ofstream OutputFile;
unsigned int i2; 


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

unsigned int last;
if (InitialPos==-1) last=genotype::TotalSNPs-1;
else
last=InitialPos+Length-1;


if (InitialPos==-1) 
{
last=genotype::TotalSNPs-1;
Length=genotype::TotalSNPs;
} 
else
{
last=InitialPos+Length-1;
cout <<"From position " << InitialPos << " until position " << InitialPos+Length-1 <<"\n";
}

for (int i=0; i<Size;i++)
{
 if (((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) && (!IsAChild (IndPhenotype))) || (ic==2))
{
if ((ic==2) && (IsAChild(IndPhenotype)))
{
FatherCode2=(GetPhenotype(GetFather(IndPhenotype)))->Code2;
MotherCode2=(GetPhenotype(GetMother(IndPhenotype)))->Code2;
}
else // for only children or only parents, all the individuals must be considered as founders
{
FatherCode2=0;
MotherCode2=0;
}
	OutputFile << IndPhenotype->Pedigree << ' ';
	OutputFile << IndPhenotype->Code2 << ' ';
	OutputFile << FatherCode2 << ' ';
	OutputFile << MotherCode2 << ' ';
	OutputFile << IndPhenotype->Gender << ' ';
	OutputFile << IndPhenotype->Affectation << ' ';
 for (i2=0; i2<genotype::TotalSNPs;i2++)
	 		if ((InitialPos==-1) || ((InitialPos<=(i2+1))  && ((InitialPos+Length)>(i2+1))))

 {
 if (!IsANonMissingSNP(IndGenotype,i2))
  OutputFile << "0 0";
 else 
 {
  OutputFile << *(IndGenotype->Left+i2) << " ";
  OutputFile << *(IndGenotype->Right+i2);
 }
 if (i2==last)
	  OutputFile << "\n";
  else OutputFile << " ";
 }
}
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
}

//if (Bayes)
{
	//father
	OutputFile << "0 1 0 0 0 1" << ' '; 
	 for (i2=0; i2<genotype::TotalSNPs;i2++)
	 {
      OutputFile << MajorAllele[i2] << " " << MajorAllele[i2];
      if (i2==(genotype::TotalSNPs-1))
	  OutputFile << "\n";
      else OutputFile << " ";
	 }
	//mother
	OutputFile << "0 1 0 0 0 1" << ' '; 
	 for (i2=0; i2<genotype::TotalSNPs;i2++)
	 {
      OutputFile << MajorAllele[i2] << " " << MajorAllele[i2];
      if (i2==(genotype::TotalSNPs-1))
	  OutputFile << "\n";
      else OutputFile << " ";
	 }


	OutputFile << "1" << ' ';
	OutputFile << "0" << ' ';
	OutputFile << "0" << ' ';
	OutputFile << IndPhenotype->Gender << ' ';
	OutputFile << IndPhenotype->Affectation << ' ';
}

OutputFile.close();
}
/*____________________________________________________________ */

void genoma::ImportFromPHASE (char *filename)
{
ifstream InputFile; 
unsigned int i2;

cout <<"Importing from PHASE file " << filename << "\n";



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2, *cad3;
    if ((genotypebuf=new char[100*genotype::TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad2=new char[100*genotype::TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad3=new char[100*genotype::TotalSNPs])==NULL)
     throw NoMemory();


//     unsigned long int pos;
	 bool found=false;
//	InputFile.getline (genotypebuf, 2000, '\n');
//	cout <<genotypebuf << "\n";
	 cout <<"totalSNPS:" << genotype::TotalSNPs <<"\n";
	do
	{
		InputFile.getline (genotypebuf, 100*genotype::TotalSNPs);
//		cout << "V:" <<genotypebuf << "\n";

	cad=strtok (genotypebuf," \t");
//	cin >>a;
	//cout <<"l2n:" << strlen(cad);
	//<<",len2:" << strlen (genotypebuf);
	if (cad!=NULL)
	if (*cad=='B')
	{
	sscanf (cad, "%s", cad2);
    //cout << cad;
	cad=strtok (NULL," \t");
	sscanf (cad, "%s", cad3);
if ((strcmp(cad2, "BEGIN\0")==0) && (strcmp (cad3, "BESTPAIRS1\0")==0))
		found = true;
	}		
//	found=false;
//if (InputFile.peek()==EOF) cout <<"FIN";
//if (found) cout <<"F";
	}
	while ((InputFile.peek()!=EOF) && (!found));



if (!found)
{
	cout << "Incompatible format for PHASE output";
	exit(0);
}

unsigned int alle;

unsigned short int *typ;
Genotype *IndGenotype=TheFirstGenotype;

if ((typ=new unsigned short int[genotype::TotalSNPs])==NULL)
 throw NoMemory();


for (int i=0; i<SizeP; i++)
{
	if (IsAChild(i))
	{
		if (InputFile.peek()==EOF) 
	     throw EOFile();
//	if (IndGenotype==NULL) {cout << i; exit(0);}
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');

	for (unsigned short int side=0;side<2;side++)
	{
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	//cout << "\n" << genotypebuf;
	for (i2=0; i2<genotype::TotalSNPs; i2++)
	{
	if (i2==0)
     cad = strtok (genotypebuf," \t");
    else cad = strtok (NULL," \t");
	if (cad==NULL) cout <<"\nError in SNP " << i2;
	if ((*cad=='(') || (*cad==')') || (*cad=='[') || (*cad==']'))
		cad=cad+1;

	alle=atoi(cad);

   if (side==0)
   {
	typ[i2]=0;
	if (IsANonMissingSNP(IndGenotype, i2))
     if (IsHeterozygous(IndGenotype, i2)) 
	  typ[i2]=1;
	  else 
	   if (IsHomozygous1(IndGenotype, i2)) 
	    typ[i2]=2;
	   else 
		if (IsHomozygous2(IndGenotype, i2)) 
		 typ[i2]=3;
   }


if ((typ[i2]==2) || (typ[i2]==3))
if  (*((IndGenotype->Left)+i2) != (allele) alle)
{
	cout <<"inc at ind " << i << " SNP" << i2;
	alle=(unsigned int)*((IndGenotype->Left)+i2);
}
 //throw Inconsistent(); 

if ((typ[i2]==1) && (side==1))
if  (*((IndGenotype->Left)+i2) == (allele) alle)
{
	cout <<"inc2 at ind " << i << " SNP" << i2; 
	alle=(unsigned int)*((IndGenotype->Right)+i2);
}

//throw Inconsistent(); 


 
// if (IsANonMissingSNP(IndGenotype, i2))
	if (side==0)
    *((IndGenotype->Left)+i2) = (allele) alle; 
	else
    *((IndGenotype->Right)+i2) = (allele) alle; 
	}// end for each SNP
	}// end for each size
	}// end if a child
	if (i<(Size-1))
	IndGenotype=genotype::GetNext(IndGenotype);
}
InputFile.close();

//delete genotypebuf; //, cad2;
// cad3;


}



/*____________________________________________________________ */

void genoma::ImportFromSNPHAP (char *filename)
{
ifstream InputFile; 
unsigned int i2;

cout <<"Importing from SNPHAP\n";




InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2;
    if ((genotypebuf=new char[8*genotype::TotalSNPs])==NULL)
     throw NoMemory();
	//if ((cad=new char[10])==NULL)
    // throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


//     unsigned long int pos;
	 bool found=false;

	 InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	 InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');


char alle;

Genotype *IndGenotype=TheFirstGenotype;
Phenotype *IndPhenotype=TheFirstPhenotype;


genotype::Size=Size;

	for (int i=0;i<Size;i++)
	 if (InputFile.peek()!=EOF)
	{
	if (IsAChild(IndPhenotype))
	{
	 InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
    
	 cad = strtok (genotypebuf," \t");
	while ((atoi(cad)<=(i+1)) && (InputFile.peek()!=EOF))
	{
	 InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	 cad = strtok (genotypebuf," \t");
	}
    if (InputFile.peek()!=EOF)
	if (atoi(cad)==(i+1))
    {
	cad = strtok (NULL," \t"); // read haplotype number (1)
	cad = strtok (NULL," \n\t"); // read haplotype left strand
	
    for (i2=0; i2<genotype::TotalSNPs; i2++)
    {

	sscanf (cad, "%c", &alle);
    *(IndGenotype->Left)= (allele) ConvertAllele(alle); 
	}


	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	cad = strtok (genotypebuf," \t");
	cad = strtok (NULL," \t"); // read haplotype number (2)
	cad = strtok (NULL," \n\t"); // read haplotype right strand
    
	for (i2=0; i2<genotype::TotalSNPs; i2++)
    {
	sscanf (cad, "%c", &alle);
    *(IndGenotype->Right)= (allele) ConvertAllele(alle); 
	}
	}
	} // end if a child
	IndPhenotype=phenotype::GetNext(IndPhenotype);
	IndGenotype=genotype::GetNext(IndGenotype);
	} // end for each individual

InputFile.close();

delete genotypebuf, cad2, cad;
}


/*____________________________________________________________ */

void genoma::ImportFromHTYPER (char *filename)
{

cout <<"Importing from HTYPER at file " << filename << "\n";

	unsigned int i2;
ifstream InputFile; 



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();


	char *genotypebuf, *cad, *cad2;
    if ((genotypebuf=new char[8*genotype::TotalSNPs])==NULL)
     throw NoMemory();
	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


 //    unsigned long int pos;
	 bool found=false;

	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
   	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');


/*
individual *Sample;

char *filename2;

if ((filename2=new char[64])==NULL)
 throw NoMemory();

filename2=strtok(filename, ".");

strncat(filename2, ".txt\0", 4);//


if ((Sample = new individual(filename2, genotype::TotalSNPs, Size, true, (IndCategory)1))==NULL)
 throw NoMemory();


 if ((TheFirstGenotype=new Genotype)==NULL)
   throw NoMemory();
 if ((TheFirstGenotype->Left=new allele[genotype::TotalSNPs])==NULL)
   throw NoMemory();
 if ((TheFirstGenotype->Right=new allele[genotype::TotalSNPs])==NULL)
   throw NoMemory();
 TheFirstGenotype->Previous=NULL;
	


genotype::Size=Size;

*/
	Genotype *IndGenotype=TheFirstGenotype;
	Phenotype *IndPhenotype=TheFirstPhenotype;
	bool *hetero;
	if ((hetero=new bool[genotype::TotalSNPs])==NULL)
     throw NoMemory();

	for (int i=0; i<Size; i++)
	{

	if (IsAChild(i))
	{
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	for (i2=0; i2<genotype::TotalSNPs; i2++)
	 if (IsHeterozygous(IndGenotype, i2))	// to prevent changes from homos to heteros
	 {
		 hetero[i2]=true;
	//	 cout << "pos " << i2 << " hetero for ind code  :" << i <<"\n";
	 }
	 else hetero[i2]=false;

	for (i2=0; i2<genotype::TotalSNPs; i2++)
	{
	 if (hetero[i2])
	 if (*(genotypebuf+i2)=='0')
	 *((IndGenotype->Left)+i2)= GetMajorAllele(i2); 
	 else
	 *((IndGenotype->Left)+i2)= GetMinorAllele(i2);
	 }
	
	
	InputFile.getline (genotypebuf, 8*genotype::TotalSNPs, '\n');
	
    for (i2=0; i2<genotype::TotalSNPs; i2++)
	{
   if (hetero[i2])	
    if (*(genotypebuf+i2)=='0') // to prevent changes from homos to heteros
	 *((IndGenotype->Right)+i2)= GetMajorAllele(i2); 
	else
	 *((IndGenotype->Right)+i2)= GetMinorAllele(i2);
	}
	
//	if (i<(Size-1))
	{
/*
		if ((IndGenotype->Next=new Genotype)==NULL)
      throw NoMemory();
	if ((IndGenotype->Next->Left=new allele[genotype::TotalSNPs])==NULL)
      throw NoMemory();
    if ((IndGenotype->Next->Right=new allele[genotype::TotalSNPs])==NULL)
      throw NoMemory();
	  */
	}
	}
		IndGenotype=genotype::GetNext(IndGenotype);
		IndPhenotype=phenotype::GetNext(IndPhenotype);


}
InputFile.close();

delete genotypebuf, cad2, cad, hetero;

}

/*____________________________________________________________ */

void genoma::ImportFromMSAMPLE (char *filename, char *filename2, const long int InitialPos, const unsigned int Length)
{

cout <<"Importing from MSAMPLE at file " << filename << "\n";

unsigned int i2, NonRepeated=0;

//unsigned long int RegionSize=0;
ifstream InputFile; 

InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *genotypebuf2, *cad, *cad2, *oldcad;
	bool *ChosenPosition;

// this buffer will contain the positions and afterwards, genotypes
	// positions can require about 10 chars
    if ((genotypebuf=new char[10*genotype::TotalSNPs])==NULL)
     throw NoMemory();

// only a char per haplotype plus endl
	if ((genotypebuf2=new char[2+genotype::TotalSNPs])==NULL)
     throw NoMemory();


	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();
	if ((oldcad=new char[10])==NULL)
     throw NoMemory();


 //    unsigned long int pos;
	 bool found=false;
	 unsigned long int TotalSNPs;


     InputFile.getline (genotypebuf, 200, '\n');

//    cad = strtok (genotypebuf,"r");

//	 cad = strtok (NULL," \t");
//	 cad = strtok (NULL," \t");
// 	 RegionSize=atoi(cad);




	 while  (InputFile.peek()!='s')
     InputFile.getline (genotypebuf, 200, '\n');
     
	 InputFile.getline (genotypebuf, 200, '\n');

	cad = strtok (genotypebuf," \t");
	if (strcmp(cad, "segsites:")!=0)
	{
		cout <<"Error in file format. Line beginning with \"segsites:\" was expected";
		exit(0);
	}
	cad = strtok (NULL," \t");
	TotalSNPs=atoi(cad);
	if (TotalSNPs!=genotype::TotalSNPs)
	{
		cout <<"Error in the number of SNPs especified as argument";
		exit(0);
	}

   	InputFile.getline (genotypebuf, 10*TotalSNPs, '\n'); // positions

 if ((ChosenPosition=new bool[TotalSNPs])==NULL)
     throw NoMemory();

 for(unsigned int i=0;i<TotalSNPs;i++)
  ChosenPosition[i]=false;


char *filename3;

ofstream OutputFile;

if ((filename3=new char[64])==NULL)
 throw NoMemory();

strcpy (filename3, filename);
strtok(filename3, ".");

strncat(filename3, ".pos\0", 4);//


OutputFile.open (filename3, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

  cad = strtok (genotypebuf," \t");
  if (strncmp(cad, "prob:", 5)==0) // the line was prob:
  {
  InputFile.getline (genotypebuf, 10*TotalSNPs, '\n'); // positions
  cad = strtok (genotypebuf," \t");
  }

unsigned int WrittenPositions=0;

for (i2=0; i2<TotalSNPs; i2++)
{   
	cad = strtok (NULL," \t");
if ((i2>=InitialPos) && (WrittenPositions<Length))
 if (strcmp(cad, "n")==0)
  OutputFile << i2 << "\n";//????
 else
 {

	if ((i2==0) || (strcmp(cad, oldcad)!=0))
	{
	OutputFile << atof(cad) << "\n";
	strcpy(oldcad, cad);
	NonRepeated++;
	WrittenPositions++;
	ChosenPosition[i2]=true;
	}	 
}
}

OutputFile.close();

cout << "Position file " << filename3 << " has been generated\n";





OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

	 unsigned int cont;
	 unsigned int size=0;
	while  (InputFile.peek()!=EOF)

	{
    InputFile.getline (genotypebuf, 15+TotalSNPs, '\n');
	InputFile.getline (genotypebuf2, 15+TotalSNPs, '\n');

     size++;
     OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 int cont=0;
	 for (i2=0; i2<TotalSNPs; i2++)
   	   if (ChosenPosition[i2]==true)
	 {
	 if (*(genotypebuf+i2)=='0')
	 OutputFile << "1 "; 
	 else
	 OutputFile << "2 "; 
	 if (*(genotypebuf2+i2)=='0')
	 OutputFile << "1"; 
	 else
	 OutputFile << "2"; 
	 if (cont<(Length-1))
      OutputFile << " "; 
	 else
	  OutputFile << "\n"; 
	 cont++;
	 }
	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename << " has been saved in dHAP format at " << filename2 <<"\n";
//if (TotalSNPs>NonRepeated)
cout << "Final number of non-repeated SNPs " << WrittenPositions << "\n";


delete genotypebuf, cad2, cad, genotypebuf2, filename, filename3, ChosenPosition;

}
/*____________________________________________________________ */

void genoma::ImportFromHUDSON (char *filename)
{
// a first line must be introduced with the total nmber of SNPs
// lst two lines must be removed
cout <<"Importing from HUDSON at file " << filename << "\n";


unsigned int i2;
ifstream InputFile; 




InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *genotypebuf2, *cad, *cad2;
    if ((genotypebuf=new char[100000])==NULL)
     throw NoMemory();
	if ((genotypebuf2=new char[100000])==NULL)
     throw NoMemory();
	if ((cad=new char[10])==NULL)
     throw NoMemory();
	if ((cad2=new char[10])==NULL)
     throw NoMemory();


 //    unsigned long int pos;
	 bool found=false;
	 unsigned long int TotalSNPs;

   	InputFile.getline (genotypebuf, 200, '\n');
	cad = strtok (genotypebuf," \t");
//	cad = strtok (NULL," \t");
	TotalSNPs=atoi(cad);



char *filename2;

ofstream OutputFile;

if ((filename2=new char[64])==NULL)
 throw NoMemory();

filename2=strtok(filename, ".");

strncat(filename2, ".pos\0", 4);//


OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

  cad = strtok (genotypebuf," \t");
  for (i2=0; i2<TotalSNPs; i2++)
   OutputFile << i2 << "\n";


OutputFile.close();

cout << "Position file " << filename2 << " has been generated\n";




filename2=strtok(filename, ".");

strncat(filename2, ".txt\0", 4);//


OutputFile.open (filename2, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


	 unsigned int size=0;

	 
	while  (InputFile.peek()!=EOF)
	{
    InputFile.getline (genotypebuf, 200, '\n'); // number
	InputFile.getline (genotypebuf, 8*TotalSNPs, '\n');
    InputFile.getline (genotypebuf2, 200, '\n'); // number
	InputFile.getline (genotypebuf2, 8*TotalSNPs, '\n');

	size++;

    OutputFile << size << " " << size << " 1 2 0 0 " << size << " ";	
	
	 for (i2=0; i2<TotalSNPs; i2++)
	 {
	 OutputFile << ConvertAllele(*(genotypebuf+i2)) << " "; 
 	 OutputFile << ConvertAllele(*(genotypebuf2+i2)); 
	 if (i2<(TotalSNPs-1))
      OutputFile << " "; 
	 else
	  OutputFile << "\n"; 
	 }
	}; // end while
InputFile.close();
OutputFile.close();

cout << "File " << filename2 << " has been saved in dHAP format\n";


delete genotypebuf, cad2, cad, genotypebuf2, filename, filename2;

}
/*____________________________________________________________ */


void genoma::ChangeFormat (char* filename, char* filename2, unsigned short int Alg, bool Export, const long int InitialPos, const unsigned int Length)
{

	
try {	
if (Export)
{
switch (Alg)
{
case 1:  //  PHASE
ExportForPHASE(filename, InitialPos, Length);
break;
case 2: // SNPHAP
ExportForSNPHAP (filename, InitialPos, Length);
break;
case 3: // HTYPER
ExportForHTYPER (filename, InitialPos, Length);
break;
case 4: // BN
ExportForBN (filename, InitialPos, Length);
break;
case 7: // HAPLOVIEW (OR OTHER PROGRAMS REQUIRING STANDARD LINKAGE PEDIGREE FORMAT)
ExportForHAPLOVIEW (filename, InitialPos, Length);
break;

}
cout << "Exporting has finished.\n";
}
else // Import
{
switch (Alg)
{
case 1:  //  PHASE
ImportFromPHASE(filename);
break;
case 2: // SNPHAP
ImportFromSNPHAP (filename);
break;
case 3: // HTYPER
ImportFromHTYPER (filename);
break;
case 5: // MSAMPLE
ImportFromMSAMPLE (filename, filename2, InitialPos, Length);
break;
case 6: // HUDSON
ImportFromHUDSON (filename);
break;
}
cout << "Importing has finished.\n";
}
}
catch (UnorderedPos up) {
		 up.PrintMessage();}
catch (EOFile eo) {
		 eo.PrintMessage();}
catch (MultiAllelic ma) {
		 ma.PrintMessage();}
catch (Inconsistent inc) {
		 inc.PrintMessage();}
}


};  // Fin del Namespace

#endif
/* Fin Fichero: ChangeFormat.h */
