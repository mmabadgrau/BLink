  /**
    * @file ChangeFormat.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

//#include "genoma.h"
#include "ChangeFormat.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {


bool GetWay (char* Way)
{
	bool Export;
 if (strcmp(Way, "e\0")==0)
	  Export=true; // export
	 else
	 if (strcmp(Way,  "i\0")==0)
	  Export=false; // inport
	 else throw IncorrectWay();
return Export;
}

/*___________________________________________________________*/

unsigned short int GetCodeAlgorithm (char* Algorithm)
{
	unsigned short int Alg=0;
 if (strcmp(Algorithm, "PHASE\0")==0)
	  Alg=1; // Phase
	 else
	 if (strcmp(Algorithm, "SNPHAP\0")==0)
	  Alg=2; // SNPHAP
	 else
	 if (strcmp(Algorithm, "HTYPER\0")==0)
	  Alg=3; // HTYPER
	 else
	 if (strcmp(Algorithm, "BN\0")==0)
	  Alg=4; // BN
	 else throw IncorrectAlgorithm();
return Alg;
}
}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc<7)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " (e/i) " << " PHASE/SNPHAP/HTYPER " << " <source file> " << " <target file>" << " <ExistPhenotype (1/0)>" << " <# loci>" << " <SampleSize>" << " <length>"<< endl;
        exit(-1);
        }
     char* filename, *filename2, *filename3, filephenotypes[20]="pedigree.txt", *Way, *Algorithm;

	 	 try{ 

	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename2=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename3=new char[64])==NULL)
		 throw NoMemory();
	 if ((Way=new char[2])==NULL)
		 throw NoMemory();
	 if ((Algorithm=new char[20])==NULL)
		 throw NoMemory();
     strcpy(Way, argv[1]);
	 
     strcpy (Algorithm,argv[2]);
     unsigned int Alg; 
	
	 bool Exist;
	 strcpy(filename, argv[3]);
	 strcpy(filename2, argv[4]);
     unsigned short int ExistGenotype= atoi(argv[5]); 

	 if (ExistGenotype==0)
		 Exist=false;
	 else
	 if (ExistGenotype==1)
		 Exist=true;
	 else throw NonBoolean();

	 unsigned int TotalSNPs=atoi(argv[6]);
     unsigned int Size=atoi(argv[7]);
	 unsigned int Length=0;
		 if (argc==9)
		 Length=atoi(argv[8]);
     
	 genoma * Sample;
	 
	 Alg=GetCodeAlgorithm (&Algorithm[0]);

	 
	 bool Export=GetWay (&Way[0]);

	 strcpy (filename3, filename);
	 strtok(filename3, ".");
	 strcat (filename3, ".pos\0");

	 

	 if (Export)
	 {
	  if ((Sample = new genoma(filename, filename3, TotalSNPs, Size, Exist, (IndCategory)1))==NULL)
	   throw NoMemory();
	 
	  Sample->OrderSNPs();
	  // Sample->WriteGenotypes(filename2);
	  //exit(0);
	 }
	 else
	  if ((Sample = new genoma(TotalSNPs, Size, Exist))==NULL)
	   throw NoMemory();

char initialpos[10], len[6];
float i2[TotalSNPs/Length];

      for (int i=0;i<(TotalSNPs/Length);i++);
		i2[i]=(float)i;


      for (int i=0;i<(TotalSNPs/Length);i++);
	  {
	 strcpy (filename2, filename);
	 strtok(filename2, ".");
	 strcat (filename2, Algorithm);
	 strcat (filename2, ".\0");
	 gcvt (i2[i], 9, initialpos);
	 strcat (filename2, initialpos);
	 strcat (filename2, "-");
	 gcvt ((float)Length, 6, len);
	 strcat (filename2, len);
cout << "filename2\n" << filename2;
//	  Sample->ChangeFormat (filename2, Alg, Export, i*Length, Length);
	  }
	  if (!Export)
		  Sample->WriteGenotypes(filename);


		 }

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (IncorrectAlgorithm ia) {
		 ia.PrintMessage();}
 	 catch (IncorrectWay iw) {
		 iw.PrintMessage();}
	  catch (NonBoolean nb) {
		 nb.PrintMessage();}
	delete filename, filename2, filename3, Way, Algorithm;

   return 0;

}





