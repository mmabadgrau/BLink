/**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "../commonc++/Fachade.h"
#include "FachadeGenoma.h"



char line[300];

/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

char line[100];
bool phen=true, markUnphased=false;
if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " << " <ic (father=0, mother=1, offspring=2, everybody=3, parent=4)>"
<< " <print phenotypes (0, means no, 1 -default- means true)>" <<" <mark unphased (0, default means no, 1 means true)>" << endl;
        exit(-1);
        }
    
  char filename[256], filepos[256], filename2[256];
  strcpy (filename, argv[1]);
  IndCategory ic= (IndCategory) atoi(argv[2]);
if (argc>3)
 phen=atoi(argv[3]);
if (argc>4)
 markUnphased=atoi(argv[4]);
TrioSample *sample;
Positions* Pos;
ChangeExtension (filename, filepos, "pou");

Pos=new Positions (filepos);
sample=new TrioSample (filename, everybody, LeftRight);

ChangeExtension (filename, filename2, "phasedFromFamily");

sample->WriteResults(filename2, phen, ic, 0, 0, markUnphased); // write results without phenotypes


cout << "\nHaplotypes solved using families has been saved in " << filename2 <<"\n";
 
return 0;

};

