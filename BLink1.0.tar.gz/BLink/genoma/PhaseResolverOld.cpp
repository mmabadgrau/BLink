  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <stdlib.h>// gnu accets cstdlib
#include <fstream>

#include <string>
#include <iostream>
//#include <cassert>
//#include <fstream.h>
#include <stdio.h>// gnu accepts cstdio.h
#include <math.h>//gnu accepts <cmath>

#include "genoma.h"
#include "PhaseResolver.h"
//#include "Tables2x2.h"


//using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

//IndCategory ic;

//using namespace std;
//using namespace string;

namespace SNP 
	 {



/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

void PhaseResolution(char *filename, unsigned int TotalSNPs, unsigned int Size, bool ExistPhenotype, IndCategory ic, 
					 unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance, float MAF, 
					 unsigned short int PhaseMode, short unsigned int ReduceSample, unsigned short int affected=1, bool OnlyU=false, unsigned short int Bayes=0, 
					 bool OutputWay=false)
{
char *filename2, *filename3, *Estimator;
//strcpy(filename2, filename);
genoma *PhasedSample;


  if ((filename2=new char[128])==NULL)
		 throw NoMemory();

    if ((filename3=new char[128])==NULL)
		 throw NoMemory();

    if ((Estimator=new char[50])==NULL)
		 throw NoMemory();

cout <<"Uploading file " << filename <<"...\n";


bool ComputeHaplotypes=false;


if ((PhasedSample = new genoma(filename, TotalSNPs, Size, ExistPhenotype, ic,  
	ComputeHaplotypes, (PhaseType)PhaseMode, MAF, affected, OnlyU, Bayes, OutputWay, ReduceSample))==NULL)
 throw NoMemory();

strcpy (filename2, filename);
filename2=strtok(filename2, ".");
switch (Bayes)
{
case 0: strcpy(Estimator, "MLE.\0"); break;//
case 1: strcpy(Estimator, "UniformBayes.\0"); break;//
case 2: strcpy(Estimator, "ReducedUniformBayes.\0"); break;//
case 3: strcpy(Estimator, "EquilibriumBayes.\0"); break;//
}
strcat(filename2, Estimator);
strncat(filename2, "dp\0", 2);
strcpy (filename3, filename);
filename3=strtok(filename3, ".");
strcat(filename3, Estimator);//
strncat(filename3, "way\0", 3);//
PhasedSample->PrintDPrime(filename2, filename3); // OnlyU is only needed when UTSolved

strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strcat(filename2, Estimator);//
strncat(filename2, "sw\0", 2);//
PhasedSample->PrintDPrimeSlidingWindows(filename2, SlideSize, SlideOverlap, MaxDistance);

//cout <<"Slide size:" << SlideSize <<", overlap:" << SlideOverlap <<", maxdistance:" << MaxDistance <<", MAP:" << MAP;
	
strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strcat(filename2, Estimator);//
strncat(filename2, "sal\0", 3);//
PhasedSample->WriteResults(filename2);


strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strcat(filename2, Estimator);//
strncat(filename2, "hap\0", 3);//
PhasedSample->WriteHaplotypes(filename2);


strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strcat(filename2, Estimator);//
strncat(filename2, "SNPs\0", 3);//
PhasedSample->PrintSNPPositions(filename2);

}

}
/*****************/
/*          MAIN          */
/*****************/

using namespace SNP;


int main(int argc, char*argv[]) {

     if(argc<12)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <#SNPs>" << " <#individuals>" << " <ExistPhenotype={0,1}>" 
			<< " <IndCategory (0:only parents/1: only children /2:all)>" 
			<< "<ReduceSample (1: all, 2: take 1 of each 2, 3: take 1 of each 3 ...)>" 
			<< "<PhaseMode>(0=IsPhased/1=KeepUnordered/2=ToOrder/3=ResolvFromTU/4=dHap)" 
			<< "<Phenotype (0=non-affected/1=all/2=affected)>" 
			<< "<Only untransmitted (0=false/1=true), applied only if ic=0 (parents)>" 
			<< "<Bayesian correction (0=MLE/1=UniformBayes/2=ReducedUiformBayes/3=EquilibriumBayes)>" 
			<< "<Output Way (0=false/1=true)>" 
			<< "<slide size>" << "<slide overlap>" << "<max distance>" << "<MAF>" << endl;
        exit(-1);
        }
     char* filename;
         if ((filename=new char[128])==NULL)
		 throw NoMemory();
	 strcpy(filename, argv[1]);
     unsigned int TotalSNPs=atoi(argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int IsPhenotype=atoi(argv[4]);
     IndCategory ic=(IndCategory) atoi(argv[5]);
     short unsigned int ReduceSample=atoi(argv[6]);

	 bool ExistPhenotype;

	 if (IsPhenotype==1)
		 ExistPhenotype=true;
	 else
		 ExistPhenotype=false;


		unsigned int PhaseMode=atoi(argv[7]);

	 	unsigned int SlideSize=1;
		unsigned int SlideOverlap=0;
		unsigned int MaxDistance=0;
		float MAP;


	 unsigned short int affected=atoi(argv[8]);
		
 unsigned short int OnlyU=0;

 if (atoi(argv[9])==1)
 
	 OnlyU=atoi(argv[9]);

 unsigned short int Bayes=atoi(argv[10]);

  bool OutputWay=false;

 if (atoi(argv[11])==1) OutputWay=true;

//	if ((PhaseType)PhaseMode==ResolveFromTU)
	 {
		 SlideSize=atoi(argv[12]);
		 SlideOverlap=atoi(argv[13]);
		 MaxDistance=atoi(argv[14]);
		 MAP=atof(argv[15]);
		 }

cout <<"Configuration: IsPhenotype=" << IsPhenotype << ", IndCategory: " << (int)ic << ", Method for phasing:" 
<< PhaseMode
<<", affected:" << affected <<", OnlyUntransmitted:" << OnlyU <<", Bayes correction:" << Bayes
<<" OutputWay:" << OutputWay <<"\n" ;

//if (
     try{                     
         PhaseResolution(filename, TotalSNPs, TotalIndividuals, ExistPhenotype, ic, 
			 SlideSize, SlideOverlap, MaxDistance, MAP, PhaseMode, ReduceSample, affected, 
			 OnlyU, Bayes, OutputWay);
	}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
 	 catch (MonoAllelic ma) {
		 ma.PrintMessage();}
 	 catch (NullValue nv) {
		 nv.PrintMessage();}
 	 catch (ZeroValue zv) {
		 zv.PrintMessage();}
	 delete filename;

   return 0;

}





