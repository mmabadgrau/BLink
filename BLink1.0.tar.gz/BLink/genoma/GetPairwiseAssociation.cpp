  /**
    * @file GetPairwiseAssociation.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"

#include "../commonc++/list.h"
#include "../commonc++/Sampling.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "GenomaSample.h"

/* This program select individuals for IndType and also ramdomly reduce the sample size*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "   << "<IndType(0:father, 1: mother, 2: offspring, 4: parent>"
			<< "<0: NotChanged, 1: Major First>" << " <output file> ";
        exit(-1);
        }
     char filename[128], filename2[128], filepos[128], filepos2[128];
        
	 strcpy(filename, argv[1]);


	 IndCategory ic=(IndCategory) atoi(argv[2]);
     AlleleOrderType AlleleOrderMode=(AlleleOrderType) atoi(argv[3]);

   	 strcpy(filename2, argv[4]);
		

	 ChangeExtension(filename, filepos, "pou");
	 ChangeExtension(filename2, filepos2, "pou");
     FileCopy(filepos, filepos2);

GenomaSample *sample;
sample=new GenomaSample (filename, AlleleOrderMode);

sample->WriteResults(filename2, true, ic); 
delete sample;
cout <<"Selected individuals have been recorded in file " << filename2;
return 0;


}










