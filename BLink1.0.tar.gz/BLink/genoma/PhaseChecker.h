/* File: PhaseChecker.h */

#include <string>


#ifndef __PhaseChecker_h__
#define __PhaseChecker_h__

#include "Exceptions.h"

#include "genoma.h"

#include "PhaseResolver.h"



namespace SNP {

	
//ofstream OutputFile;


/*______________________________________________________________________*/

void genoma::CheckRecombinationPositions ()
{
	//Revisar
// obtain phase for parent when at least one children is homozygous in the pair of loci to be resolved
// compare with the solution given by dHAP. If it is different, mark like a recombination place (although if recombination
// occurred in the parent or in the children cannot be known
// otherwise, write the simbol minus and the heterozygous values,
// with  the lower one first Ex: 3 1 will be written as - 1 -3
// Phase from children must have been resolved first
	long int LastResolved;
cout << "\nReconstructing parental haplotypes from children...";
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *FatherGenotype, *MotherGenotype;
//cout << "Siz:" << Size << "SNP" << genotype::TotalSNPs;
//exit(0);
// initialize all heterozygous positions in parents as unresolved. We need to do that for the case with more than one child per family
for (int i=0;i<Size;i++)
{
 if (!IsAChild (IndPhenotype))
  for (unsigned int SNP=0;SNP<genotype::TotalSNPs;SNP++)
   if (IsHeterozygous (IndGenotype, SNP))
   {
	*((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP));
    *((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP));
   }
   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);
}

IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++)
{
 if (IsAChild (IndPhenotype))
 {
  FatherGenotype=GetGenotype(GetFather(IndPhenotype));
  MotherGenotype=GetGenotype(GetMother(IndPhenotype));
  LastResolved=-1;
  for (unsigned int SNP=0;SNP<genotype::TotalSNPs;SNP++)
  {
	  if (IsHeterozygous (FatherGenotype, SNP))
		  if (LastResolved==-1) LastResolved=SNP;
		  else 
			  if (!((IsHeterozygous (IndGenotype, LastResolved)) && (IsHeterozygous (IndGenotype, SNP)) &&
			  ((IsUnresolved(IndGenotype, LastResolved)) || (IsUnresolved(IndGenotype, SNP))))) // if can be resolved from the child
			  {
			
			    *((FatherGenotype->Left)+SNP)=MarkAllele(*((FatherGenotype->Left)+SNP)); // resolved
				if (*((FatherGenotype->Left)+LastResolved)!=abs(*((IndGenotype->Left)+LastResolved))) 
     			 ChangeAlleles(FatherGenotype, SNP);
				 
			  }	
  }
 LastResolved=-1;
 for (unsigned int SNP=0;SNP<genotype::TotalSNPs;SNP++)
  {
	  if (IsHeterozygous (MotherGenotype, SNP))
		  if (LastResolved==-1) LastResolved=SNP;
		  else 
			  if (!((IsHeterozygous (IndGenotype, LastResolved)) && (IsHeterozygous (IndGenotype, SNP)) &&
			  ((IsUnresolved(IndGenotype, LastResolved)) || (IsUnresolved(IndGenotype, SNP))))) // if can be resolved from the child
			  {
				  
				*((MotherGenotype->Left)+SNP)=MarkAllele(*((MotherGenotype->Left)+SNP)); // resolved
				if (*((MotherGenotype->Left)+LastResolved)!=abs(*((IndGenotype->Left)+LastResolved))) 
     			 ChangeAlleles(MotherGenotype, SNP);
				 
			  }

  } // end for each SNP

  } // end for each child

//if (i<(Size-1))
 {
	 IndGenotype=genotype::GetNext(IndGenotype);
	 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
} // end for each individual

cout << "\nReconstruction of parents from children has finished";
}
/*____________________________________________________________ */

void genoma::SetKnownPhases (bool *MustBeResolved,
Genotype *TheFirstTrivialGenotype, bool Distance, unsigned int InitialSNP, unsigned int Length)
{

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
Genotype *IndTrivialGenotype=TheFirstTrivialGenotype;


bool FirstHeteroKnown=true;

for (int cont=0; cont<(Size*genotype::TotalSNPs); cont++)
*(MustBeResolved+cont)=false;
int c2=0, l=0;

for (int row=0;row<Size;row++)
{
 if (((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) && (!IsAChild (IndPhenotype))) || (ic==2))
 {
//	 cout <<"\n";
	 if (!Distance)
        FirstHeteroKnown=false;  
	 for (int SNP=0;SNP<genotype::TotalSNPs; SNP++) 
        //for (int SNP=InitialSNP;SNP<(InitialSNP+Length); SNP++) 
         //if (IsANewSNP(SNP))
		{
		//	cout << *((IndGenotype->Left)+SNP) << " ";
		//	cout << *((IndGenotype->Right)+SNP) << " ";
		 if ((IsHeterozygous (IndGenotype, SNP)))
			 l++;
//					   (*(MustBeResolved+row*genotype::TotalSNPs+SNP))=true;

         if ((IsHeterozygous (IndTrivialGenotype, SNP)) && (!IsMarked(*((IndTrivialGenotype->Left)+SNP))))  
	  //       if ((*((IndTrivialGenotype->Left)+SNP)>0)  && (*((IndTrivialGenotype->Right)+SNP)>0))
		//if (*((IndTrivialGenotype->Left)+SNP)>0) 
	//	if 	(IsHeterozygous (IndGenotype, SNP))
		{

          if (FirstHeteroKnown==true)   
    //        MustBeResolved[row, SNP]=true;
		  {
		   (*(MustBeResolved+row*genotype::TotalSNPs+SNP))=true;
			c2++;
		  }
//		  cout <<"a1:" << &MustBeResolved[SNP, row];
//		  cout <<"a2:" << MustBeResolved+row*genotype::TotalSNPs+SNP;
//		  exit(0);
          FirstHeteroKnown=true;
		 } // end if hetero and trivially resolved
		} // end for each SNP
 } // end if is this type
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
 IndTrivialGenotype=IndTrivialGenotype->Next;
}
cout <<"Totalmustbe: " << c2 <<"l:" <<l;
}



/*____________________________________________________________ */

void genoma::SetUnresolvedPhases (bool *Unresolved, bool *MustBeResolved)
{

	
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;

for (int cont=0; cont<(Size*genotype::TotalSNPs); cont++)
 *(Unresolved+cont)=false;

for (int row=0;row<Size;row++)
{
 if (IsAChild (IndPhenotype))
  for (int SNP=0;SNP<genotype::TotalSNPs; SNP++) 
   //if (IsANewSNP(SNP))
  {
 if ((*(MustBeResolved+row*genotype::TotalSNPs+SNP)) && (*((IndGenotype->Right)+SNP)==(allele)5))  
// if ((*(MustBeResolved+row*genotype::TotalSNPs+SNP)) && (*((IndGenotype->Right)+SNP)==(allele)5))  
 {
    (*(Unresolved+row*genotype::TotalSNPs+SNP))=true;
	 if (*((IndGenotype->Left)+SNP)==MajorAllele[SNP])  	
		*((IndGenotype->Right)+SNP)==MinorAllele[SNP];
	 else
		*((IndGenotype->Right)+SNP)==MajorAllele[SNP];

//	cout <<"u";
 }

// if (*((IndGenotype->Left)+SNP)==5)
//		  cout <<"B";
//  if (*((IndGenotype->Right)+SNP)==5)
//		  cout <<"b";
  }
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
}
}


/*____________________________________________________________ */

void genoma::SetBadResolvedPhases(bool *MustBeResolved, bool *Unresolved, bool *BadResolved, Genotype *TheFirstTrivialGenotype)

{
//	for (int r=0;r<genotype::TotalSNPs;r++)
//		cout <<"Maj for SNP " << r <<": " << MajorAllele[r];
unsigned int H, H2;
unsigned short int Phase;
	
  ofstream OutputFile; 


 OutputFile.open ("PosAccuracy.csv", ifstream::out);
 
 if (!OutputFile)
	 throw ErrorFile();


OutputFile << "Pedigree Code" << ", " << "Individual Code" << ", " << "Left locus" << "-" << "Right locus" <<", "<< "Physical distance" <<", " 
<< "Erroneous Phase" << ", " << "Correct Phase" <<", " << "Heterozygous individuals at left locus" << ", " 
<< "Heterozygous individuals at right locus" << "\n";


Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *IndGenotypeTrivial=TheFirstTrivialGenotype;
int LastHetero;
allele LeftLast, LeftCurrent, LeftLastTrivial, LeftCurrentTrivial;
int  c2=0;

for (int cont=0; cont<(Size*genotype::TotalSNPs); cont++)
 *(BadResolved+cont)=false;

for (int row=0;row<Size;row++)
{
 if (((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) && (!IsAChild (IndPhenotype))) || (ic==2))
 {
  LastHetero=-1;
  for (int SNP=0;SNP<genotype::TotalSNPs; SNP++) 
  {
   //if (IsANewSNP(SNP))
//   if ((!IsHeterozygous (IndGenotype, SNP)) && ((*(Unresolved+row*genotype::TotalSNPs+SNP))))
//   {
//cout <<"error";
//cout <<"left: " << *((IndGenotype->Left)+SNP) << "right " << *((IndGenotype->Right)+SNP) <<"\n";
//   }
   {
	if (LastHetero!=-1)
	{
    if ((*(MustBeResolved+row*genotype::TotalSNPs+SNP)))
     if (!(*(Unresolved+row*genotype::TotalSNPs+SNP)))
	 {
	 if (IsMarked(*((IndGenotype->Left)+LastHetero)))
	  LeftLast=UnmarkAllele(*((IndGenotype->Left)+LastHetero));
     else LeftLast=*((IndGenotype->Left)+LastHetero);

	  if (IsMarked(*((IndGenotypeTrivial->Left)+LastHetero)))
	  LeftLastTrivial=UnmarkAllele(*((IndGenotypeTrivial->Left)+LastHetero));
     else LeftLastTrivial=*((IndGenotypeTrivial->Left)+LastHetero);
	
//	*((IndGenotype->Left)+LastHetero)=MarkAllele(*((IndGenotype->Left)+LastHetero));
	
	if (IsMarked(*((IndGenotype->Left)+SNP)))
     LeftCurrent=UnmarkAllele(*((IndGenotype->Left)+SNP));
 	else LeftCurrent=*((IndGenotype->Left)+SNP);

//	if (IsMarked(*((IndGenotypeTrivial->Left)+SNP))) cout <<"\nerror en SNP " << SNP <<", ind: " << row;

	if (IsMarked(*((IndGenotypeTrivial->Left)+SNP)))
     LeftCurrentTrivial=UnmarkAllele(*((IndGenotypeTrivial->Left)+SNP));
 	else LeftCurrentTrivial=*((IndGenotypeTrivial->Left)+SNP);

 	//LeftCurrentTrivial=*((IndGenotypeTrivial->Left)+SNP);

	//if (IsMarked(*((IndGenotypeTrivial->Left)+SNP))) cout <<"error";
//	if (LastHetero!=-1)
	  if ((((LeftCurrent==LeftCurrentTrivial))
		   && ((LeftLast!=LeftLastTrivial)))
          || (((LeftCurrent!=LeftCurrentTrivial))
		   && ((LeftLast==LeftLastTrivial))))
	  {
       *(BadResolved+row*genotype::TotalSNPs+SNP)=true;
	   *((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP));
	   *((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP));
	   c2++;
	  }

	  
     if ((LeftLastTrivial==MajorAllele[LastHetero]) &&
		(LeftCurrentTrivial==MajorAllele[SNP]))
		Phase=1;
	 else Phase=2;


 H=GetTotalHeterozygous(LastHetero);
 H2=GetTotalHeterozygous(SNP);

	  OutputFile << IndPhenotype->Pedigree << ", " << IndPhenotype->Code << ", " << GetPosition(LastHetero) << "-" << GetPosition(SNP) <<", "<< GetPosition(SNP)-GetPosition(LastHetero) <<", " << (unsigned int) *(BadResolved+row*genotype::TotalSNPs+SNP) << ", " << Phase <<", " << H << ", " << H2 << "\n";
	  LastHetero=SNP;
	 } // end if it was solved
//	  LastHetero=SNP; // 
	} // end if s not the first hetero
    if ((LastHetero==-1) && (IsHeterozygous (IndGenotype, SNP))  &&
		(!IsMarked(*((IndGenotypeTrivial->Left)+SNP))))
     LastHetero=SNP;
	} // if is hetero or unresolved
  } // for each SNP
  } // end is a child
 IndGenotype=genotype::GetNext(IndGenotype);
 IndPhenotype=phenotype::GetNext(IndPhenotype);
 IndGenotypeTrivial=genotype::GetNext(IndGenotypeTrivial);
} // end for
cout <<"c2" << c2;
OutputFile.close();
}
/*____________________________________________________________ */

void genoma::SetBadResolvedPhasesDistance(bool *MustBeResolved, bool *Unresolved, bool *BadResolved, Genotype *TheFirstTrivialGenotype)

{
//	for (int r=0;r<genotype::TotalSNPs;r++)
//		cout <<"Maj for SNP " << r <<": " << MajorAllele[r];
unsigned int H, H2;
unsigned short int Phase;
	
  
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *IndGenotypeTrivial=TheFirstTrivialGenotype;
int LastHetero;
allele LeftLast, LeftCurrent, LeftLastTrivial, LeftCurrentTrivial;
int  c2=0;

for (int cont=0; cont<(Size*genotype::TotalSNPs); cont++)
 *(BadResolved+cont)=false;

for (int row=0;row<Size;row++)
{
 if (((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) && (!IsAChild (IndPhenotype))) || (ic==2))
 {
  for (int SNP=0;SNP<genotype::TotalSNPs; SNP++) 
   //if (IsANewSNP(SNP))
   if (IsHeterozygous (IndGenotypeTrivial, SNP)) 
   if ((!IsHeterozygous (IndGenotype, SNP)) && (!(*(Unresolved+row*genotype::TotalSNPs+SNP))))
   {
cout <<"error";
cout <<"left: " << *((IndGenotype->Left)+SNP) << "right " << *((IndGenotype->Right)+SNP) <<"\n";
   }
   else // heterozygous or == 5 (unresolved)
   {
    if ((*(MustBeResolved+row*genotype::TotalSNPs+SNP)))
     if (!(*(Unresolved+row*genotype::TotalSNPs+SNP)))
	 {

	if (IsMarked(*((IndGenotype->Left)+SNP)))
     LeftCurrent=UnmarkAllele(*((IndGenotype->Left)+SNP));
 	else LeftCurrent=*((IndGenotype->Left)+SNP);

//	if (IsMarked(*((IndGenotypeTrivial->Left)+SNP))) cout <<"\nerror en SNP " << SNP <<", ind: " << row;

	if (IsMarked(*((IndGenotypeTrivial->Left)+SNP)))
     LeftCurrentTrivial=UnmarkAllele(*((IndGenotypeTrivial->Left)+SNP));
 	else LeftCurrentTrivial=*((IndGenotypeTrivial->Left)+SNP);


 	//LeftCurrentTrivial=*((IndGenotypeTrivial->Left)+SNP);

	  if (LeftCurrent!=LeftCurrentTrivial)
	  {
       *(BadResolved+row*genotype::TotalSNPs+SNP)=true;
	   *((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP));
	   *((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP));
	   c2++;
	  }

	  
    	 } // end if it was solved
	} // end for each heterozygous SNP that must be solved
 } // end is a child
 IndGenotype=genotype::GetNext(IndGenotype);
 IndPhenotype=phenotype::GetNext(IndPhenotype);
 IndGenotypeTrivial=genotype::GetNext(IndGenotypeTrivial);
} // end for
cout <<"c2" << c2;
}
/*____________________________________________________________ */

void genoma::WriteAccuracy (char* filename, char* filename2, unsigned int hetero, unsigned int Error, unsigned int unchecked, unsigned int homo, unsigned int missing, unsigned int unresolved, unsigned int Solved, unsigned int WholeHapAccuracy)

 {


  ofstream OutputFile; 

  try
{
  OutputFile.open (filename, ifstream::app);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
	OutputFile << "Dataset: " << filename2 << ' ';
	if (Solved!=0)
	 OutputFile <<"Accuracy: " << ((float)hetero-Error-unresolved)/(Solved) << ' '; 
	else 
	 OutputFile <<"Accuracy: 1 "; 
	OutputFile <<"AccuracyWholeHaplotype: " << ((float)WholeHapAccuracy/CountType()) <<' '; 
	OutputFile <<"ErrorsWholeHaplotype: " << CountType()-WholeHapAccuracy << ' '; 
	OutputFile << "hetero: " << hetero << ' ';
	OutputFile << "error: " << Error << ' ';
	OutputFile << "unchecked: " << unchecked << ' ';
	OutputFile << "homo: " << homo << ' ';
	OutputFile << "missing: " << missing << ' ';
	OutputFile << "unresolved: " << unresolved << '\n';

 
 OutputFile.close();

 }

/*____________________________________________________________ */

void PrintRecombinationIntervals (char* filename, bool *BadResolved)

 {

  ofstream OutputFile; 

  try
{
  OutputFile.open (filename, ifstream::app);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
							}
/*

	OutputFile << "Dataset: " << filename << ' ';
	OutputFile << "Accuracy: " << ((float)hetero-Error-unresolved)/hetero << ' ';
	OutputFile << "hetero: " << hetero << ' ';
	OutputFile << "error: " << Error << ' ';
	OutputFile << "homo: " << homo << ' ';
	OutputFile << "missing: " << missing << ' ';
	OutputFile << "unresolved: " << unresolved << '\n';
*/
 
 OutputFile.close();

 }
/*________________________________________________________________________*/

void genoma::PhaseAccuracy (const genoma & TrivialSNP, char* filename, char *filenameb, char* filename2=NULL, bool Distance=false, unsigned int InitialSNP=0, unsigned int Length=0)
{
// This function reorder bad-resolved phases using the SNPTrivialPhase 
// Each phase that has to be resolved is counted in MustBeResolved
// Each error is counted in BadResolved. 
// Each unresolved phase is counted in Unresolved
// type: 0, only parents, 1: only children, 2: all
//OrderSNPs((IndCategory) 1);

//if (filename2!=NULL)
//{
//position* Pos;
//if ((Pos = new position(filename, genotype::TotalSNPs, Size, true, (IndCategory)1))==NULL)
// throw NoMemory();

//}

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
Genotype *IndTrivialGenotype=TrivialSNP.TheFirstGenotype;

if (Length==0) Length=genotype::TotalSNPs;

bool *MustBeResolved, *Unresolved, *BadResolved;

if ((MustBeResolved=new bool[Size*genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Unresolved=new bool[Size*genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((BadResolved=new bool[Size*genotype::TotalSNPs])==NULL)
      throw NoMemory();

SetKnownPhases(MustBeResolved, TrivialSNP.TheFirstGenotype, Distance, InitialSNP, Length);

SetUnresolvedPhases(Unresolved, MustBeResolved);

if (!Distance)
 SetBadResolvedPhases(MustBeResolved, Unresolved, BadResolved, TrivialSNP.TheFirstGenotype);
else
SetBadResolvedPhasesDistance(MustBeResolved, Unresolved, BadResolved, TrivialSNP.TheFirstGenotype);

cout << "heteros2 old:" << GetHeterozygousGenotypes();

//cout << "heteros2 trivial:" << TrivialSNP.GetHeterozygousGenotypes();


cout <<"DIS:" << Distance;
unsigned long int unresolved=0, Error=0, Total=0, known=0, homo=0, phase=0, homoormissing=0, missing=0, unchecked=0, ErrorInd, HeteroInd, Solved=0, SolvedInd, WholeHapAccuracy=0;

IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;
IndTrivialGenotype=TrivialSNP.TheFirstGenotype;

//cout << "het in trivial:" << TrivialSNP.GetHeterozygousGenotypes();
//cout << "het in solved:" << GetHeterozygousGenotypes();


for (int row=0;row<Size;row++)
{
 if (IsAChild (IndPhenotype))
 {
 ErrorInd=0;
 HeteroInd=0;
 SolvedInd=0;
 for (int SNP=InitialSNP;SNP<(InitialSNP+Length); SNP++) 
//   if (IsANewSNP(SNP))
  {
   phase=phase+1;
   if (!IsANonMissingSNP (IndTrivialGenotype, SNP)) 
    missing=missing+1;
   if ((IsANonMissingSNP(IndTrivialGenotype, SNP)) && (!IsHeterozygous(IndTrivialGenotype, SNP)))
    homo=homo+1;
   if ((!IsANonMissingSNP(IndTrivialGenotype, SNP)) || (!IsHeterozygous(IndTrivialGenotype, SNP)))
    homoormissing=homoormissing+1;
   if (IsHeterozygous(IndTrivialGenotype, SNP))
    if   (*(MustBeResolved+row*genotype::TotalSNPs+SNP))
     {
      if (*(Unresolved+row*genotype::TotalSNPs+SNP))
       unresolved=unresolved+1;
      else
      {
       if (*(BadResolved+row*genotype::TotalSNPs+SNP))
        ErrorInd=ErrorInd+1;
       SolvedInd=SolvedInd+1; 
      }
      Total=Total+1;
     }
     else unchecked=unchecked+1;    
    } // for each SNP
  if (Distance)
   if (ErrorInd>(SolvedInd/2))
    ErrorInd=SolvedInd-ErrorInd;
 if (ErrorInd==0)
   WholeHapAccuracy=WholeHapAccuracy+1;
 Solved=Solved+SolvedInd;
 Error=Error+ErrorInd;
 }
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
 IndTrivialGenotype=IndTrivialGenotype->Next;
}


cout <<"\nNumber of heterozygous positions to check: " << Solved; 
cout <<"\nNumber of errors: " << Error; 
if (Solved!=0)
cout <<"\nAccuracy: " << ((float)Total-Error-unresolved)/(Solved); 
else 
cout <<"\nAccuracy: 1"; 
cout <<"\nAccuracy whole haplotype: " << ((float)WholeHapAccuracy/CountType()); 
cout <<"\nErrors whole haplotype: " << CountType()-WholeHapAccuracy; 
cout <<"\nTotal number of positions: " << phase; 
cout <<"\nTotal number of missing positions: " << missing; 
cout <<"\nTotal number of homo positions: " << homo; 
cout <<"\nTotal number of unckecked positions: " << unchecked; 
cout <<"\nTotal number of unresolved positions: " << unresolved; 
cout <<"\n";

genoma::WriteAccuracy(filename, filenameb, Total, Error, unchecked, homo, missing, unresolved, Solved, WholeHapAccuracy);

delete MustBeResolved;
delete Unresolved;
delete BadResolved;

}

/*__________________________________________________________________________________*/

void genoma::CheckInconsistencies (const genoma& GenomaTrivial)
{
	
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *IndGenotypeTrivial=GenomaTrivial.TheFirstGenotype;

for (int row=0;row<Size;row++)
{
 if (IsAChild (IndPhenotype))
  for (int SNP=0;SNP<genotype::TotalSNPs; SNP++) 
  {
 if (((IsHeterozygous (IndGenotype, SNP)) && (!IsHeterozygous (IndGenotypeTrivial, SNP)))  
	|| ((!IsHeterozygous (IndGenotype, SNP)) && (IsHeterozygous (IndGenotypeTrivial, SNP))))  
cout <<"\nInconsistence at ind " << row << " pos " << SNP << " val file: " 
<< *(IndGenotype->Left+SNP) <<*(IndGenotype->Right+SNP) << " versus "
<< *(IndGenotypeTrivial->Left+SNP) <<*(IndGenotypeTrivial->Right+SNP);
  }
 IndGenotype=IndGenotype->Next;
 IndGenotypeTrivial=IndGenotypeTrivial->Next;
 IndPhenotype=IndPhenotype->Next;
}
}

 /*____________________________________________________________ */

void genoma::TestSPD (bool FromParents, char* namefile)
{
int LastResolved, BeforeLastResolved;
cout << "Computing relative pairwise frequencies...\n";

if (haps==NULL)
 throw NullValue();

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype* IndGenotype=TheFirstGenotype;

// counters for phase b,c and a,b
int **Phase11, **Phase21, **Phase12, **Phase22, maxi;
unsigned int ***Frequencies;
unsigned int First;

if ((Phase11=new int*[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase21=new int*[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase12=new int*[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase22=new int*[genotype::TotalSNPs])==NULL)
      throw NoMemory();

for (int i=0; i<(genotype::TotalSNPs);i++)
{

if ((Phase11[i]=new int[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase21[i]=new int[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase12[i]=new int[genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((Phase22[i]=new int[genotype::TotalSNPs])==NULL)
      throw NoMemory();
}

for (int i=0; i<(genotype::TotalSNPs);i++)
 for (int j=0; j<(genotype::TotalSNPs);j++)
{
  Phase11[i][j]=0;
  Phase21[i][j]=0;
  Phase12[i][j]=0;
  Phase22[i][j]=0;
 }


ofstream OutputFile, OutputFile2, OutputFile3;


OutputFile.open ("SPD.csv", ifstream::out);
OutputFile2.open ("Class.txt", ifstream::out);
OutputFile3.open ("Dependence.txt", ifstream::app);

 
 if (!OutputFile)
	 throw ErrorFile();

 
IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;
unsigned int c=0;
for (int i=0;i<Size;i++)
{
 if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
 {
 LastResolved=-1; 
 BeforeLastResolved=-1;
 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
 {
   if (IsHeterozygous (IndGenotype, SNP)) 
   {
    if (((FromParents) && (!IsMarked(*((IndGenotype->Left)+SNP)))) || (!FromParents))
	{
    if ((LastResolved!=-1))  // && (BeforeLastResolved!=-1))//    UnknownPreviousPhase
	{
	if (LastResolved>=genotype::TotalSNPs) 
	 cout <<"val" << LastResolved;
    if (IsHeterozygous (IndGenotype, LastResolved))
    {
   // if ((SNP==10) && (LastResolved==5)) cout <<"\nKKKKind:" << i <<"\n";

   if (((*((IndGenotype->Left)+BeforeLastResolved)==MajorAllele[BeforeLastResolved]) &&
      (*((IndGenotype->Left)+LastResolved)==MajorAllele[LastResolved])) ||
      ((*((IndGenotype->Left)+BeforeLastResolved)==MinorAllele[BeforeLastResolved]) &&
      (*((IndGenotype->Left)+LastResolved)==MinorAllele[LastResolved])))

   if (((*((IndGenotype->Left)+LastResolved)==MajorAllele[LastResolved]) &&
      (*((IndGenotype->Left)+SNP)==MajorAllele[SNP])) ||
      ((*((IndGenotype->Left)+LastResolved)==MinorAllele[LastResolved]) &&
      (*((IndGenotype->Left)+SNP)==MinorAllele[SNP])))

        Phase11[LastResolved][SNP]++;
	   else
		Phase21[LastResolved][SNP]++;
	  else
   if (((*((IndGenotype->Left)+LastResolved)==MajorAllele[LastResolved]) &&
      (*((IndGenotype->Left)+SNP)==MajorAllele[SNP])) ||
      ((*((IndGenotype->Left)+LastResolved)==MinorAllele[LastResolved]) &&
      (*((IndGenotype->Left)+SNP)==MinorAllele[SNP])))

      	Phase12[LastResolved][SNP]++;  
 	   else 
		Phase22[LastResolved][SNP]++;
	  c++;
     }
	}
    BeforeLastResolved=LastResolved;
    LastResolved=SNP;
	} // if must be resolved
    //    if (BeforeLastResolved==-1) BeforeLastResolved=LastResolved;
//        if (LastResolved==-1) LastResolved=SNP;
   } // end is Hetero
 } //end for each SNP

 } // for each child
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;


} // end for each individual

//cout <<"Totlch:" << c << ",";  
c=0;
for (int i=0; i<genotype::TotalSNPs; i++)
 for (int j=i+1; j<genotype::TotalSNPs; j++)
  if ((Phase11[i][j]>0) || (Phase12[i][j]>0) || (Phase21[i][j]>0) || (Phase22[i][j]>0))
   c=c+Phase11[i][j]+Phase21[i][j]+Phase12[i][j]+Phase22[i][j];

//cout <<"Totlchbbbbb:" << c << ",";  



unsigned long int f11=0, f21=0, f12=0, f22=0, t1=0, t2=0, t=0, total=0;
unsigned short int way1, way2, way;
float pAm, pA, pBm, pB;

OutputFile2 <<"SNPA, SNPB, B-A, n(AB), n(ab), n(AB)*n(ab), Homo1, n(Ab), n(aB), n(Ab)*n(aB), Homo2, HetHet, n(A), n(a), n(B), n(b), way1, way2, Phase \n"; 

for (int i=0; i<genotype::TotalSNPs; i++)
 for (int j=i+1; j<genotype::TotalSNPs; j++)
   if ((Phase11[i][j]>0) || (Phase21[i][j]>0) || (Phase12[i][j]>0) || (Phase22[i][j]>0))
   {
	if (Phase11[i][j]>Phase21[i][j]) way1=1; else way1=2; // phase b,c when phase a,b is F1
	if (Phase12[i][j]>Phase22[i][j]) way2=1; else way2=2; // phase b,c when phase a,b is F2
	if ((Phase12[i][j]+Phase11[i][j])>(Phase22[i][j]+Phase21[i][j])) way=1; else way=2; // phase b,c when phase a,b is F2

        if ((Phase11[i][j]>0) && (Phase21[i][j]>0))
	OutputFile << "\nSNPs " << i << " and " << j <<", " << Phase11[i][j] <<", " << Phase21[i][j];
        if ((Phase12[i][j]>0) && (Phase22[i][j]>0))
	 OutputFile << "\nSNPs " << i << " and " << j <<", " << Phase12[i][j] <<", " << Phase22[i][j];
/*    
	OutputFile2 <<"\n" << i <<", " << j <<", " << j-i <<", "; 
	
	OutputFile2 << haps[i][j][5] <<", " << haps[i][j][8] << ", " << haps[i][j][5]*haps[i][j][8] << ", " << GetTotalHomozygous1(ic, i)
		<< ", "  << haps[i][j][6] << ", " << haps[i][j][7] << ", " << haps[i][j][6]*haps[i][j][7] << ", " << GetTotalHomozygous1(ic, j)
	 << ", " <<  haps[i][j][4]  << ", " << GetTotalAllele(ic, i, true) << ", "
				<< GetTotalAllele(ic, i, false) << ", " << GetTotalAllele(ic, j, true) << ", " 
				<< GetTotalAllele(ic, j, false) << ", " << way1 <<", " <<way2 << ", " << way;
*/
	OutputFile2 <<"\n" << i <<", " << j <<", " << j-i <<", "; 

		OutputFile2 << GetHapFrequency(i,j,0) <<", " << GetHapFrequency(i,j,3) << ", " << GetHapFrequency(i,j,0)*GetHapFrequency(i,j,3) << ", " << GetTotalHomozygous1(i)
		<< ", "  << GetHapFrequency(i,j,1) << ", " << GetHapFrequency(i,j,2) << ", " << GetHapFrequency(i,j,1)*GetHapFrequency(i,j,2) << ", " << GetTotalHomozygous1(j)
	  << ", " <<  GetHapFrequency(i,j,4) << ", " << GetTotalAllele(i, true) << ", "
				<< GetTotalAllele(i, false) << ", " << GetTotalAllele(j, true) << ", " 
				<< GetTotalAllele(j, false) << ", " << way1 <<", " <<way2 << ", " << way;


/*
	if ((Phase11[i][j]>0) || (Phase21[i][j]>0) || (Phase12[i][j]>0) || (Phase22[i][j]>0))  
// if ((Phase11[i][j]>0) && (Phase2[i][j]>0))
	 OutputFile2 << ", 1\n";
 else
		OutputFile2 << ", 0\n";
*/
for (int c=5;c<9;c++)
		total=total+GetHapFrequency(i,j,c);

pA=(float)GetTotalAllele(i, false)/(float)total;
pB=(float)GetTotalAllele(j, false)/(float)total;

if ((pA==0) || (pB==0))
cout <<"Nul";


	   t1=t1+Phase11[i][j]+Phase21[i][j];
	   t2=t2+Phase12[i][j]+Phase22[i][j];

	   f21=f21+Phase11[i][j]+Phase21[i][j];
	   f22=f22+Phase12[i][j]+Phase22[i][j];

	if (Phase11[i][j]>Phase21[i][j])
		maxi=Phase11[i][j];
	else
		maxi=Phase21[i][j];
	 f11=f11+Phase11[i][j]+Phase21[i][j]-maxi;

	 if (Phase12[i][j]>Phase22[i][j])
		maxi=Phase12[i][j];
	else
		maxi=Phase22[i][j];
	 f12=f12+Phase12[i][j]+Phase22[i][j]-maxi;


   }
OutputFile3 <<"\nNamefile: " << namefile << " n11: " << f11 <<" n1: " << f21 << " n12: " << f12 <<" n2: " << f22;
OutputFile3 <<" t1: " << t1 << " t2: " << t2;


cout << "SPD checking has finished\n";
//delete PairwiseF;
OutputFile.close();
OutputFile2.close();


for (int i=0; i<genotype::TotalSNPs; i++)
{
 delete Phase11[i];
 delete Phase21[i];
 delete Phase12[i];
 delete Phase22[i];
}

}

};  // Fin del Namespace

#endif

/* Fin Fichero: PhaseChecker.h */
