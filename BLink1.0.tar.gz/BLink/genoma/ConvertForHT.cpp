  /**
    * @file ChangeFormat.cpp
    * @brief Program to change formats in genotype files
	* @example ChangeFormat e PHASE chrom1.red chrom1PHASE.inp c1 1 100 90
	* convert a file called chrom1.red in our format to PHASE format (e means "export"). The target file will be
    * called chrom1PHASE.inp. File c1 is a reference file. The origen file contains phenotypr information (1). 
	* The origen has 200 loci and 90 individuals. 
    */


#include <iostream>
#include <cassert>
#include <fstream>
#include <stdio.h>

#include "Exceptions.h"







namespace HT {

void ConvertToLetters (char * cad1, char * cad2, unsigned int Block)
{
//	cout << "\n" << cad1;
	unsigned int val, i;
	char basis[2];
	for (i=0;i<strlen(cad1);i++)
	{
	sscanf(cad1+i, "%c", basis);
	val=atoi(basis);
	switch (val)
	{
		case 1: cad2[i]='A'; break;
		case 2: cad2[i]='C'; break;
		case 3: cad2[i]='G'; break;
		case 4: cad2[i]='T'; break;
		default: cout <<"original value: " << basis <<"converted to: " << atoi(basis) <<" at block " << Block <<" with chain " << cad1 << " "; throw BadFormat(); break;
	}
	}
	cad2[i]='\0';
}
/*___________________________________________________________*/

void ConvertForHT (char* filename, char * chromid)
{
char filename2[128]="\0", filename3[128]="\0", filename4[128]="\0", BlockChar[10], NumberChar[3];
ifstream InputFile; 
ofstream OutputFile, OutputFile2, OutputFile3;
unsigned int i2, BlockCounter, FirstMarker, MarkerPos;

cout <<"Exporting " << filename << " to be used for htSNPs \n";



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2, *cad3, *cadold;
    if ((genotypebuf=new char[1000])==NULL)
     throw NoMemory();
	if ((cad2=new char[10000])==NULL)
     throw NoMemory();
	if ((cad3=new char[10000])==NULL)
     throw NoMemory();


	 bool found=false, found2=false;

	filename3[0]='\0';

	strcpy (filename3, "chromosome");
	strcat (filename3, chromid);
	strcat (filename3, "htSNPs");
	strcat (filename3, "July2004.txt");


	filename4[0]='\0';

	strcpy (filename4, "chromosome");
	strcat (filename4, chromid);
	strcat (filename4, "SizeBlock");
	strcat (filename4, "July2004.txt");


OutputFile2.open (filename3, ifstream::out);

OutputFile3.open (filename4, ifstream::out);


 BlockCounter=1;

	do
	{
	InputFile.getline (genotypebuf, 100000);
//		cout << "V:" <<genotypebuf << "\n";

	cad=strtok (genotypebuf," ");// read the first word 
	if (*cad!='B') {cout <<"h"; throw BadFormat();}


	cad=strtok (NULL,". \t");
    
	sscanf (cad, "%s", cad2);

	if (atoi(cad2)!=BlockCounter) {cout <<"h2"; throw BadFormat();}
	
	OutputFile2 << "Block " << BlockCounter << ". ";

	OutputFile3 << "Block " << BlockCounter << ". ";

	
	
	cad=strtok (NULL,":");
	cad=strtok (NULL," \n");

	FirstMarker=atoi(cad);
	MarkerPos=0;
	OutputFile3 << atoi(cad) <<" ";

	do
{
   found2=false;
		if (*(cad+strlen(cad)-1)=='!')
		{
			found2 = true;
		//	OutputFile2 << atoi(cad)-FirstMarker+1;
			OutputFile2 << MarkerPos;
		}
		cadold=cad;
	cad=strtok (NULL," \n");
	if (found2 && cad!=NULL) OutputFile2 << " ";

   if (cad==NULL) 	OutputFile3 << atoi(cadold) <<" ";
	MarkerPos++;

}
while (cad!=NULL);

OutputFile2 << "\n";

OutputFile3 << MarkerPos << " ";


	filename2[0]='\0';

	strcpy (filename2, "chromosome");
	strcat (filename2, chromid);
	strcat (filename2, "block");
	gcvt ((float)BlockCounter, 10, BlockChar);
	strcat (filename2, BlockChar);
	strcat (filename2, "July2004.txt");


	OutputFile.open (filename2, ifstream::out);

   
    do
	{
	InputFile.getline (genotypebuf, 1000); // read lines with frequent haplotypes
	cad=strtok (genotypebuf," ");// read the first word 
	cad2[0]='\0';
	sscanf (cad, "%s", cad2);
	//if (BlockCounter<6)
	//cout <<"\nB" << BlockCounter << "cad:" << cad << ", long:" << strlen(cad2);

	if (cad2[0]!='M')
	{
	ConvertToLetters(cad2, cad3, BlockCounter);
	OutputFile << cad3 << " ";
	}
	cad=strtok (NULL,")");// read the first word 
	cad2[0]='\0';
	sscanf (cad+1, "%s", cad2);
	OutputFile << cad2 << endl;
	}
	while ((InputFile.peek()!='M') && (InputFile.peek()!=EOF)); 

    OutputFile.close();	
	
BlockCounter=BlockCounter+1;

if (InputFile.peek()!=EOF)
{
InputFile.getline (genotypebuf, 1000); // D prime
cad=strtok (genotypebuf,":");// read "Multiallelic Dprime:"
cad=strtok (NULL," \n");// read value
cad2[0]='\0';
sscanf (cad, "%s", cad2);
OutputFile3 << cad2 <<"\n";
}
}
while (InputFile.peek()!=EOF);

OutputFile2.close();

OutputFile3.close();
}

} // end of namespace

/*****************/
/*          MAIN          */
/*****************/

using namespace HT;


int main(int argc, char*argv[]) {


     if(argc!=3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0]  << " <source file> " << " chromosome-id " << endl;
        exit(-1);
        }
     char* filename;
	 char* chromid;
	 	 try{ 

	 if ((filename=new char[128])==NULL)
		 throw NoMemory();

 	 strcpy(filename, argv[1]);
	 	
	 if ((chromid=new char[3])==NULL)
		 throw NoMemory();

 	 strcpy(chromid, argv[2]);

	 


	 ConvertForHT(filename, chromid);



 

		 }

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (ErrorFile ef) {
		 ef.PrintMessage();}
	 catch (BadFormat bf) {
		 bf.PrintMessage();}


        delete filename, chromid;

   return 0;

}





