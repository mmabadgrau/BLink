R CMD BATCH DPrimeSimulations.r result

