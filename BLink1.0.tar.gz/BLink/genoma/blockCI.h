/* File: block.h */


#ifndef __blockCI_h__
#define __blockCI_h__

//#include <string.h>
//#include <cstdio>

#include "../commonc++/Fachade.h"
#include "BlockList.h"
//#include "DiagonalTable.h"

#include "Genoma.h"

#define MinUpperStrongLD 0.98
#define MinLowerStrongLD 0.7
#define MinLowerStrongLD2SNPs 0.8
#define MinLowerStrongLD3SNPsEuropeanAsian 0.5
#define MinLowerStrongLD3SNPsYorubanAfricanA 0.75
#define MaxUpperStrongRecombination 0.9
#define MinStrongOverInformative 0.95


namespace BIOS {


/************************/
/* block SNP*/
/************************/


/**
        @memo block

	@doc
        Definition:
        An array SampleValues of Size values

        Memory space: O(size). 

        @author Maria M. Abad
	@version 1.0
*/
 class blockCI : public BlockList
 {

 

protected:
    /** @name Implementation of class block
        @memo Private part.
    */
Positions* Pos;
	typedef struct Counters
	{
	SNPPos TotalStrongLD;
	SNPPos TotalStrongRecombination;
	SNPPos TotalInconclusive;
	SNPPos TotalChecked;
	};

	DiagonalTable<Counters> *TableCounters;
	DiagonalTable<float> *UpperBound, *LowerBound;

    bool EuropeanOrAsian;

	Positions* poss;

	Block GetMaxBlock(SNPPos FirstPos, SNPPos LastPos);

	void AddBlock(SNPPos FirstPos, SNPPos LastPos);

	struct Counters GetCounters(SNPPos SNP, SNPPos SNP2, struct Counters ci, SNPPos TotalSNPs);


	void InitializeTableCounters();


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
/* PUBLIC FUNCTIONS (INTERFACE) */

    public:

	blockCI(Positions *Pos, DiagonalTable<float> * UpperB, DiagonalTable<float> * LowerB, SNPPos TotalS, float MaxW, bool EurOrAs, bool *UsedSNPs);

	~blockCI(){if (TableCounters!=NULL) delete TableCounters;};


};  // End of class block



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

/*______________________________________________________________________________*/

void blockCI::InitializeTableCounters()
{
TableCounters=new DiagonalTable<Counters>(TotalSNPs);
Counters c;
c.TotalStrongLD=0;
c.TotalStrongRecombination=0;
c.TotalInconclusive=0;
TableCounters->initialize(c);
}

/*______________________________________________________________________________*/

struct blockCI::Counters blockCI::GetCounters(SNPPos SNP, SNPPos SNP2, struct blockCI::Counters ci, SNPPos TotalSNPs)
{
Counters c=ci;
float upperbound, lowerbound;


float MinLowStrongLD;

switch (TotalSNPs)
{
 case 2: MinLowStrongLD=MinLowerStrongLD2SNPs; break;
 case 3: if (EuropeanOrAsian==true) MinLowStrongLD=MinLowerStrongLD3SNPsEuropeanAsian; 
		 else MinLowStrongLD=MinLowerStrongLD3SNPsYorubanAfricanA; break;
 default: MinLowStrongLD=MinLowerStrongLD; break;
}

//MinLowStrongLD=MinLowerStrongLD;

   upperbound=UpperBound->getValue(SNP, SNP2);
   lowerbound=LowerBound->getValue(SNP, SNP2);
   if (upperbound<=1.0  && lowerbound<=1.0) // Bounds have maxreal if this position is not used
   {
	c.TotalChecked++;
	if (upperbound>MinUpperStrongLD  && lowerbound>MinLowStrongLD) c.TotalStrongLD++;
	else if (upperbound<MaxUpperStrongRecombination) c.TotalStrongRecombination++;
	 	 else  c.TotalInconclusive++;
   }
 return c;
}
/*______________________________________________________________________________*/

Block blockCI::GetMaxBlock(SNPPos FirstPos, SNPPos LastPos)
{
//	cout <<"\nfirst:" <<FirstPos <<", last:" << LastPos;

Block BestBlock;
SNPPos Ini=FirstPos, End=FirstPos, TotalInformative;
float MaxRatio=0, ratio, distance;
SNPPos MaxChecked=0, TotalMarkers, MaxInformative=0;
Counters c;
BestBlock.IniPos=Ini;
BestBlock.LastPos=End;

for (SNPPos SNP=FirstPos; SNP<maxi(LastPos-1, FirstPos+1);SNP++)
if (ListUsedSNPs[SNP]==true)
{
 c.TotalStrongLD=0;
 c.TotalStrongRecombination=0;
 c.TotalInconclusive=0;
 c.TotalChecked=0;

 TotalMarkers=1;
 
 for (SNPPos SNP2=SNP+1; SNP2<=mini(LastPos, (SNPPos)(SNP+Pos->GetTotalSNPs(0, MaxWidth)-1));SNP2++)
 {
 distance=poss->GetDistance(SNP, SNP2-1); 

 if (distance<MaxWidth)
 if (ListUsedSNPs[SNP2]==true)
 {
 TotalMarkers++;
 if   ((TotalMarkers==2 && EuropeanOrAsian && distance<=20000.0)
	|| (TotalMarkers==2 && !EuropeanOrAsian && distance<=10000.0)
	|| (TotalMarkers==3 && EuropeanOrAsian && distance<=30000.0)
	|| (TotalMarkers==3 && !EuropeanOrAsian && distance<=20000.0)
	|| (TotalMarkers==4 && distance<=30000.0)
	|| (TotalMarkers>=5))
if (UpperBound->getValue(SNP, SNP2)>MinUpperStrongLD  && 
 LowerBound->getValue(SNP, SNP2)>MinLowerStrongLD) 
 {
  c=GetCounters(SNP, SNP2, c, TotalMarkers);
  TotalInformative=c.TotalStrongLD + c.TotalStrongRecombination;
  if ((TotalMarkers<=4 && c.TotalStrongLD==c.TotalChecked) || (TotalMarkers >4 && TotalInformative>=6))
  {
  if ((c.TotalStrongLD/(float)TotalInformative)>0.95 || TotalMarkers<5)
  if (c.TotalChecked>=MaxChecked)
  {
	MaxChecked=c.TotalChecked;
	Ini=SNP;
	End=SNP2;
  }
  }
  }
 }
 }
}

TotalMarkers=End-Ini+1;


//if ((TotalMarkers>=4 && MaxRatio>=MinStrongOverInformative) || MaxRatio==1.0)
{
BestBlock.IniPos=Ini;
BestBlock.LastPos=End;
//cout <<"\nSNP1: " << Ini <<", SNP2: " << End <<", lower: " <<LowerBound->GetValue(Ini, End) << ", upper: " << UpperBound->GetValue(Ini, End) 
//		<< ", low all:" << MinLowerStrongLD << ", upp allow:" << MinUpperStrongLD;

}
return BestBlock;
}
/*********************************************************************/
void blockCI::AddBlock(SNPPos FirstPos, SNPPos LastPos)
{
//if (LastPos<=FirstPos) cout <<"ERROR";

Block OneBlock=GetMaxBlock(FirstPos, LastPos);
//if (OneBlock.LastPos>OneBlock.IniPos)
{
insertElement(OneBlock);
//if (OneBlock.IniPos>=2)
if (FirstPos<(OneBlock.IniPos)) AddBlock(FirstPos,OneBlock.IniPos-1);
if (OneBlock.LastPos<(TotalSNPs-1))
if (LastPos>(OneBlock.LastPos)) AddBlock(OneBlock.LastPos+1, LastPos);
}
}
/*********************************************************************/


///////////////////
//// public ////////
///////////////////


blockCI::blockCI(Positions* Pos, DiagonalTable<float> * UpperB, DiagonalTable<float> * LowerB, SNPPos TotalS, float MaxW, bool EurOrAs=true, bool * UsedSNPs=NULL):BlockList()
{
this->Pos=Pos;
TableCounters=NULL;
ListUsedSNPs=&UsedSNPs[0];
poss=Pos;
EuropeanOrAsian=EurOrAs;
UpperBound=UpperB;
LowerBound=LowerB;
TotalSNPs=TotalS;
MaxWidth=MaxW;
//InitializeTableCounters();
AddBlock(0, TotalSNPs);
Order();
}

};  // End of Namespace

#endif

/* End of file: blockCI.h */




