  /**
    * @file HapBlocking.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method)
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "SNP.h"

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"


#include "block.h"
#include "blockCI.h"
#include "SNPAfter.h"


using namespace UTILS;
using namespace stats;

namespace BIOS 
{
char filename[128];
float Width=0.0;
bool EuropeanOrAsian=true;
/*****************/
void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <output file> "  
			<< " <MaxWidth> <IsEuropeanOrAsian (0: no, 1: yes)>" 
	 << endl;
        exit(-1);;  
        exit(-1);
        }
        

	 strcpy(filename, argv[1]);

	 if (argc>=3) Width=atof(argv[2]);
	 if (argc==4) EuropeanOrAsian=atoi(argv[3]);


}



} //end namespace
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
     
		 
//float **UpperBound, **LowerBound;

block * blocks;


char filepos[128], fileci[128];
Positions * Pos;

ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, fileci, "ci");
Pos=new Positions (filepos);
SNPPos TotalSNPs=GetTotalSNPs(filepos), SNPn;
bool found=false;
SNPPos SNPRange=TotalSNPs;
double distance=0;

if (Width==0.0 || Width>Pos->GetDistance(0, TotalSNPs-1)) 
{
	Width=Pos->GetDistance(0, TotalSNPs-1);
	SNPRange=TotalSNPs;
}
else
	for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
	{
	SNPn=SNP+1;
	found=false;
	while (!found && SNPn<TotalSNPs)
	{
	distance=Pos->GetDistance(SNP, SNPn);
	if (distance >= Width)
	{
		found=true;
		if ((SNPn-SNP)>SNPRange)
			SNPRange=SNPn-SNP;
	}
	SNPn++;
	}
	}




CoupleTable<float> UpperBound(TotalSNPs, SNPRange), LowerBound(TotalSNPs, SNPRange);
LowerBound.Initialization(2);
UpperBound.Initialization(2);
ifstream InputFile; 

try
{
 if (!ExistFile(fileci))
	 throw ErrorFile();
  InputFile.open (fileci, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
catch (EmptyFile EFile) {EFile.PrintMessage(fileci);}


	cout <<"Obtaining confidence intervals from file " << fileci << "...\n";
	bool ListUsedSNPs[TotalSNPs];
	for (SNPPos SNP=0;SNP<TotalSNPs;SNP++) 
 	 ListUsedSNPs[SNP]=false;


	SNPPos s=100, SNP, SNP2;
	char line[s];
	NextLine(&InputFile);
	if (InputFile.peek()!=EOF) 
	NextLine(&InputFile);
	float upperbound, lowerbound, DPrime;
	while (InputFile.peek()!=EOF) 
	{
	CaptureLine(&InputFile, line, s);
	sscanf(line, "%d%d%f%f%f", &SNP, &SNP2, &DPrime, &lowerbound, &upperbound);
	if ((SNP2-SNP)>SNPRange)
	{
		cout<<"error, range:" << SNPRange <<", snp:" << SNP <<", SNP2:" << SNP2;
		exit(0);
	}
	UpperBound.SetValue(SNP-1, SNP2-1, upperbound);
	LowerBound.SetValue(SNP-1, SNP2-1, lowerbound);
	ListUsedSNPs[SNP-1]=true;
	ListUsedSNPs[SNP2-1]=true;
	};
	cout <<"Confidence intervals have been obtained from file\n";


InputFile.close();

blockCI *blockCI1;

cout <<"Obtaining blocks...\n";
 
 if ((blockCI1 = new blockCI(Pos, &UpperBound, &LowerBound, TotalSNPs, Width, EuropeanOrAsian, &(ListUsedSNPs[0])))==NULL)
 throw NoMemory();

cout << blockCI1->GetSize() << " blocks have been obtained\n";
cout << blockCI1->GetSize() << " blocks have been obtained\n";


blockCI1->WriteBlocks(filename);

return 0;


}










