./CIHapmap.sh /home/mabad/hapmapJune2005/Yoruba/ YRI June 2005

