./GetLDDecayUnrelated data/crossover.gou 0 0 2 0 50000 40000
#mv data/crossover.ci data/crossoverMLE.ci
./GetLDDecayUnrelated  data/crossover.gou 0 4 2 0 50000 40000
#mv data/crossover.ci data/crossoverBDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover10.gou 0 0 2 0 50000 40000
#mv data/crossover10.ci data/crossover10MLE.ci
./GetLDDecayUnrelated data/crossover10.gou 0 4 2 0 50000 40000
#mv data/crossover10.ci data/crossover10BDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover5.gou 0 0 2 0 50000 40000
#mv data/crossover5.ci data/crossover5MLE.ci
./GetLDDecayUnrelated data/crossover5.gou 0 4 2 0 50000 40000
#mv data/crossover5.ci data/crossover5BDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover5-60.gou 0 0 2 0 50000 40000
#mv data/crossover5-60.ci data/crossover5-60MLE.ci
./GetLDDecayUnrelated data/crossover5-60.gou 0 4 2 0 50000 40000
#mv data/crossover5-60.ci data/crossover5-60BDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover5-120.gou 0 0 2 0 50000 40000
#mv data/crossover5-120.ci data/crossover5-120MLE.ci
./GetLDDecayUnrelated data/crossover5-120.gou 0 4 2 0 50000 40000
#mv data/crossover5-120.ci data/crossover5-120BDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover10-60.gou 0 0 2 0 50000 40000
#mv data/crossover10-60.ci data/crossover10-60MLE.ci
./GetLDDecayUnrelated data/crossover10-60.gou 0 4 2 0 50000 40000
#mv data/crossover10-60.ci data/crossover10-60BDistanceAlpha4.ci
./GetLDDecayUnrelated data/crossover10-120.gou 0 0 2 0 50000 40000 
#mv data/crossover10-120.ci data/crossover10-120MLE.ci
./GetLDDecayUnrelated data/crossover10-120.gou 0 4 2 0 50000 40000
#mv data/crossover10-120.ci data/crossover10-120BDistanceAlpha4.ci

