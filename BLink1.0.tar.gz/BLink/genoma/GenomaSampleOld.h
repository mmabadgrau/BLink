
/* File: GenomaSample.h */

//#include <string>
//#include <math.h>
//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include <cstdio>//
//#include <cmath>//



#ifndef __GenomaSample_h__
#define __GenomaSample_h__

#include "Exceptions.h"

#include "basic.h"
#include "SNP.h"
#include "Diplotype.h"
#include "Phenotype.h"
#include "Genotype.h"
#include "Genoma.h"
#include "CoupleGenotype.h"
#include "GenotypeSample.h"
#include "PhenotypeSample.h"
#include "Trio.h"

//#include "RepeatedGenomaSample.h"
     
        



namespace BIOS {


class GenomaSample: public PhenotypeSample, public GenotypeSample
//class GenomaSample: public list<Genoma>
 
 {
	 
       //  public:


    /** @name Implementation of class GenomaSample
        @memo Private part.
    */




  private:

 
  unsigned long int GetTotalHomozygousType (SNPPos SNP, unsigned short int typ, IndCategory ic);



/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////

  GenotypeSample::NodePointer GetGenotype (PhenotypeSample::NodePointer);

  Trio GetTrioMembers (GenotypeSample::NodePointer IndGenotype, PhenotypeSample::NodePointer IndPhenotype);


  /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by individual.
           Time complexity O(1).

      */
	  ~GenomaSample ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
	
	  GenomaSample(GenomaSample& source, IndPos *Sampling, IndPos size);

 

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

//		GenomaSample(char* filename, unsigned short int ReduceSample, bool CompleteMissing, AlleleOrderType AlleleOrderMode);

		GenomaSample(char* filename, IndCategory ic, bool CompleteMissing, AlleleOrderType AlleleOrderMode);

		void CheckInconsistenciesFromParents ();

		void CompleteMissingFromParents ();

		void WriteResults (char* filename, bool PrintPhenotypes, IndCategory ic);

		unsigned long int GetTotalType (unsigned long int SNP, IndCategory ic, GenotypeType type);

		unsigned long int GetTotalHomozygous1 (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalHomozygous2 (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalHeterozygous (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalMissing (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalNonMissing (unsigned long int SNP, IndCategory ic);


		SNPPos GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic);

		SNPPos GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool IsPartiallySolved);

		SNPPos GetTotalAllele (SNPPos SNP, bool IsMajor, IndCategory ic);

		//void ComputeHaps (hprobs probs, SNPPos SNP1, SNPPos SNP2, LDType mode, bool Semi, unsigned short int Bayes);

		SNPPos GetHap (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic, bool IsMajor1, bool IsMajor2, bool IsPartiallySolved);

		SNPPos GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic);

		SNPPos GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic);

		SNPPos GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic);
		
		SNPPos Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic);

		void SetFamilyPointers();

		void CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic);

	
		};  // End of class GenomaSample





/*____________________________________________________________ */
// copy individuals at positions in Samplong (they can be repeated)
GenomaSample::GenomaSample(GenomaSample& source, IndPos *Sampling=NULL, IndPos size=0): 
PhenotypeSample(source), 
GenotypeSample(source, Sampling, size)
{
};
/*____________________________________________________________ */

GenomaSample::GenomaSample(char* filename, AlleleOrderType AlleleOrderMode=MajorFirst): 
				PhenotypeSample(filename), 
				GenotypeSample(filename, true, AlleleOrderMode)
{
};
/*___________________________________________________________ */
/*
void GenomaSample::SetFamilyPointers()
{
 GenotypeSample::NodePointer g=GenotypeSample::GetFirst(), g1, g2;
 Genotype *G;
 PhenotypeSample::NodePointer p=PhenotypeSample::GetFirst(), p1, p2;
 Phenotype *P;

 while (p!=NULL && g!=NULL)
 {
  G=(Genotype*)g;
  P=(Phenotype*)p;
  if (P->IsAChild())
  {
	  p1=GetFather(p);
	  p2=GetMother(p);
  }
  else
  {
	  p1=GetCouple(p);
	  p2=GetFirstChild(p);
  }
  if (&p1==&p2) 
  {
	  cout <<"error in PhenotypeSample::SetFamilyPointers()";
	  exit(0);
  }
  g1=GetGenotype(p1);
  g2=GetGenotype(p2);
  G->LinkGenotype(g1,g2);
  p=PhenotypeSample::GetNext(p);
  g=GenotypeSample::GetNext(g);
  }
}/*____________________________________________________________ */

void GenomaSample::WriteResults (char* filename, bool PrintPhenotypes=true, IndCategory ic=everybody)
 {
  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
  Genotype* genotype;
  ofstream OutputFile; 

  SNPPos TotalSNPs=GetTotalSNPs();
  try
{
	  OutputFile.open (filename, ifstream::out);
	 if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
Phenotype P;
while (IndPhenotype!=NULL && IndGenotype!=NULL)
  {
	P=PhenotypeSample::GetElement(IndPhenotype);
	 if ((ic==offspring && P.IsAChild ()) || (ic==parent && P.IsAParent ()) 
	 || (ic==everybody) || (ic==father && P.IsAFather()) || (ic==mother && P.IsAMother()))
	 {
   if (PrintPhenotypes==true) OutputFile <<	PhenotypeSample::GetElement(IndPhenotype).PrintPhenotype();
   genotype=(Genotype*)IndGenotype;
   for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
	 //  if (SNP==53 || SNP==54)
   OutputFile << genotype->PrintGenotype(SNP);     
   OutputFile << "\n";
	 }
   IndGenotype=GenotypeSample::GetNext(IndGenotype);
   IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
  OutputFile.close();

cout << "\nInformation about phased genotype has been saved in file " << filename <<"\n";
 }


/*__________________________________________________________*/

unsigned long int GenomaSample::GetTotalType (unsigned long int SNP, IndCategory ic, GenotypeType type)
{
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
Phenotype* phenotype;
Genotype* genotype;
Diplotype Dip;
unsigned long int Total=0;
while (IndGenotype!=NULL && IndPhenotype!=NULL)
{
	
 phenotype=(Phenotype*)IndPhenotype;
 genotype=(Genotype*)IndGenotype;
 Dip=genotype->GetDiplotype(SNP);
 if ((ic==offspring && phenotype->IsAChild ()) || (ic==parent && phenotype->IsAParent ()) 
	 || (ic==everybody) || (ic==father && phenotype->IsAFather()) || (ic==mother && phenotype->IsAMother()))
 switch (type)
 {
 case missing: if (Dip.IsAMissingSNP ()) Total++; break;
 case homozygous1: if (Dip.IsHomozygous1(MajorAllele[SNP])) Total++; break;
 case homozygous2: if (Dip.IsHomozygous2(MajorAllele[SNP])) Total++; break;
 case heterozygous: if (Dip.IsHeterozygous(MajorAllele[SNP])) Total++; break;
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}
return Total;
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHomozygous1 (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, homozygous1));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHomozygous2 (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, homozygous2));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHeterozygous (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, heterozygous));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalMissing (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, missing));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalNonMissing (unsigned long int SNP, IndCategory ic)
{
	return GetTotalHomozygous1 (SNP, ic)+GetTotalHomozygous2(SNP, ic)+GetTotalHeterozygous(SNP, ic);
}
/*__________________________________________________________*/

SNPPos GenomaSample::GetTotalAllele (unsigned long int SNP, bool IsMajor, IndCategory ic)
{
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
Phenotype* phenotype;
Genotype* genotype;
Diplotype Dip;
SNPPos Total=0;
while (IndPhenotype!=NULL && IndGenotype!=NULL)
{
 if (IndPhenotype==NULL) throw NullValue();
 phenotype=(Phenotype*)IndPhenotype;
 genotype=(Genotype*)IndGenotype;
 Dip=genotype->GetDiplotype(SNP);
 if ((ic==offspring && phenotype->IsAChild ()) || (ic==parent && phenotype->IsAParent ()) 
	 || (ic==everybody) || (ic==father && phenotype->IsAFather()) || (ic==mother && phenotype->IsAMother()))
 switch (IsMajor)
 {
 case true: 
//	 cout << Dip.PrintDiplotype() <<"major:" << MajorAllele[SNP];
	 if (Dip.IsHomozygous1(MajorAllele[SNP])) Total=Total+2; 
	if (Dip.IsHeterozygous(MajorAllele[SNP])) 
				Total++; break;
 case false:
	 if (Dip.IsHomozygous2(MajorAllele[SNP])) Total=Total+2;
	if (Dip.IsHeterozygous(MajorAllele[SNP])) 
				Total++; break;
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}
 //cout <<"Total:" << Total;
return Total;
}
/*____________________________________________________________ */

GenotypeSample::NodePointer GenomaSample::GetGenotype (PhenotypeSample::NodePointer p)
{
 return GenotypeSample::GetNode(PhenotypeSample::GetPos(p));
}

/*____________________________________________________________ */

SNPPos GenomaSample::GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody)
{
SNPPos Total=0;
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
Phenotype * P;
Genotype * G;
while (IndGenotype!=NULL && IndPhenotype!=NULL)
{
	P=(Phenotype*)IndPhenotype;
 if ((ic==offspring && P->IsAChild()) || (ic==parent && P->IsAParent()) || (ic==everybody))
 {
 G=(Genotype*)IndGenotype;
 if (G->IsHeterozygousHeterozygous (FirstSNP, LastSNP, MajorAllele)) Total=Total+1; 
 }
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 }
return Total;
}
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody, bool IsPartiallySolved=true)
{
SNPPos Total=0;
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
Phenotype P;
Genotype *FatherGenotype, *MotherGenotype, *ChildGenotype, *G;
Genoma GE;
TrioGenotype *Trio;

while (IndGenotype!=NULL && IndPhenotype!=NULL)
{
 G=GenotypeSample::GetElement(IndGenotype);
 P=PhenotypeSample::GetElement(IndPhenotype);
 GetTrioMembers(FatherGenotype, MotherGenotype, ChildGenotype, IndGenotype, IndPhenotype);
 Trio=new TrioGenotype(FatherGenotype, MotherGenotype, ChildGenotype);
 GE=Genoma(G, &P, *Trio);
 if ((ic==offspring && P.IsAChild()) || (ic==parent && P.IsAParent()) || (ic==everybody))
 {
 G=GenotypeSample::GetElement(IndGenotype);
 if (G->IsHeterozygousHeterozygous (FirstSNP, LastSNP, MajorAllele)) 
 {
  if (GE.CanBeSolved (FirstSNP, LastSNP, MajorAllele, IsPartiallySolved)==false)     
	 Total=Total+1; 
 
 }
 }
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 }
 
return Total;
}

/*____________________________________________________________ */

Trio GenomaSample::GetTrioMembers (GenotypeSample::NodePointer IndGenotype, PhenotypeSample::NodePointer IndPhenotype)
{
 Phenotype*P=(Phenotype*)IndPhenotype;
 Genotype *G=(Genotype*)IndGenotype;
 Trio T;
  if (P->IsAChild())
  {
  T.SetChildPhenotype(P);
  T.SetChildGenotype(G);
  T.SetFatherPhenotype((Phenotype*)GetFather(IndPhenotype));
  T.SetFatherGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetFatherPhenotype())));
  T.SetMotherPhenotype((Phenotype*)GetMother(IndPhenotype));
  T.SetMotherGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetMotherPhenotype())));
  }
  if (P->IsAFather()) 
  {
  T.SetFatherPhenotype(P);
  T.SetFatherGenotype(G);
  T.SetChildPhenotype((Phenotype*)GetFirstChild(IndPhenotype));
  T.SetChildGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetChildPhenotype())));
  T.SetMotherPhenotype((Phenotype*)GetCouple(IndPhenotype));
  T.SetMotherGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetMotherPhenotype())));
  }
  if (P->IsAMother())
  {
  T.SetMotherPhenotype(P);
  T.SetMotherGenotype(G);
  T.SetChildPhenotype((Phenotype*)GetFirstChild(IndPhenotype));
  T.SetChildGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetChildPhenotype())));
  T.SetFatherPhenotype((Phenotype*)GetCouple(IndPhenotype));
  T.SetFatherGenotype((Genotype*)GenotypeSample::GetNode(PhenotypeSample::GetPos((PhenotypeSample::NodePointer)T.GetFatherPhenotype())));
  }
  return T;
}
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetHap (SNPPos FirstSNP, SNPPos LastSNP, IndCategory ic=everybody, bool IsMajor1=true, bool IsMajor2=true, bool IsPartiallySolved=true)
{
Genoma GE;
SNPPos Total=0;
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype *FatherGenotype, *MotherGenotype, *ChildGenotype, *G;
TrioGenotype Trio;
Phenotype P;
//Genotype genotype;
while (IndGenotype!=NULL && IndPhenotype!=NULL)
{

 P=PhenotypeSample::GetElement(IndPhenotype);
 G=GenotypeSample::GetElement(IndGenotype);
 Trio=GetTrioMembers(IndGenotype, IndPhenotype);
 GE=Genoma(G, &P, *(Trio->TrioGenotype));
 if ((ic==offspring && P.IsAChild()) || (ic==parent && P.IsAParent()) || (ic==everybody))
  Total=Total+GE.GetHap(FirstSNP, LastSNP, IsMajor1, IsMajor2, MajorAllele, IsPartiallySolved);  
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 }
return Total;
}
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnAB(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, true, true);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnAb(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, true, false);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::GetnaB(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, false, true);
};  
/*____________________________________________________________ */
/*
SNPPos GenomaSample::Getnab(SNPPos SNP1, SNPPos SNP2, IndCategory ic)
{
return GetHap(SNP1, SNP2, ic, false, false);
};  
/*____________________________________________________________ */

void GenomaSample::CountAlleles (SNPPos SNP, unsigned int Basis[5], IndCategory ic=parent)
{
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();

for (int c=0;c<=4;c++) Basis[c]=0;

Genotype * genotype;
Phenotype *phenotype;
while (IndGenotype!=NULL && IndPhenotype!=NULL)
{
 phenotype=(Phenotype*)IndPhenotype;
 if ((ic==offspring && phenotype->IsAChild()) || (ic==parent && phenotype->IsAParent()) || (ic==everybody))
 {
 genotype=(Genotype*)IndGenotype;
// cout <<  genotype->GetDiplotype(SNP).PrintDiplotype();
// cout <<"cont:" << cont;
 Basis[(int)genotype->GetLeftAllele(SNP)]++; 
 Basis[(int)genotype->GetRightAllele(SNP)]++; 
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);

}

unsigned int TotalUsed=0;
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0) TotalUsed++;    
try
{
 if (TotalUsed>2)
 throw MultiAllelic();
}
catch (MultiAllelic ma) {ma.PrintMessage(SNP);}
}
/*____________________________________________________________ */

GenomaSample::~GenomaSample ()
{
}

};  // Fin del Namespace

#endif

/* Fin Fichero: GenomaSample.h */
