  /**
    * @file PhaseChecker.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "PhaseChecker.h"
//#include "hapmap.h"
//#include "PhaseResolver.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

unsigned int HapMapProcessing(char *filename, char* filephenotypes, char*filename2, unsigned int Size)
{


hapmap *HapMap;
if ((HapMap = new hapmap(filename, Size))==NULL)
 throw NoMemory();


HapMap->ProcessHapmap(filephenotypes, filename2);
cout << "\nOutput file: " << filename2 <<"\n";
cout << "\nNumber of SNPs: " << HapMap->GetTotalSNPs() <<"\n";
return HapMap->GetTotalSNPs();
}

/* _____________________________________________________*/

void GenomaProcessing(char *filename, char* filenameacc, unsigned int TotalSNPs, unsigned int Size)
{

char * filename2, *filename3, *filepos;
//strcpy(filename2, filename);
genoma *Sample, *SampleTrivial;
// phase will be resolved only for offspring
IndCategory ic=(IndCategory)1; 
// phenotypes are setup as all children if !ExistPhenotype holds for the sample at filename

/*
to show distances versus errors (Paola)

 if ((filepos=new char[64])==NULL)
		 throw NoMemory();

	 strcpy (filepos, filename);
	 strtok(filepos, ".");
	 strcat (filepos, ".poo\0");


if ((Sample = new genoma(filename, filepos, TotalSNPs, Size, true, ic))==NULL)
 throw NoMemory();

Sample->OrderPositions();
*/

if ((Sample = new genoma(filename, TotalSNPs, Size, true, ic))==NULL)
 throw NoMemory();


if ((SampleTrivial = new genoma(*Sample, ic))==NULL)
 throw NoMemory();


Sample->ResolveTrivialPhase();

Sample->ResolveParentPhaseGivenChildren(); 


Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;

bool *MustBeResolved, *BadResolved;

if ((MustBeResolved=new bool[Size*genotype::TotalSNPs])==NULL)
      throw NoMemory();

if ((BadResolved=new bool[Size*genotype::TotalSNPs])==NULL)
      throw NoMemory();

SampleTrivial->ResolvePhase((IndCategory)0);

Sample->SetKnownPhases(MustBeResolved, SampleTrivial.TheFirstGenotype, (IndCategory)0);

Sample->SetBadResolvedPhases(MustBeResolved, Unresolved, BadResolved, SampleTrivial.TheFirstGenotype, (IndCategory)0);

if ((filename2=new char[64])==NULL)
 throw NoMemory();

strcpy (filename2, filename);
filename2=strtok(filename, ".");
strncat(filename2, ".rec\0", 4);//

Sample->PrintRecombinationIntervals(BadResolved, filename2);

delete filename2;
}




}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc!=5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <ficheroacc> " << " <#individuals>" << " <#SNPs>" << endl;
        exit(-1);
        }
     char* filename;
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filename, argv[1]);

		 char* filenameacc;
	 if ((filenameacc=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filenameacc, argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int TotalSNPs=atoi(argv[4]);

	 try{ 

		GenomaProcessing (filename, filenameacc, TotalSNPs, TotalIndividuals);

		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (NullValue nv) {
		 nv.PrintMessage();}

 
	delete filename;

   return 0;

}





