



#include "FachadeGenoma.h"





using namespace BIOS;

int main(int argc, char*argv[]) 
{

char line[100];
if(argc<2)
     {
        cerr << "Error: you have to especify the name of the file in post-makeped format\n" << endl;
        exit(-1);
        }
  float alpha=90;
  char filename[256], filepos[256], filename2[256], filenameReduced[256], ext[128];;
  strcpy (filename, argv[1]);
  float MAF=0;
  BayesType BayesMode=BDistanceUniform;
  IndCategory ic= parent;
  bool IsPartiallySolved=true;
  SNPPos size=1000;
  unsigned int nHH;
  double upperbound, lowerbound;

  
  
strcpy(ext, "\0");



if (BayesMode==MLE)
sprintf(ext, "%sMAF%d-MLE.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceUniform)
sprintf(ext, "%sMAF%d-BDistanceUniform.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceSymmetrical)
sprintf(ext, "%sMAF%d-BDistanceSymmetrical.pm", ext, (int)(MAF*100));
  
  
ChangeExtension (filename, filename2, ext);

try
{
  OutputFile.open (filename2, ofstream::out);
  if (!OutputFile) throw ErrorFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
TrioSample *ts;
AlleleOrderType AlleleOrderMode=MajorFirst;
//GenomaSample *gs;
Positions* Pos;
Table2x2 T2x2;
ChangeExtension (filename, filepos, "pou");
float distance;
Pos=new Positions (filepos);
ts=new TrioSample (filename, AlleleOrderMode);


float alphaBayes=4;
bool onlyConsecutives=false;
bool Phase=false; // phase partially solved
bool invariant=false;
double firstPosition=0, lastPosition=0;
float MaximumDistance=500000;
bool basic=true;


PairwiseMeasuresResults<TrioSample> *PM=NULL;

PM=new PairwiseMeasuresResults<TrioSample>(filename, MAF, BayesMode, alphaBayes, onlyConsecutives, ic, Phase, AlleleOrderMode, alpha, invariant, firstPosition, lastPosition);
PM->PrintClassicPairwisesMeasures(filename2, false, MaximumDistance, basic); 

zap(PM);











/*

OutputFile << PrintHeading();
double fAB, fA, fB, DPrime, MaxDPrime;
SNPPos SNP2, TotalSNPs=ts->GetTotalSNPs(), total;

TriosPairwiseMeasure *PM;
TriosMonolociMeasure MM = TriosMonolociMeasure(ts, (BayesType)0, ic);

for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 if (ts->GetTotalMissing(SNP, ic)==0) 
  if (MM.GetTotalFreqAllele(SNP, false)>MAF) 
  {
 if (SNP%100==0)
 cout <<"\nsnp:" << SNP+1;
 for (SNPPos SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
  if (ts->GetTotalMissing(SNP2, ic)==0) 
   if (MM.GetTotalFreqAllele(SNP2, false)>MAF) 
 {
distance=Pos->GetDistance(SNP, SNP2);
if (distance<500000)
{
 PM = new TriosPairwiseMeasure(SNP, SNP2, ts, BayesMode, ic, IsPartiallySolved, distance);
 fA=PM->GetfA();
 fB=PM->GetfB();
 fAB=PM->GetfAB();
 DPrime=T2x2.GetDPrime(fAB, fA, fB);
 OutputFile 
	 << SNP+1 << ", " << Pos->PrintPosition(SNP)  << ", ";
 OutputFile
	 << SNP2+1 << ", " << Pos->PrintPosition(SNP2)  << ", " 
   	 << ts->GetTotalAllele(SNP, true, ic) << ", " 
   	 << ts->GetTotalAllele(SNP, false, ic) << ", " 
   	 << ts->GetTotalAllele(SNP2, true, ic) << ", " 
  	 << ts->GetTotalAllele(SNP2, false,  ic) << ", " 
	 << ts->GetUnsolvedDoubleHeterozygous(SNP, SNP2, ic, IsPartiallySolved) << ", "
	 << PM->GetnAB() <<", "
 	 << PM->GetnAb() <<", "
	 << PM->GetnaB() <<", "
	 << PM->Getnab() <<", "
	 << fA <<", "
 	 << fB <<", "
	 << fAB <<", "
	 << T2x2.GetD(fAB, fA, fB) <<", "
	 << T2x2.GetMaxD(fAB, fA, fB) <<", ";
	sprintf(line, "%1.2f, ", DPrime);
	OutputFile << line;
	OutputFile << line; 
 sprintf(line, "%1.2f, %1.2f\n", T2x2.GetR2(fAB, fA, fB), T2x2.GetQ(fAB, fA, fB));
 OutputFile << line;
} //if in distance
  } // end for each SNP2 a real SNP
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise measures has been saved in file " << filename2 <<"\n";
 
 OutputFile.close();
*/
   return 0;

};

