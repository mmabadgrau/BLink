  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "PhaseResolver.h"

using namespace UTILS;
using namespace stats;


/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) 
{

if(argc<2)
{
 cerr << "Error: you have to specify the following information:" << endl;
 cerr  << argv[0] << " <input file> "  << " <ExistPhenotype (0/1)> ";  
 exit(-1);
}
char filename[128], filename2[128], filepos[128];
        
strcpy(filename, argv[1]);

bool ExistPhenotype=false;
if (argc==3)  ExistPhenotype=argv[2];
else ChangeExtension(filename, filename2, "hap\0");
 
PhaseResolver *PhasedSample;
Positions* Pos;
//cout << "file:" << filename;

ChangeExtension (filename, filepos, "pou");
//cout << "file:" << filepos;
Pos=new Positions (filepos);


Pos=new Positions (filepos);

ts=new TrioSample (filename);

double fAB, fA, fB, DPrime, MaxDPrime;
SNPPos SNP2, TotalSNPs=ts->GetTotalSNPs(), total;

PairwiseMeasure<TrioSample> *PM;
MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(ts, (BayesType)0, ic);

unsigned short int MajorPhase;
SNPPos LastResolved, TotalSNPs=GetTotalSNPs(), SNP;
cout << "\nReconstructing haplotypes...";

NodePointer IndGenotype=GenotypeSample::GetFirst();
NodePointer IndPhenotype=PhenotypeSample::GetFirst();

Genotype* G;
Phenotype P;

unsigned short int Phase=0;
bool IsAnOrderedPhase;
while (IndGenotype!=NULL && IndPhenotype!=NULL)
{
  G=GetElement(IndGenotype);
  LastResolved=G->GetFirstHeterozygous(MajorAllele);
  SNP=LastResolved+1;
  while (SNP<TotalSNPs)
  {
   if (G->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) 
   {
   if (PhaseMode==dHap) Phase=AssignPhase (LastResolved, SNP);
   if (PhaseMode==NR) Phase=AssignPhaseNR (LastResolved, SNP, IndGenotype);
   IsAnOrderedPhase=G->IsMajorMajor(MajorAllele[LastResolved], MajorAllele[SNP], G->GetDiplotype(LastResolved), G->GetDiplotype(SNP));
   if ((Phase==1 && !IsAnOrderedPhase) || (Phase==2 && IsAnOrderedPhase)) 
  //if (!IsAnOrderedPhase)
    G->ChangeAlleles(SNP);
   LastResolved=SNP;
   } //end for each hetero SNP
   SNP++;
  } // for each SNP
 IndGenotype=GetNext(IndGenotype);
} // end for each individual
cout << "\nReconstruction has finished";

PhasedSample->PrintHaplotypes(filename2);


}








