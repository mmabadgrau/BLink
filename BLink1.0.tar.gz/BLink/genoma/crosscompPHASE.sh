rm crosscomp
echo crosscomp
../ChangeFormat i PHASE cross50PHASE.out cross50.pha cross50.txt 1 100 50
../ChangeFormat i PHASE cross100PHASE.out cross100.pha cross100.txt 1 100 50
../ChangeFormat i PHASE cross150PHASE.out cross150.pha cross150.txt 1 100 50
../ChangeFormat i PHASE cross200PHASE.out cross200.pha cross200.txt 1 100 50
../ChangeFormat i PHASE cross250PHASE.out cross250.pha cross250.txt 1 100 50
../ChangeFormat i PHASE cross300PHASE.out cross300.pha cross300.txt 1 100 50
../ChangeFormat i PHASE cross350PHASE.out cross350.pha cross350.txt 1 100 50
../ChangeFormat i PHASE cross400PHASE.out cross400.pha cross400.txt 1 100 50
../ChangeFormat i PHASE cross450PHASE.out cross450.pha cross450.txt 1 100 50
../ChangeFormat i PHASE cross500PHASE.out cross500.pha cross500.txt 1 100 50
../ChangeFormat i PHASE cross550PHASE.out cross550.pha cross550.txt 1 100 50
../ChangeFormat i PHASE cross600PHASE.out cross600.pha cross600.txt 1 100 50
echo Phase checker
../PhaseCheckerComparingSamples cross50.pha cross50.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross100.pha cross100.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross150.pha cross150.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross200.pha cross200.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross250.pha cross250.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross300.pha cross300.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross350.pha cross350.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross400.pha cross400.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross450.pha cross450.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross500.pha cross500.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross550.pha cross550.txt crosscompP 50 100 0
../PhaseCheckerComparingSamples cross600.pha cross600.txt crosscompP 50 100 0
echo Phase checker accuracy distance
../PhaseCheckerComparingSamples cross50.pha cross50.txt crosscompP 50 100 1 
../PhaseCheckerComparingSamples cross100.pha cross100.txt crosscompP 50 100 1 
../PhaseCheckerComparingSamples cross150.pha cross150.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross200.pha cross200.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross250.pha cross250.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross300.pha cross300.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross350.pha cross350.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross400.pha cross400.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross450.pha cross450.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross500.pha cross500.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross550.pha cross550.txt crosscompP 50 100 1
../PhaseCheckerComparingSamples cross600.pha cross600.txt crosscompP 50 100 1
exit 0
