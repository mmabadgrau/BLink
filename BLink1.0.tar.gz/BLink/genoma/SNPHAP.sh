cd /home/mar/genoma/data
echo convert to PHASE format
../ChangeFormat e PHASE crohn.txt crohnPHASE.inp 1 103 387
home/mar/phase/phase.2.0.2.linux/PHASE -n -f1 -k crohnPHASE.inp crohnforphase.inp crohnPHASE.out
../ChangeFormat i PHASE crohnPHASE.out crohnPHASE.txt
../PhaseResolver crohnPHASE 387
../PhaseChecker  crohnPHASE 
