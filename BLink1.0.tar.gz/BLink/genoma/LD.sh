./PhaseResolver data/genotypes_chr21.gen 16511 90 1 0 1 1 1700000 1600000 50000 0.05 

