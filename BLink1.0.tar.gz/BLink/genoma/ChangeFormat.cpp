  /**
    * @file ChangeFormat.cpp
    * @brief Program to change formats in genotype files
	* @example ChangeFormat e PHASE chrom1.red chrom1PHASE.inp c1 1 100 90
	* convert a file called chrom1.red in our format to PHASE format (e means "export"). The target file will be
    * called chrom1PHASE.inp. File c1 is a reference file. The origen file contains phenotypr information (1). 
	* The origen has 200 loci and 90 individuals. 
    */


#include <iostream>
#include <cassert>
#include <fstream>

//#include "basic.h"
#include "ChangeFormat.h"
#include "PhaseResolver.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {


bool GetWay (char* Way)
{
	bool Export;
 if (strcmp(Way, "e\0")==0)
	  Export=true; // export
	 else
	 if (strcmp(Way,  "i\0")==0)
	  Export=false; // inport
	 else throw IncorrectWay();
return Export;
}

/*___________________________________________________________*/

unsigned short int GetCodeAlgorithm (char* Algorithm)
{
	unsigned short int Alg=0;
 if (strcmp(Algorithm, "PHASE\0")==0)
	  Alg=1; // Phase
	 else
	 if (strcmp(Algorithm, "SNPHAP\0")==0)
	  Alg=2; // SNPHAP
	 else
	 if (strcmp(Algorithm, "HTYPER\0")==0)
	  Alg=3; // HTYPER
	 else
	 if (strcmp(Algorithm, "BN\0")==0)
	  Alg=4; // BN
	 else
	 if (strcmp(Algorithm, "MSAMPLE\0")==0)
	  Alg=5; // MSAMPLE
	 else
	 if (strcmp(Algorithm, "HUDSON\0")==0)
	  Alg=6; // HUDSON
	 else
	 if (strcmp(Algorithm, "MAKEPED\0")==0)
	  Alg=7; // STANDARD LINKAGE PEDIGREE FORMAT, USED AS AN EXAMPLE, IN HAPLOVIEW
	 else throw IncorrectAlgorithm();
return Alg;
}
}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

	 srand(24226616);

	 unsigned int affected=1, MAF=0;

	 bool OnlyU=false, Bayes=false, OutputWay=false;

     if(argc<10)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " (e/i) " << " PHASE/SNPHAP/HTYPER/BN/MSAMPLE/HUDSON/MAKEPED " << " <source file> " 
			<< " <target file> " << " <reference file>" << " <ExistPhenotype (1/0)>" 
			<< " <# loci>" << " <SampleSize>" << " <onlyparents/onlychildren/all (0/1/2)>" 
			<< " <Bayes(only for Makeped)>"
			<< " <Initial pos>" << " <Length>"  << endl;
        exit(-1);
        }
     char* filename, *filename2, *filename4, filephenotypes[20]="pedigree.txt", *Way, *Algorithm;

	 	 try{ 

	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename2=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename4=new char[64])==NULL)
		 throw NoMemory();
	 if ((Way=new char[2])==NULL)
		 throw NoMemory();
	 if ((Algorithm=new char[20])==NULL)
		 throw NoMemory();
     strcpy(Way, argv[1]);
	 
     strcpy (Algorithm,argv[2]);
     unsigned int Alg; 
	 Alg=GetCodeAlgorithm (&Algorithm[0]);

	 bool Exist;
	 strcpy(filename, argv[3]);
	 strcpy(filename2, argv[4]);
 	 strcpy(filename4, argv[5]);


     unsigned short int ExistPhenotype= atoi(argv[6]); 

	 if (ExistPhenotype==0)
		 Exist=false;
	 else
	 if (ExistPhenotype==1)
		 Exist=true;
	 else throw NonBoolean();

	 unsigned int TotalSNPs=atoi(argv[7]);
     unsigned int Size=atoi(argv[8]);
	 
	 unsigned int Type=atoi(argv[9]);
	
	 long int InitialPos=-1;



	 if (argc>10)
		 InitialPos=atoi(argv[10]);
	
	 unsigned int Length=2;
	 if (argc==12)
		 Length=atoi(argv[11]);
   
	 genoma * Sample;
	 

	 
	 bool Export=GetWay (&Way[0]);

	 bool ComputeHaplotypes=false;


	 if ((Export) && (Alg!=5) && (Alg!=6))
	{



//PhaseType PhaseMode=Phased;

     if ((Sample = new genoma(filename, TotalSNPs, Size, Exist, ic, ComputeHaplotypes, 
		 IsPhased, MAF, affected, OnlyU, Bayes, OutputWay))==NULL)
     throw NoMemory();
 
	 if (Alg!=7)
	 {
	  Sample->OrderSNPs();// remove the phase information
	  cout <<"Total number of heterozygous:" << Sample->GetHeterozygousGenotypes();//obtain the total number of heterozygous positions
  	  }
//	 cout << "TotalSNPS:" << Sample->GetTotalSNPs();
	  Sample->ChangeFormat (filename2, NULL, Alg, Export, InitialPos, Length);

//      Sample->WriteResults(filename2);

	 } // end Export

	 if ((Alg==5) || (Alg==6)) // import from msample or Hudson
	 {

	  if ((Sample = new genoma(TotalSNPs, 0, false, IsPhased))==NULL)
	   throw NoMemory();
  	  Sample->ChangeFormat (filename, filename2, Alg, Export, InitialPos, Length);
	 }


	  if ((!Export) && (Alg!=5) && (Alg!=6))
	  {


         cout << "Uploading reference file " << filename4  << "\n";

		 if ((Sample = new genoma(filename4, TotalSNPs, Size, Exist, (IndCategory)2, ComputeHaplotypes, 
		 IsPhased, MAF, affected, OnlyU, Bayes, OutputWay))==NULL)
	   throw NoMemory();
	  if (Sample->IsHomozygous(Sample->GetGenotype(1), 7)) cout <<"ishomo"; else cout <<"Het";
		  Sample->OrderSNPs();
	  if (Sample->IsHomozygous(Sample->GetGenotype(1), 7)) cout <<"ishomo"; else cout <<"Het";

	  Sample->ChangeFormat (filename, NULL, Alg, Export, InitialPos, Length);
	  	  cout << Sample->GetHeterozygousGenotypes();
/*
		  RedType R=None;

		  bool *Selected=NULL;
		  int FirstSNP;
		  unsigned int RegionSize=;


		void WriteResults (char* filename, RedType R, bool* Selected, int FirstSNP, unsigned int RegionSize);


      Sample->WriteResults(filename2, R, Selected, (IndCategory)Type, );
	  */
	        Sample->WriteResults(filename2);

	  cout << "File " << filename2 << " created with dHAP format\n";
	 }


		 }

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (IncorrectAlgorithm ia) {
		 ia.PrintMessage();}
 	 catch (IncorrectWay iw) {
		 iw.PrintMessage();}
	  catch (NonBoolean nb) {
		 nb.PrintMessage();}	  
	  catch (ErrorFile ef) {
		 ef.PrintMessage();}
	delete filename, filename2, filename4, Way, Algorithm;

   return 0;

}





