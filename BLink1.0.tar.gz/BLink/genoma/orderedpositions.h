/* File: positions.h */

#ifndef __orderedpositions_h__
#define __orderedpositions_h__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//





#include "positions.h"


//using namespace std;
//using namespace string;

using namespace TAD;

namespace BIOS {


/************************/
/* positions DEFINITION */
/************************/

/**
        @memo positions for SNPs

	@doc
        Definition:
        This class is only used to remove repeated positions.

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in file.

        @author Maria M. Abad
	@version 1.0
*/

	class orderedpositions: public positions
	 {


		void CheckRepeated();


/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      /* PUBLIC FUNCTIONS (INTERFACE) */


      public:



      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		orderedpositions(char* filename); 


        void PrintUnrepeatedPositions(char * filename);


};  // End of class positions



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

orderedpositions::orderedpositions(char* filename): positions(filename)
{
if (strncmp(strtok(filename+2, ".")-2, "poo", 3)!=0)
{
	cout <<"File poo is required";
	exit (0);
}

GetInfo(filename);        
}

/*____________________________________________________________ */


void orderedpositions::PrintUnrepeatedPositions (char * filepos)
 {

 CheckRepeated();

  char* filepos2;

 if ((filepos2=new char[128])==NULL)
		 throw NoMemory();


 ChangeExtension (filepos2, filepos, "pou\0");
 

 PrintPositions(filepos2);

 
 }

/*____________________________________________________________ */

void orderedpositions::CheckRepeated()
{

SNPPos TotalSNPs=GetTotalSNPs(), i=0;

bool PosList[TotalSNPs], *p=PosList;

NodePointer IndPosition=GetFirst();

double Pos, OldPos;

while (IndPosition!=NULL)
{
 Pos=GetElement(IndPosition).pos;
 if (i>0 && (Pos==OldPos))
  PosList[i]=true;
 else PosList[i]=false;
 IndPosition=GetNext(IndPosition);   
 i++;
 OldPos=Pos;
}

 Remove(p);

}

};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
