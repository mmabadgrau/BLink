#ifndef __TrioSampling_h__
#define __TrioSampling_h__

//#include <string.h>
//#include <cstdio>

#include "Exceptions.h"
#include "basic.h"


using namespace UTILS;
//using namespace TAD;


namespace BIOS {

/*____________________________________________________________ */

IndPos SetBootstrapFrequencies(TrioSample * sample, double* DPrimeList, unsigned long int size, SNPPos SNP1, SNPPos SNP2, BayesType Bayes, IndCategory ic, const bool IsPartiallySolved=false)
{
Sampling * bootstrap;
Table2x2 T2x2;
IndPos Total=sample->GetTotalTrios(), totalused=0;
TrioSample* g;
double fA, fB, fAB;
InitializeList(DPrimeList, size, (double)2.0);
PairwiseMeasure<TrioSample> *PM;

for (int s=0; s<2;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();

g=new TrioSample(*sample, bootstrap->Pos, Total, MajorFirst);

//MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(g, (BayesType)0, ic);
if (g->GenotypeSample::GetTotalAllele(SNP1, false, NULL)>0)

//if (MM.GetTotalFreqAllele(SNP1, false)>0) 
{

PM = new PairwiseMeasure<TrioSample>(SNP1, SNP2, g, Bayes, ic, IsPartiallySolved);

fA=PM->GetfAx();
//fB=PM->GetfB();
//fAB=PM->GetfAB();
//DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
//delete PM;
}

//delete g;
//delete bootstrap;
}
return 0;
}
/*____________________________________________________________ */

IndPos SetBootstrapFrequencies(GenomaSample * sample, double* DPrimeList, unsigned long int size, SNPPos SNP1, SNPPos SNP2, BayesType Bayes, IndCategory ic, const bool IsPartiallySolved=false)
{
Sampling * bootstrap;
Table2x2 T2x2;
IndPos Total=sample->PhenotypeSample::GetSize(), totalused=0;
GenomaSample* g;
double fA, fB, fAB;
InitializeList(DPrimeList, size, (double)2.0);
PairwiseMeasure<GenomaSample> *PM;

for (int s=0; s<2;s++)
{
if ((bootstrap = new Sampling(Total, true))==NULL) // true allows repetitions
 throw NoMemory();

g=new GenomaSample(*sample, bootstrap->Pos, Total);

//MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(g, (BayesType)0, ic);
if (g->GetTotalAllele(SNP1, false, NULL)>0)

//if (MM.GetTotalFreqAllele(SNP1, false)>0) 
{
g->WriteResults("f");

PM = new PairwiseMeasure<GenomaSample>(SNP1, SNP2, g, Bayes, everybody, IsPartiallySolved);

PM->GetfAx();

//fB=PM->GetfB();
//fAB=PM->GetfAB();
//DPrimeList[s]=T2x2.GetDPrime(fAB, fA, fB);
totalused++;
//delete PM;
}

//delete g;
//delete bootstrap;
}
return 0; //totalused;
}
} // end makespace
#endif