/* File: positions.h */

#ifndef __positions_h__
#define __positions_h__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//





//#include "Exceptions.h"


//using namespace std;
//using namespace string;

using namespace TAD;

namespace SNP {


/************************/
/* positions DEFINITION */
/************************/


/**
        @memo positions for SNPs

	@doc
        Definition:
        A set of phenotype's features and genotypes for an positions

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in the sample
        Each positions in a sample has been genotyped for the same TotalSNPs SNPs.

        @author Maria M. Abad
	@version 1.0
*/

	class positions: public list <position>
	 {

  private:
    /** @name Implementation of class positions
        @memo Private part.
    */
  
  bool OrderedPositions;
  bool UnrepeatedPositions;
	  
  



/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


void ReadInfo (ifstream * origen, position *targetpos);

void copy(position * Target, const position * Origen);

void SetPositions (char* filepos);





      /* PUBLIC FUNCTIONS (INTERFACE) */




      public:



      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */
	/*  void WriteResults (char* filename);   */
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by positions.
           Time complexity O(1).

      */
	  ~positions ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */


  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		positions(const positions& origen); 


//	  positions(const phenotype& porigen, const genotype& gorigen, IndCategory ic);

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		positions(char* filename); 

		positions(SNPPos TotalSNPs); 

        void GetInfo(ifstream *InputFile);

		  
	  /**
         @memo Creates a new positions object with the phase resolved.
         @param Origen: the origianl positions object 
         Time complexity O(TotalSNPs*Size*Size)

      */
		 void OrderByPosition ();   


	 	bool IsOrdered ();   

        void PrintPositions(char * filename);

		double GetPosition (SNPPos SNP);
		
		SNPPos GetSNPUnordered(double PositionNumber);

		position* GetSNP(double PositionNumber);

		unsigned long int GetExtremeSNP(SNPPos Pos, SNPPos SlideSize);

		SNPPos GetTotalSNPs(position* IniPos, SNPPos SlideSize);

		SNPPos GetTotalSNPs();
		
		position* MoveToPos(position * IniPos, SNPPos Pos);

		bool IsANewSNP (SNPPos SNP);

       void SelectSNPsFromFile (char* filename);

	   SNPPos SelectSNPs (SNPPos TotalSelected, bool random, SNPPos InitialPos);

	   bool IsEndReached(position * IniPos, SNPPos Width);

	   bool OrderPositions();
  


};  // End of class positions



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

void positions::destroy(position * Position)
{
 if (Position != NULL)
 destroy (Position->Next);
 delete Position;
};


/*___________________________________________________________ */

void positions::ReadInfo (ifstream* origen, position *targetpos)
{

	char *genotypebuf, *cad;
    if ((genotypebuf=new char[20])==NULL)
     throw NoMemory();


     double pos;

do
{
  	origen-> getline (genotypebuf, 20, '\n');
	cad = strtok (genotypebuf," \t");
//        sscanf (cad, "%f", &pos);
        pos=atof(cad);
	targetpos->pos= pos;
	if (TotalSNPs>0)
	{
	if (pos<((targetpos->Previous)->pos))
	{
         Unordered=true;
	 //cout << "\ndesordenado, " << pos << "menor que " << (targetpos->Previous)->pos;
	}
        if (pos==((targetpos->Previous)->pos))
         targetpos->unrepeated=false;
        else targetpos->unrepeated=true;
	}
        else targetpos->unrepeated=true;
	targetpos->filepos=TotalSNPs;
	targetpos->selected=true;
    // cout <<"pos:" << TotalSNPs; 


	
	TotalSNPs++;
	if ((origen->peek()!=EOF) && (origen->peek()!='\n'))
	{
	if ((targetpos->Next=new position)==NULL)
     throw NoMemory();
	targetpos->Next->Previous=targetpos;
	targetpos=targetpos->Next;
    // ReadInfo (origen, targetpos->Next);
	}
	else
	 targetpos->Next=NULL;
    
}
while ((origen->peek()!=EOF) && (origen->peek()!='\n'));

	assert (genotypebuf!=NULL);
    delete genotypebuf;

}

/*___________________________________________________________ */

void positions::copy(position * Target, const position * Origen)
{

  Target->pos=Origen->pos;
  Target->filepos=Origen->filepos;


 		 
 if (Origen->Next!=NULL)
 {
  if ((Target->Next=new position)==NULL)
   throw NoMemory();

  Target->Next->Previous=Target;
  TotalSNPs++;

  copy(Target->Next,Origen->Next);     
 }  
 else Target->Next=NULL;
}



/*____________________________________________________________ */

void positions::GetInfo(ifstream *InputFile)
{

//cout <<"TS:" << TotalSNPs;
TotalSNPs=0;
cout << "Reading positions ...\n";


try {

if ((this->TheFirstPosition=new position)==NULL)
      throw NoMemory();

ReadInfo (InputFile,this->TheFirstPosition);

  }
catch (NoMemory no) {
  no.PrintMessage();
  }

/*
if (TotalSNPs != TotalS)
{
 cerr << "There are " << TotalSNPs <<" loci in the file but you have especified that the number is " << TotalS << "\n";
 exit(0);
}
*/

cout <<"Positions reading has finished\n";

};

///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

positions::positions(SNPPos TotalSNPs)
{
	Unordered=true;
};


/*____________________________________________________________ */

positions::positions(const positions& origen)
{
Unordered=false;	
TotalSNPs=0;

  if (&origen==NULL)
  TheFirstPosition=NULL; 


else 
{
 if ((TheFirstPosition=new position)==NULL)
   throw NoMemory();
try 
{
 copy (TheFirstPosition, origen.TheFirstPosition);
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}
}


if (TotalSNPs != origen.TotalSNPs)
{
 cerr << "There are " << origen.TotalSNPs <<" loci in the original sample but only " << TotalSNPs << " has been copied\n";
 exit(0);
}

 


cout <<"Positions copying has finished\n";


};



/*____________________________________________________________ */

positions::positions(char* filename)
{
UnrepeatedPositions=false;


char* filepos;

 if ((filepos=new char[128])==NULL)
		 throw NoMemory();


 
         strcpy (filepos, filename);
         strtok(filepos, ".");
         strcat (filepos, ".pos\0");

SetPositions(filepos);        

delete filepos;
}


/*____________________________________________________________ */

bool positions::IsOrdered ()
{
	return OrderedPositions;
}

/*____________________________________________________________ */

positions::~positions ()
{
	positions::destroy(TheFirstPosition);


}

/*____________________________________________________________ */

void positions::PrintPositions (char* filename)
 {
  FILE * OutputFile; 
  position *IndPosition=TheFirstPosition;

  if (filename[strlen(filename)-4]!='.')
  {
  cout <<"Error, file pos does not have a 3 char extension";
  exit(0);
  }

  char extension[4];
  strcpy(extension, filename+strlen(filename)-3);
  
//cout <<"unrep:" << UnrepeatedPositions << ", order:" << OrderedPositions << ", ext:" << extension; 
  /*
       if 
       (((OrderedPositions) && (UnrepeatedPositions) && (strncmp(extension, "pou", 3)!=0))
       ||
       ((OrderedPositions) && (!UnrepeatedPositions) && (strncmp(extension, "poo", 3)!=0))
       ||
       ((!OrderedPositions) && (!UnrepeatedPositions) && (strncmp(extension, "pos", 3)!=0)))
       {
        cout <<"\nError in positions::PrintPositions";
        exit(0);
       }
*/

       if ((!OrderedPositions)  && (strncmp(extension, "pos", 3)!=0))
              {
        cout <<"\nError in positions::PrintPositions";
        exit(0);
       }

  try
{
  OutputFile=fopen (filename, "w");
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

unsigned long int cont=0;
for (SNPPos i=0; i<TotalSNPs;i++)
{
     if ((IndPosition->unrepeated)==true)
      if ((IndPosition->selected)==true)
      {
   fprintf(OutputFile, "%.0f\n", IndPosition->pos);
   cont++;
   }
IndPosition=IndPosition->Next;
}
  
 fclose(OutputFile);

 }

/*____________________________________________________________ */

position* positions::GetFirst()
{

  if (TheFirstPosition==NULL) {
    throw NullValue();
	 return 0;
  }
  else {
  return TheFirstPosition;
  }
}

/*____________________________________________________________ */

position* positions::GetNext(const position *i)
{

  if (i==NULL) {
    throw NullValue();
	 return 0;
  }
  else {
  return i->Next;
  }
}
  /*____________________________________________________________ */

double positions::GetPosition(SNPPos SNP)
{
// SNP is the order number of the SNP
position *i=TheFirstPosition;
  try {
//while (i!=NULL)
//{
//i->Next;
//cont++;
//}

  for (SNPPos c=0;c<SNP;c++)
  {
   if (i==NULL)
    throw NullValue();
     i=i->Next;
 // cout << Pos;
  }
  }
  catch (NullValue null) {
    null.PrintMessage();
    }

 // return i->pos;
  return i->pos;
};
/*____________________________________________________________ */

SNPPos positions::GetSNPUnordered(double PositionNumber)
{
// SNP is the order number of the SNP
position *i=TheFirstPosition;
bool found=false;
SNPPos c=0;
  try {
	  while (c<TotalSNPs && (!found))
	  {
   if (i==NULL)
    throw NullValue();
   if (i->pos==PositionNumber)
	   found=true;
   else
   {
     i=i->Next;
	 c++;
   }
 // cout << Pos;
	  } // end while
  }
  catch (NullValue null) {
    null.PrintMessage();
    }

 // return i->pos;
  return c;
};
/*____________________________________________________________ */

position* positions::GetSNP(double PositionNumber)
{
// SNP is the order number of the SNP
position *i=TheFirstPosition;
bool found=false;
unsigned int c=0;
  try {
	  while (c<TotalSNPs && (!found))
	  {
   if (i==NULL)
    throw NullValue();
   if (i->pos==PositionNumber)
	   found=true;
   else
   {
     i=i->Next;
	 c++;
   }
 // cout << Pos;
  } // end while
  }
  catch (NullValue null) {
    null.PrintMessage();
    }

 // return i->pos;
  return i;
};
/*____________________________________________________________ */

unsigned long int positions::GetExtremeSNP(SNPPos SNP, SNPPos SlideSize)
{
//if extreme is before the SlideSize, returns the last position
position *i=TheFirstPosition;
  double InitialPos=GetPosition(SNP);
  SNPPos c;
  try {
  if (i==NULL)
     throw NullValue();


  for (c=0;c<SNP;c++)
  {
  if (i==NULL)
     throw NullValue();
     i=i->Next; 
  } 
  
  }
  catch (NullValue null) {
    null.PrintMessage();
 }
  
while ((i!=NULL) && (((i->pos)-InitialPos)<SlideSize))
{
 i=i->Next;
 if (i!=NULL)
 c++;

}

 
 // return i->pos;
  return c;
}
/*____________________________________________________________ */
SNPPos positions::GetTotalSNPs()
{
	return TotalSNPs;
}
/*____________________________________________________________ */

SNPPos positions::GetTotalSNPs(position * IniPos, SNPPos Width)
{
//if extreme is before the Width, returns the last position
  position *i=IniPos;
  double InitialPos=IniPos->pos;
  unsigned long int c=0;
  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && (((i->pos)-InitialPos)<Width))
{
 i=i->Next;
 if (i!=NULL)
 c++;

}

  
  }
  catch (NullValue null) {
    null.PrintMessage();
 }
  
 
 // return i->pos;
  return c;
}
/*____________________________________________________________ */

bool positions::IsEndReached(position * IniPos, unsigned long int Width)
{
//if extreme is before the Width, returns the last position
  position *i=IniPos;
  double InitialPos=IniPos->pos;
  unsigned long int c=0;
  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && (((i->pos)-InitialPos)<Width))
{
 i=i->Next;
 if (i!=NULL)
 c++;

}

  
  }
  catch (NullValue null) {
    null.PrintMessage();
 }
  
 if (i==NULL) return true;
 else return false;
}

/*____________________________________________________________ */

position* positions::MoveToPos(position * InitialPos, unsigned long int Pos)
{
//if extreme is before the Pos, returns the last position
  position* i=InitialPos;


  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && (((i->pos)-(InitialPos->pos))<Pos))
{
 i=i->Next;
}

  
  }
  catch (NullValue null) {
    null.PrintMessage();
 }
  
 
  return i;
}
/*____________________________________________________________ */

bool positions::IsANewSNP (SNPPos SNP)
{
 if ((SNP>0) && (GetPosition(SNP)==GetPosition(SNP-1)))
	 return false;
 else return true;
}

/*____________________________________________________________ */

void positions::SelectSNPsFromFile (char* filename)
{

double pos;

position* IndPosition;

 char *cad; 


 if ((cad=new char[10])==NULL)
		 throw NoMemory();

ifstream InputFile;

InputFile.open (filename, ifstream::in);


IndPosition=TheFirstPosition;

for (SNPPos i=0; i<TotalSNPs;i++)
{
IndPosition->selected=false;
IndPosition=IndPosition->Next;
}


do
{ 
	InputFile.getline (cad, 10);
	pos=atof(cad);
	IndPosition=GetSNP(pos);
	IndPosition->selected=true;
}
while (InputFile.peek()!=EOF);

InputFile.close();

}
/**********************************************/
SNPPos positions::SelectSNPs (SNPPos TotalSelected, bool random=true, SNPPos InitialPos=0)
{

SNPPos FirstSNP;

if (random) 
 FirstSNP=rand() % (TotalSNPs-TotalSelected);
else
FirstSNP=InitialPos;

position* IndPosition=TheFirstPosition;

for (SNPPos i=0; i<TotalSNPs;i++)
{
if ((i>=FirstSNP) && (i<(FirstSNP+TotalSelected)))
 IndPosition->selected=true;
else
 IndPosition->selected=false;

IndPosition=IndPosition->Next;
}

return(FirstSNP);

}

/****************************************/

bool positions::OrderPositions()
{
 SNPPos i;
 struct posit
  {
  double pos;
  unsigned int filepos;
 };

 position* IndPosition=TheFirstPosition;

 cout << "Sorting SNPs by positions...\n";
	
        double *ListPos;
        if ((ListPos=new double[TotalSNPs])==NULL)
		throw NoMemory();
	
	struct posit *IndPosit;
        if ((IndPosit=new struct posit[TotalSNPs])==NULL)
		throw NoMemory();

        for (i=0; i<TotalSNPs;i++)
	{
		*(ListPos+i)=IndPosition->pos;
		(IndPosit+i)->pos=IndPosition->pos;
		(IndPosit+i)->filepos=i;
		IndPosition=IndPosition->Next;
		//(ListPos+i)=i;
	}

//for (int a=0;a<10;a++)
//printf ("%.0f\n",*(ListPos+a));
        qsort ((void*)ListPos, TotalSNPs, sizeof (*ListPos), compare);
//        qsort (ListPos, TotalSNPs, sizeof (*ListPos), compare);

        cout <<"or:";
//for (int a=0;a<10;a++)
//printf ("%.0f\n",*(ListPos+a));
//exit(0);
	bool AlreadyOrdered=true, found;
	unsigned int count;



	IndPosition=TheFirstPosition;

        double LastPosition;

        for (i=0; i<TotalSNPs;i++)
	{
		try{
		  found=false;
		  count=0;
          while ((!found) && (count<TotalSNPs))
		  {
			  if (*(ListPos+i)==(IndPosit+count)->pos)
				  found=true;
			  else count++;
		  }
		if (!found) throw NonExist();
		}
			catch (NonExist ne) {
        ne.PrintMessage(0);
      }
    
		IndPosition->pos=*(ListPos+i);
		IndPosition->filepos=count;
                if ((IndPosition==TheFirstPosition) || (IndPosition->pos!=LastPosition))
                IndPosition->unrepeated=true;
                else
                IndPosition->unrepeated=false;
                if (IndPosition->filepos!=i)
                 AlreadyOrdered=false;
                LastPosition=IndPosition->pos;
		IndPosition=IndPosition->Next;
                
	}
delete ListPos;
delete IndPosit;
OrderedPositions=true;
return AlreadyOrdered;
}

};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
