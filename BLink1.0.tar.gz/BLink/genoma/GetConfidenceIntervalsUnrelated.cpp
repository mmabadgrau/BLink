  /**
    * @file HapBlocking.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method)
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"

using namespace UTILS;

namespace BIOS 
{
IndCategory ic=everybody;
BayesType BayesMode=MLE;
double MAF=0.0, alpha=95.0;
double Width=0.0;
IndPos size=100;
bool unrelated=false;
AlleleOrderType AlleleOrderMode;
char filename[128];
bool onlyKnown=false;

/*****************/
void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "\nYou have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  <<"<max width>"
			<< " <Bayes Type (0:MLE/1:Ulpha4/2:Ulpha1/3:Equilibrium/4:Bdistancealpha2>"
		<< "< phase (0: not changed/2: leftright(known phase))>" <<"<MAF>" <<"<alpha ci>" << "<use only known phased (0/1) (default is 0)>"<< endl;
        exit(-1);;  
        exit(-1);
        }
        

	 strcpy(filename, argv[1]);

if (argc>=3) Width=atof(argv[2]);

if (argc>=4) BayesMode=(BayesType) atoi(argv[3]);

if (argc>=5) AlleleOrderMode=(AlleleOrderType) atoi(argv[4]);

if (argc>=6) MAF=atof(argv[5]);

if (MAF>=1)
{
	cout <<"Error, MAF must be in [0.1[\n";
	exit(0);
}

if (argc>=7) alpha=atof(argv[6]);

if (argc>=8) onlyKnown=atof(argv[7]);

}



} //end namespace
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
     
		 
double upperbound, lowerbound, DPrime;
SNPPos TotalSNPs; 

Positions * Pos;
Table2x2 T2x2;

char filepos[128], fileci[128];

ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, fileci, "ci");
Pos=new Positions (filepos);

GenomaSample *Sample;
Sample=new GenomaSample (filename, AlleleOrderMode);

//Sample->PrintSampleReducedFormat(filered, false, ic, 2); // snp 3
//Sample->WriteResults("short");
TotalSNPs=Sample->GetTotalSNPs();
if (Width>Pos->GetDistance(0, TotalSNPs-1)) 
 Width=Pos->GetDistance(0, TotalSNPs-1);

double fA, fB, fAB, MaxDPrime;
IndPos total=0, top;
PairwiseMeasure<GenomaSample> *PM;
MonolociMeasure<GenomaSample> MM = MonolociMeasure<GenomaSample>(Sample, (BayesType)0, ic);

ofstream OutputFile; 
try
{
	  OutputFile.open (fileci, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

float DPrime2, D, MaxD, distance;
char line[100];
struct Pair pair;
cout <<"Obtaining confidence intervals...\n";
OutputFile << "file source:" << filename <<", Bayes type:" << BayesMode << ", IndCategory:" << ic <<", phase:" << AlleleOrderMode <<", MAF: " << MAF <<", Max Width:" << Width << "alpha:" << alpha << "\n";
OutputFile <<"SNP1\tSNP2\tD\tDPrime\tLower bound\tUpper bound\n";
//cout <<"TotalSNPS:" << TotalSNPs;
for (long unsigned int SNP=0; SNP<(TotalSNPs-1);SNP++)
 //if (Sample->GetTotalMissing(SNP, ic)==0) 
  if (MM.GetTotalFreqAllele(SNP, false)>MAF) 
 {
//if (SNP%100==0)
 cout <<"SNP " << SNP+1<<"\n";
// TotalSNPs=10;
 for (long unsigned int SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
 {
  if (Width==0.0 || distance<Width)
 //  if (Sample->GetTotalMissing(SNP2, ic)==0) 
    if (MM.GetTotalFreqAllele(SNP2, false)>MAF)
   {
// cout <<"SNP2 " << SNP2+1<<"\n";
   distance=Pos->GetDistance(SNP, SNP2);
	PM = new PairwiseMeasure<GenomaSample>(SNP, SNP2, Sample, BayesMode, ic, distance);
	
	fA=PM->GetfA();
    fB=PM->GetfB();
//	if (fA<1 && fB<1) // to avoid different missing counters between both SNPs
	{ 
//	cout << "\nf:";
//	cout << PM->PrintHaplotypeFrequencies();
//	cout <<"fAB:" << fAB <<", fA:" << fA <<", fB:" << fB << "D: " << T2x2.GetD(fAB, fA, fB);
//		cout <<"\n";
    fAB=PM->GetfAB();
	D=T2x2.GetD(fAB, fA, fB);
    MaxD=T2x2.GetMaxD(fAB, fA, fB);
    DPrime=T2x2.GetDPrime(fAB, fA, fB);
//	MaxDPrime=T2x2.GetMaxDPrime(fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());

  	pair=T2x2.GetQuantilesDPrime(50-alpha/2, 50+alpha/2, fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
	lowerbound=pair.First;
	upperbound=pair.Second;

	sprintf(line, "%d\t%d\t%1.8lf\t%1.2lf\t%1.2lf\t%1.2lf\n", SNP+1, SNP2+1, D, DPrime, lowerbound, upperbound);

	OutputFile << line;
    }
	
    delete PM;
	}
	}
	
 }
 
 cout <<"Confidence intervals " << 50-alpha/2 << "-" << 50+alpha/2 << " have been obtained and save in file " << fileci <<"\n";

OutputFile.close();

delete Pos, Sample; 




}










