rm dHap
echo coalescent
../PhaseResolver coalescent.txt 100 50 0 1
../PhaseCheckerComparingSamples coalescent.sal coalescent.txt dHap 50 100 0
../PhaseResolverAndChecker coalescent.txt dHap 50 100 1 0
echo crossover
../PhaseResolver crossover.txt 100 50 0 1
../PhaseCheckerComparingSamples crossover.sal crossover.txt dHap 50 100 0
../PhaseResolverAndChecker crossover.txt dHap 50 100 1 0
echo migration
../PhaseResolver migration.txt 100 50 0 1
../PhaseCheckerComparingSamples migration.sal migration.txt dHap 50 100 0
../PhaseResolverAndChecker migration.txt dHap 50 100 1 0
exit 0
