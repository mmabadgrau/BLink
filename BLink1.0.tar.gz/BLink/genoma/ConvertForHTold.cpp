  /**
    * @file ChangeFormat.cpp
    * @brief Program to change formats in genotype files
	* @example ChangeFormat e PHASE chrom1.red chrom1PHASE.inp c1 1 100 90
	* convert a file called chrom1.red in our format to PHASE format (e means "export"). The target file will be
    * called chrom1PHASE.inp. File c1 is a reference file. The origen file contains phenotypr information (1). 
	* The origen has 200 loci and 90 individuals. 
    */


#include <iostream>
#include <cassert>
#include <fstream>
#include <stdio.h>

#include "Exceptions.h"







namespace HT {

void ConvertToLetters (char * cad1, char * cad2)
{
//	cout << "\n" << cad1;
	unsigned int val, i;
	char * basis;
	for (i=0;i<strlen(cad1);i++)
	{
	sscanf(cad1+i, "%c", basis);
	val=atoi(basis);
	switch (val)
	{
		case 1: cad2[i]='A'; break;
		case 2: cad2[i]='C'; break;
		case 3: cad2[i]='G'; break;
		case 4: cad2[i]='T'; break;
		default: {cout <<"h3:" << val; throw BadFormat();}
	}
	}
	cad2[i+1]='\0';
}
/*___________________________________________________________*/

void ConvertForHT (char* filename, char * chromid)
{

char filename2[128]="\0", BlockChar[10], NumberChar[3];
ifstream InputFile; 
ofstream OutputFile;
unsigned int i2, BlockCounter;

cout <<"Exporting " << filename << " to be used for htSNPs \n";



InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();

	char *genotypebuf, *cad, *cad2, *cad3;
    if ((genotypebuf=new char[1000])==NULL)
     throw NoMemory();
	if ((cad2=new char[100])==NULL)
     throw NoMemory();
	if ((cad3=new char[100])==NULL)
     throw NoMemory();


	 bool found=false;


 BlockCounter=1;

	do
	{
	InputFile.getline (genotypebuf, 1000);
//		cout << "V:" <<genotypebuf << "\n";

	cad=strtok (genotypebuf," ");// read the first word 
	if (*cad!='B') {cout <<"h"; throw BadFormat();}


	cad=strtok (NULL,". \t");
    
	sscanf (cad, "%s", cad2);

	if (atoi(cad2)!=BlockCounter) {cout <<"h2"; throw BadFormat();}
	
	filename2[0]='\0';
	strcpy (filename2, "block");
	gcvt ((float)BlockCounter, 10, BlockChar);
	strcat (filename2, BlockChar);
	strcat (filename2, ".");
	strcat (filename2, "chrom");
	strcat (filename2, chromid);

	OutputFile.open (filename2, ifstream::out);

   
    do
	{
	InputFile.getline (genotypebuf, 1000); // read lines with frequent haplotypes
	cad=strtok (genotypebuf," ");// read the first word 
	sscanf (cad, "%s", cad2);
	if (cad2[0]!='M')
	{
	ConvertToLetters(cad2, cad3);
	OutputFile << cad3 << endl;
	}
	}
	while ((InputFile.peek()!='M') && (InputFile.peek()!=EOF)); 

    OutputFile.close();	
	
BlockCounter++;

if (InputFile.peek()!=EOF)
InputFile.getline (genotypebuf, 1000); // D prime

}
while (InputFile.peek()!=EOF);

}
}



/*****************/
/*          MAIN          */
/*****************/

using namespace HT;


int main(int argc, char*argv[]) {


     if(argc!=3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0]  << " <source file> " << " chromosome id " << endl;
        exit(-1);
        }
     char* filename;
	 char* chromid;
	 	 try{ 

	 if ((filename=new char[128])==NULL)
		 throw NoMemory();

 	 strcpy(filename, argv[1]);
	 	
	 if ((chromid=new char[3])==NULL)
		 throw NoMemory();

 	 strcpy(chromid, argv[2]);

	 


	 ConvertForHT(filename, chromid);



 

		 }

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (ErrorFile ef) {
		 ef.PrintMessage();}
	 catch (BadFormat bf) {
		 bf.PrintMessage();}


        delete filename, chromid;

   return 0;

}





