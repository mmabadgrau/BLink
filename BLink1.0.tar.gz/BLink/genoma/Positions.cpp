/* File: positions.cpp */

#ifndef __Positions_cpp__
#define __Positions_cpp__





#include "Positions.h"



namespace BIOS {




/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/




///////////////////
//// public ////////
///////////////////
/*____________________________________________________________ */

void Positions::CheckFilename(char* filename)
{

if (HasThisExtension(filename, "pou", 3)==false)
{
	cout <<"File pos is required";
	exit (0);
}
//	cout <<"file:" << filename;

}
/*____________________________________________________________ */
/*
double Positions::GetPosition(SNPPos SNP)
{
	return VirtualPositions::GetPosition(SNP);
}
/*____________________________________________________________ */

double Positions::GetDistance(SNPPos SNP, SNPPos SNP2)
{
	return GetDistance(GetNode(SNP), GetNode(SNP2));
}
/*____________________________________________________________ */

double Positions::GetDistance(Positions::NodePointer p1, Positions::NodePointer p2)
{
	return fabs(GetPosition(p1)-GetPosition(p2));
}
/*____________________________________________________________ */

unsigned long int Positions::GetTotalSNPs(SNPPos IniPos, float Width)
{
return GetTotalSNPs(GetNode(IniPos), Width);
}
/*____________________________________________________________ */

unsigned long int Positions::GetTotalSNPs(NodePointer IniPos, float Width)
{
//if extreme is before the Width, returns the last position
  NodePointer i=IniPos;
//cout <<"ddd\n";
  

  try {

double InitialPos=(GetElement(IniPos))->pos;
  unsigned long int c=0;
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && ((((GetElement(i))->pos)-InitialPos)<Width))
{
 i=i->Next;
// if (i!=NULL)
 c++;

}
return c;
}
  catch (NullValue null) {
    null.PrintMessage(" Positions::GetTotalSNPs");
 }
}
/*____________________________________________________________ */

bool Positions::IsEndReached(NodePointer IniPos, float Width)
{
//if extreme is before the Width, returns the last position
  NodePointer i=IniPos;
  double InitialPos=GetElement(IniPos)->pos;
  unsigned long int c=0;
  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && (((GetElement(i)->pos)-InitialPos)<Width))
{
 i=i->Next;
 if (i!=NULL)
 c++;

}

  
  }
  catch (NullValue null) {
    null.PrintMessage(" Positions::IsEndReached");
 }
  
 if (i==NULL) return true;
 else return false;
}
/*____________________________________________________________ */

void Positions::PosSampling (list<double> *pos)
{
	Positions* sample2;
	sample2=new Positions();
    PosS *newpos;
	list<double>::NodePointer p=pos->GetFirst();
	NodePointer p2=GetFirst();

	while (p!=NULL)
	{
	 p2=GetPointerWithPos(pos->GetElement(p));
	 if (p2!=NULL)
	 {
     newpos=GetElement(p2);
	 sample2->insertElement(newpos);
	 }
	 p=pos->GetNext(p);
	}
    *this=*sample2;
}
/*____________________________________________________________ */

Positions::NodePointer Positions::MoveToPos(NodePointer InitialPos, float Pos)
{
//if extreme is before the Pos, returns the last position
  NodePointer i=InitialPos;


  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL) && (((GetElement(i)->pos)-(GetElement(InitialPos)->pos))<Pos))
{
 i=i->Next;
}

  
  }
  catch (NullValue null) {
    null.PrintMessage(" Positions::MoveToPos");
 }
  
 
  return i;
}
/*____________________________________________________________ */

Positions::NodePointer Positions::GetPointerWithPos(float Pos)
{
//if extreme is before the Pos, returns the last position
  NodePointer i=GetFirst();

  try {
  if (i==NULL)
     throw NullValue();


while ((i!=NULL))
{
 if (GetElement(i)->pos==Pos)
	 return i;
 else i=i->Next;
}

  
  }
  catch (NullValue null) {
    null.PrintMessage(" Positions::MoveToPos");
 }
  
 
  return i;
}
};  // Fin del Namespace

#endif

/* Fin Fichero: Positions.h */
