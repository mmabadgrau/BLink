/* File: TrioSample.h */


#ifndef __TrioSample_h__
#define __TrioSample_h__

//#include <string.h>
//#include <cstdio>

#include "Exceptions.h"
#include "Diplotype.h"
#include "Genotype.h"

//#include "RepeatedTrioSample.h"

using namespace UTILS;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class TrioSample: public list<Trio*>  {


	protected:
    /** @name Implementation of class TrioSample
        @memo Private part.
    */


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
     bool ExistPhenotypes;


	protected:

	 NodePointer FirstTrioGenotype;


/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */

		//Genotype  ReadElement (ifstream * source, SNPPos size);

	
//		void  ReadGenotype (list<Diplotype::DiplotypeS>* DiplotypeList, char* line, SNPPos size);


				   /**
         @memo Compute the more frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the more frequent value
*/


/**
         @memo Compute the less frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the less frequent value
*/


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

      /** @name Operations on TrioSample 
        @memo Operations on a TrioSample 
    */

		        /**
         @memo Copy constructor
         @param destino: TrioSample where will be copy
         @param origen: TrioSample to copy
         @doc
           Make a copy of TrioSample
           Time complexity in time O(1).
        */
	
		  TrioSample (GenomaSample& Source);


		  TrioSample (const TrioSample& source, unsigned int *Sampling);


		  ~TrioSample (){};


	  /**
         @memo Obtain the number of SNPs.
         @return the number of SNPs
         @doc Return the number of SNPs. This value
         is in the variable TotalSNPs.
         Time complexity O(1)

      */
		void PrintHaplotypes (char* filename);


};  // End of class TrioSample



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

TrioSample::TrioSample (const TrioSample& source, unsigned int *Sampling=NULL):list<Trio*>(source, Sampling)
{
}

/*____________________________________________________________ */

TrioSample::TrioSample (const GenomaSample& source)
{
 GenomaSample* SourceCopy;
 SourceCopy=new GenomaSample(source);
 Trio T;
 GenotypeSample::NodePointer IndGenotype=SourceCopy->GenotypeSample::GetFirst();
 PhenotypeSample::NodePointer IndPhenotype=SourceCopy->PhenotypeSample::GetFirst();
 while (IndGenotype!=NULL && IndPhenotype!=NULL)
  {
 T=GetTrioMembers(IndGenotype, IndPhenotype);
 T=new Trio(FatherGenotype, MotherGenotype, ChildGenotype, FatherPhenotype, MotherPhenotype, ChildPhenotype);
 GE=Genoma(G, &P, *Trio);

}


/*____________________________________________________________ */

void TrioSample::PrintHaplotypes (char* filename)
 {
/*
  TrioSample::NodePointer IndGenotype=TrioSample::GetFirst();
  Genotype* genotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 

  SNPPos TotalSNPs=GetTotalSNPs();

while (IndGenotype!=NULL)
  {
   genotype=TrioSample::GetElement(IndGenotype);
   genotype->PrintCompleteHaplotype(left);     
   OutputFile << "\n";
   genotype->PrintCompleteHaplotype(right);     
   OutputFile << "\n";
   IndGenotype=TrioSample::GetNext(IndGenotype);
  }
  OutputFile.close();

cout << "\nInformation about haplotypes has been saved in file " << filename <<"\n";

  }

};
// End of Namespace

#endif

/* End of file: TrioSample.h */




