  /**
    * @file genoma.cpp
    * @brief Program to project for SNPs
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "SNP.cpp"

#include "GenomaSample.cpp"

namespace BIOS {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }


/* _____________________________________________________*/

void ReduceSample(char *filename, char* filename2, unsigned int TotalSNPs, bool random, unsigned int InitialPos)
{
GenomaSample *Sample;
if ((Sample = new GenomaSample(filename, NotChanged))==NULL)
 throw NoMemory();

//srand((unsigned) time(&t));//

srand(24226616);
list<SNPPos> *Sampling;
Sampling=new list<SNPPos>();
SNPPos LastPos;
if (TotalSNPs==0) LastPos=Sample->GetTotalSNPs();
else LastPos=TotalSNPs+InitialPos;
if (random) 
{
	InitialPos=rand()% (Sample->GetTotalSNPs()-TotalSNPs);
	LastPos=InitialPos+TotalSNPs;
	cout << "Inipos: " << InitialPos;
}

for (SNPPos i=InitialPos;i<LastPos;i++)
 Sampling->InsertElement(i);
Sample->SNPSampling (Sampling);
Sample->WriteResults (filename2);
delete Sample;

char filepos[128], filepos2[128]; 
ChangeExtension(filename2, filepos2, "pou");
ChangeExtension(filename, filepos, "pou");
Positions * Pos;
Pos=new Positions (filepos);
 // exit(0);
Pos->SNPSampling(Sampling);
Pos->PrintPositions (filepos2);
delete Pos, Sampling;
}
}



/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <orig file> " << " <target file> " <<"<TotalSNPs>" << "<InitialPos (0 if random)>" << endl;
        exit(-1);
        }
     char* filename, *filename2;
      if ((filename=new char[128])==NULL)
		 throw NoMemory();
         if ((filename2=new char[128])==NULL)
		 throw NoMemory();
	 strcpy(filename, argv[1]);
	 strcpy(filename2, argv[2]);

     unsigned int TotalSNPs=atoi(argv[3]);
     bool random=false;
	 SNPPos InitialPos=atoi(argv[4]);
     if (InitialPos==0) random=true;
	 else InitialPos--;

		 



	 try{ 

         ReduceSample (filename, filename2, TotalSNPs, random, InitialPos);

		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}

	 delete filename, delete filename2;
 
   return 0;

}





