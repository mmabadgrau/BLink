#rm(list=ls())
#############################################################
################## Function GetMLDPrime #####################
#############################################################
# It computes the ML estimator of DPrime  

GetMLDPrime<-function(VectorHaplotypes, Method, BayesType, truemafa, truemafb, truefAB, i,j,k,l,m) 
{
DPrimeVector<-c(0.01*-100:100)
DVector<-c(1:201)*0
frequency<-c(1:201)*0
MaxFrequency=-Inf
Max=0
total <- GetTotal(VectorHaplotypes, Method, BayesType)
nA=GetnA(VectorHaplotypes, Method, BayesType)
nB=GetnB(VectorHaplotypes, Method, BayesType)
nAB<-GetnAB(VectorHaplotypes, Method, BayesType)
#nAB=truefAB*total
nAb<-nA-nAB
naB<-nB-nAB
nab<-total-nAB-nAb-naB

#fA<-a/100
#fB<-b/100
fA<-nA/total
fB<-nB/total
#fA<-1-truemafa
#fB<-1-truemafb
fa<-1-fA
fb<-1-fB
DMax<-min(fA*(1-fB), (1-fA)*fB)
DMin<--min(fA*fB, (1-fA)*(1-fB))
distanceD<-min(fa,fb)
DVector[1]<-DMin
for (r in 2:length(DVector))
 DVector[r]<-DVector[r-1]+distanceD/length(DVector)



for (v in 1:length(DVector))
{
#for (a in 0:100)
#for (b in 0:100)
 {

#if (DPrimeVector[v]>0)
#fAB<-DPrimeVector[v]*DMax+fA*fB
#else
#fAB<-DPrimeVector[v]*DMin+fA*fB
fAB<-DVector[v]+fA*fB
if ((fA-fAB)<zero) fAb=0
else fAb=fA-fAB # =D-fA*fb
if ((fB-fAB)<zero) faB=0
else faB=fB-fAB # =D-fa*fB
if (abs(1-(fAB+fAb+faB))<=zero) 
fab=0 
else fab=1-fAB-fAb-faB # =D+fa*fb

if ((fAB==0 && nAB!=0) || ((1-fAB)==0 && (total-nAB)!=0)) #(fAb==0 && nAb!=0) || (faB==0 && naB!=0) || (fab==0 && nab!=0))
 frequency[v]<--Inf
else
{
frequency[v]<-0
if (fAB>0) frequency[v]=frequency[v]+(nAB)*log(fAB)
if ((1-fAB)>0) frequency[v]<-frequency[v]+(total-nAB)*log(1-fAB)
#if (fAb>0) frequency[v]=frequency[v]+(nAb)*log(fAb)
#if (faB>0) frequency[v]=frequency[v]+(naB)*log(faB)
#if (fab>0) frequency[v]=frequency[v]+(nab)*log(fab)
}
frequency[v]<-exp(frequency[v])#*factorial(total)/(factorial(nAB)*factorial(total-nAB))
#frequency[v]<-frequency[v]/DMax

#if (Method==Bayes)
#if (D>0)
#frequency[v]<-min(GetfA(VectorHaplotypes),GetfB(VectorHaplotypes))*frequency[v]
#else
#frequency[v]<-max(1-GetfA(VectorHaplotypes),1-GetfB(VectorHaplotypes))*frequency[v]


if (frequency[v]>MaxFrequency)
{
 MaxFrequency<-frequency[v]
 Max<-v
 maxfA[i,j,k,l,m]<-fA
 maxfB[i,j,k,l,m]<-fB
 maxfAB[i,j,k,l,m]<-fAB
 if (frequency[v]==MaxFrequency && MaxFrequency!=-Inf)
  multimodal<-Max
}
}# end for each combination of allele frequencies
}
D<-DVector[Max]
#plot(DPrimeVector, frequency)
#write(DPrime, "")
#stop("")
fA<-maxfA[i,j,k,l,m]
fB<-maxfB[i,j,k,l,m]
DMax<-min(fA*(1-fB), (1-fA)*fB)
DMin<--min(fA*fB, (1-fA)*(1-fB))

if (D>0)
DPrime<-D/DMax
else DPrime<--D/DMin
#DPrime<-(truefAB-nAB/total)^2 # variance fAB
trueD<-truefAB-(1-truemafa)*(1-truemafb)
DPrime<-(trueD-D)^2 # variance D
}

#############################################################
################## Function GetMLWeightedDPrime #####################
#############################################################
# It computes the ML estimator of DPrime  


GetMLWeightedDPrime<-function(VectorHaplotypes, Method, BayesType, truemafa, truemafb, truefAB) 
{
DPrimeVector<-c(0.01*0:100)
frequency<-c(1:101)*0
MaxFrequency=-Inf
Max=0
total <- GetTotal(VectorHaplotypes, Method, BayesType)
nA=GetnA(VectorHaplotypes, Method, BayesType)
nB=GetnB(VectorHaplotypes, Method, BayesType)
nAB<-GetnAB(VectorHaplotypes, Method, BayesType)
nAb<-nA-nAB
naB<-nB-nAB
nab<-total-nAB-nAb-naB
fA=nA/total
fB=nB/total
for (i in 1:length(frequency))
{
# for (a in 0:100)
# for (b in 0:100)
 {
# fA<-a/100
# fB<-b/100
DPrimeVector[i]<- -max(1-fB, 1-fA)+(i-1)*0.01
DMax=min(1-fB, 1-fA)
D=DPrimeVector[i]*DMax
fAB=D+fA*fB
fAb=fA-fAB
faB=fB-fAB
if (abs(1-(fAB+fAb+faB))<=zero) 
fab=0
else fab=1-fAB-fAb-faB

if ((fAB==0 && nAB!=0) || (fAb==0 && nAb!=0) || (faB==0 && naB!=0) || (fab==0 && nab!=0))
 frequency[i]<--Inf
else
{
frequency[i]<-0
frequency[i]<-frequency[i]+(nAB)*log(fAB)
frequency[i]<-frequency[i]+(nAb)*log(fAb)
frequency[i]<-frequency[i]+(naB)*log(faB)
frequency[i]<-frequency[i]+(nab)*log(fab)
}
frequency[i]<-exp(frequency[i])

if (frequency[i]>MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
}
}
}
DPrime<-DPrimeVector[Max]
#plot(DPrimeVector, frequency)
#write(DPrime, "")

#stop("")
DPrime
}
#############################################################
################## Function GetMLDPrime #####################
#############################################################
# It computes the ML estimator of DPrime  

GetMLAbsDPrime<-function(VectorHaplotypes, Method, BayesType, truemafa, truemafb, truefAB) 
{
D<-GetD(VectorHaplotypes, Method, BayesType)
#if (D>0)
#DPrimeVector<-c(0.01*0:100)
#else
DPrimeVector<-c(0.01*100:0)

frequency<-c(1:101)*0
MaxFrequency=-Inf
Max=0
total <- GetTotal(VectorHaplotypes, Method, BayesType)
nA=GetnA(VectorHaplotypes, Method, BayesType)
nB=GetnB(VectorHaplotypes, Method, BayesType)
nAB<-GetnAB(VectorHaplotypes, Method, BayesType)
nAB=truefAB*total
nAb<-nA-nAB
naB<-nB-nAB
nab<-total-nAB-nAb-naB
fA=nA/total
fB=nB/total
fA<-1-truemafa
fB<-1-truemafb
for (i in 1:length(DPrimeVector))
for (sign in 1:2)
{
# for (a in 0:100)
# for (b in 0:100)
 {
# fA<-a/100
# fB<-b/100
if (sign==2)
DMax=min(fA*(1-fB), (1-fA)*fB)
else
DMax=min(fA*fB, (1-fA)*(1-fB))
D=DPrimeVector[i]*DMax
fAB=D+fA*fB
if ((fA-fAB)<zero) fAb=0
else fAb=fA-fAB
if ((fB-fAB)<zero) faB=0
else faB=fB-fAB
if (abs(1-(fAB+fAb+faB))<=zero) 
fab=0
else fab=1-fAB-fAb-faB

if ((fAB==0 && nAB!=0) || (fAb==0 && nAb!=0) || (faB==0 && naB!=0) || (fab==0 && nab!=0))
 freq<--Inf
else
{
freq<-0
if (fAB>0) freq=freq+(nAB)*log(fAB)
if (fAb>0) freq=freq+(nAb)*log(fAb)
if (faB>0) freq=freq+(naB)*log(faB)
if (fab>0) freq=freq+(nab)*log(fab)
}

freq<-exp(freq)


if (sign==1)
DMin=min(fA*(1-fB), (1-fA)*fB)
else
DMin=min(fA*fB, (1-fA)*(1-fB))

frequency[i]<-frequency[i]+freq/DMax

if (frequency[i]>MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
 if (frequency[i]==MaxFrequency && MaxFrequency!=-Inf)
  multimodal<-Max
}
}
}
DPrime<-DPrimeVector[Max]
#plot(DPrimeVector, frequency)
#write(DPrime, "")
#stop("")
#if (D<0) DPrime<- -DPrime
DPrime
}
#############################################################
################## Function GetMLr      #####################
#############################################################
# It computes the ML estimator of r

GetMLr<-function(VectorHaplotypes, Method, BayesType) 
{
rVector<-c(0.01*-100:100)
frequency<-c(1:101)*0
MaxFrequency=-Inf
Max=0
total <- sum(VectorHaplotypes)
nA=GetnA(VectorHaplotypes, Method, BayesType)
nB=GetnB(VectorHaplotypes, Method, BayesType)
nAB<-GetnAB(VectorHaplotypes, Method, BayesType)
nAb<-nA-nAB
naB<-nB-nAB
nab<-total-nAB-nAb-naB
fA=nA/total
fB=nB/total
for (i in 1:length(rVector))
{
denominator=sqrt(fA*(1-fB)*(1-fA)*fB)
D=rVector[i]*denominator
if (abs(D)<=abs(denominator))
{
fAB=D+fA*fB
if ((fA-fAB)<zero) fAb=0
else fAb=fA-fAB
if ((fB-fAB)<zero) faB=0
else faB=fB-fAB
if (abs(1-(fAB+fAb+faB))<=zero) 
fab=0
else fab=1-fAB-fAb-faB
if (fAB<0 || fAb<0 || faB<0 || fab<0)
{
write("ho","")
write(rVector[i],"")
write(D,"")
write(nAB,"")
write(nAb,"")
write(naB,"")
write(nab,"")
write(fAB,"")
write(fAb,"")
write(faB,"")
write(fab,"")
stop("error")

frequency[i]=0

if (nAB>0) frequency[i]=frequency[i]+nAB*log(fAB)
if (nAb>0) frequency[i]=frequency[i]+nAb*log(fAb)
if (naB>0) frequency[i]=frequency[i]+naB*log(faB)
if (nab>0) frequency[i]=frequency[i]+nab*log(fab)

if (frequency[i]>=MaxFrequency)
{
 MaxFrequency<-frequency[i]
 Max<-i
}
}
}
}
plot(rVector, frequency)
r<-rVector[Max]
r
}
#############################################################
################## Function GetDMax #########################
#############################################################
# It computes DMax given p(a), (called MAFa, minor allele frequency locus a),
# p(b) (called MAFb, minor allele frequency for locus b) and
# signed DPrime or D (only the sign is used, so it does not matter if we five
# signed DPrime or D. 
# This function will be used to compute population DMax or sample DMax.
# Usually DMax is computed using estimations from sample for
# MAFa, MAFb and D, in order to compute an estimation of DPrime from the sample.
# In this program this function is also used to compute (TRUE) population
# DMax, considering that we know (TRUE) population DPrime, p(a) and p(b).
# With population DMax later we will be able to obtain population D.maxPositiveD1-,maxPositiveD2)

GetDMax<-function(VectorHaplotypes, Method, BayesType, TrueDPrime, alpha) 
{
D<-GetD(VectorHaplotypes, Method, BayesType, TrueDPrime)
fA<-GetfA(VectorHaplotypes, Method, BayesType, alpha)
fB<-GetfB(VectorHaplotypes, Method, BayesType, alpha)
ifelse(D<0,min(fA*fB,(1-fA)*(1-fB)),min(fA*(1-fB),(1-fA)*fB))
#min(fA*(1-fB),(1-fA)*fB)
#min(fA*fB,(1-fA)*(1-fB))
}
#######################################################
################## Function GetD ######################
#######################################################
# It estimates D from a sample with genotypes in VectorGenotypes and method Method.
# If a Bayesian method is used, variation of Bayesian method is in BayesType.
# D is computed as Estf(AB)-Estf(A)*Estf(B)

GetD<-function(VectorHaplotypes, Method, BayesType, TrueDPrime, alpha)
 GetfAB(VectorHaplotypes, Method, BayesType,TrueDPrime, alpha)-GetfA(VectorHaplotypes, Method, BayesType, alpha)*GetfB(VectorHaplotypes, Method, BayesType, alpha)
 #######################################################
################## Function LocusAIsInverted #####################
#######################################################
# It returns true only if n(a)>n(A) for sample in VectorHaplotype
LocusAIsInverted<-function(VectorHaplotype) 
{
IsInverted<-FALSE
if ((VectorHaplotype[1]+VectorHaplotype[2])<(VectorHaplotype[3]+VectorHaplotype[4]))
IsInverted<-TRUE
IsInverted<-FALSE
IsInverted
}
#######################################################
################## Function LocusBIsInverted #####################
#######################################################
# It returns true only if n(b)>n(b) for sample in VectorGenotype

LocusBIsInverted<-function(VectorHaplotype) 
{
IsInverted<-FALSE
if ((VectorHaplotype[1]+VectorHaplotype[3])<(VectorHaplotype[2]+VectorHaplotype[4]))
IsInverted<-TRUE
IsInverted<-FALSE
IsInverted
}
#######################################################
################## Function GetTotal ##################
#######################################################
# It computes sample absolute frequency of haplotype AB, given haplotypes for the
# sample in VectorHaplotypes.

GetTotal<-function(VectorHaplotypes, Method, BayesType, alpha=0) 
{
Total<-sum(VectorHaplotypes)
 
if (Method==Bayes && BayesType==Uniform)
 Total<-Total+alpha/4
Total
}
#######################################################
################## Function GetnAB ####################
#######################################################
# It computes sample absolute frequency of haplotype AB, given haplotypes for the
# sample in VectorHaplotypes.

GetnAB<-function(VectorHaplotypes, Method, BayesType, TrueDPrime, alpha=0) 
{
fA<-GetfA(VectorHaplotypes)
fB<-GetfB(VectorHaplotypes)
fa<-1-fA
fb<-1-fB

if (!LocusAIsInverted(VectorHaplotypes))
ifelse (!LocusBIsInverted(VectorHaplotypes),
 nAB<-VectorHaplotypes[1], #AB
nAB<-VectorHaplotypes[2]) #Ab
else
ifelse (!LocusBIsInverted(VectorHaplotypes),
 nAB<-VectorHaplotypes[3], #aB
nAB<-VectorHaplotypes[4]) #ab
 
if (Method==Bayes && BayesType==Uniform)
 nAB<-nAB+alpha/4
if (Method==Bayes && BayesType==LD)
#if(GetD(VectorHaplotypes, MLE, 0)>0)
# nAB<-nAB+min(fA,fB)*alpha
#else
 nAB<-nAB+(min(fA,fB)-min(fa,fb))*alpha
if (Method==Bayes && BayesType==Equilibrium)
nAB<-nAB+fA*fB*alpha

nAB
}
#######################################################
################## Function GetfAB ####################
#######################################################
# It computes sample relative frequency of haplotype AB, given haplotypes for the
# sample in VectorHaplotypes.

GetfAB<-function(VectorHaplotypes, Method, BayesType, TrueDPrime, alpha=0) 
{
numerator<-GetnAB(VectorHaplotypes, Method, BayesType, TrueDPrime)
denominator<-sum(VectorHaplotypes)
if (Method==Bayes) 
 denominator<-denominator+alpha
fAB<-numerator/denominator
}
#######################################################
################## Function GetnA #####################
#######################################################
# It computes major allele absolute frequency nA from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetnA<-function(VectorHaplotype, Method=MLE, BayesType=0, alpha=0) 
{
nA<-ifelse(!LocusAIsInverted(VectorHaplotype),VectorHaplotype[1]+VectorHaplotype[2],VectorHaplotype[3]+VectorHaplotype[4])
if (Method==Bayes && BayesType==Uniform)
nA<-nA+alpha/2
if (Method==Bayes && (BayesType==Equilibrium || BayesType==LD))
nA<-nA+GetfA(VectorHaplotype, 0, 0)*alpha
nA
}
#######################################################
################## Function GetfA #####################
#######################################################
# It computes major allele frequency fA from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetfA<-function(VectorHaplotype, Method=MLE, BayesType=0, alpha=0) 
{
numerator<-GetnA(VectorHaplotype, Method, BayesType)
denominator<-sum(VectorHaplotype)
if (Method==Bayes) 
 denominator<-denominator+alpha
numerator/denominator
}
#######################################################
################## Function GetnB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetnB<-function(VectorHaplotype, Method=MLE, BayesType=0, alpha=0) 
{
nB<-ifelse(!LocusBIsInverted(VectorHaplotype), VectorHaplotype[1]+VectorHaplotype[3],VectorHaplotype[2]+VectorHaplotype[4])
if (Method==Bayes && BayesType==Uniform)
nB<-nB+alpha/2
if (Method==Bayes && (BayesType==Equilibrium || BayesType==LD))
nB<-nB+GetfB(VectorHaplotype, 0, 0)*alpha
nB
}
#######################################################
################## Function GetfB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetfB<-function(VectorHaplotype, Method=MLE, BayesType, alpha) 
{
numerator<-GetnB(VectorHaplotype, Method, BayesType)
denominator<-sum(VectorHaplotype)
if (Method==Bayes) 
 denominator<-denominator+alpha
numerator/denominator
}
#############################################################
################## Function GetTrueU ########################
#############################################################
# It computes population U for each MAFa in vector VectorMAFa, each MAFb in vector VectorMAFb and 
# each DPrime in vector VectorDPrime, considering that DPrime=D/DMax
# Results are written in VectorD.
GetTrueU<-function(VectorDPrime, VectorMAFa, VectorMAFb)
{
ArrayU<-c(1:(length(VectorMAFa)*length(VectorMAFb)*length(VectorDPrime)))*0
dim(ArrayU)<-c(length(VectorMAFa),length(VectorMAFb),length(VectorDPrime))
for (i in 1:length(VectorMAFa))
for (j in 1:length(VectorMAFb))
for (k in 1:length(VectorDPrime))
if(VectorDPrime[k]>=0)
 ArrayU[i,j,k]<-VectorDPrime[k]
else
if (i<j)
 ArrayU[i,j,k]<-VectorDPrime[k]*(1-VectorMAFb[j])/VectorMAFb[j]
 else
 ArrayU[i,j,k]<-VectorDPrime[k]*(1-VectorMAFa[i])/VectorMAFb[i]

ArrayU
}


###############################################################################################
######################################### Main program ########################################
###############################################################################################


# Initialization


# INFORMATION ABOUT POPULATIONS 



# Population MAF locus a used to make simulations can be 0.05, 0.1, 0.25 or 0.5
Population.VectorMAFa<-c(0.05, 0.1, 0.25, 0.5)
Population.VectorMAFa<-c(0.05)

# Population MAF locus b used to make simulations can be 0.05, 0.1, 0.25 or 0.5
Population.VectorMAFb<-c(0.05, 0.1, 0.25, 0.5)
Population.VectorMAFb<-c(0.05)


# Population DPrime used to make simulations goes from -1 to 1 in steps of 0.1
Population.VectorDPrime<-c(0.1*-10:10)
#Population.VectorDPrime<-c(1:11)*0






# Population.ArrayU must have U true values for each combination of MAFa, MAFb and DPrime
Population.ArrayU<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)))*0
dim(Population.ArrayU)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime))
Population.ArrayU<-GetTrueU(Population.VectorDPrime, Population.VectorMAFa, Population.VectorMAFb)


# INFORMATION ABOUT SAMPLING
# Now we need variables with information about samples

# Simulations will be done for samples with 5 different sizes: 50, 100, 200, 500 and 1000.
VectorSize<-c(20, 60, 100, 200, 500, 1000)
#VectorSize<-c(20)

# Repetitions1 is the number of simulated samples used to compute mean DPrime is 1000
Repetitions1<-1000 # for basic sampling

h<-c(0,0,0,0)


# From samples phased genotypes, sample D can be computed.
# Mean DPrime of the 1000 simulations given population MAFa, MAFb, DPrime and
# given the samples sizes will be written in Simulations.ArrayMeanD.
# So here the array is initialized.

Simulations.ArrayMeanDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))


Simulations.ArrayMeanpa<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanpa)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayMeanpb<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanpb)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))


Simulations.ArrayMeanAbsDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)))*0
dim(Simulations.ArrayMeanAbsDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize))

Simulations.ArrayDPrime<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(Simulations.ArrayDPrime)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)

maxfA<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(maxfA)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)

maxfB<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(maxfB)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)

maxfAB<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*Repetitions1))*0
dim(maxfAB)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),Repetitions1)

Simulations.Sign<-c(1:(length(Population.VectorMAFa)*length(Population.VectorMAFb)*length(Population.VectorDPrime)*length(VectorSize)*4))*0
dim(Simulations.Sign)<-c(length(Population.VectorMAFa),length(Population.VectorMAFb),length(Population.VectorDPrime),length(VectorSize),4)



MLE<-0 # MLE estimation for Lewontin's D'
Bayes<-1
Method<-MLE
#Method<-Bayes
Uniform<-1
Equilibrium<-3
LD<-4
BayesType<-Uniform
BayesType<-Equilibrium
#BayesType<-LD

zero<-1e-10

# CORE PROGRAM
# For each configuration of population values MAFa, MAFb, DPrime and for each
# sample size, samples will be simulated considering the Method.
# MeanDPrime and MeanDEMPrime will be computed as the avarage of DPRime and DEMPrime
# respectively of the Repetitions1 samples (1000).


for (i in 1:length(Population.VectorMAFa))
for (j in 1:length(Population.VectorMAFb))
for (k in 1:length(Population.VectorDPrime))
for (l in 1:length(VectorSize))
{

write ("\nMAFa:","")
write(Population.VectorMAFa[i],"")
write ("MAFb:","")
write(Population.VectorMAFb[j],"")
write ("DPrime:","")
write(Population.VectorDPrime[k],"")
write ("Size3 sample:","")
write(VectorSize[l],"")
counter<-0

if (Population.VectorDPrime[k]<0) DMax=Population.VectorMAFa[i]*Population.VectorMAFb[j]
else DMax=min(Population.VectorMAFa[i]*(1-Population.VectorMAFb[j]), (1-Population.VectorMAFa[i])*Population.VectorMAFb[j])


#distanceD<-min(Population.VectorMAFa, Population.VectorMAFb)
#Population.VectorDPrime[1]<- -1
#for (i in 2:length(Population.VectorDPrime))
# Population.VectorDPrime[i]<-Population.VectorDPrime[i-1]+(distanceD/length(Population.VectorDPrime))/MaxD

PopD=Population.VectorDPrime[k]*DMax
h[1]<-PopD+(1-Population.VectorMAFa[i])*(1-Population.VectorMAFb[j])#fAB
h[2]<-(1-Population.VectorMAFa[i])-h[1] # fAb
h[3]<-(1-Population.VectorMAFb[j])-h[1] # faB
h[4]<-1-h[1]-h[2]-h[3] # fab

for (m in 1:Repetitions1)
{
VectorHaplotypes<-rmultinom(1, VectorSize[l]*2, h)
while (GetfA(VectorHaplotypes)==1 || GetfB(VectorHaplotypes)==1)
 VectorHaplotypes<-rmultinom(1, VectorSize[l]*2, h)

EstfA<-GetfA(VectorHaplotypes); EstfB<-GetfB(VectorHaplotypes)
Estfa<-1-EstfA; Estfb<-1-EstfB

if (Method==MLE) alpha<-0
if (Method==Bayes && BayesType==Uniform) alpha<-4
if (Method==Bayes && (BayesType==Equilibrium || BayesType==LD)) alpha<-1/(EstfA*EstfB)

#DMax<-GetDMax(VectorHaplotypes, Method, BayesType, Population.VectorDPrime[k], alpha)

#if (VectorHaplotypes[4]!=0) #D<-runif(1,-1,0)*DMax
{
counter<-counter+1
#D<-GetD(VectorHaplotypes, Method, BayesType, Population.VectorDPrime[k], alpha)

DPrime<-GetMLDPrime(VectorHaplotypes, Method, BayesType, Population.VectorMAFa[i], Population.VectorMAFb[j], h[1], i,j,k,l,m)
#DPrime<-1-GetfB(VectorHaplotypes, Method, BayesType, alpha)
#DPrime<-GetMLAbsDPrime(VectorHaplotypes, Method, BayesType, Population.VectorMAFa[i], Population.VectorMAFb[j], h[1]*VectorSize[l])
#DPrime2<-GetMLWeightedDPrime(VectorHaplotypes, Method, BayesType)
#r<-GetMLr(VectorHaplotypes, Method, BayesType)
#DPrime<-D/DMax
#if (D>0)
#DPrime<-min(EstfA,EstfB)*DPrime 
#else
#DPrime<-max(Estfa,Estfb)*DPrime

#DPrime<-DPrime/max(Estfa,Estfb)

#if ((abs(DPrime)-abs(DPrime2))>(0.01+zero))
#{
#write (DPrime, "")
#write (DPrime2, "")
#write (abs(DPrime)-abs(DPrime2),"")
#write (VectorHaplotypes[1],"")
#write (VectorHaplotypes[2],"")
#write (VectorHaplotypes[3],"")
#write (VectorHaplotypes[4],"")
#stop("different")
#}


Simulations.ArrayDPrime[i,j,k,l,m]<-DPrime
Simulations.ArrayMeanDPrime[i,j,k,l]<-Simulations.ArrayMeanDPrime[i,j,k,l]+DPrime
Simulations.ArrayMeanAbsDPrime[i,j,k,l]<-Simulations.ArrayMeanAbsDPrime[i,j,k,l]+abs(DPrime)
Simulations.ArrayMeanpa[i,j,k,l]<-Simulations.ArrayMeanpa[i,j,k,l]+Estfa
Simulations.ArrayMeanpb[i,j,k,l]<-Simulations.ArrayMeanpb[i,j,k,l]+Estfb

if (DPrime>=0) sign=3
if (DPrime<=0) sign=2
if (DPrime==0) sign=1
if (VectorHaplotypes[4]==0) sign<-4

Simulations.Sign[i,j,k,l, sign]<-Simulations.Sign[i,j,k,l, sign]+1
} # end if non 0
} # end for each subsample

#D<- 1-Estfa*Estfb-(Simulations.Sign[i,j,k,l,4]/counter)^(1/VectorSize[l])
#if (Population.VectorDPrime[k]<0) DMax=Population.VectorMAFa[i]*Population.VectorMAFb[j]
#else DMax=min(Population.VectorMAFa[i]*(1-Population.VectorMAFb[j]), (1-Population.VectorMAFa[i])*Population.VectorMAFb[j])
#Simulations.ArrayMeanDPrime[i,j,k,l]<-D/DMax
} # end for each configuration


Simulations.ArrayMeanDPrime<-Simulations.ArrayMeanDPrime/counter
Simulations.ArrayMeanAbsDPrime<-Simulations.ArrayMeanAbsDPrime/counter

save.image("BayesDist.RData")