/* File: genoma.h */

//#include <string>
//#include <math.h>
//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include <cstdio>//
//#include <cmath>//



#ifndef __genoma_h__
#define __genoma_h__

#include "Exceptions.h"

#include "basic.h"
#include "SNP.h"
#include "Tables2x2.h"
#include "phenotype.h"
#include "positions.h"
#include "genotype.h"

      
        



namespace SNP {


         class genoma: public genotype, public phenotype, public positions, public Table2x2
 {


 




	 
       //  public:


    /** @name Implementation of class genoma
        @memo Private part.
    */




  private:

  IndCategory ic;
  
  bool OnlyU, OutputWay;

  unsigned short int Bayes;

  float MAF;

  unsigned short int affected; // 0: non affected, 1: all, 2: affected
 	
  ofstream OutputFile, OutputFile2; 

  frequencies **haps; // AA, Ab, aB, ab, x

  void GetHap (unsigned int FirstSNP, unsigned int LastSNP, frequencies hap);

  void CopyFromHaps(frequencies Target, unsigned int FirstSNP, unsigned int LastSNP);
        
	   /**
         @memo Compute the more frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the more frequent value
*/

		 void SetMajorAllele();

/**
         @memo Compute the less frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the less frequent value
*/

		 void SetMinorAllele();

   	    unsigned long int GetTotalHeterozygous (unsigned long int SNP);

		unsigned long int GetTotalHomozygousType (unsigned long int SNP, unsigned short int typ);

		unsigned long int GetTotalHomozygous1 (unsigned long int SNP);

		unsigned long int GetTotalHomozygous2 (unsigned long int SNP);

		double GetTotalAllele (unsigned long int SNP, bool IsMajor, IndCategory ic2);

		double GetTotalFreqAllele (unsigned long int SNP, bool IsMajor, IndCategory ic2);

		unsigned long int CountType ();

		IndCategory GetIndCat();

		void MarkAllAlleles();

		
		void ChangeIds (char *filename);

		unsigned int FindFirstHeterozygous(Genotype* IndGenotype);

		int GetNextHeterozygous(Genotype* IndGenotype, unsigned int SNP);

		int  GetChildHomozygous(unsigned int i, unsigned int SNP);

		int  GetChildHomozygousHomozygous(unsigned int i, unsigned int SNP, unsigned int SNP2);

		int GetFinalWay (unsigned int SNP1, unsigned int SNP2, int* WayList);

		void ComputeWindowsValues(unsigned int mini, position* i, unsigned int SNP, double Pos, unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance);


/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


		  
		  /**
         @memo Creates a new individual object with the phase resolved.
         @param Origen: the origianl individual object 
         Time complexity O(TotalSNPs*Size*Size)

      */
	 // genoma* ResolvePhase (genoma* Origen);   


	  

      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */
	/*  void WriteResults (char* filename);   */
    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by individual.
           Time complexity O(1).

      */
	  ~genoma ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
	  genoma(const unsigned int TotalSNPs, const unsigned int Size, bool ExistPhenotype, PhaseType PhaseMode);


  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

	//	genoma(const genoma& origen, IndCategory ic); 

		genoma(const genoma& origen, IndCategory ic);
		

//	  individual(const phenotype& porigen, const genotype& gorigen, IndCategory ic);

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

      			
				genoma(char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, bool ExistPhenotype, IndCategory ic, 
			    bool SetHaplotypes, PhaseType PhaseMode, 
				float MAF, unsigned short int affected, bool OnlyU, unsigned short int Bayes, 
				bool OutputWay, unsigned short int ReduceSample);
			

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

      			
				genoma(char* filename, bool ExistPhenotype, IndCategory ic, 
			    bool SetHaplotypes, PhaseType PhaseMode, 
				float MAF, unsigned short int affected, bool OnlyU, unsigned short int Bayes, 
				bool OutputWay, unsigned short int ReduceSample);
			



		 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

	//	genoma(const char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, bool ExistPhenotype, IndCategory ic); 


		/**
         @memo Resolve phase for every pair of consecutive heterozygous positions for every individual in the sample
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
*/





/**
         @memo Compute if heterozygous position have already been resolved.
         @param: individual genotype, first and last position of the region to check
		 @ return: true if all positions are homozygous or heterozygous already resolved; false otherwise
*/
 		void OrderSNPs();

		void ComputeHaplotypes();

	    void ResolveParentPhaseGivenChildren ();

		void CheckRecombinationPositions ();

		void ResolveTrivialPhase ();

		void ChangeFormat (char* filename, char* filename2, unsigned short int Alg, bool Export, const long int InitPos, const unsigned int Length);

		void PhaseAccuracy (const genoma &  TrivialSNP, char* filenameacc, char *filename, char* filesal, bool Distance, unsigned int InitialSNP, unsigned int Length);
	 
		void ExportForPHASE (char *filename, long int InitPos, unsigned int Length);

		void ExportForSNPHAP (char *filename, long int InitPos, unsigned int Length);

		void ExportForHTYPER (char *filename, long int InitPos, unsigned int Length);

		void ExportForBN (char *filename, long int InitPos, unsigned int Length);

		void ExportForHAPLOVIEW (char *filename, long int InitPos, unsigned int Length);

		void ImportFromPHASE (char *filename);
		
		void ImportFromSNPHAP (char *filename);
		
		void ImportFromHTYPER (char *filename);

		void ImportFromMSAMPLE (char *filename, char *filename2, const long int InitialPos, const unsigned int Length);

		void ImportFromHUDSON (char *filename);

		void OrderPositions ();

        unsigned int ReduceSample (char* filename, unsigned int TotalSNPs2, unsigned int Size2, bool FromParents, bool random, unsigned int InitialPos);

		void WriteAccuracy (char* filenameacc, char *filename, unsigned int hetero, unsigned int Error, unsigned int unchecked, unsigned int homo, unsigned int missing, unsigned int unresolved, unsigned int Solved, unsigned int WholeHapAccuracy);

		void PrintAccuracyDistance ();

		void PrintDPrime (char* filename, char* filename2);

		void PrintDPrimeSlidingWindows (char* filename, unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance);

		void SetKnownPhases (bool *MustBeResolved, Genotype *TrivialTheFirstGenotype, bool Distance, unsigned int InitialSNP, unsigned int Length);

		void SetUnresolvedPhases (bool *Unresolved, bool *MustBeResolved);

		void SetBadResolvedPhases(bool *MustBeResolved, bool *Unresolved, bool *BadResolved, Genotype *TrivialTheFirstGenotype);

		void SetBadResolvedPhasesDistance(bool *MustBeResolved, bool *Unresolved, bool *BadResolved, Genotype *TheFirstTrivialGenotype);

		void PrintRecombinationIntervals (char* filename, bool *BadResolved);

		void CheckInconsistencies (const genoma & GenomaTrivial);
		
		void CheckInconsistenciesFromParents ();

		void CompleteMissingFromParents ();

        void TestSPD (bool FromParents, char* namefile);

		bool IsResolved (Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP);

		unsigned int AssignPhasedHAP (unsigned int FirstHetero, unsigned int LastHetero);

		unsigned int AssignPhaseNR (unsigned int FirstHetero, unsigned int LastHetero, Genotype* IndGenotype);
		
		void ReconstructHaplotypes(unsigned short int *MajorPhase, Genotype *IndGenotype);
		
		bool IsLD (unsigned int *Frequencies);
		
		void AssignFrequencies (LDType, frequencies hap, sfrequencies hap2);
   
	    unsigned int Frequency (unsigned int FirstSNP, unsigned int LastSNP, unsigned int Haplotype, frequencies hap);

	    void SetFrequencies (frequencies Frequencies, unsigned int FirtSNP, unsigned int LastSNP);
 
	    void ResolvePhase (sfrequencies Frequencies, double* probs, unsigned int SNP1, unsigned int SNP2);

		void UseProbabilities (sfrequencies Frequencies, double* probs);

	    bool MarginalIsZero (double* probs);

		bool MarginalIsZero (unsigned int SNP1, unsigned int SNP2);

		void PrintSNPPositions (char* filename);

		bool ResolveTrivialPhase(unsigned int ind, unsigned int SNP1, unsigned int SNP2);

		bool ResolvePhaseForAGenericParent(unsigned int ind, unsigned int SNP1, unsigned int SNP2, bool trios);

		bool ResolveTU(unsigned int ind, unsigned int SNP, bool trios);

		void ResolveTU ();

		void ResolvePhase (PhaseType PhaseMode);

		double GetHapFrequency (unsigned int FirstSNP, unsigned int LastSNP, unsigned int Haplotype, frequencies hap);

		void WriteResults (char* filename, bool PrintPhenotypes, short int Ic, RedType R, int FirstSNP, unsigned int RegionSize);

		void WriteHaplotypes (char* filename, int FirstSNP, unsigned int RegionSize);

		double GetTotalHaps(frequencies hap);

		void GetLongHaps(double* LongHaps, Genotype* IndGenotypeRef, unsigned int FirstPos, unsigned int LastPos, unsigned int heteroPos);

	    /**
         @memo Resolve the phase between two consequtive heterozygous position for an individual.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param ForPhase: pointer to the genotypes of all individuals
         @param FirstSNP, LastSNP: the two loci
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
	     @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
*/

		short unsigned int ObtenerBestPhase2 (unsigned int FirstHetero, unsigned int LastHetero, 
		Genotype* IndGenotypeRef, unsigned long int Ind);

/**
         @memo Resolve the phase for a data set.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
*/
		//void ResolvePhase (bool PreSolved);

		/**
         @memo Resolve the phase for a data se between every consecutive loci.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
*/
		void AdjustFrequencies(LDType mode, frequencies hap, sfrequencies hap2, bool Semi);

		template <class T>void PrintValues (T Freqs, unsigned int SNP1, unsigned int SNP2, bool EM);

		template <class T>void PrintValues (T Freqs, T Freqs2, bool max, double total, unsigned int SNP1, unsigned int SNP2);

		void PrintWay (unsigned int SNP, sfrequencies hap);

		void ResolveFromPhasedChildren ();

		void ResolveFromFile (char *filename);

		double SumFreqs(frequencies hap);

		void SetHapsFreqsUnderEquilibrium(double* Freqs, unsigned int SNP1, unsigned int SNP2, IndCategory inc2);

		void SetHapsFreqsUnderEquilibrium2(double* Freqs, double* Freqs2);


};  // End of class genoma


/* _____________________________________________________*/

void genoma::SetMajorAllele()
{
//OrderSNPs(ic);
	cout <<"Computing major alleles...\n";
	Phenotype * IndPhenotype;
Genotype * IndGenotype;
unsigned int TotalUsed;
unsigned int Basis[5], max, MaxVal;
if (MajorAllele==NULL)
{
if ((MajorAllele=new allele[genotype::TotalSNPs])==NULL)
      throw NoMemory();
}
else { cout << "Already computed"; exit(0);}

for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
{
for (int c=0;c<=4;c++)
 Basis[c]=0;

IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++)
{
	
 //if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
	{
     if (*((IndGenotype->Left)+SNP)>0)
	  Basis[(int)*((IndGenotype->Left)+SNP)]++; 
	 if (*((IndGenotype->Right)+SNP)>0)
	  Basis[(int)*((IndGenotype->Right)+SNP)]++; 
	}
	
  IndPhenotype=IndPhenotype->Next;
  IndGenotype=IndGenotype->Next;
}
TotalUsed=0; 
max=0;
MaxVal=0;

try
{

for (int c2=1;c2<=4;c2++)
{
 if (Basis[c2]>0) TotalUsed++;  

if (Basis[c2]>max)
{
 max=Basis[c2];
 MaxVal=c2;
}
}

if (TotalUsed>2)
{
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0)     
  cout << "\nallele " << c2;

 throw MultiAllelic();
}
//if (TotalUsed<2)
// throw MonoAllelic();

}
	catch (MultiAllelic ma) {
        ma.PrintMessage(SNP);
      }
	catch (MonoAllelic ma) {
        ma.PrintMessage(SNP);
      }
MajorAllele[SNP]=(allele)MaxVal;
//cout <<"\nMajor allele SNP: " << SNP <<" is: " << MajorAllele[SNP];
   
}

cout <<"Major alleles has been computed\n";
} 


/* _____________________________________________________*/


void genoma::SetMinorAllele()
{
//OrderSNPs(ic);
	cout <<"Computing minor alleles...\n";
Phenotype * IndPhenotype;
Genotype * IndGenotype;
unsigned int TotalUsed;
unsigned int Basis[5], min, MinVal;
if (MinorAllele==NULL)
{
if ((MinorAllele=new allele[genotype::TotalSNPs])==NULL)
      throw NoMemory();
}
else { cout << "Already computed"; exit(0);}

for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
{
for (int c=0;c<=4;c++)
 Basis[c]=0;
IndPhenotype=TheFirstPhenotype;
IndGenotype=TheFirstGenotype;
for (int i=0;i<Size;i++)
{
// if ((ic==2) || ((ic==1) && (IsAChild (IndPhenotype))) || ((ic==0) & (!IsAChild (IndPhenotype))))
	{
     if ((*((IndGenotype->Left)+SNP)>0) && (*((IndGenotype->Left)+SNP)<5))
	  Basis[(int)*((IndGenotype->Left)+SNP)]++; 
	 if ((*((IndGenotype->Right)+SNP)>0) && (*((IndGenotype->Right)+SNP)<5))
	  Basis[(int)*((IndGenotype->Right)+SNP)]++; 
	}
  IndPhenotype=IndPhenotype->Next;
  IndGenotype=IndGenotype->Next;
}
TotalUsed=0; 
min=Size+1;
MinVal=0;
try
{
for (int c2=1;c2<=4;c2++)
{
 if (Basis[c2]>0) TotalUsed++;      


if ((Basis[c2]<min) && (Basis[c2]>0) && (c2!=(int)MajorAllele[SNP]))
{
 min=Basis[c2];
 MinVal=c2;
}
}
if (TotalUsed>2) 
{
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0)     
  cout << "\nallele " << c2;
 throw MultiAllelic();
}
// throw MultiAllelic(); 
 
}
catch (MultiAllelic ma)
{
	ma.PrintMessage(SNP);
};

try
{
if (TotalUsed==2)
{
//for (int c2=1;c2<=4;c2++)
// if (Basis[c2]>0)     
//  cout << "\nallele " << c2 <<", Basis: " << Basis[c2];

 MinorAllele[SNP]=(allele)MinVal; 
// cout <<"\nMinor allele SNP: " << SNP <<" is: " << MinorAllele[SNP];
// cout <<"\nMajor allele SNP: " << SNP <<" is: " << MajorAllele[SNP];
}
if (TotalUsed<2)
{
// throw MonoAllelic();
// MinorAllele[SNP]=(allele)((((int)MajorAllele[SNP]+1)%4)+1);
// cout <<"\nMinVal:" << MinVal; 
// cout <<"\ndMinor allele SNP: " << SNP <<" is: " << MinorAllele[SNP];
// cout <<"\nMajor allele SNP: " << SNP <<" is: " << MajorAllele[SNP];
// cout <<"\nTotalUsed:" << TotalUsed;
}
// cout <<"error at pos" << SNP;
}
catch (MonoAllelic ma)
{
	ma.PrintMessage(SNP);
};


}
cout <<"Minor alleles has been computed\n";

}

/*____________________________________________________________ */

void genoma::WriteResults (char* filename, bool PrintPhenotypes=true, short int intIc=-1, RedType R=None, int FirstSNP=-1, unsigned int RegionSize=0)
 {
IndCategory Ic;
if (intIc==-1) Ic=ic;
else Ic=(IndCategory) intIc;
  ofstream OutputFile; 
  Phenotype *IndPhenotype=TheFirstPhenotype; 
  Genotype *IndGenotype=TheFirstGenotype;
  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }



  for (int i=0; i<Size;i++)
  {
if (Selected[i] || Selected==NULL)	  
 if ((Ic==offspring && IsAChild (IndPhenotype)) || (Ic==parent && IsAParent (IndPhenotype)) 
	 || (Ic==everybody) || (Ic==father && IsAFather(IndPhenotype)) || (Ic==mother && IsAMother(IndPhenotype)))
    if (IndPhenotype!=NULL)
	{
	if (PrintPhenotypes)
	{
		
	OutputFile << IndPhenotype->Pedigree << ' ';
	OutputFile << IndPhenotype->Code << ' ';
	OutputFile << IndPhenotype->Father << ' ';
	OutputFile << IndPhenotype->Mother << ' ';
	OutputFile << IndPhenotype->Gender << ' ';
	OutputFile << IndPhenotype->Affectation << ' ';
	OutputFile << IndPhenotype->Code2 << ' ';
	}
    position* IndPosition=TheFirstPosition;

	unsigned int cont=0;

    for (int i2=0; i2<genotype::TotalSNPs;i2++)
    {
     if ((IndPosition->unrepeated)==true)
      if
      (
      ((R==Project) && (IndPosition->selected))
      ||
      (
      (R==None)
       &&
      (FirstSNP==-1 || ((i2>=FirstSNP) && (cont<RegionSize)))
      )
      )
	{
	 OutputFile << *((IndGenotype->Left)+i2) << ' ';
     OutputFile << *((IndGenotype->Right)+i2) << ' ';
	 cont++;
	}
      
     IndPosition=IndPosition->Next;
	}
	OutputFile << "\n";
	}
    IndGenotype=IndGenotype->Next;
    IndPhenotype=IndPhenotype->Next;
  }
  OutputFile.close();

cout << "\nInformation about phased genotype has been saved in file " << filename <<"\n";
 }

/*____________________________________________________________ */

void genoma::WriteHaplotypes (char* filename, int FirstSNP=-1, unsigned int RegionSize=0)
 {


  ofstream OutputFile; 
  Phenotype *IndPhenotype=TheFirstPhenotype; 
  Genotype *IndGenotype=TheFirstGenotype;
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
  for (int i=0; i<Size;i++)
  {
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
	if (Selected[i])
	{
	 OutputFile << "ind " << IndPhenotype->Pedigree << '-';
	 OutputFile << IndPhenotype->Code << '\n';

    for (int i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
	 OutputFile << *((IndGenotype->Left)+i2) << ' ';
	}
	OutputFile << "\n";
	for (int i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
     OutputFile << *((IndGenotype->Right)+i2) << ' ';
	}
	OutputFile << "\n";
	}
    IndGenotype=genotype::GetNext(IndGenotype);
	IndPhenotype=phenotype::GetNext(IndPhenotype);
	}
 OutputFile.close();
cout << "Information about haplotypes has been saved in file " << filename <<"\n";
 }



/*__________________________________________________________*/

unsigned long int genoma::GetTotalHeterozygous (unsigned long int SNP)
{
Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

unsigned long int TotalHeterozygous=0;
try
{
for (int i=0;i<Size;i++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))


   if (IsHeterozygous(IndGenotype, SNP))
	   TotalHeterozygous++;

   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);

   if (i<(Size-1))
	if (IndGenotype==NULL) 
    throw NullValue();

	
   if (i<(Size-1))
	if (IndPhenotype==NULL) 
    throw NullValue();
}
}
	catch (NullValue nv) {
        nv.PrintMessage();
      }


return TotalHeterozygous;
}
/* ____________________________________________*/
void genoma::MarkAllAlleles()
{
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;

for (int i=0;i<Size;i++) 
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
  for (unsigned int SNP=1;SNP<genotype::TotalSNPs;SNP++)
   if (IsHeterozygous (IndGenotype, SNP))  
	   MarkAlleles(IndGenotype, SNP);
   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);
}
}
/*__________________________________________________________*/

unsigned long int genoma::GetTotalHomozygousType (unsigned long int SNP, unsigned short int typ)
{
Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

unsigned long int TotalHomozygous=0;
try
{
for (int i=0;i<Size;i++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))

 if (((typ==1) && (IsHomozygous1(IndGenotype, SNP))) || ((typ==2) && (IsHomozygous2(IndGenotype, SNP))))
	   TotalHomozygous++;

   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);

   if (i<(Size-1))
	if (IndGenotype==NULL) 
    throw NullValue();

	
   if (i<(Size-1))
	if (IndPhenotype==NULL) 
    throw NullValue();
}
}
	catch (NullValue nv) {
        nv.PrintMessage();
      }


return TotalHomozygous;
}

/*___________________________________________________________*/
unsigned long int genoma::GetTotalHomozygous1 (unsigned long int SNP)
{
	return (GetTotalHomozygousType (SNP, 1));
}
/*___________________________________________________________*/
unsigned long int genoma::GetTotalHomozygous2 (unsigned long int SNP)
{
	return (GetTotalHomozygousType (SNP, 2));
}

/*__________________________________________________________*/

double genoma::GetTotalAllele (unsigned long int SNP, bool IsMajor, IndCategory ic2)
{
try
{
	if (SNP>=genotype::TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}



Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

double TotalAllele=0.0;
try
{
for (int i=0;i<Size;i++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
{
   if (IsHeterozygous(IndGenotype, SNP))
	   TotalAllele=TotalAllele+1;
   if ((IsHomozygous1(IndGenotype, SNP) && IsMajor) ||  (IsHomozygous2(IndGenotype, SNP) && !IsMajor)) 
   	   TotalAllele=TotalAllele+2;
 }
   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);

   if (i<(Size-1))
	if (IndGenotype==NULL) 
    throw NullValue();

	
   if (i<(Size-1))
	if (IndPhenotype==NULL) 
    throw NullValue();
}
}
	catch (NullValue nv) {
        nv.PrintMessage();
      }


switch (Bayes)
{
case 0: break;
case 1: TotalAllele=TotalAllele+2; break;
case 2: TotalAllele=TotalAllele+0.5; break;
case 3: break;
}

return TotalAllele;
}
/*__________________________________________________________*/

double genoma::GetTotalFreqAllele (unsigned long int SNP, bool IsMajor, IndCategory ic2)
{
return GetTotalAllele(SNP, IsMajor, ic2)/(double)(GetTotalAllele(SNP, IsMajor, ic2)+GetTotalAllele(SNP, !IsMajor, ic2));
}
/*__________________________________________________________*/

unsigned long int genoma::CountType ()
{
Genotype* IndGenotype=TheFirstGenotype;
Phenotype* IndPhenotype=TheFirstPhenotype;

unsigned long int Total=0;
try
{
for (int i=0;i<Size;i++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
  Total++;

   IndGenotype=genotype::GetNext(IndGenotype);
   IndPhenotype=phenotype::GetNext(IndPhenotype);

   if (i<(Size-1))
	if (IndGenotype==NULL) 
    throw NullValue();

	
   if (i<(Size-1))
	if (IndPhenotype==NULL) 
    throw NullValue();
}
}
	catch (NullValue nv) {
        nv.PrintMessage();
      }



return Total;
}
/*______________________________________________________________________________*/

IndCategory genoma::GetIndCat()
{
return ic;
}

/*____________________________________________________________ */

genoma::genoma(const unsigned int TotalSNPs, const unsigned int Size, bool ExistPhenotype, PhaseType PhaseMode): 
positions(TotalSNPs), phenotype(Size, ExistPhenotype), genotype(TotalSNPs, Size)
//, positions (TotalSNPs)
{
	this->PhaseMode=PhaseMode;
	haps=NULL;
	MajorAllele=NULL;
    MinorAllele=NULL;

};
/*____________________________________________________________ */

genoma::genoma(const genoma& origen, IndCategory ic): positions(origen), phenotype(origen), genotype(origen)
//, positions (origen.genotype::TotalSNPs)
{

  MajorAllele=NULL;
  MinorAllele=NULL;

	if ((haps=new frequencies*[genotype::TotalSNPs-1])==NULL)
     throw NoMemory();
	for (unsigned int i=0;i<(genotype::TotalSNPs-1);i++)
	{
	if ((haps[i]=new frequencies[genotype::TotalSNPs-i-1])==NULL)
     throw NoMemory();
   	for (unsigned int j=0;j<(genotype::TotalSNPs-i-1);j++)
 	 for (unsigned int k=0;k<9;k++)	
      haps[i][j-i-1][k]=origen.haps[i][j-i-1][k];

	}



};

/*____________________________________________________________ */

genoma::genoma(char* filename, bool ExistPhenotype, IndCategory ic, 
			    bool SetHaplotypes, PhaseType PhaseMode=KeepUnordered, 
				float MAF=0.05, unsigned short int affected=0, bool OnlyU=false, unsigned short int Bayes=0, 
				bool OutputWay=false, unsigned short int ReduceSample=1): 
				positions (filename), 
					phenotype(filename, positions::TotalSNPs, ExistPhenotype, ReduceSample), 
					genotype(filename, positions::TotalSNPs, ReduceSample)
                                //positions (filename2, InputTotalSNPs) 
{
 
this->PhaseMode=PhaseMode;
this->ic=ic;
this->MAF=MAF;
this->affected=affected;
this->OnlyU=OnlyU;
this->Bayes=Bayes; 

if (!IsOrdered())
 OrderPositions();
else
 cout << "\nAll the SNPs positions were already ordered\n";


MajorAllele=NULL;
MinorAllele=NULL;


try {
 SetMajorAllele ();
 SetMinorAllele (); 
}
  catch (NoMemory no) {
  no.PrintMessage();
  }

if (((ic==1) || (ic==2)) && (PhaseMode!=KeepUnordered))
{
 CheckInconsistenciesFromParents();
 CompleteMissingFromParents();
}

// after completing missing genotypes, major and minor will be computed again

cout << "Computing major and minor alleles from file " << filename << " ...\n";


delete MajorAllele;
delete MinorAllele;

MajorAllele=NULL;
MinorAllele=NULL;



try {
 SetMajorAllele ();
 SetMinorAllele (); 
}
  catch (NoMemory no) {
  no.PrintMessage();
  }


 cout << "Computation of major and minor alleles has finished\n";


switch (PhaseMode)
{
case IsPhased: break;
case KeepUnordered: break;
case ToOrder: OrderSNPs(); break;
case ResolveFromTU: ResolveTU(); break;
case dHap: ResolvePhase(dHap); break; 
case ResolveFromPhasedChild: ResolveFromPhasedChildren(); break;
case ResolvePhaseFromFile: 
	ResolveTU(); // first do this to identify T/U haplotypes
	ResolveFromPhasedChildren(); 
	break;
case NR: ResolvePhase(NR); break; 

};
if (SetHaplotypes)
 ComputeHaplotypes();


};
/*____________________________________________________________ */


void genoma::OrderPositions()
{

	if (!OrderedPositions)

		if (positions::OrderPositions()) cout << "\nAll the SNPs positions were already ordered";
	else
	{

         position* IndPosition=TheFirstPosition;

	allele *ListAllelesLeft, *ListAllelesRight;

	if ((ListAllelesLeft=new allele[genotype::TotalSNPs])==NULL)
		throw NoMemory();
	if ((ListAllelesRight=new allele[genotype::TotalSNPs])==NULL)
		throw NoMemory();


	Phenotype* IndPhenotype=TheFirstPhenotype;
	Genotype* IndGenotype=TheFirstGenotype;

    for (int i=0; i<SizeP;i++)
	{
     for (int i2=0; i2<genotype::TotalSNPs;i2++)
	 {
	  *(ListAllelesLeft+i2)=*(IndGenotype->Left+i2);
  	  *(ListAllelesRight+i2)=*(IndGenotype->Right+i2);
	 }

	 IndPosition=TheFirstPosition;
     for (int i2=0; i2<genotype::TotalSNPs;i2++)
	 {
	  *(IndGenotype->Left+i2)=*(ListAllelesLeft+(IndPosition->filepos));  
  	  *(IndGenotype->Right+i2)=*(ListAllelesRight+(IndPosition->filepos));   
	  IndPosition=IndPosition->Next;
	 }
     
     IndPhenotype=IndPhenotype->Next;
	 IndGenotype=IndGenotype->Next;
	}
 delete ListAllelesLeft, ListAllelesRight;
	}
	

  cout <<"Sorting has been finished\n";
}
/*____________________________________________________________ */

void genoma::OrderSNPs()
{
Phenotype  *IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
allele SwitchAllele;

if (ic==offspring)
cout <<"\nSorting offspring genotypes as unphased...";
if (ic==parent)
cout <<"\nSorting parent genotypes as unphased...";
if (ic==everybody)
cout <<"\nSorting all genotypes as unphased";
if (ic==father)
cout <<"\nSorting father genotypes as unphased";
if (ic==mother)
cout <<"\nSorting mother genotypes as unphased";

for (int i=0;i<Size;i++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
 
	 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)

    if (IsHeterozygous(IndGenotype, SNP))
	{
     if (*((IndGenotype->Left)+SNP)>*((IndGenotype->Right)+SNP))
	 {        
      SwitchAllele=*((IndGenotype->Left)+SNP);
      *((IndGenotype->Left)+SNP)=*((IndGenotype->Right)+SNP);
	  *((IndGenotype->Right)+SNP)=SwitchAllele;
     }
	}
  IndPhenotype=IndPhenotype->Next;
  IndGenotype=IndGenotype->Next;
}
cout <<"\nSorting genotypes has finished";
}      
            
/*______________________________________________________*/
bool genoma::ResolveTrivialPhase(unsigned int ind, unsigned int SNP1, unsigned int SNP2)
{
// It is better to use procedure ResolveT/U. There are still errors in this procedure about the
// marking for non known phase that has to be fixed.
// This procedure should be used to solve the phase between every pair of closest hetero for each
// individual. If it used to solve the phase only between every pair of consecutive hetero, 
// the whole haplotype will not be correctly reconstructed.
// if cannot be solved, mark the first position only if the other 2 members in the trio are
// also hetero in that position
// if ind is a child
// to can solve the phase between a pair of loci, at least one parent must be homozygous in both loci 
// or  both of them must be homozygous in different loci
// if ind is a parent, phase can be solved when at least one child is homozygous in the pair of loci to be solved
// or the couple and one child are homozygous in different positions
// for parents, this routine assumes that there is not a recombination from the parent to the children
// In this case, basis are interchanged if needed.
// If ind is a parent, basis will be also interchanged if need so that the first haplotypes must correspond to the haplotype transmitted to the child,
// the other is the untransmitted haplotype (only valid for trios)
// If ind is a child, basis will be also interchanged if need so that the first haplotype is the one inherited from the father, the second from the mother

	
bool Solved=true, found=false;
Genotype* IndGenotype=GetGenotype(ind), *WildCardGenotype;
Phenotype* IndPhenotype=GetPhenotype(ind);

Genotype* Relative1Genotype, * Relative2Genotype;

try
{
 if (!IsHeterozygous (IndGenotype, SNP1)) 
	 throw NonHetero();
}
 	 catch (NonHetero nh) {
		 nh.PrintMessage(SNP1, ind);}

try
{
 if (!IsHeterozygous (IndGenotype, SNP2)) 
	 throw NonHetero();
}
 	 catch (NonHetero nh) {
		 nh.PrintMessage(SNP2, ind);}

 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
  {
if (IsAChild(IndPhenotype))
{
Relative1Genotype=GetGenotype(GetFather(IndPhenotype));
Relative2Genotype=GetGenotype(GetMother(IndPhenotype));
if ((
	(IsHomozygous(Relative1Genotype, SNP1) && IsHomozygous(Relative1Genotype, SNP2))
	|| 
	(IsHomozygous(Relative2Genotype, SNP1) && IsHomozygous(Relative2Genotype, SNP2))
	|| 
	(IsHomozygous(Relative1Genotype, SNP1) && IsHomozygous(Relative2Genotype, SNP2))
	|| 
	(IsHomozygous(Relative1Genotype, SNP2) && IsHomozygous(Relative2Genotype, SNP1))
	))
found=true;
//cout <<"child";
}
else
{
//cout <<"Parent";
int child=GetFirstChild(IndPhenotype);

while ((child>=0) && (!found))
{
Relative2Genotype=GetGenotype(child);
Relative1Genotype=GetGenotype(GetCouple(IndPhenotype, GetPhenotype(child)));
if ((
	 (IsHomozygous(Relative1Genotype, SNP1) && IsHomozygous(Relative1Genotype, SNP2))
	|| 
	(IsHomozygous(Relative2Genotype, SNP1) && IsHomozygous(Relative2Genotype, SNP2))
	|| 
	(IsHomozygous (Relative1Genotype, SNP1) && IsHomozygous (Relative2Genotype, SNP2))
	|| 
	(IsHomozygous (Relative1Genotype, SNP2) && IsHomozygous (Relative2Genotype, SNP1))
	))
found=true;
else child=GetNextSib(child, IndPhenotype);
};
}

   if (!found)
   {
	Solved=false;
   }

else
{
   UnmarkAlleles (IndGenotype, SNP1);
   if ((IsHomozygous(Relative1Genotype, SNP1) && IsHomozygous(Relative1Genotype, SNP2))
	|| (IsHomozygous(Relative2Genotype, SNP1) && IsHomozygous(Relative2Genotype, SNP2)))
   {
   if (IsHomozygous(Relative1Genotype, SNP1) && IsHomozygous(Relative1Genotype, SNP2)) 
	   WildCardGenotype=Relative1Genotype;
   else 
	   WildCardGenotype=Relative2Genotype;

   if (!IsTheSamePhase(IndGenotype, WildCardGenotype, SNP1, SNP2, Left))
    ChangeAlleles(IndGenotype, SNP2);
   }
   else // both homozyogus in different positions
	if (IsHomozygousHeterozygous (Relative1Genotype, Relative2Genotype, SNP1) &&
	IsHomozygousHeterozygous (Relative1Genotype, Relative2Genotype, SNP2))
	{
	if (IsHeterozygous(Relative1Genotype, SNP1)) 	  
		WildCardGenotype=Relative1Genotype;
	 else WildCardGenotype=Relative2Genotype;
      if   (*((Relative1Genotype->Left)+SNP1)!=*((Relative2Genotype->Left)+SNP1)) 
	  {
	   if (!IsTheSamePhase(IndGenotype, WildCardGenotype, SNP1, SNP2, Left))
        ChangeAlleles(IndGenotype, SNP2);
	  }
	  else
      if (!IsTheSamePhase(IndGenotype, WildCardGenotype, SNP1, SNP2, Right))
       ChangeAlleles(IndGenotype, SNP2);
	}
} // end if can be solved
 } //end if ic
return Solved;
}
/*______________________________________________________*/
bool genoma::ResolveTU(unsigned int ind, unsigned int SNP, bool trios=true)
{
// this procedure should be equivalent to the ResolveTrivialPhase procedure when ResolveTrivialPhase
// is appropiately used: to solve the phase in every pair of closest heterozygous.
// If T/U cannot be determined from the family, mark the position 
// if ind is a child, the first allele will be the one inherited from the father,
// the second from the mother.
// to can solve the T/U of an heterozygous individual, at least one of the
// other members of the trio hsa to be homozygous.
// In this case, basis are interchanged if needed.


bool Solved=false;
Genotype* IndGenotype=GetGenotype(ind);
Phenotype* IndPhenotype=GetPhenotype(ind);

Genotype* Relative1Genotype, * Relative2Genotype;


try
{
 if (!IsHeterozygous (IndGenotype, SNP)) 
	 throw NonHetero();
}
 	 catch (NonHetero nh) {
		 nh.PrintMessage(SNP, ind);}


if (IsAChild(IndPhenotype))
{
//cout <<"child";
//	exit(0);
Relative1Genotype=GetGenotype(GetFather(IndPhenotype));
Relative2Genotype=GetGenotype(GetMother(IndPhenotype));
if (IsHomozygous(Relative1Genotype, SNP)) // father homozygous
{
Solved=true;
//cout <<"child";
if (!IsTheSameAllele(IndGenotype, Relative1Genotype, SNP, left)) 
 ChangeAlleles(IndGenotype, SNP);
}
else
if (IsHomozygous(Relative2Genotype, SNP)) //mother homozygous
{
Solved=true;
//cout <<"child";
if (!IsTheSameAllele(IndGenotype, Relative2Genotype, SNP, right))
 ChangeAlleles(IndGenotype, SNP);
}
}

else // a parent
{
//	cout <<"parent";
//	exit(0);
//cout <<"Parent";
int child=GetFirstChild(IndPhenotype);
//cout <<"child:" << child;

while ((child>=0) && (!Solved))
{
Relative1Genotype=GetGenotype(child);
Relative2Genotype=GetGenotype(GetCouple(IndPhenotype, GetPhenotype(child)));
  //cout <<"couple:" << GetCouple(IndPhenotype, GetPhenotype(child));


if (IsHomozygous(Relative1Genotype, SNP)) //child homo
{
 Solved=true;
 //cout <<"\nsolved parent " << ind;
 if (!IsTheSameAllele(IndGenotype, Relative1Genotype, SNP, left))
 ChangeAlleles(IndGenotype, SNP);
}
else
if (IsHomozygous(Relative2Genotype, SNP)) // couple homo
{
 Solved=true;
 //cout <<"\nsolved parent " << ind;
 if (IsTheSameAllele(IndGenotype, Relative2Genotype, SNP, left))
 ChangeAlleles(IndGenotype, SNP);
}
else 
if (!trios)
child=GetNextSib(child, IndPhenotype);
else
child=-1;
};
}

if (!Solved)
 MarkAlleles (IndGenotype, SNP);

return Solved;
}
/*______________________________________________________*/
bool genoma::ResolvePhaseForAGenericParent(unsigned int ind, unsigned int SNP1, unsigned int SNP2, bool trios=true)
{
// solve phase for a parent without distinguishing between parents when both
// of them are heterozygous in both positions and the child is homozygous in 1 position
// we will solve the phase for the father and the mother always in the same way
bool Solved=false;
Genotype* IndGenotype=GetGenotype(ind);
Phenotype* IndPhenotype=GetPhenotype(ind);

Genotype* Relative1Genotype, * Relative2Genotype;

try
{
 if (!IsHeterozygous (IndGenotype, SNP1))
	 throw NonHetero();
}
 	 catch (NonHetero nh) {
		 nh.PrintMessage(SNP1, ind);}

try
{
 if (!IsHeterozygous (IndGenotype, SNP2)) 
	 throw NonHetero();
}
 	 catch (NonHetero nh) {
		 nh.PrintMessage(SNP2, ind);}

if (!IsAParent(ind))
{
cout <<"Ind " << ind <<" is not a parent";
exit(0);
}

int child=GetFirstChild(IndPhenotype);

while ((child>=0) && (!Solved))
{
Relative2Genotype=GetGenotype(child);
Relative1Genotype=GetGenotype(GetCouple(IndPhenotype, GetPhenotype(child)));
if ((
	 (IsHeterozygous(Relative1Genotype, SNP1) && IsHeterozygous(Relative1Genotype, SNP2))
&& 
	(((IsHomozygous(Relative2Genotype, SNP1) && IsHeterozygous(Relative2Genotype, SNP2)) 
	|| (IsHeterozygous(Relative2Genotype, SNP1) && IsHomozygous(Relative2Genotype, SNP2))))
	))
Solved=true;
else 
if (!trios)
 child=GetNextSib(child, IndPhenotype);
else child=-1;
};

if (Solved)
  {

	if ((IsAFather(ind) && !IsAnOrderedPhase(IndGenotype, SNP1, SNP2))
	   || (IsAMother(ind) && IsAnOrderedPhase(IndGenotype, SNP1, SNP2)))
       ChangeAlleles(IndGenotype, SNP2);

//		cout <<" cambiado a " << *((IndGenotype->Left)+SNP1) << *((IndGenotype->Right)+SNP1) <<"," 
//<<*((IndGenotype->Left)+SNP2) << *((IndGenotype->Right)+SNP2);
} // end if can be solved
return Solved;
}
/*______________________________________________________*/

void genoma::ResolveTrivialPhase ()
{
// obtain phase for ind. using his/her family
// otherwise, write the symbol minus and the heterozygous values,
// with  the lower one first Ex: 3 1 will be written as - 1 -3 in the first position
cout << "\nReconstructing haplotypes from families...";
//cout << "Siz:" << Size << "SNP" << genotype::TotalSNPs;
//exit(0);

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
unsigned int LastHetero=0;
unsigned int SNP;
for (int i=0;i<Size;i++) // for each individual
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
{
LastHetero=FindFirstHeterozygous(IndGenotype);
for (SNP=LastHetero+1;SNP<genotype::TotalSNPs;SNP++)
if (IsHeterozygous(IndGenotype, SNP))
{
 ResolveTrivialPhase(i, LastHetero, SNP); 
 LastHetero=SNP;
} // end for if Heterozygous SNP
} // end for each child

 if (i<(Size-1))
 {
 if  ((IndGenotype=IndGenotype->Next)==NULL)
	 throw NullValue();
 if  ((IndPhenotype=IndPhenotype->Next)==NULL)
	 throw NullValue();
 }
} // end for each individual

cout << "\nReconstruction from families has finished";
}
/*______________________________________________________*/

void genoma::ResolveTU ()
{
// obtain transmitted and untransmitted haplotypes for ind. using his/her family
	// should equivalent to procedure ResolveTrivialPhase
// otherwise, write the symbol minus and the heterozygous values,
cout << "\nReconstructing transmitted/untransmitted haplotypes from families...";
//cout << "Siz:" << Size << "SNP" << genotype::TotalSNPs;
//exit(0);

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
unsigned int SNP;

for (int i=0;i<Size;i++) // for each individual
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
{
for (SNP=0;SNP<genotype::TotalSNPs;SNP++)
if (IsHeterozygous(IndGenotype, SNP))
 ResolveTU(i, SNP); 
} // end for each individual

 if (i<(Size-1))
 {
	 IndGenotype=genotype::GetNext(IndGenotype);
	 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
} // end for each individual

cout << "\nReconstruction from families has finished";
}
/*______________________________________________________*/

void genoma::ResolveFromPhasedChildren ()
{
// done for trios
// consider children already phased and obtain transmitted and untransmitted haplotypes for 
// parents using the child's phase. 
cout << "\nReconstructing transmitted/untransmitted haplotypes of parents assuming phased children...";
//cout << "Siz:" << Size << "SNP" << genotype::TotalSNPs;
//exit(0);
bool FirstUnsolved=false;
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *ChildGenotype;
unsigned int SNP;
for (int i=0;i<Size;i++) // for each individual
{
if ((ic!=1) && (IsAParent (IndPhenotype))) // for parents
for (SNP=0;SNP<genotype::TotalSNPs;SNP++)
if (IsHeterozygous(IndGenotype, SNP))
{
 ChildGenotype=GetGenotype(GetFirstChild(IndPhenotype));
 if (!IsUnresolved(ChildGenotype, SNP)) // is not missing and is solved
 {
  if ((IsAMother(IndPhenotype) && !IsTheSameAllele(IndGenotype, ChildGenotype, SNP, leftright)) ||
	  (IsAFather(IndPhenotype) && !IsTheSameAllele(IndGenotype, ChildGenotype, SNP, left)))
	ChangeAlleles (IndGenotype, SNP);
 }
 else
	 if (!FirstUnsolved) FirstUnsolved=true;
	 else MarkAlleles (IndGenotype, SNP);
} // end for heterozygous SNP

 if (i<(Size-1))
 {
	 IndGenotype=genotype::GetNext(IndGenotype);
	 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
} // end for each individual

cout << "\nReconstruction from phased children has finished";
}
/*___________________________________________________________________________*/
int genoma::GetFinalWay (unsigned int SNP1, unsigned int SNP2, int* WayList)
{
// it computes the final way if all the phases are solved between SNP1 and SNP2 in WayList, 
// if not it will return a 0;
	int way=1;
	for (unsigned int SNP=SNP1;SNP<SNP;SNP++)
	 if (WayList[SNP]==2 && way==1)
		 way=2;
	 else if (WayList[SNP]==1 && way==2)
		 way=1;
	 else if (WayList[SNP]==0) way=0;
	 return (way);
}
/*__________________________________________________________________________ */

void genoma::ResolveFromFile (char *filename)
{
// is phase is 0 in the file, means that cannot be solved, and position will be marked
// to keep the T/U haplotypes in order, the rutine will begin in the first TU-unknown hetero position 
// after one TU-known hetero position. It will advance right and left until reach the extremes
// of this pair of haplotypes.

cout << "\nReconstructing phase using a file ...";

ifstream InputFile; 


InputFile.open (filename, ifstream::in);
if (!InputFile)
	throw ErrorFile();
    int * Way;
	char *buf;
    if ((buf=new char[2])==NULL)
     throw NoMemory();
	if ((Way=new int[genotype::TotalSNPs])==NULL)
     throw NoMemory();




// read file in array Way
for (int i=0; i<(genotype::TotalSNPs-1); i++)
{
		if (InputFile.peek()==EOF) 
	     throw EOFile();
	    InputFile.getline (buf, 2, '\n');
		sscanf (buf, "%d", Way+i);
}
InputFile.close();

Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;
int LastHetero=0;
int SNP, InitialSNP;
short int FinalWay;
for (int i=0;i<Size;i++) // for each individual
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
{
do // look for the first solved hetero using families, this will be the initial point
{
InitialSNP=FindFirstHeterozygous(IndGenotype);
}
while (InitialSNP<genotype::TotalSNPs && IsUnresolved(IndGenotype, InitialSNP));

LastHetero=InitialSNP;
// from InitialSNP to right
for (SNP=InitialSNP+1;SNP<genotype::TotalSNPs;SNP++)
if (IsHeterozygous(IndGenotype, SNP))
{
 FinalWay=GetFinalWay(LastHetero, SNP, Way);
 if (IsUnresolved (IndGenotype, SNP) && FinalWay!=0)
 {
 if ((FinalWay==1 && !IsAnOrderedPhase(IndGenotype, LastHetero, SNP)) 
	 || (FinalWay==2 && IsAnOrderedPhase(IndGenotype, LastHetero, SNP)))
 ChangeAlleles (IndGenotype, SNP);
 UnmarkAlleles(IndGenotype, SNP);
 }
 LastHetero=SNP;
}
LastHetero=InitialSNP;
// from InitialSNP to Left
for (SNP=InitialSNP-1;SNP>=0;SNP--)
if (IsHeterozygous(IndGenotype, SNP))
{
 FinalWay=GetFinalWay(LastHetero, SNP, Way);
 if (IsUnresolved (IndGenotype, SNP) && FinalWay!=0)
 {
 if ((FinalWay==1 && !IsAnOrderedPhase(IndGenotype, SNP, LastHetero)) 
	 || (FinalWay==2 && IsAnOrderedPhase(IndGenotype, SNP, LastHetero)))
 ChangeAlleles(IndGenotype, SNP);
 UnmarkAlleles(IndGenotype, SNP);
 }
 LastHetero=SNP;
}
} // end if individual match IndCategory
 if (i<(Size-1))
 {
	 IndGenotype=genotype::GetNext(IndGenotype);
	 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
} // end for each individual

cout << "\nReconstruction from a file has finished";
}

/*____________________________________________________________ */


unsigned int genoma::ReduceSample (char* filename, unsigned int TotalSNPs2, unsigned int Size2, bool FromParents=true, bool random=true, unsigned int InitialPos=0)
{
unsigned int chosen, acum=0, cont=0, cont2=0;
int truly_chosen;
Phenotype* IndPhenotype=TheFirstPhenotype;


if (FromParents)
 genoma::ResolveTU();




for (cont=0;cont<SizeP;cont++)
 Selected[cont]=false;


if (Size2<Size)
{


while (cont2<Size2)
{ 
 chosen=rand() % (SizeP-acum-cont2);
  truly_chosen=-1;
   for (cont=0;cont<=chosen; cont++)
  {
  truly_chosen=truly_chosen+1;
  while ((Selected[truly_chosen]==true) || (ic==offspring && IsAChild(truly_chosen)) || 
	  (ic==parent && IsAParent(truly_chosen))) 
   truly_chosen=truly_chosen+1;
  }
if (truly_chosen>=SizeP) 
{cout <<"out of memory"; exit(0);}
Selected[truly_chosen]=true;//

cont2++;

}


if (ic==offspring)
for (cont=0;cont<Size;cont++)
 if (Selected[cont])
 {
	 Selected[GetFather(cont)]=true;
	 Selected[GetMother(cont)]=true;
 }

}
else // all individuals with the same IndCategory
{
for (cont=0;cont<Size;cont++)
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
	 Selected[cont]=true;
 IndPhenotype=phenotype::GetNext(IndPhenotype);
}
}


unsigned int FirstSNP;

if (random) 
 FirstSNP=rand() % (genotype::TotalSNPs-TotalSNPs2);
else
FirstSNP=InitialPos;

return(FirstSNP);
//RedType r=Project;


}

/*_______________________________________________________________*/
double genoma::SumFreqs(frequencies hap)
{
return hap[0]+hap[1]+hap[2]+hap[3];
}
/*_______________________________________________________________*/
double genoma::GetTotalHaps(frequencies hap)
{
return hap[0]+hap[1]+hap[2]+hap[3]+hap[4]*2+hap[5]+hap[6]+hap[7]+hap[8];
}

/*_____________________________________________________________*/
void genoma::AdjustFrequencies(LDType mode, frequencies hap, sfrequencies hap2, bool Semi=false)
{
// Adjust frequencies but it does not use all haplotypes always
// hap[4] has the HH individuals, although its phase was inferred using families
// Semi is true if phase has partially been solved using families
// known and Semi: use only known phases
// infered and Semi: use only inferred phases from families, remove those values from hap2[4] for possible EM  
// complete and Semi: use known and infered phases from families, remove inferred from hap2[4] for EM
// infered and !Semi: use known and EM with the remaining counters???
// complete and !Semi: use EM for all???
// 
double total=0;
 hap2[4]=hap[4];
 
 switch (mode)
{
case Complete:
 for(int i=0;i<4;i++)
 {
	 hap2[i]=hap[i]+hap[i+5];
	 total=total+hap[i+5];
 }
// cout <<"total:" << total;
// cout <<"hap4:" << hap2[4];
//  cout <<"hap4orig:" << hap[4];

 if (Semi)
  hap2[4]=hap2[4]-total/2;
//  cout <<"hap4after:" << hap2[4];

 break;
 
case Known:
 for(int i=0;i<4;i++)
	 hap2[i]=hap[i];
 break;
 case Infered:
 for(int i=0;i<4;i++)
 {
	 hap2[i]=hap[i+5];
	 total=total+hap[i+5];
 }
 if (Semi)
 hap2[4]=hap2[4]-total/2;
 break;
  
 default:
 break;
}

if ((SumFreqs(hap2)+hap2[4]*2)>GetTotalHaps(hap))
{
cout <<"Error in AdjustFrequencies";
throw ZeroValue();
}

switch (Bayes)
{
case 0: break;
case 1: for (int i=0;i<4;i++)  hap2[i]=hap2[i]+1; break;
case 2: for (int i=0;i<4;i++)  hap2[i]=hap2[i]+0.25; break;
case 3: 
	double Freqs2[4];
	if (!MarginalIsZero(hap2))
	{
	SetHapsFreqsUnderEquilibrium2(hap2, Freqs2);
	hap2[0]=hap2[0]+Freqs2[0];// p(A)p(B)
	hap2[1]=hap2[1]+Freqs2[1];/// p(A)p(b)
	hap2[2]=hap2[2]+Freqs2[2]; // p(a)p(B)
	hap2[3]=hap2[3]+Freqs2[3];// p(a)p(b)
	}
	break;
}


}


/*********************************************************************/
void genoma::ComputeHaplotypes()
 // haps meanining:
// 0: AB haplotypes
// 1: Ab


// 2: aB
// 3: ab
// 4: XX (individuals XX, not haplotypes)
// 5: AB considering that phase is resolved
// 6: Ab id.
// 7: aB id.
// 8: ab id.
{
Phenotype* IndPhenotype;
Genotype* IndGenotype;

 if (haps==NULL)
 {

  if ((haps=new frequencies*[genotype::TotalSNPs-1])==NULL)
  throw NoMemory();

  for (long int SNP=0; SNP<(genotype::TotalSNPs-1);SNP++)
  {
   if ((haps[SNP]=new frequencies[genotype::TotalSNPs-SNP-1])==NULL)
    throw NoMemory();
 }
 }

  for (long int SNP=0; SNP<(genotype::TotalSNPs-1);SNP++)
   for (long int SNP2=SNP+1; SNP2<(genotype::TotalSNPs-1);SNP2++)
   {
	if  ((IndGenotype=TheFirstGenotype)==NULL)
	 throw NullValue();
 
	if  ((IndPhenotype=TheFirstPhenotype)==NULL)
	 throw NullValue();

     for (int k=0;k<9;k++) 
      haps[SNP][SNP2-SNP-1][k]=0;
	
	for (int i=0;i<SizeP;i++) // number of individuals
	{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
     CountHaps(haps[SNP][SNP2-SNP-1], IndGenotype, SNP, SNP2);
	if (i<(SizeP-1))
	{
	IndGenotype=genotype::GetNext(IndGenotype);
	IndPhenotype=phenotype::GetNext(IndPhenotype);
	}
	}// end for
	
	}//end for
  // cout << "\nSNP " << SNP << " counted";
}
/*____________________________________________________________ */
void genoma::CopyFromHaps(frequencies Target, unsigned int FirstSNP, unsigned int LastSNP)
{
	if (haps==NULL)
		throw NullValue();
unsigned int SizeArray=(genotype::TotalSNPs*(genotype::TotalSNPs-1))/2;
if (FirstSNP*(LastSNP-FirstSNP-1)>SizeArray)
 throw NoMemory();
for (int i=0;i<9;i++)
 Target[i]=haps[FirstSNP][LastSNP-FirstSNP-1][i];
}
/*____________________________________________________________ */
double genoma::GetHapFrequency (unsigned int FirstSNP, unsigned int LastSNP, unsigned int Haplotype, frequencies hap=NULL)
{
if (hap!=NULL)
{
GetHap(FirstSNP, LastSNP, hap);
return (hap[Haplotype]);
}
else // haps array exists
{
unsigned int SizeArray=(genotype::TotalSNPs*(genotype::TotalSNPs-1))/2;
if (FirstSNP*(LastSNP-FirstSNP-1)>SizeArray)
throw NoMemory();
else
return (haps[FirstSNP][LastSNP-FirstSNP-1][Haplotype]);
}
}
/*____________________________________________________________ */
void genoma::GetHap (unsigned int FirstSNP, unsigned int LastSNP, frequencies hap)
{
Genotype *IndGenotype;
Phenotype *IndPhenotype;	

for (int k=0;k<9;k++) 
 hap[k]=0;

if  ((IndGenotype=TheFirstGenotype)==NULL)
 throw NullValue();

if (ExistPhenotype)
if  ((IndPhenotype=TheFirstPhenotype)==NULL)
 throw NullValue();

bool SolvedGenericParent=false;
for (int i=0;i<SizeP;i++) // number of individuals
{
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
if ((affected==1) || (IndPhenotype->Affectation==affected))
{
  if (PhaseMode==ResolveFromTU && (ic==parent || ic==everybody) && IsAParent(i)) 
	 {
	if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))
	  SolvedGenericParent=ResolvePhaseForAGenericParent(i, FirstSNP, LastSNP);
	//if (FirstSNP==1) cout << "\nSNP1, padre: " << i;
	 CountHaps(hap, IndGenotype, FirstSNP, LastSNP, OnlyU, SolvedGenericParent);
	 }
	 else 
	 
	CountHaps(hap, IndGenotype, FirstSNP, LastSNP);


}
 if (i<(SizeP-1))
 {
 IndGenotype=genotype::GetNext(IndGenotype);
 if (ExistPhenotype)
 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
}
}
/*____________________________________________________________ */

void genoma::CheckInconsistenciesFromParents ()
{
	
cout << "Checking inconsistencies from parents...\n";
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *FatherGenotype, *MotherGenotype;

for (int row=0;row<Size;row++)
{
 if (IsAChild (IndPhenotype))
 {
  FatherGenotype=GetGenotype(GetFather(IndPhenotype));
  MotherGenotype=GetGenotype(GetMother(IndPhenotype));
  for (unsigned int SNP=0;SNP<genotype::TotalSNPs;SNP++)
   if (((IsHomozygous1Heterozygous (FatherGenotype, MotherGenotype, SNP)) && (IsHomozygous2(IndGenotype, SNP))) ||
		  ((IsHomozygous2Heterozygous (FatherGenotype, MotherGenotype, SNP)) && (IsHomozygous1(IndGenotype, SNP))) ||
		  ((IsHomozygous1Homozygous1 (FatherGenotype, MotherGenotype, SNP)) && ((IsHomozygous2(IndGenotype, SNP)) || (IsHeterozygous(IndGenotype, SNP))  )) ||
		  ((IsHomozygous2Homozygous2 (FatherGenotype, MotherGenotype, SNP)) && ((IsHomozygous1(IndGenotype, SNP)) || (IsHeterozygous(IndGenotype, SNP))  )))	  
   {	
		  cout <<"\nInconsistence at ind " << row+1 << "(code " << IndPhenotype->Code <<", family code " << IndPhenotype->Pedigree << ")" << " pos " << SNP+1 << " val file: " 
            << *(IndGenotype->Left+SNP) <<*(IndGenotype->Right+SNP) << " with father "
			<< *(FatherGenotype->Left+SNP) <<*(FatherGenotype->Right+SNP) << " and mother " 
			<< *(MotherGenotype->Left+SNP) <<*(MotherGenotype->Right+SNP) ; 
 //exit(0);
   }
}
 if (row<(Size-1))
 {
 IndGenotype=genotype::GetNext(IndGenotype);
 IndPhenotype=phenotype::GetNext(IndPhenotype);
 }
}
cout <<"Inconsistencies have been checked from parents\n";
}
/*____________________________________________________________ */

void genoma::CompleteMissingFromParents ()
{
	
cout << "\nCompleting missing from parents...";
Phenotype* IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype, *FatherGenotype, *MotherGenotype;

for (int row=0;row<Size;row++)
{
 if (IsAChild (IndPhenotype))
 {
  FatherGenotype=GetGenotype(GetFather(IndPhenotype));
  MotherGenotype=GetGenotype(GetMother(IndPhenotype));
  for (unsigned int SNP=0;SNP<genotype::TotalSNPs;SNP++)
   if (!IsANonMissingSNP(IndGenotype, SNP))
  {
   if (IsHomozygous1Homozygous1 (FatherGenotype, MotherGenotype, SNP)) 
	{
	   *((IndGenotype->Left)+SNP)=MajorAllele[SNP];
	   *((IndGenotype->Right)+SNP)=MajorAllele[SNP];
   }
    if (IsHomozygous2Homozygous2 (FatherGenotype, MotherGenotype, SNP)) 
	{
	   *((IndGenotype->Left)+SNP)=MinorAllele[SNP];
	   *((IndGenotype->Right)+SNP)=MinorAllele[SNP];
   }
	// for this case child will not be correctly phased
 if (IsHomozygous1Homozygous2 (FatherGenotype, MotherGenotype, SNP)) 
	{
	   *((IndGenotype->Left)+SNP)=MajorAllele[SNP];
	   *((IndGenotype->Right)+SNP)=MinorAllele[SNP];
   } 
  } // end for each missing SNP
 } // end for each child
 IndGenotype=IndGenotype->Next;
 IndPhenotype=IndPhenotype->Next;
} // end for each individual
cout <<"\nMissing data have been completed from parents\n";
}
/*****************************************************/
void genoma::SetFrequencies (frequencies Frequencies, unsigned int FirstSNP, unsigned int LastSNP)
{
if (haps==NULL)
GetHap(FirstSNP, LastSNP, Frequencies);// 
else
CopyFromHaps(Frequencies, FirstSNP, LastSNP);
//if (MAF==0.0)
//for (int i=0;i<9;i++)
// if (i!=4)
//  Frequencies[i]++;

}
/*****************************************************/
void genoma::SetHapsFreqsUnderEquilibrium2(double* Freqs, double* Freqs2)
{
	double total=SumFreqs(Freqs);
	
	if (total<zero)
	{
	for (int i=0;i<4;i++)
     cout <<"Freqs:" << Freqs[i];
	cout <<"total:" << total;
    throw NonSNP();
	}

	double
	fA=(Freqs[0]+Freqs[1])/total,
	fB=(Freqs[0]+Freqs[2])/total;
	Freqs2[0]=fA*fB;
	Freqs2[1]=fA*(1-fB);
	Freqs2[2]=(1-fA)*fB;
	Freqs2[3]=(1-fA)*(1-fB);
}
/*****************************************************/
void genoma::SetHapsFreqsUnderEquilibrium(double* Freqs, unsigned int SNP1, unsigned int SNP2, IndCategory inc2)
{
    Freqs[0]=GetTotalFreqAllele(SNP1,true,inc2)*GetTotalFreqAllele(SNP2,true,inc2);
	Freqs[1]=GetTotalFreqAllele(SNP1,true,inc2)*GetTotalFreqAllele(SNP2,false,inc2);
	Freqs[2]=GetTotalFreqAllele(SNP1,false,inc2)*GetTotalFreqAllele(SNP2,true, inc2);
	Freqs[3]=GetTotalFreqAllele(SNP1,false,inc2)*GetTotalFreqAllele(SNP2,false, inc2);
}
/*****************************************************/
void genoma::UseProbabilities (sfrequencies Frequencies, double* probs)
{
double total=0.0;


for (int i=0;i<4;i++)
 total=total+Frequencies[i]; // 

if (total==0)
 throw ZeroValue();

 for (int i=0;i<4;i++)
  probs[i]=Frequencies[i]/(double)total; // 

}
/*****************************************************/
void genoma::ResolvePhase (sfrequencies Frequencies, double* probs, unsigned int SNP1, unsigned int SNP2)
{
double total=0.0;

for (int i=0;i<4;i++)
 total=total+Frequencies[i]; // known or infered haplotypes

SetHapsFreqsUnderEquilibrium(probs, SNP1, SNP2, ic);
EstimateMLE (Frequencies, &probs[0], total, 1000); // estimate unknown phases
}
/*********************************************/
bool genoma::MarginalIsZero(double* probs)
{
	if ((probs[0]+probs[1])<=zero) return true; // fA
	if ((probs[0]+probs[2])<=zero) return true; // fB
	if ((probs[1]+probs[3])<=zero) return true; // fb
	if ((probs[2]+probs[3])<=zero) return true; // fa



	return(false);

}
/*********************************************/
bool genoma::MarginalIsZero (unsigned int SNP1, unsigned int SNP2)
{
 if (GetTotalFreqAllele(SNP1,true,ic)<=zero) return true;
 if (GetTotalFreqAllele(SNP2,true,ic)<=zero) return true;
 if (GetTotalFreqAllele(SNP1,false,ic)<=zero) return true;
 if (GetTotalFreqAllele(SNP2,false,ic)<=zero) return true;
 return false;

}
/*********************************************/
template <class T>
void genoma::PrintValues (T Freqs, unsigned int SNP1, unsigned int SNP2, bool EM=false)
{
double probs[4], total=SumFreqs(Freqs);
if (EM)  total=total+Freqs[4]; 
if (!MarginalIsZero(SNP1,SNP2) && total>zero)
 {
	if (!EM)
	UseProbabilities(Freqs, &probs[0]);
	else ResolvePhase(Freqs, &probs[0], SNP1, SNP2);
    
	OutputFile 
	 << probs[0]*total <<"\t"
	 << probs[1]*total << "\t" 
	 << probs[2]*total << "\t" 
	 << probs[3]*total << "\t"
	 << GetLD(probs) << "\t"
 	 << GetMaxLD(probs) << "\t";
	
	if (MarginalIsZero(probs)) 
		OutputFile << "-\t-\t";
	else
	
	OutputFile 
	 << GetLDPrime(probs) <<"\t"
	 << GetR2(probs, SNP1, SNP2) << "\t";
}
 else 	OutputFile << "-\t-\t-\t-\t-\t-\t";

}
/*********************************************/
template <class T>
void genoma::PrintValues (T Freqs, T Freqs2, bool max, double total, unsigned int SNP1, unsigned int SNP2)
{
	if (SumFreqs(Freqs)>zero)
 {
	if ((max && GetLDPrime(Freqs)>=GetLDPrime(Freqs2)) || (!max && GetLDPrime(Freqs)<GetLDPrime(Freqs2)))
	{
	OutputFile 
	 << Freqs[0]*total << "\t" 
	 << Freqs[1]*total << "\t" 
	 << Freqs[2]*total << "\t" 
	 << Freqs[3]*total << "\t"
	 << GetLD(Freqs) << "\t"
 	 << GetMaxLD(Freqs) << "\t";
	if (MarginalIsZero(Freqs)) 
		OutputFile << "-\t";
	else
     OutputFile << GetLDPrime(Freqs) <<"\t";
	}
	else
	{
	OutputFile 
	 << Freqs2[0] << "\t" 
	 << Freqs2[1] << "\t" 
	 << Freqs2[2] << "\t" 
	 << Freqs2[3] << "\t"
	 << GetLD(Freqs2) << "\t"
 	 << GetMaxLD(Freqs2) << "\t";
	if (MarginalIsZero(Freqs2)) 
		OutputFile << "-\t";
	else
	 OutputFile << GetLDPrime(Freqs2) <<"\t";
	}
	
	if ((MarginalIsZero(Freqs))  && (MarginalIsZero(Freqs2)))
		OutputFile << "-\t";
	else
        if ((max && GetLD(Freqs)>=GetLD(Freqs2)) || (!max && GetLD(Freqs)<GetLD(Freqs2)))
	 OutputFile << GetR2(Freqs, SNP1, SNP2) <<"\t";
	else
	 OutputFile << GetR2(Freqs2, SNP1, SNP2) <<"\t";
	}
 else 	OutputFile << "-\t-\t-\t-\t-\t-\t-\t-\t";

}
/*********************************************/
void genoma::PrintWay (unsigned int SNP, sfrequencies Freqs)
{
  	 if (GetLDPrime(Freqs)<1)
		OutputFile <<"0" << "\n";
	 else	
	 if (GetLD(Freqs)>0) 
	 OutputFile <<"1" << "\n";
	 else
	 OutputFile <<"2" << "\n";
}
/*****************************************************/
void genoma::PrintDPrime (char* filename, char* filename2)
{
bool found;
try
{
  OutputFile.open (filename, ofstream::out); //app
  if (OutputWay)
  OutputFile2.open (filename2, ofstream::out); //app
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
}

frequencies Frequencies;
sfrequencies Frequencies2;

double Pos, Pos2;

 OutputFile 
	 << "First SNP" << "\t" <<  "Position"  << "\t" 
 	 << "Second SNP" << "\t" <<  "Position"  << "\t" 
	 << "n(A)" << "\t" 
	 << "n(a)" << "\t" 
 	 << "n(B)" << "\t" 
	 << "n(b)" << "\t" 
 	 << "n(a)n(b)" << "\t"
	 << "n(HH) (individuals)" << "\t";  


// plus known

OutputFile
	 << "n(AB) for infered phase from families plus known" << "\t" 
	 << "n(Ab) for infered phase from families plus known" << "\t" 
	 << "n(aB) for infered phase from families plus known" << "\t" 
	 << "n(ab) for infered phase from families plus known" << "\t"  
	 << "D for for infered phase from families plus known" << "\t"
 	 << "max LD for infered phase from families plus known" << "\t" 
	 << "Dprime for infered phase from families plus known" <<"\t"
     << "R2 for infered phase from families plus known" <<"\t";

if (!OnlyU)
{

// plus known
OutputFile
	 << "n(AB) for known and infered phase from families using EM afterwards" << "\t" 
	 << "n(Ab) for known and infered phase from families using EM afterwards" << "\t" 
	 << "n(aB) for known and infered phase from families using EM afterwards" << "\t" 
	 << "n(ab) for known and infered phase from families using EM afterwards" << "\t"  
	 << "D for known and infered phase from families using EM afterwards" << "\t"
 	 << "max LD for known and infered phase from families using EM afterwards" << "\t" 
	 << "Dprime for known and infered phase from families using EM afterwards" << "\t" 
	 << "R2 for known and infered phase from families using EM afterwards" <<"\t";

}
OutputFile <<"\n";

unsigned int SNP2;
for (unsigned int SNP=0; SNP<(genotype::TotalSNPs-1);SNP++)
 if (GetTotalFreqAllele(SNP, false,  (IndCategory)0)>=MAF) 
 {
 try
 {
 SNP2=SNP+1;
 found=false;
 do
 {
 if (GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>=MAF)
 {
 found=true;
  if (SNP%100==0)
  cout <<"\nsnp:" << SNP;
//cout <<" and " << SNP2;
 Pos=GetPosition(SNP);
 Pos2=GetPosition(SNP2);
 // Pos2=GetPosition(25);

 //cout <<"SNP:" << SNP <<",SNP2:" << SNP+1;
  SetFrequencies(Frequencies, SNP, SNP2); 
 // SetFrequencies(Frequencies, SNP, 25, MAF); 



 OutputFile 
	 << SNP+1 << "\t" <<  (unsigned int) Pos  << "\t" 
  << SNP2+1 << "\t" <<  (unsigned int) Pos2  << "\t" 
  //	 << 26 << "\t" <<  (unsigned int) Pos2  << "\t" 
   	 << GetTotalAllele(SNP, true, ic) << "\t" 
   	 << GetTotalAllele(SNP, false, ic) << "\t" 
   	 << GetTotalAllele(SNP2, true, ic) << "\t" 
  	 << GetTotalAllele(SNP2, false,  ic) << "\t" 

 	 << GetTotalAllele(SNP, false, ic)*GetTotalAllele(SNP2, false, ic) << "\t"
	 << Frequencies[4] << "\t";



 AdjustFrequencies(Complete, Frequencies, Frequencies2);
 PrintValues(Frequencies, SNP,SNP2, false);// plus known

 if (!OnlyU)
 {
 bool EM=true; 
 AdjustFrequencies(Complete, Frequencies, Frequencies2, false);// plus known
 PrintValues(Frequencies2, SNP,SNP2, EM);
//
 
 }
 OutputFile <<"\n";

 } // if SNP2 is a real SNP
 SNP2++;
 } // end do
 while ((found==false) && (SNP2<genotype::TotalSNPs));
 } // end try


	 catch (NonSNP ns) {
		 ns.PrintMessage(SNP);}  
	 catch (OutOfRange ora) {
	 ora.PrintMessage(SNP);}

 
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise D has been saved in file " << filename <<"\n";
 
 OutputFile.close();
 if (OutputWay) 
 {
 OutputFile2.close();
 cout << "\nInformation about phase solution has been saved in file " << filename2 <<"\n";
 }
 
}
/*****************************************************/
void genoma::ComputeWindowsValues(unsigned int mini, position* i, unsigned int SNP, double Pos, 
								  unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance)
{
frequencies Frequencies;
sfrequencies Frequencies2;

position* j=i;
unsigned int LastComparison;
double probs[4];
bool Semi;

unsigned int comparisons=0, ComparisonsFamiliesAndKnown=0, SNP1;

double 
MultiLDFamiliesAndKnown=0.0,
MultiLDPrimeFamiliesAndKnown=0.0,
MultiR2FamiliesAndKnown=0.0,
MultiLDEMafterfamiliesAndKnown=0.0,
MultiLDPrimeEMafterfamiliesAndKnown=0.0,
MultiR2EMafterfamiliesAndKnown=0.0;

for (unsigned int SNP2=SNP+1; SNP2<=mini;SNP2++) // until the end of the windows
{
 if (GetTotalFreqAllele(SNP2, false,  (IndCategory)0)>=MAF) 
 {  	

   SNP1=SNP; 
   LastComparison=SNP2+positions::GetTotalSNPs(j, MaxDistance);

   if (mini<LastComparison)
	   LastComparison=mini;
   
   for (unsigned int SNP3=SNP2+1; SNP3<LastComparison;SNP3++) // until max distance allowed

   if (GetTotalFreqAllele(SNP3, false,  (IndCategory)0)>=MAF)
   {

	    SetFrequencies(Frequencies, SNP2, SNP3); 


        AdjustFrequencies(Complete, Frequencies, Frequencies2); // plus known
    	if (!MarginalIsZero(Frequencies2)) 
		{
		UseProbabilities(Frequencies2, &probs[0]);
		MultiLDFamiliesAndKnown=MultiLDFamiliesAndKnown+GetLD(probs);
		MultiLDPrimeFamiliesAndKnown=MultiLDPrimeFamiliesAndKnown+GetLDPrime(probs);
    	MultiR2FamiliesAndKnown=MultiR2FamiliesAndKnown+GetR2(Frequencies2, SNP2, SNP3);
		ComparisonsFamiliesAndKnown++;
		}
		
		if (!OnlyU)
		{
		Semi=true; // compute EM after solving the phase from families

		AdjustFrequencies(Complete, Frequencies, Frequencies2, Semi); // plus known
    	if (!MarginalIsZero(Frequencies2)) 
        { 
		ResolvePhase(Frequencies2, &probs[0], SNP2, SNP3);
    	MultiLDEMafterfamiliesAndKnown=MultiLDEMafterfamiliesAndKnown+GetLD(probs);
    	MultiLDPrimeEMafterfamiliesAndKnown=MultiLDPrimeEMafterfamiliesAndKnown+GetLDPrime(probs);
       	MultiR2EMafterfamiliesAndKnown=MultiR2EMafterfamiliesAndKnown+GetR2(probs, SNP2, SNP3);
		comparisons++;
		}
		
		} // end !OnlyU
		//	cout <<", M:" << MultiLD;


   } // end for each SNP3 with freq>MAF
 } // end if freq>MAF
 j=positions::GetNext(j);
} // end for each SNP2

if (comparisons>0)
{
 OutputFile << SNP+1 << "\t" <<  Pos; 
 cout << SNP1+1 << "\n";
 if (ComparisonsFamiliesAndKnown>0)
 OutputFile  
	 << "\t" << comparisons
 	 << "\t" << MultiLDFamiliesAndKnown/(double)(ComparisonsFamiliesAndKnown) 
	 << "\t" << MultiLDPrimeFamiliesAndKnown/(double)(ComparisonsFamiliesAndKnown) 
  	 << "\t" << MultiR2FamiliesAndKnown/(double)(ComparisonsFamiliesAndKnown);
 else OutputFile << "\t0\t-\t-\t-";
  if (!OnlyU)
	 OutputFile
 	 << "\t" << comparisons
 	 << "\t" << MultiLDEMafterfamiliesAndKnown/(double)(comparisons)
	 << "\t" << MultiLDPrimeEMafterfamiliesAndKnown/(double)(comparisons)
	 << "\t" << MultiR2EMafterfamiliesAndKnown/(double)(comparisons);
 	 
 OutputFile <<"\n";
 }
}
 /*****************************************************/
void genoma::PrintDPrimeSlidingWindows (char* filename, unsigned int SlideSize, unsigned int SlideOverlap, unsigned int MaxDistance)
{
unsigned int SlideGap=SlideSize-SlideOverlap;

unsigned int LastSNPInWindow, SNP=0;

double Pos;

try
{
  OutputFile.open (filename, ofstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
}



OutputFile << "Initial SNP" 
<< "\t" <<  "Initial Position" 
<< "\t" <<  "number of comparisons" 
<< "\t" << "D for infered phase from families and known"
<< "\t" << "DPrime for infered phase from families and known"
<< "\t" << "R2 for infered phase from families and known";


if (!OnlyU)
OutputFile 
<< "\t" <<  "number of comparisons" 
<< "\t" << "D for known and infered phase from families using EM afterwards" 
<< "\t" << "DPrime for known and infered phase from families using EM afterwards" 
<< "\t" << "R2 for known and infered phase from families using EM afterwards"; 


OutputFile <<"\n";


position *i=TheFirstPosition;
  try {


 // cout << Pos;

bool EndReached=false;

if (SlideSize>1)
do
{
//cout <<"\n" << SNP+1;

try {
//cout <<"Maxdis:" << MaxDistance <<"\n";  	
//cout <<"SNP:" << SNP << ", SlideSize:" << SlideSize;

if (IsEndReached(i, SlideSize))
 EndReached=true;
else
{
LastSNPInWindow=SNP+positions::GetTotalSNPs(i, SlideSize);

//   cout <<"LastS:" << LastSNPInWindow <<"\n";  	
//   cout <<"totalSNPs:" << genotype::TotalSNPs <<"\n";  	

	 Pos=i->pos;

 ComputeWindowsValues(LastSNPInWindow, i, SNP, Pos, SlideSize, SlideOverlap, MaxDistance);
 
 SNP=SNP+positions::GetTotalSNPs(i, SlideGap);

 i=MoveToPos(i, SlideGap);
 
  }
}
         catch (OutOfRange ora) {
		 ora.PrintMessage(SNP);}	 
		 catch (NonSNP ns) {
		 ns.PrintMessage(SNP);}

 
}
while ((SNP<(genotype::TotalSNPs-1)) && (EndReached==false));


  }
  catch (NullValue null) {
    null.PrintMessage();
    }


 OutputFile.close();

 cout << "\nInformation about sliding windows has been saved in file " << filename <<"\n";

}
/*****************************************************/
void genoma::PrintSNPPositions (char* filename)
{

	ofstream OutputFile; 

try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
}

OutputFile << "SNP" << "\t" <<  "Position"  << "\n"; 


for (unsigned int SNP=0; SNP<(genotype::TotalSNPs-1);SNP++)
{ 
if ((GetTotalFreqAllele(SNP, false,  (IndCategory)0)>=MAF) && (GetTotalFreqAllele(SNP, false,  (IndCategory)0)>0))
   OutputFile << SNP+1 << "\t" <<  (unsigned int) GetPosition(SNP)  << "\n" ;
if ((MAF!=0.0) && (GetTotalFreqAllele(SNP, false, (IndCategory)0)==MAF))
  OutputFile << SNP+1 << "\t" <<  (unsigned int) GetPosition(SNP)  << "\n" ;

}
OutputFile.close();



}

/*____________________________________________________________________*/
void genoma::ChangeIds (char *filename)
{

	
  ofstream OutputFile; 
  Phenotype *IndPhenotype=TheFirstPhenotype; 
  unsigned int FatherCode2, MotherCode2;
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

unsigned int *FamilyCode;
  if ((FamilyCode=new unsigned int [Size])==NULL)
     throw NoMemory();

bool found;


  for (int i=0; i<Size;i++)
  {
	if (IsAChild(IndPhenotype))
	{
	found=false;
	for (int i2=0;i2<i;i2++)
     if (FamilyCode[i2]==(IndPhenotype->Pedigree))
	  found=true;
	if (found)
	FamilyCode[i]=(IndPhenotype->Pedigree)*10;
	else FamilyCode[i]=(IndPhenotype->Pedigree);
	}
	IndPhenotype=IndPhenotype->Next;
  }

IndPhenotype=TheFirstPhenotype;
Genotype *IndGenotype=TheFirstGenotype;

  for (int i=0; i<Size;i++)
  {
	if (IsAChild(IndPhenotype))
	{
	FatherCode2=(GetPhenotype(GetFather(IndPhenotype)))->Code2;
 	MotherCode2=(GetPhenotype(GetMother(IndPhenotype)))->Code2;
	}
	else
	{
	FatherCode2=0;
 	MotherCode2=0;
	}
	if (IsAChild(IndPhenotype))
 	 OutputFile << FamilyCode[i] << ' ';
	else 
	OutputFile << FamilyCode[GetFirstChild(IndPhenotype)] << ' ';
	OutputFile << IndPhenotype->Code2 << ' ';
	OutputFile << FatherCode2 << ' ';
	OutputFile << MotherCode2 << ' ';
	OutputFile << IndPhenotype->Gender << ' ';
	OutputFile << IndPhenotype->Affectation << ' ';
	OutputFile << IndPhenotype->Code2 << ' ';

    for (int i2=0; i2<genotype::TotalSNPs;i2++)
	{

	 OutputFile << *((IndGenotype->Left)+i2) << ' ';
     OutputFile << *((IndGenotype->Right)+i2) << ' ';
	}
    OutputFile << "\n";
    IndGenotype=IndGenotype->Next;
	IndPhenotype=IndPhenotype->Next;
  }
 OutputFile.close();
cout << "New ids has been saved in file " << filename <<"\n";

delete FamilyCode;	
}




/* ____________________________________________*/
unsigned int genoma::FindFirstHeterozygous(Genotype* IndGenotype)
{
// return TotalSNPs if there is not any heterozygous position
unsigned int SNP=0;
while ((!IsHeterozygous (IndGenotype, SNP))  && (SNP<genotype::TotalSNPs))
   {
   SNP++;
}
return SNP;
}

/* ____________________________________________*/
int genoma::GetNextHeterozygous(Genotype* IndGenotype, unsigned int SNP)
{
// return -1 if there is not more heterozygous position
while ((!IsHeterozygous (IndGenotype, SNP))  && (SNP<genotype::TotalSNPs))
   {
   SNP++;
}
return SNP;
}


/*____________________________________________________________ */

int  genoma::GetChildHomozygous(unsigned int i, unsigned int SNP)
{
bool found=false;
int child=GetFirstChild(i);
Genotype *GenotypeChild;
if (child<0)
 return -1;

do
{
if (IsHomozygous(GenotypeChild, SNP))
 found=true;
if (!found)
 child=GetNextSib(child, GetPhenotype(i));
}
while ((child>=0) && (!found));

if (found) return child; else return -1;

}
/*____________________________________________________________ */

int  genoma::GetChildHomozygousHomozygous(unsigned int i, unsigned int SNP, unsigned int SNP2)
{
bool found=false;
int child=GetFirstChild(i);
Genotype *GenotypeChild;
if (child<0)
 return -1;

do
{
if (IsHomozygous(GenotypeChild, SNP) && IsHomozygous(GenotypeChild, SNP2))
 found=true;
if (!found)
 child=GetNextSib(child, GetPhenotype(i));
}
while ((child>=0) && (!found));

if (found) return child; else return -1;

}

/*____________________________________________________________ */

genoma::~genoma ()
{
//	phenotype::destroy(TheFirstPhenotype);
//	genotype::destroy(TheFirstGenotype);



	if (MajorAllele!=NULL)
	 delete MajorAllele;
	if (MinorAllele!=NULL)
	 delete MinorAllele;




    if (haps!=NULL)
	{
		for (int i=0;i<(genotype::TotalSNPs-1);i++)
			for (int j=0;j<genotype::TotalSNPs-i-1;i++)
			 delete haps[i][j];
		delete haps;
	}


}

};  // Fin del Namespace

#endif

/* Fin Fichero: genoma.h */
