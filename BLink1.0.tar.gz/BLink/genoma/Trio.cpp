/* File: Trio.cpp */


#ifndef __Trio_cpp__
#define __Trio_cpp__


#include "Trio.h"


namespace BIOS {




/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

Trio::Trio ()
{

}

/*____________________________________________________________ */

Trio::Trio (PhenotypePointer FatherP, PhenotypePointer MotherP, PhenotypePointer ChildP, GenotypePointer FatherG, GenotypePointer MotherG, GenotypePointer ChildG):
TrioPhenotype(FatherP, MotherP, ChildP), TrioGenotype(FatherG, MotherG, ChildG)
{
}

/*____________________________________________________________ */
/*
Trio::Trio (PhenotypeSample *ps, GenotypeSample *gs, PhenotypePointer IndPhenotype, GenotypePointer IndGenotype)
{
Phenotype P=ps->GetElement(IndPhenotype);
Genotype G=gs->GetElement(IndGenotype);
if (P.IsAChild())
  {
  SetChildPhenotype(P);
  SetChildGenotype(G);
  SetFatherPhenotype(ps->GetFather(IndPhenotype));
  SetFatherGenotype(gs->GetNode(ps->GetPos(GetFatherPhenotype()));
  SetMotherPhenotype(ps->GetMother(IndPhenotype));
  SetMotherGenotype((gs->GetNode(ps->GetPos(GetMotherPhenotype()));
  }
  if (P.IsAFather()) 
  {
  SetFatherPhenotype(P);
  SetFatherGenotype(G);
  SetChildPhenotype(ps->GetFirstChild(IndPhenotype));
  SetChildGenotype(gs->GetNode(ps->GetPos(GetChildPhenotype()));
  SetMotherPhenotype(ps->GetCouple(IndPhenotype));
  SetMotherGenotype(gs->GetNode(ps->GetPos(GetMotherPhenotype()));
  }
  if (P.IsAMother())
  {
  SetMotherPhenotype(P);
  SetMotherGenotype(G);
  SetChildPhenotype(ps->GetFirstChild(IndPhenotype));
  SetChildGenotype(gs->GetNode(ps->GetPos(GetChildPhenotype()));
  SetFatherPhenotype(ps->GetCouple(IndPhenotype));
  SetFatherGenotype(gs->GetNode(ps->GetPos(GetFatherPhenotype()));
  }
}
*/
/*____________________________________________________________ */

char* Trio::PrintTrio (SNPPos SNP)
{
	/*
char *p=line;
strcpy(line,"\0");
strcat(line, FatherGenotype->PrintGenotype(SNP));
strcat(line, MotherGenotype->PrintGenotype(SNP));
strcat(line, ChildGenotype->PrintGenotype(SNP));
return p;
*/
}


};  // End of Namespace

#endif

/* End of file: Genotype.h */




