#./GetSlidingWindowsUnrelated data/crossover.gou 0 0 2 0 50000 40000
#./GetSlidingWindowsUnrelated  data/crossover.gou 0 4 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover10.gou 0 0 2 0 50000 40000 data/crossover10-60.gou
./GetSlidingWindowsUnrelated data/crossover10.gou 0 4 2 0 50000 40000 data/crossover10-60.gou
./GetSlidingWindowsUnrelated data/crossover10.gou 0 0 2 0 50000 40000 data/crossover5-60.gou
./GetSlidingWindowsUnrelated data/crossover10.gou 0 4 2 0 50000 40000 data/crossover5-60.gou
./GetSlidingWindowsUnrelated data/crossover5.gou 0 0 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover5.gou 0 4 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover5-60.gou 0 0 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover5-60.gou 0 4 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover5-120.gou 0 0 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover5-120.gou 0 4 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover10-60.gou 0 0 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover10-60.gou 0 4 2 0 50000 40000
./GetSlidingWindowsUnrelated data/crossover10-120.gou 0 0 2 0 50000 40000 
./GetSlidingWindowsUnrelated data/crossover10-120.gou 0 4 2 0 50000 40000
