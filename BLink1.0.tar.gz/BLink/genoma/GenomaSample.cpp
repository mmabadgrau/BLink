
/* File: GenomaSample.cpp */



#ifndef __GenomaSample_cpp__
#define __GenomaSample_cpp__



#include "GenomaSample.h"
     
        



namespace BIOS {


/*____________________________________________________________ */

GenomaSample* GenomaSample::copyElementsWithPositionsIn(intList* positions, bool inThis)
{
PhenotypeSample* rP=this->PhenotypeSample::copyElementsWithPositionsIn(positions, inThis);
GenotypeSample* gP=this->GenotypeSample::copyElementsWithPositionsIn(positions, inThis);
GenomaSample* result= new  GenomaSample(*rP, *gP);
//result->PrintPhenotypes();

zap(rP);
zap(gP);
return result;
}
/*____________________________________________________________ */

GenomaSample::GenomaSample(): 
PhenotypeSample(), 
GenotypeSample()
{
currentIc=everybody;
currentGender=everyGender;
currentAffectation=allAffectation;
Marked=NULL;
};
/*____________________________________________________________ */

GenomaSample::GenomaSample(GenomaSample& source): 
PhenotypeSample(source),GenotypeSample(source)
{
currentIc=source.currentIc;
currentGender=source.currentGender;
currentAffectation=source.currentAffectation;
Marked=NULL;
};
/*____________________________________________________________ */

GenomaSample::GenomaSample(PhenotypeSample& sourceP, GenotypeSample& sourceG): 
PhenotypeSample(sourceP), 
GenotypeSample(sourceG)
{
currentIc=everybody;
currentGender=everyGender;
currentAffectation=allAffectation;
Marked=NULL;
};
/*____________________________________________________________ */

GenomaSample::GenomaSample(char* filename, IndCategory ic, AlleleOrderType AlleleOrderMode): PhenotypeSample(filename), GenotypeSample(filename, true, AlleleOrderMode)
{
currentIc=ic;					
Marked=NULL;
}
/*____________________________________________________________ */

void GenomaSample::setMarked(IndCategory ic, int gender, int affectation)
{
 if ((Marked!=NULL && (ic!=currentIc || gender!=currentGender || affectation != currentAffectation)) || Marked==NULL)
{
 Marked=Initialize(PhenotypeSample::GetSize(), true);
 SetMarked(Marked, ic, gender, affectation);
// this has to be done because current marked settings have to be stored
currentIc=ic;
currentGender=gender;
currentAffectation=affectation;
}
}
/*____________________________________________________________ */

void GenomaSample::ExportForML (char *filename)
{
cout <<"Exporting to ML\n";
SNPPos TotalSNPs=GetTotalSNPs();
ofstream OutputFile;
unsigned int i2; 
OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();
Genotype* g;
Phenotype p;
Diplotype D;
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();

while (IndGenotype!=NULL)
{
 g=GenotypeSample::GetElement(IndGenotype);	
 p=PhenotypeSample::GetElement(IndPhenotype);	
 for (SNPPos i=0; i<TotalSNPs;i++)
 {
 D=g->GetDiplotype(i);
 if (D.IsHeterozygous (MajorAllele[i])) OutputFile << "0";
  if (D.IsAMissingSNP()) OutputFile << "?";
  if (D.IsHomozygous1 (MajorAllele[i]))
  if (AlleleOrderMode==NotChanged || MajorAllele[i]<MinorAllele[i]) OutputFile << "1";
  else OutputFile <<"2";
  if (D.IsHomozygous2 (MajorAllele[i]))
  if (AlleleOrderMode==NotChanged || MajorAllele[i]<MinorAllele[i]) OutputFile << "2";
  else OutputFile <<"1";
 OutputFile << ", ";
 }
if (p.IsAffected()) OutputFile << 1;
else OutputFile << 0;
OutputFile << "\n";
IndGenotype=GenotypeSample::GetNext(IndGenotype);
IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}
OutputFile.close();
char filename2[256];
ChangeExtension(filename, filename2, "mas");
OpenOutput(filename2, &OutputFile);
for (SNPPos i=0;i<TotalSNPs;i++) 
OutputFile << "0 SNP" << i <<": 0, 1, 2 //\n";
OutputFile << "0 class: 0, 1 //\n";
OutputFile.close();
}
/*____________________________________________________________ */

void GenomaSample::ExportForMLHAP (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

ofstream OutputFile; 

//cout <<"Exporting to ML, file " << filename << "\n";

OpenOutput(filename, &OutputFile);
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();

Genotype* g;
Diplotype D;
Phenotype p;

while (IndGenotype!=NULL)
{
 g=GenotypeSample::GetElement(IndGenotype);	
 p=PhenotypeSample::GetElement(IndPhenotype);	
 for (SNPPos i=0; i<TotalSNPs;i++)
  {
  D=g->GetDiplotype(i);
  if (D.IsAMissingSNP()) OutputFile << "?";
  if (D.IsHeterozygous (MajorAllele[i]) && D.GetLeftAllele()==MajorAllele[i]) OutputFile << "12";
  if (D.IsHeterozygous (MajorAllele[i]) && D.GetLeftAllele()!=MajorAllele[i]) OutputFile << "21";
  if (D.IsHomozygous1 (MajorAllele[i]))  OutputFile << "11";
  if (D.IsHomozygous2 (MajorAllele[i]))  OutputFile << "22";
  OutputFile << ",";
  }
if (p.IsAffected()) OutputFile << 1;
else OutputFile << 0;
  OutputFile << "\n";
  IndGenotype=GenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}
OutputFile.close();
char filename2[256];
ChangeExtension(filename, filename2, "mas");
OpenOutput(filename2, &OutputFile);
for (SNPPos i=0;i<TotalSNPs;i++)
OutputFile << "0 SNP" << i <<": 12, 21, 11, 22 //\n";
OutputFile << "0 class: 0, 1 //\n";
OutputFile.close();
}

/*____________________________________________________________ */

SNPPos GenomaSample::GetTotalAllele (SNPPos SNP, bool IsMajor, const IndCategory ic, int gender, int affectation)
{
 setMarked(ic, gender, affectation);
 return GenotypeSample::GetTotalAllele(SNP, IsMajor, Marked);
};
/*____________________________________________________________ */

allele GenomaSample::getMajorAllele (SNPPos SNP, const IndCategory ic, int gender, int affectation)
{
 setMarked(ic, gender, affectation);
 return GenotypeSample::getMajorAllele(SNP, Marked);
};
/*____________________________________________________________ */

allele GenomaSample::getMinorAllele (SNPPos SNP, const IndCategory ic, int gender, int affectation)
{
 setMarked(ic, gender, affectation);
 return GenotypeSample::getMinorAllele(SNP, Marked);
};


/*____________________________________________________________ */

void GenomaSample::WriteResults (char* filename, bool PrintPhenotypes, IndCategory ic, SNPPos first,SNPPos last, bool markUnphased)
 {
 if (GenotypeSample::GetSize()!=0) 
{
  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
  Genotype* genotype;
  ofstream OutputFile; 
  SNPPos TotalSNPs=GetTotalSNPs();
  OpenOutput(filename, &OutputFile);
Phenotype P;
while (IndPhenotype!=NULL && IndGenotype!=NULL)
  {
	P=PhenotypeSample::GetElement(IndPhenotype);
	 if ((ic==offspring && P.IsAChild ()) || (ic==parent && P.IsAParent ()) 
		|| (ic==everybody) || (ic==father && P.IsAFather()) || (ic==mother && P.IsAMother()))
	 {
	if (PrintPhenotypes==true) 
	OutputFile << P.PrintPhenotype();
    genotype=GenotypeSample::GetElement(IndGenotype);
    OutputFile << genotype->print(first, last, markUnphased);
    OutputFile << "\n";
	 }
  IndGenotype=GenotypeSample::GetNext(IndGenotype);
  IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
  OutputFile.close();
//cout << "\nInformation about phased genotype has been saved in file " << filename <<"\n";
}
 }


/*____________________________________________________________ */

void GenomaSample::RemoveByCategory (IndCategory ic=parent)
 {
  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
  Genotype* genotype;
  Phenotype P;

  SNPPos TotalSNPs=GetTotalSNPs();
  while (IndPhenotype!=NULL && IndGenotype!=NULL)
  {
	P=PhenotypeSample::GetElement(IndPhenotype);
	 if ((ic==offspring && P.IsAChild ()) || (ic==parent && P.IsAParent ()) 
	 || (ic==everybody) || (ic==father && P.IsAFather()) || (ic==mother && P.IsAMother()))
	 {
	 GenotypeSample::removeNode(IndGenotype);
 	 PhenotypeSample::removeNode(IndPhenotype);
	 }
	
   IndGenotype=GenotypeSample::GetNext(IndGenotype);
   IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
	 
  }
 }


/*____________________________________________________________ */

Trio GenomaSample::GetTrioMembers (PhenotypeSample::NodePointer IndPhenotype, GenotypeSample::NodePointer IndGenotype)
{
 Trio T;

  if (IndPhenotype->element.IsAChild())
  {
  T.SetChildPhenotype(IndPhenotype);
  T.SetChildGenotype(IndGenotype);
  T.SetFatherPhenotype(GetFather(IndPhenotype));
  T.SetFatherGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetFatherPhenotype())));
  T.SetMotherPhenotype(GetMother(IndPhenotype));
  T.SetMotherGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetMotherPhenotype())));
  }
  if (IndPhenotype->element.IsAFather()) 
  {
  T.SetFatherPhenotype(IndPhenotype);
  T.SetFatherGenotype(IndGenotype);
  T.SetChildPhenotype(GetFirstChild(IndPhenotype));
  T.SetChildGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetChildPhenotype())));
  T.SetMotherPhenotype(GetCouple(IndPhenotype));
  T.SetMotherGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetMotherPhenotype())));
  }
  if (IndPhenotype->element.IsAMother())
  {
  T.SetMotherPhenotype(IndPhenotype);
  T.SetMotherGenotype(IndGenotype);
  T.SetChildPhenotype(GetFirstChild(IndPhenotype));
  T.SetChildGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetChildPhenotype())));
  T.SetFatherPhenotype(GetCouple(IndPhenotype));
  T.SetFatherGenotype(GenotypeSample::GetNode(PhenotypeSample::GetPos(T.GetFatherPhenotype())));
  }
  return T;
}

/*____________________________________________________________ */

GenotypeSample::NodePointer GenomaSample::GetGenotype (PhenotypeSample::NodePointer p)
{
	return GenotypeSample::GetNode(PhenotypeSample::GetPos(p));

}
/*____________________________________________________________ */

GenomaSample::~GenomaSample ()
{
zaparr(Marked);
}

};  // Fin del Namespace

#endif

/* Fin Fichero: GenomaSample.h */
