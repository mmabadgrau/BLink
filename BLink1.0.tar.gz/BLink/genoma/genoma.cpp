  /**
    * @file genoma.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "genoma.h"
#include "hapmap.h"
#include "PhaseResolver.h"
#include "PhaseChecker.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

unsigned int HapMapProcessing(char *filename, char* filephenotypes, char*filename2, unsigned int Size)
{


hapmap *HapMap;
if ((HapMap = new hapmap(filename, Size))==NULL)
 throw NoMemory();


HapMap->ProcessHapmap(filephenotypes, filename2);
cout << "\nOutput file: " << filename2 <<"\n";
cout << "\nNumber of SNPs: " << HapMap->GetTotalSNPs() <<"\n";
return HapMap->GetTotalSNPs();
}

/* _____________________________________________________*/

void GenomaProcessing(char *filename, unsigned int TotalSNPs, unsigned int Size)
{

char * filename2;
//strcpy(filename2, filename);
genoma *Sample, *SampleTrivial;
// phase will be resolved only for offspring
IndCategory ic=(IndCategory)1; 
// phenotypes are setup as all children if !ExistPhenotype holds for the sample at filename

char *filename3; 

 if ((filename3=new char[64])==NULL)
		 throw NoMemory();

	 strcpy (filename3, filename);
	 strtok(filename3, ".");
	 strcat (filename3, ".pos\0");


if ((Sample = new genoma(filename, filename3, TotalSNPs, Size, true, ic))==NULL)
 throw NoMemory();

filename2=strtok(filename, ".");

if ((SampleTrivial = new genoma(*Sample, ic))==NULL)
 throw NoMemory();


Sample->ResolvePhase((IndCategory)1); 


cout << "\nOutput file: " << filename2 <<"\n";
cout <<"TotalSize:" << Sample->GetSize();
strncat(filename2, ".sal\0", 4);//
Sample->WriteGenotypes(filename2);



SampleTrivial->ResolveTrivialPhase();
Sample->PhaseAccuracy(*SampleTrivial);


strcpy(filename2, "crohndiff.sal\0");
Sample->WriteGenotypes(filename2);

strcpy(filename2, "crohntriv.sal\0");
SampleTrivial->WriteGenotypes(filename2);


delete filename2;
delete filename3;

}

}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc!=3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <#individuals>" << endl;
        exit(-1);
        }
     char* filename, *filename2, *filename3, filephenotypes[20]="pedigree.txt";
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename2=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename3=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filename, argv[1]);
     unsigned int TotalIndividuals=atoi(argv[2]);

	 try{ 

		 strcpy (filename3, filename);
		 strtok(filename3, ".");
		 strcpy (filename2, filename3);
		 strncat(filename2, ".inp\0", 4);//
      //   TotalSNPs=HapMapProcessing (filename, filephenotypes, filename2, TotalIndividuals);
		// GenomaProcessing (filename2, TotalSNPs, TotalIndividuals);
		// GenomaProcessing (filename2, 22603, TotalIndividuals);
		 GenomaProcessing (filename2, 103, TotalIndividuals);

		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
 
	delete filename, filename2;

   return 0;

}





