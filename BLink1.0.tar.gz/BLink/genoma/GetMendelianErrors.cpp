
/*
#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "../commonc++/Fachade.h"
#include "SNP.h"
#include "Tables2x2.cpp"

#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "MonolociMeasure.h"
#include "MonolociMeasuresResults.h"
#include "PairwiseMeasuresResults.h"
*/

#include "FachadeGenoma.h"
//#include "Tables2x2.h"
//#include "SNP.cpp"

//#include "PairwiseMeasuresResults.h"
//#include "TrioSample.h"


/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{
int type=0, phenotype=-1;
double MAF=0;

if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " <<" <output file>" <<"operation: 0 (default): errors, 1-5: allele frequencies (A/C/G/T/N respectively), 6: non-hetero parents (those where Mendelian errors can be detected), 7: HWE" <<"<MAF(default is 0)>" << "<phenotype value (-1, delfault, means all phenotypes)>" << endl;

         exit(-1);
        }
  char filename[256], filepos[256], filename2[256];
  strcpy (filename, argv[1]);
  strcpy (filename2, argv[2]);
 
if (argc>=4)
type=atoi(argv[3]);

 
if (argc>=5)
MAF=atof(argv[4]);

if (argc>=6)
phenotype=atoi(argv[5]);

//cout <<"MAF is" << MAF <<"\n";

    OpenOutput(filename2, &OutputFile);
    ChangeExtension (filename, filepos, "pou");
    Positions*Pos=new Positions (filepos);
    TrioSample* gs=new TrioSample (filename, everybody, NotChanged, false);
    SNPPos TotalSNPs=gs->GetTotalSNPs();

int* results, fa;
double cMAF;

if (type==0) results=gs->inconsistencies;
else 
{
if (type==5) type=0;
if (type<6)
results=gs->getAlleleFrequencies((allele)type, everybody, everyGender, phenotype);
else if (type==6) results=gs->nonHeteroParents;
else results=gs->childrenNotInHWE;
}


    for (int i=0; i<TotalSNPs; i++)
{
fa=gs->GetTotalAllele(i, false, offspring);
cMAF=fa/(double)(gs->GetTotalAllele(i, true, offspring)+fa);
//cout <<"\n" << fa;
if (cMAF>=MAF)
     OutputFile << results[i] << "\n";
}
    zap(gs);	
    OutputFile.close();

//if (type!=0) zaparr(results);




return 0;
};

 


