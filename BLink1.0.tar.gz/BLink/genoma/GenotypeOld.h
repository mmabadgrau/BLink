/* File: genotype.h */


#ifndef __genotype_h__
#define __genotype_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"


namespace SNP {

	typedef enum {IsPhased=0, KeepUnordered=1, ToOrder=2, ResolveFromTU=3, dHap=4, ResolveFromPhasedChild=5, ResolvePhaseFromFile=6} PhaseType ; 




/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


     /**
       @memo Definition of type allele
       @doc
        Used to declare alleles in SNPs. They can have one of the values 0,1,2,3,4,
        representing missing, adenine, cytosine, guanine, thymine respectively.
    */


        // adenine     A=1;
        // cytosine     C=2;
        // guanine    G=3;
        // thymine   T=4;

	typedef enum  {N=0, A=1, C=2, G=3, T=4, U=5, UT=-4, UG=-3, UC=-2, UA=-1} allele; // U: unphased, N:non known


	typedef enum  {Left=0, Right=1, All=2} ModePhase; // U: unphased, N:non known

	typedef enum  {left=0, right=1, leftright=2, rightleft=4, all=5} ModePair; // U: unphased, N:non known

class genotype: public positions {


protected:
    /** @name Implementation of class genotype
        @memo Private part.
    */


bool *Selected;

  PhaseType PhaseMode;

   	
	 /** @name Pointer to the list of the wild-type allele for every SNP
        @memo The wild-type will be the more frequent allele in the dataset
    */


        
	 allele* MajorAllele;

	 

	 /** @name Pointer to the list of the mutant allele for every SNP
        @memo The mutant will be the less frequent allele in the dataset
    */


        
	 allele* MinorAllele;


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
    int Size;





   struct Genotype{

      /**
      @memo A pointer to the list of left alleles
      @doc  Each left allele contains a value {0,1,2,3,4}
      */
      allele *Left;

      /**
      @memo A pointer to the list of right alleles
      @doc Each right allele contains a value {0,1,2,3,4}
      */
      allele *Right;

		   /**
      @memo next
      @doc It contains a pointer to the phenotype of the following individual
      */

      Genotype *Next;

	  
	  /**
      @memo next
      @doc It contains a pointer to the phenotype of the previous individual
      */
      Genotype *Previous;

   };  // end structure genotype


/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/

    Genotype * TheFirstGenotype;


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */
      void destroy (Genotype * IndGenotype);

	  /**
         @memo Copy the vector of genotypes
         @param target: pointer where will be copied
         @param origen: pointer to the vector of genotypes to copy
	*/
       void copy(Genotype * target, const Genotype * origen);
 
	   void ReadGenotypes (Genotype * TheFirstGenotype, ifstream * Origen, unsigned short int ReduceSample);

	   void ChangeAlleles (const Genotype *IndGenotype, const unsigned int SNP);

	   bool IsAnOrderedPhase (const Genotype* IndGenotype1, 
							    unsigned int SNP1, 
							    unsigned int SNP2);
	  /**
         @memo Increase the count the total number of known haplotypes between two positions.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param IndGenotype: individual whose haplotype is going to be checked
         @param FirstSNP, LastSNP: the two loci
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
     */

                 void CountHaps (frequencies comb, genotype::Genotype* IndGenotype, 
							unsigned int FirstSNP, unsigned int LastSNP, 
							bool OnlyU, bool SolvedGenericParent); 

	  
	 
	  /**
         @memo Increase the count the total number of known haplotypes between two positions for homozygous individuals at both positions.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param IndGenotype: individual whose haplotype is going to be checked
         @param FirstSNP, LastSNP: the two loci
         @param MajorAllele: pointer to a a TotalSNPs allele table with the major allele for each SNP
     */

		 void CountHaps3 (unsigned int* comb, genotype::Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP);

		allele GetMajorAllele (unsigned int SNP);
		
		allele GetMinorAllele (unsigned int SNP);


      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on genotype 
        @memo Operations on a genotype 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  genotype(const unsigned int TotalSNPs, unsigned int Size);

      /**
         @memo Copy constructor
         @param destino: genotype where will be copy
         @param origen: genotype to copy
         @doc
           Make a copy of genotype
           Time complexity in time O(1).
        */
		  genotype (const genotype & origen);


/**
         @memo From file constructor
         @param destino: genotype where will be copy
         @param origen: file with genotypes to copy
         @doc
           Make a copy of genotype
           Time complexity in time O(1).
        */
		  genotype (char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, unsigned short int ReduceSample);


      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
      ~genotype ();

      /**
         @memo Assignation
         @param g genotype to copy.
         @return Reference to the receptor genotype.
	 @doc
           Copy the genotype in the receptor genotype.
           Time complexity O(1).

      */
      genotype& operator=(const genotype& g);


	    /////////////////////////////////////////////
      /**
         @memo Constructor from input buffer
         @param file: file position in which is the individual who will be copy
         @param origen: individual to read
         @doc
           Read an individual
           Time complexity in time O(1).
        */
      genotype (const genotype & origen, istream* file);

	   /**
         @memo Obtain the k genotype in the sample.
         @param The number k
         @return return a pointer to the k genotype in the sample
         Time complexity O(TotalSNPs)

      */

	  Genotype* GetGenotype(const int k);

	    /**
         @memo Obtain the Next genotype in the sample.
         @param The pointer to the current genotype
         @return return a pointer to the Next genotype in the sample
         Time complexity O(1)
		 **/

	  Genotype* GetNext(const genotype::Genotype *i);


      /**
         @memo Check if the genotype is non missing.
         @param g: pointer to the genotype to check.
         @return bool
         @doc Return a false if one or both alleles in the genotype are missing,
         return a true if both are non missing. Complexity O(1).

      */
        bool IsANonMissingSNP (const Genotype* IndGenotype, const unsigned int position);   


      /**
         @memo Check if the genotype is heterozygous
         @param g: pointer to the genotype to check.
         @return bool 
         @doc Return a false if the genotype snp is not heterozygous
         (it can be missing, homozygous wild type or homozygous mutant).
         return a true if the genotype snp is heterozygous.
         Complexity O(1).

      */
        bool IsHeterozygous (const Genotype* IndGenotype, const unsigned int position);             
      
		/**
         @memo Check if the genotype is homozygous for wild-type allele
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous wild-type
         (it can be missing, homozygous mutant or heterozygous).
         return a true if the genotype snp is homozygous wild-type.
         Complexity O(1).

      */
        bool IsHomozygous1 (const Genotype* IndGenotype, const unsigned int position);             

/**
         @memo Check if the genotype is homozygous for mutant allele
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous wild-type
         (it can be missing, homozygous mutant or heterozygous).
         return a true if the genotype snp is homozygous wild-type.
         Complexity O(1).

      */
        bool IsHomozygous2 (const Genotype* IndGenotype, const unsigned int position);             


/**
         @memo Check if the genotype is homozygous 
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous 
         (it can be missing, or heterozygous).
         return a true if the genotype snp is homozygous.
         Complexity O(1).

      */
        bool IsHomozygous (const Genotype* IndGenotype, const unsigned int position);             

	/**
         @memo Check if a pair of genotypes (used for parents) is homozygous for wild-type allele
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity.
         @return bool 
         @doc Return a false if at least one of the genotype snp is not homozygous wild-type
         (it can be missing, homozygous mutant or heterozygous).
         return a true if both the genotypes snp are homozygous wild-type.
         Complexity O(1).
      */
        bool IsHomozygous1Homozygous1 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

		
	/**
         @memo Check if a pair of genotypes (used for parents) is homozygous for mutant allele
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity.
         @return bool 
         @doc Return a false if at least one of the genotype snp is not homozygous mutant
         (it can be missing, homozygous wild-type or heterozygous).
         return a true if both the genotypes snp are homozygous mutant.
         Complexity O(1).
      */
        bool IsHomozygous2Homozygous2 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

				
	/**
         @memo Check if a pair of genotypes (used for parents) is homozygous for different types
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity1 and homozygosity2.
         @return bool 
         @doc Return a false they are not homozygous1 and homozygous2 
         return a true if one genotype snp is homozygous wild-type and the other mutant.
         Complexity O(1).
      */
        bool IsHomozygous1Homozygous2 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

	/**
         @memo Check if a pair of genotypes (used for parents) are homozygous1 and heterozygous
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity1 and heterozygosity.
         @return bool 
         @doc Return a false they are not homozygous1 and heterozygous 
         return a true if one genotype snp is homozygous wild-type and the other heterozygous.
         Complexity O(1).
      */
        bool IsHomozygous1Heterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

		/**
         @memo Check if a pair of genotypes (used for parents) are homozygous2 and heterozygous
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity2 and heterozygosity.
         @return bool 
         @doc Return a false they are not homozygous2 and heterozygous 
         return a true if one genotype snp is homozygous mutant and the other heterozygous.
         Complexity O(1).
      */
        bool IsHomozygous2Heterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

		/**
         @memo Check if a pair of genotypes (used for parents) are homozygous(1 or 2) and heterozygous
         @param position: pointers to the genotypes to check,
         alleles to check homozygosity2 and heterozygosity.
         @return bool 
         @doc Return a false they are not homozygous2 and heterozygous 
         return a true if one genotype snp is homozygous mutant and the other heterozygous.
         Complexity O(1).
      */
        bool IsHomozygousHeterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      


			/**
         @memo Check if a pair of genotypes (used for parents) are heterozygous
         @param position: pointers to the genotypes to check,
         alleles to check heterozygosity.
         @return bool 
         @doc Return a false they are not heterozygous 
         return a true if both are heterozygous.
         Complexity O(1).
      */
        bool IsHeterozygousHeterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

	/**
         @memo Check if a pair of genotypes (used for parents) are both missing
         @param position: pointers to the genotypes to check,
         alleles to check double missingness.
         @return bool 
         @doc Return a false they if at least one is not missing 
         return a true if both genotypes at SNP are missing.
         Complexity O(1).
      */
        bool IsMissingMissing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

	/**
         @memo Check if a pair of genotypes (used for parents) are one homozygous wild-type the other missing
         @param position: pointers to the genotypes to check,
         alleles to check one missing, the other homozygous wild-type.
         @return bool 
         @doc Return a true if one genotype at SNP is missing and the other homozyogus wild-type.
		 Otherwise return false
         Complexity O(1).
      */
        bool IsHomozygous1Missing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      


		/**
         @memo Check if a pair of genotypes (used for parents) are one homozygous mutant the other missing
         @param position: pointers to the genotypes to check,
         alleles to check one missing, the other homozygous mutant.
         @return bool 
         @doc Return a true if one genotype at SNP is missing and the other homozyogus mutant.
		 Otherwise return false
         Complexity O(1).
      */
        bool IsHomozygous2Missing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

	
		/**
         @memo Check if a pair of genotypes (used for parents) are one heterozygous and the other missing
         @param position: pointers to the genotypes to check,
         alleles to check one missing, the other heterozygous.
         @return bool 
         @doc Return a true if one genotype at SNP is missing and the other heterozyogus.
		 Otherwise return false
         Complexity O(1).
      */
        bool IsHeterozygousMissing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position);      

      /**
         @memo Is equal at position p
         @param g: genotype to compare with and position of the SNP.
	 @return
           Return true if the genotype at this position is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool IsEqual(const Genotype* IndGenotype, const Genotype*  g, const unsigned int position);


      /**
         @memo Is equal
         @param g: genotype to compare with.
	 @return
           Return true if all the genotype is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const genotype & g);
      /**
         @memo Is different
         @param g, position: genotype to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const genotype & g);

        /**
         @memo Obtain the sample Size.
         @param g: the sample whose size is being obtained.
         @return the size of a sample
         @doc Return the number of phenotypes in the sample. This value
         is in the variable Size.
         Time complexity O(1)

      */
        unsigned int GetSize ();          
		

		
	        /**
         @memo Obtain the number of SNPs.
         @return the number of SNPs
         @doc Return the number of SNPs. This value
         is in the variable TotalSNPs.
         Time complexity O(1)

      */
        unsigned int GetTotalSNPs ();        
		
				
	        /**
         @memo Obtain the number of heterozygous genotypes.
         @return the number of heterozygous genotypes
         @doc Return the number of heterozygous genotypes. 
         Time complexity O(Size*TotalSNPs)

      */
        unsigned long int GetHeterozygousGenotypes ();          




		  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */

	  void WriteGenotypes (char* filename);

	  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */
	  
	  void PrintGenotype (unsigned int Position);

	   unsigned int ConvertAllele (char);

	   char UnconvertAllele (short int number);

	   bool IsUnresolved (const Genotype* IndGenotype, const unsigned int SNP);

	   allele MarkAllele (allele number);

	   allele UnmarkAllele (allele number);

   	   void MarkAlleles (Genotype* IndGenotype, unsigned int SNP, ModePhase TypePhase);

	   void UnmarkAlleles (Genotype* IndGenotype, unsigned int SNP, ModePhase TypePhase);

	   bool IsMarked (allele number);

	   bool IsTheSamePhase (const Genotype* IndGenotype1, const Genotype* IndGenotype2, unsigned int SNP1, unsigned int SNP2, ModePhase Mode);    

	   bool IsTheSameAllele (const Genotype* IndGenotype1, const Genotype* IndGenotype2, unsigned int SNP, ModePair Mode);    



};  // End of class genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



void genotype::destroy(Genotype * IndGenotype)
{
if (IndGenotype != NULL)
{
  if (IndGenotype->Left != NULL)
  delete IndGenotype->Left;
 if (IndGenotype->Right != NULL)
  delete IndGenotype->Right;
 destroy (IndGenotype->Next);
 delete IndGenotype;
}
};

/*___________________________________________________________ */

void genotype::copy(Genotype * Target, const Genotype * Origen)
{

 for (int i=0; i<TotalSNPs;i++)
 {
  *((Target->Left)+i)=*((Origen->Left)+i);
  *((Target->Right)+i)=*((Origen->Right)+i);


 }
//PrintGenotype(Size);
 		 
 if (Origen->Next!=NULL)
 {
  if ((Target->Next=new Genotype)==NULL)
   throw NoMemory();
  if ((Target->Next->Left=new allele[TotalSNPs])==NULL)
   throw NoMemory();
  if ((Target->Next->Right=new allele[TotalSNPs])==NULL)
   throw NoMemory();
  Target->Next->Previous=Target;
  copy(Target->Next,Origen->Next);     
 }  
 else Target->Next=NULL;
Size++;
}


/*___________________________________________________________ */

void  genotype::ReadGenotypes (genotype::Genotype * target, ifstream * origen, unsigned short int ReduceSample)
{

    char *genotypebuf, *cad, cadena[2], cadena2[2];
    if ((genotypebuf=new char[TotalSNPs*4+40])==NULL)
     throw NoMemory();

	origen-> getline (genotypebuf, TotalSNPs*4+40, '\n');

if (Size%ReduceSample==0)
{
	cad = strtok (genotypebuf," \t");

	for (int phen=1;phen<7;phen++)
     cad = strtok (NULL," \t");
    for (int cont=0;cont<TotalSNPs;cont++)
    {
	cad = strtok (NULL," \t");
	if (cad==NULL)
	{
	 cout <<"cont:" << cont;
     throw NullValue();
	}
	if (strlen(cad)==1)
	{
	sscanf (cad, "%s", cadena);
	*((target->Left)+cont)=(allele) atoi(cadena);

	cad = strtok (NULL," \t");
    if (cad==NULL)
	 throw NullValue();

	sscanf (cad, "%s", cadena);

	*((target->Right)+cont)=(allele) atoi(cadena);
    }
	else
	{
	sscanf (cad, "%c%c", cadena, cadena2);
	*((target->Left)+cont)=(allele) atoi(cadena);
	*((target->Right)+cont)=(allele) atoi(cadena2);
    }
	}// end for
}	// end if selected


assert (genotypebuf!=NULL);
delete genotypebuf;

    if (origen->peek()!=EOF)
     {
     if (Size%ReduceSample==0)
	{
	if ((target->Next=new Genotype)==NULL)
      throw NoMemory();
	if ((target->Next->Left=new allele[TotalSNPs])==NULL)
      throw NoMemory();
    if ((target->Next->Right=new allele[TotalSNPs])==NULL)
      throw NoMemory();
    target->Next->Previous=target;
     }
    ReadGenotypes (target->Next, origen, ReduceSample);
    }
    else target->Next=NULL;
    Size++;
}

///////////////////
//// public ////////
///////////////////


genotype::genotype(const unsigned int TotalSNPs, unsigned int Size): positions (TotalSNPs)
{
 // this->TheFirstGenotype=NULL;
  this->TotalSNPs=TotalSNPs;
  this->Size=Size;


  TheFirstGenotype=NULL;

     if ((Selected=new bool[Size])==NULL)
     throw NoMemory();
        for (unsigned int i=0;i<Size;i++)
	Selected[i]=true;

   
}

/*____________________________________________________________ */

genotype::genotype (const genotype& origen):positions (origen.genotype::TotalSNPs)
{

//  TotalSNPs=origen.TotalSNPs;

  
  Size=0;

  if (&origen==NULL)
    TheFirstGenotype=NULL;
else 
{
 if ((TheFirstGenotype=new Genotype)==NULL)
   throw NoMemory();
 if ((TheFirstGenotype->Left=new allele[TotalSNPs])==NULL)
   throw NoMemory();
if ((TheFirstGenotype->Right=new allele[TotalSNPs])==NULL)
   throw NoMemory();
try 
{
 copy (TheFirstGenotype, origen.TheFirstGenotype);
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}
}
               

}



/*____________________________________________________________ */

genotype::genotype (char* filename, const unsigned int InputTotalSNPs, const unsigned int InputSize, unsigned short int ReduceSample):
positions (filename, InputTotalSNPs) 
{

this->MajorAllele=MajorAllele;
this->MinorAllele=MinorAllele;

cout << "Reading genotypes ...\n";
	
//        TotalSNPs=InputTotalSNPs;

ifstream InputFile; 
Size=0;

try
{
 InputFile.open (filename, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(filename);
   }

try {
if ((TheFirstGenotype=new Genotype)==NULL)
      throw NoMemory();
if ((TheFirstGenotype->Left=new allele[TotalSNPs])==NULL)
      throw NoMemory();
if ((TheFirstGenotype->Right=new allele[TotalSNPs])==NULL)
      throw NoMemory();
 genotype::ReadGenotypes (TheFirstGenotype, &InputFile, ReduceSample);
  }
catch (NoMemory no) {
  no.PrintMessage();
  }
catch (NullValue nv) {
  nv.PrintMessage();
  }


InputFile.close();


if (InputSize != Size)
{
 cerr << "There are " << Size <<" genotypes in the file but you have especified that the number is " << InputSize;
 exit(0);
}

if (ReduceSample>1)
 Size=(unsigned int) ceil((double)Size/ReduceSample);
cout << "Genotype reading has finished ...\n";

    if ((Selected=new bool[Size])==NULL)
     throw NoMemory();
        for (unsigned int i=0;i<Size;i++)
	Selected[i]=true;

 }



/*____________________________________________________________ */

genotype::~genotype ()
{
	if (TheFirstGenotype!=NULL) destroy(TheFirstGenotype);

   if (Selected!=NULL)
	 delete Selected;
}

/*____________________________________________________________ */

genotype& genotype::operator=(const genotype& genotype2)
{
  if (this!=&genotype2) {
   try {
                destroy(TheFirstGenotype);
   }
        catch (NullValue n) {
                n.PrintMessage();
	}
	try {
          copy (TheFirstGenotype, genotype2.TheFirstGenotype);
	}
        catch (NoMemory NM ) {
                NM.PrintMessage();
	}
  }
  return *this;
}
/*____________________________________________________________ */

genotype::Genotype* genotype::GetGenotype(const int k)
{
  genotype::Genotype *i=TheFirstGenotype;
  try {
	if (k>=0)
	 for (int c=0;c<k;c++)
      i=i->Next;
	 else
		 throw NonFound();
  }
  catch (NullValue null) {
    null.PrintMessage();
    }
  catch (NonFound nf) {
    nf.PrintMessage();
    }

  return i;
}

/*___________________________________________________*/

bool genotype::IsANonMissingSNP (const Genotype* IndGenotype, const unsigned int position)
{
if ((*((IndGenotype->Left)+position)!=0) && (*((IndGenotype->Right)+position)!=0))
 return true;
 else return false;
}

/*____________________________________________________________ */

allele genotype::GetMajorAllele (unsigned int SNP)
{
 try {
        if (MajorAllele==NULL)
		throw NullValue();
   }
        catch (NullValue n) {
                n.PrintMessage();
		}	

 return *(MajorAllele+SNP);
}

/*____________________________________________________________ */

allele genotype::GetMinorAllele (unsigned int SNP)
{

	try{

	if (MinorAllele==NULL)
		throw NullValue();
	}
 catch (NullValue n) {
                n.PrintMessage();
	}
 return *(MinorAllele+SNP);
}

/*____________________________________________________________ */


bool genotype::IsUnresolved (const Genotype* IndGenotype, const unsigned int SNP)
{
if (IndGenotype==NULL) {
 throw NullValue();
 return 0;
}
bool Is=true;
allele LeftValue=(allele)(*((IndGenotype->Left)+SNP));
allele RightValue=(allele)(*((IndGenotype->Right)+SNP));

if (IsANonMissingSNP(IndGenotype, SNP))
if ((LeftValue>0) || (RightValue>0)) 
Is=false;
return Is;
}

/*___________________________________________________*/


bool genotype::IsHeterozygous (const Genotype* IndGenotype, const unsigned int position)
{
 if (IndGenotype==NULL) {
 throw NullValue();
 return 0;
}
bool Heterozygous=false;
allele LeftValue=(allele)abs(*((IndGenotype->Left)+position));
allele RightValue=(allele)abs(*((IndGenotype->Right)+position));

if (IsANonMissingSNP(IndGenotype, position))
if ((LeftValue==MajorAllele[position] && RightValue!=MajorAllele[position]) ||
(LeftValue!=MajorAllele[position] && RightValue==MajorAllele[position]))
 Heterozygous = true;
return Heterozygous;
}

/*___________________________________________________*/


bool genotype::IsHomozygous1 (const Genotype* IndGenotype, const unsigned int position)
{
if (IndGenotype==NULL || MajorAllele==NULL || MinorAllele==NULL)
 throw NullValue();

bool Is=false;
allele LeftValue=(allele)abs(*((IndGenotype->Left)+position));
allele RightValue=(allele)abs(*((IndGenotype->Right)+position));

if (IsANonMissingSNP(IndGenotype, position))
if (LeftValue==MajorAllele[position])
if (RightValue==MajorAllele[position]) 
Is=true;
return Is;
}

/*___________________________________________________*/


bool genotype::IsHomozygous2 (const Genotype* IndGenotype, const unsigned int position)
{
if (IndGenotype==NULL || MajorAllele==NULL || MinorAllele==NULL)
 throw NullValue();

bool Is=false;
allele LeftValue=(allele)abs(*((IndGenotype->Left)+position));
allele RightValue=(allele)abs(*((IndGenotype->Right)+position));

if (IsANonMissingSNP(IndGenotype, position))
if (LeftValue!=MajorAllele[position])
if (RightValue!=MajorAllele[position]) 
Is=true;
return Is;
};

/*___________________________________________________*/


bool genotype::IsHomozygous (const Genotype* IndGenotype, const unsigned int position)
{
if (IndGenotype==NULL) {
 throw NullValue();
 return 0;
}
if ((IsHomozygous1(IndGenotype, position)) ||  (IsHomozygous2(IndGenotype, position)))
return true;
else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygous1Homozygous1 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if ((IsHomozygous1(IndGenotype1, position)) && (IsHomozygous1(IndGenotype2, position)))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygous2Homozygous2 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if ((IsHomozygous2(IndGenotype1, position)) && (IsHomozygous2(IndGenotype2, position)))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygous1Homozygous2 (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHomozygous1(IndGenotype1, position)) && (IsHomozygous2(IndGenotype2, position))) 
		|| ((IsHomozygous2(IndGenotype1, position)) && (IsHomozygous1(IndGenotype2, position))))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygous1Heterozygous (const Genotype* IndGenotype1,const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHomozygous1(IndGenotype1, position)) && (IsHeterozygous(IndGenotype2, position))) 
		|| ((IsHeterozygous(IndGenotype1, position)) && (IsHomozygous1(IndGenotype2, position))))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygous2Heterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHomozygous2(IndGenotype1, position)) && (IsHeterozygous(IndGenotype2, position))) 
		|| ((IsHeterozygous(IndGenotype1, position)) && (IsHomozygous2(IndGenotype2, position))))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHomozygousHeterozygous (const Genotype* IndGenotype1,const Genotype* IndGenotype2, const unsigned int position)      
{
	if (IsHomozygous1Heterozygous(IndGenotype1, IndGenotype2, position)
		|| IsHomozygous2Heterozygous(IndGenotype1, IndGenotype2, position))
		return true;
	else return false;
};
/*___________________________________________________*/

bool genotype::IsHeterozygousHeterozygous (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if ((IsHeterozygous(IndGenotype1, position)) && (IsHeterozygous(IndGenotype2, position))) 
		return true;
	else return false;
};


/*___________________________________________________*/

bool genotype::IsMissingMissing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if ((!IsANonMissingSNP(IndGenotype1, position)) && (!IsANonMissingSNP(IndGenotype2, position))) 
		return true;
	else return false;
};


/*___________________________________________________*/

bool genotype::IsHomozygous1Missing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHomozygous1(IndGenotype1, position)) && (!IsANonMissingSNP(IndGenotype2, position))) ||
		((!IsANonMissingSNP(IndGenotype1, position)) && (IsHomozygous1(IndGenotype2, position))))
		return true;
	else return false;
};


/*___________________________________________________*/

bool genotype::IsHomozygous2Missing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHomozygous2(IndGenotype1, position)) && (!IsANonMissingSNP(IndGenotype2, position))) ||
		((!IsANonMissingSNP(IndGenotype1, position)) && (IsHomozygous2(IndGenotype2, position))))
		return true;
	else return false;
};

/*___________________________________________________*/

bool genotype::IsHeterozygousMissing (const Genotype* IndGenotype1, const Genotype* IndGenotype2, const unsigned int position)      
{
	if (((IsHeterozygous(IndGenotype1, position)) && (!IsANonMissingSNP(IndGenotype2, position))) ||
		((!IsANonMissingSNP(IndGenotype1, position)) && (IsHeterozygous(IndGenotype2, position))))
		return true;
	else return false;
};


/*___________________________________________________*/


bool genotype::IsEqual(const Genotype* IndGenotype, const Genotype* g, const unsigned int position)
{
bool Is=false;
if (*((IndGenotype->Left)+position)==*((g->Left)+position))
if (*((IndGenotype->Right)+position)==*((g->Right)+position))
Is=true;
return Is;
}
/*____________________________________________________________ */

genotype::Genotype* genotype::GetNext(const genotype::Genotype *i)
{

  if (i==NULL) {
    throw NullValue();
	 return 0;
  }
  else {
  return i->Next;
  }
}/*____________________________________________________________ */

unsigned int genotype::GetSize()
{
  return Size;
}
	
/*____________________________________________________________ */

unsigned int genotype::GetTotalSNPs()
{
  return TotalSNPs;
}
/*____________________________________________________________ */

void genotype::PrintGenotype (unsigned int Position)
{
Genotype* target=GetGenotype(Position);
for(int i=0;i<TotalSNPs;i++)
{
cout << *(target->Left+i) << ' ';
cout << *(target->Right+i) << ' ';
}
	}
/*____________________________________________________________ */


void genotype::WriteGenotypes (char* filename)
{
Genotype * IndGenotype;
ofstream OutputFile; 

cout <<"Writing genotypes in " << filename <<" ...\n";

try
{
 OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
IndGenotype=TheFirstGenotype;
for (int i=0; i<Size;i++)
{
 for (int i2=0; i2<TotalSNPs;i2++)
 {
	// if ((int)*((IndGenotype->Left)+i2)<0)
	//	 cout <<"minus0";
  OutputFile << *((IndGenotype->Left)+i2) << ' ';
  OutputFile << *((IndGenotype->Right)+i2) << ' ';
 }
  OutputFile << "\n";

  IndGenotype=IndGenotype->Next;
}

OutputFile.close();

cout << "Writing has finished\n";
}

/*____________________________________________________________ */

unsigned int genotype::ConvertAllele (char value)
{
unsigned int val;
try
{
	if ((value=='N') || (value=='?')) val=0;
	else if (value=='A') val=1;
	else if (value=='C') val=2;	
	else if (value=='G') val=3;	
	else if (value=='T') val=4;	
	else 
	{
		throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(value);
      }

	return (val);
}

/*____________________________________________________________ */

char genotype::UnconvertAllele (short int number)
{
char c;
try
{
	switch (number)
	{
		case 0: c='?'; break;
		case 1: c='A'; break;
		case 2: c='C'; break;
		case 3: c='G'; break;
		case 4: c='T'; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(number);
      }
return(c);
}

/*____________________________________________________________ */

allele genotype::MarkAllele (allele number)
{
allele a;
try
{
	switch (number)
	{
		case N: a=N; break;
		case A: a=UA; break;
		case C: a=UC; break;
		case G: a=UG; break;
		case T: a=UT; break;
		case U: a=U; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
return(a);
}
/*____________________________________________________________ */

void genotype::MarkAlleles (Genotype* IndGenotype, unsigned int SNP,  ModePhase TypePhase=All)
{

switch (TypePhase)
{
case Left: *((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP)); break;
case Right: *((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP)); break;
case All: 
	*((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP)); 
	*((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP)); break;
}


}
/*____________________________________________________________ */

void genotype::UnmarkAlleles (Genotype* IndGenotype, unsigned int SNP,  ModePhase TypePhase=All)
{

switch (TypePhase)
{
case Left: *((IndGenotype->Left)+SNP)=UnmarkAllele(*((IndGenotype->Left)+SNP)); break;
case Right: *((IndGenotype->Right)+SNP)=UnmarkAllele(*((IndGenotype->Right)+SNP)); break;
case All: 
	*((IndGenotype->Left)+SNP)=UnmarkAllele(*((IndGenotype->Left)+SNP)); 
	*((IndGenotype->Right)+SNP)=UnmarkAllele(*((IndGenotype->Right)+SNP)); break;
}


}
/*____________________________________________________________ */

allele genotype::UnmarkAllele (allele number)
{
 allele a;
try
{
	switch (number)
	{
		case N: return a=N; break;
		case UA: return a=A; break;
		case UC: return a=C; break;
		case UG: return a=G; break;
		case UT: return a=T; break;
		case U: return a=U; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
	return a;
}
/*__________________________________________________________*/

bool genotype::IsMarked (allele number)
{
bool b;
try
{
	switch (number)
	{
		case N: 
		case A: 
		case C: 
		case G: 
		case T: 
		case U: b=false; break;
		case UA: 
		case UC: 
		case UG: 
		case UT: b=true; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
return (b);
}


/*__________________________________________________________*/

unsigned long int genotype::GetHeterozygousGenotypes ()
{
Genotype* IndGenotype=TheFirstGenotype;
unsigned long int TotalHeterozygous=0;
try
{
for (int i=0;i<Size;i++)
{
 for (int i2=0;i2<TotalSNPs;i2++)
   if (IsHeterozygous(IndGenotype, i2))
	   TotalHeterozygous++;
   IndGenotype=GetNext(IndGenotype);
   if (i<(Size-1))
if (IndGenotype==NULL) 
    throw NullValue();
}
}
	catch (NullValue nv) {
        nv.PrintMessage();
      }


return TotalHeterozygous;
}


/*____________________________________________________*/

bool genotype::IsTheSamePhase (const Genotype* IndGenotype1, 
							   const Genotype* IndGenotype2, 
							   unsigned int SNP1, 
							   unsigned int SNP2, 
							   ModePhase Mode)    
{
// if Mode=Left, compare the phase of IndGenotype1 with the phase between left of IndGenotype2 and its complementary
// if Mode=Right, compare the phase of IndGenotype1 with the phase between right of IndGenotype2 and its complementary
// if Mode=All, compare the phase of IndGenotype1 with the phase of IndGenotype2

	
	bool same=false;

switch (Mode)
{
case Left:
 if   ( (  (allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))  ) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
  if   ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
break;
case Right:
 if  ( ((allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;
 if  ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;

break;
}
return same;
}
/*____________________________________________________*/

bool genotype::IsTheSameAllele (const Genotype* IndGenotype1, 
							   const Genotype* IndGenotype2, 
							   unsigned int SNP,
							   ModePair Mode)    
{
// if Mode=Left, compare the left allele of IndGenotype1 with the left allele of IndGenotype2
// if Mode=Right, compare the right allele of IndGenotype1 with the right allele of IndGenotype2 
// if Mode=All, compare both alleles of IndGenotype1 and IndGenotype2
// if Mode=LeftRight, compare the left allele of IndGenotype1 with the right allele of IndGenotype2
// if Mode=RightLeft, compare the right allele of IndGenotype1 with the left allele of IndGenotype2
// if Mode=All, compare both alleles of IndGenotype1 and IndGenotype2


	bool same=false;

//	(!IsMarked(*((IndGenotype->Left)+SNP1)))
if  (IsMarked(*((IndGenotype1->Left)+SNP)) || IsMarked(*((IndGenotype2->Left)+SNP))) 
 throw NonSNP();

switch (Mode)
{
case left:
 if    (*((IndGenotype1->Left)+SNP)==*((IndGenotype2->Left)+SNP)) 
 same=true;
break;
case right:
 if  (*((IndGenotype1->Right)+SNP)==*((IndGenotype2->Right)+SNP)) 
 same=true;
break;
case all:
 if  ( (*((IndGenotype1->Right)+SNP)==*((IndGenotype2->Right)+SNP)) &&
 (*((IndGenotype1->Left)+SNP)==*((IndGenotype2->Left)+SNP)) )
 same=true;
break;
case leftright:
 if    (*((IndGenotype1->Left)+SNP)==*((IndGenotype2->Right)+SNP)) 
 same=true;
break;
case rightleft:
 if  (*((IndGenotype1->Right)+SNP)==*((IndGenotype2->Left)+SNP)) 
 same=true;
break;

}
return same;
}

/*____________________________________________________*/

bool genotype::IsAnOrderedPhase (const Genotype* IndGenotype1, 
							    unsigned int SNP1, 
							    unsigned int SNP2)    
{
	
	bool ordered=false;
//	if (SNP1==1)
//	{
//cout <<"\nfirstizq:" << (allele)abs(*((IndGenotype1->Left)+SNP1)) <<"firstder:" << (allele)abs(*((IndGenotype1->Right)+SNP1)) << ", mayor first: " << GetMajorAllele(SNP1);
//cout <<"lastizq:" << (allele)abs(*((IndGenotype1->Left)+SNP2)) <<"lastder:" << (allele)abs(*((IndGenotype1->Right)+SNP2)) << ", mayor first: " << GetMajorAllele(SNP2);
//	}
if (  
	((allele)abs(*((IndGenotype1->Left)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==GetMajorAllele(SNP2)) 
		  ) 
 ordered=true;
else
 if (  ((allele)abs(*((IndGenotype1->Right)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==GetMajorAllele(SNP2))  ) 
 ordered=true;

return ordered;
}
/*___________________________________________________________ */

void genotype::ChangeAlleles (const Genotype *IndGenotype, const unsigned int SNP)
{
	allele switcher;
	switcher=*((IndGenotype->Left)+SNP);
	 *((IndGenotype->Left)+SNP)=*((IndGenotype->Right)+SNP);
	 *((IndGenotype->Right)+SNP)=switcher;
}

/*_____________________________________________________________*/

void genotype::CountHaps (frequencies comb, genotype::Genotype* IndGenotype, 
							unsigned int FirstSNP, unsigned int LastSNP, 
							bool OnlyU=false, 
							bool SolvedGenericParent=false) 
//count known haplotypes
{
// if phase has been trivially solved (phase solved using families by procedure ResolveU/T) 
// each marked positions means that
// two phase are unknown: the one with the last hetero and the one with the next hetero
// If phase was solved using dHap or other like ResolveTrivialPhase, a marked position
// means that phase has not been solved between that position and the next heterozygotic one

if (OnlyU==true)
{
if (PhaseMode ==dHap)
 {
	cout <<"Configuration error: If dHap is used, OnlyUntransmitted cannot be true";
	exit(0);
 }

if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))  
{ 
  comb[4]=comb[4]+1;// HH. NOTE: criteria for completing phase (like EM or LD) cannot be used for OnlyU

if (!IsUnresolved (IndGenotype, FirstSNP) && !IsUnresolved (IndGenotype, LastSNP)) 
{
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[5]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[6]++;
      
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[7]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[8]++;
}
}
else
if (!IsUnresolved (IndGenotype, FirstSNP) && !IsUnresolved (IndGenotype, LastSNP)) 
{
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[0]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[1]++;
      
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[2]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[3]++;
}
} // end only U

else // not OnlyU
{
if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))   
 {
//	if (SolvedGenericParent)
	//	cout <<"\ngenric parent: ";
// SolvedGenericParent=false;
  comb[4]=comb[4]+1;// HH 

  if ((PhaseMode==ResolveFromTU 
	  && (!IsUnresolved (IndGenotype, FirstSNP) && !IsUnresolved (IndGenotype, LastSNP)) 
	     ||  SolvedGenericParent)
	  || (PhaseMode==dHap && !IsUnresolved (IndGenotype, FirstSNP))
	  || (PhaseMode==IsPhased) 
	  || (PhaseMode==KeepUnordered) 
	  || (PhaseMode==ToOrder))
	if (IsAnOrderedPhase(IndGenotype, FirstSNP, LastSNP))
	  {
	  comb[5]++;
	  comb[8]++;
   }
  else
	{
  	  comb[6]++;
	  comb[7]++;

	}
} // end double heterozygous
 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[0]=comb[0]+2;// 1 1 

 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[1]=comb[1]+2;// 1 2 

 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))  
  comb[3]=comb[3]+2;// 2 2 

 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[2]=comb[2]+2;// 2 1

     
 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))
 {
       comb[0]++; // 1 1 
       comb[1]++; // 1 2
 }
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))         
 {
       comb[2]++; // 2 1 
       comb[3]++; // 2 2
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
 {
     comb[0]++;// 1 1 
     comb[2]++; // 2 1
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
 {
     comb[1]++; // 1 2 
     comb[3]++; // 2 2
 }
}// end not OnlyU
};  

/*_____________________________________________________________*/

void genotype::CountHaps3 (unsigned int* comb, genotype::Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP) 
//count known haplotypes
{
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))         
  comb[4]=comb[4]+1;// HH 
 
 if (genotype::IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[0]=comb[0]+2;// 1 1 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[1]=comb[1]+2;// 1 2 
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[3]=comb[3]+2;// 2 2 
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[2]=comb[2]+2;// 2 1         
  
};  


};  // End of Namespace

#endif

/* End of file: genotype.h */




