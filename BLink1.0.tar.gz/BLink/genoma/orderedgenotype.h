/* File: Genotype.h */


#ifndef __Genotype_h__
#define __Genotype_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "positions.h"

using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Genotype {


protected:

    /** @name Implementation of class Genotype
        @memo Private part.
    */
	   
   

      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
   orderedpositions* pos;

/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
		void PrintOrderedUnrepeatedGenotype();
   

		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



		        /**
         @memo Copy constructor
         @param destino: Genotype where will be copy
         @param origen: Genotype to copy
         @doc
           Make a copy of Genotype
           Time complexity in time O(1).
        */
	
		  //Genotype (Genotype& Source, unsigned int *Sampling);

 

};  // End of class Genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

void OrderedGenotype::CheckRepeated()
{
	SNPPos TotalSNPs=GetTotalSNPs(), i=0;
	bool RepeatedPos[TotalSNPs], *p=RepeatedPos;

	 list<PosS>::NodePointer IndPosition=pos->GetFirst();
     double pos, oldpos; 
     while (IndPosition!=NULL)
	 {
	  pos=(pos->GetElement(IndPosition)).pos;
	  if (i>0 && pos==oldpos)
		  RepeatedPos[i]=true;
	  else RepeatedPos[i]=false;
	  oldpos=pos;
	  IndPosition=pos->GetNext(IndPosition);
	  i++;
	 }

DiplotypeList->Remove(p);	

}


/*__________________________________________________________*/
void Genotype::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}

/*____________________________________________________________ */

void Genotype::PrintCompleteGenotype()
{
NodePointer p=DiplotypeList->GetFirst();
while (p!=NULL)
{
    OutputFile << p->GetElement().Left << ' ' << p->GetElement().Right << ' ';
	p=GetNext(p);
}
}
/*____________________________________________________________ */

void Genotype::PrintOrderedUnrepeatedGenotype()
{
  CheckRepeated();
  PrintCompleteGenotype();
}

};  // End of Namespace

#endif

/* End of file: Genotype.h */




