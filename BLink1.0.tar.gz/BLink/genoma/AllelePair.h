

#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"


namespace BIOS {


/************************/
/* SNP'S AllelePair DEFINITION */
/************************/


/**
        @memo AllelePair has information about the four alleles in a pair of SNPs, SNP1 major, SNP1 minor, SNP2 major, SNP2 minor

	@doc
       


        @author M. Mar Abad Grau
	@version 1.0
*/



	class AllelePair  {

private:

int codeAllelePair;

AllelePair(allele values[4]);
int getCodeAllelePair();
setCodeAllelePair(allele values[4]);
};

/*___________________________________________________________________________________________________*/

int AllelePair::GetAllele(allele left, allele right)
{
int a=(int)left;
int b=(int)right;

if (a==1 && b==1) return 0;
if (a==1 && b==2) return 1;
if (a==1 && b==3) return 2;
if (a==1 && b==4) return 3;
if (a==2 && b==2) return 4;
if (a==2 && b==3) return 5;
if (a==2 && b==4) return 6;
if (a==3 && b==3) return 7;
if (a==3 && b==4) return 8;
if (a==4 && b==4) return 9;
}
/*___________________________________________________________________________________________________*/

AllelePair::AllelePair(allele values[4])
{
codeAllelePair=setCodeAllelePair(values);
}
/*___________________________________________________________________________________________________*/

AllelePair::setCodeAllelePair(allele values[4])
{
codeAllelePair=0;
for (int i=0;i<4;i++)
codeAllelePair=codeAllelePair+values[i]*pow(10,3-i);
}
/*___________________________________________________________________________________________________*/

int AllelePair::getCodeAllelePair()
{
return codeAllelePair;
}





};  // End of Namespace

#endif

/* End of file: PairwiseMeasuresResults.h */



