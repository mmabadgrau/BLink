

#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "../commonc++/Fachade.h"
#include "SNP.h"
#include "Tables2x2.cpp"

#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "MonolociMeasure.h"
#include "MonolociMeasuresResults.h"



/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

AlleleOrderType AlleleOrderMode;
float alphaBayes; 

char line[100];
if(argc<7 || argc>14)
  {
        cerr << "Error: you have to specify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " <<" <Trios (1: yes, 0: no)>"  
			<< " <MAF> "  << " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium>" 
<< " <alpha Bayes (any number, only used in Bayes modes)>" 
		<< " <ic (father=0, mother=1, offspring=2, everybody=3, parent=4)>" 
 << endl;
   exit(-1);
   }
  float alpha=90;
  bool invariant=true;
  char filename[256], filepos[256], *filenameB, filename2[512], *fileSel=NULL, ext[256], ext2[256];
  strcpy (filename, argv[1]);
  bool trios=atoi(argv[2]); 
   float MAF=atof(argv[3]);
  BayesType BayesMode=(BayesType) atoi(argv[4]);
  alphaBayes=atof(argv[5]);
   IndCategory ic= (IndCategory) atoi(argv[6]);
  
 if (argc==8)
    strcpy(fileSel, argv[7]);



switch(ic)
{
case father:
strcpy(ext2,  "OnlyFathers\0"); break;
case mother:
strcpy(ext2,  "OnlyMothers\0"); break;
case parent:
strcpy(ext2,  "OnlyParents\0"); break;
case offspring:
strcpy(ext2,  "OnlyOffSpring\0"); break;
case everybody:
strcpy(ext2,  "AllIndividuals\0"); break;
}

strcat(ext2, "AlleleFrequencies\0"); 


switch(BayesMode)
{
case MLE:
sprintf(ext, "%sMAF%d-MLE", ext2, (int)(MAF*100)); break;
case UBalpha:
sprintf(ext, "%sMAF%d-UB%f", ext2, (int)(MAF*100), alphaBayes); break;
case equilibrium:
sprintf(ext, "%sMAF%d-Bequilibrium%f", ext2, (int)(MAF*100), alphaBayes); break;
}


filenameB=GetFilename(filename);

strcpy(filename2, filenameB);
strcat(filename2, ext);

//ChangeExtension (filename, filename2, ext);
strcat(filename2, ".csv");


if (trios)
{

MonolociMeasuresResults<TrioSample> * MM=NULL;



MM=new MonolociMeasuresResults<TrioSample>(filename, MAF, BayesMode, alphaBayes, ic,  false, AlleleOrderMode, alpha, invariant, fileSel);

AlleleOrderMode=MajorFirst;
MM->PrintMonolociMeasures(filename2, false); 
zap(MM);
}
else
{
MonolociMeasuresResults<GenomaSample> * MM=NULL;
AlleleOrderMode=LeftRight;
MM=new MonolociMeasuresResults<GenomaSample>(filename, MAF, BayesMode, alphaBayes, ic, false, AlleleOrderMode, alpha, invariant, fileSel);
MM->PrintMonolociMeasures(filename2, false); 
zap(MM);
}
return 0;
};

 


