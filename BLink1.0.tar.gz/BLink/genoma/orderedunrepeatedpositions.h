/* File: positions.h */

#ifndef __orderedunrepeatedpositions_h__
#define __orderedunrepeatedpositions_h__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//





#include "orderedpositions.h"


//using namespace std;
//using namespace string;

using namespace TAD;

namespace BIOS {


/************************/
/* positions DEFINITION */
/************************/


/**
        @memo positions for SNPs

	@doc
        Definition:
        A set of positions' features 

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in the sample
        Each positions in a sample has been genotyped for the same TotalSNPs SNPs.

        @author Maria M. Abad
	@version 1.0
*/

	class orderedunrepeatedpositions: public orderedpositions
	 {

  

/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      /* PUBLIC FUNCTIONS (INTERFACE) */




      public:




	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */


		orderedunrepeatedpositions(char* filename);

};  // End of class positions



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/




///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

orderedunrepeatedpositions::orderedunrepeatedpositions(char* filename):orderedpositions(filename)
{


if (strncmp(strtok(filename+2, ".")-2, "pou", 3)!=0)
{
	cout <<"File poo is required";
	exit (0);
}

GetInfo(filename);        

}

};  // Fin del Namespace

#endif

/* Fin Fichero: orderedunrepeatedpositions.h */
