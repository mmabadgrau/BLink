/* File: genotype.h */


#ifndef __orderedgenotype_h__
#define __genotype_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"


namespace SNP {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class haplotype: public genotype  {


protected:
    /** @name Implementation of class genotype
        @memo Private part.
    */



/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



		  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */

		void Write (char* filename, RedType R=None, long int FirstSNP=-1, unsigned int RegionSize=0);
	
	  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */
	  


};  // End of class genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////




/*____________________________________________________*/

bool genotype::IsTheSamePhase (const Genotype* IndGenotype1, 
							   const Genotype* IndGenotype2, 
							   SNPPos SNP1, 
							   SNPPos SNP2, 
							   ModePhase Mode)    
{
// if Mode=Left, compare the phase of IndGenotype1 with the phase between left of IndGenotype2 and its complementary
// if Mode=Right, compare the phase of IndGenotype1 with the phase between right of IndGenotype2 and its complementary
// if Mode=All, compare the phase of IndGenotype1 with the phase of IndGenotype2

	
	bool same=false;

switch (Mode)
{
case Left:
 if   ( (  (allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))  ) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
  if   ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
break;
case Right:
 if  ( ((allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;
 if  ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;

break;
}
return same;
}

/*____________________________________________________*/

bool genotype::IsAnOrderedPhase (const Genotype* IndGenotype1, 
							    SNPPos SNP1, 
							    SNPPos SNP2)    
{
	
	bool ordered=false;
//	if (SNP1==1)
//	{
//cout <<"\nfirstizq:" << (allele)abs(*((IndGenotype1->Left)+SNP1)) <<"firstder:" << (allele)abs(*((IndGenotype1->Right)+SNP1)) << ", mayor first: " << GetMajorAllele(SNP1);
//cout <<"lastizq:" << (allele)abs(*((IndGenotype1->Left)+SNP2)) <<"lastder:" << (allele)abs(*((IndGenotype1->Right)+SNP2)) << ", mayor first: " << GetMajorAllele(SNP2);
//	}
if (  
	((allele)abs(*((IndGenotype1->Left)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==GetMajorAllele(SNP2)) 
		  ) 
 ordered=true;
else
 if (  ((allele)abs(*((IndGenotype1->Right)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==GetMajorAllele(SNP2))  ) 
 ordered=true;

return ordered;
}



 /*____________________________________________________________ */

void genotype::Write (char* filename, long int FirstSNP=-1, unsigned int RegionSize=0)
 {


  ofstream OutputFile; 
  Genotype *IndGenotype=TheFirstGenotype;
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
  for (int i=0; i<Size;i++)
  {
    for (SNPPos i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
	 OutputFile << *((IndGenotype->Left)+i2) << ' ';
	}
	OutputFile << "\n";
	for (SNPPos i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
     OutputFile << *((IndGenotype->Right)+i2) << ' ';
	}
	OutputFile << "\n";
  IndGenotype=genotype::GetNext(IndGenotype);
  }
 OutputFile.close();
cout << "Information about haplotypes has been saved in file " << filename <<"\n";
 }



/*___________________________________________________________ */

void genotype::CountPairwiseHapsOnlyU (frequencies comb, NodePointer IndGenotype, 
							SNPPos FirstSNP, SNPPos LastSNP, 
							bool SolvedGenericParent=false) 
{

CheckRangeSNP(FirstSNP);
CheckRangeSNP(LastSNP);

if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))  
{ 
  comb[4]=comb[4]+1;// HH. NOTE: criteria for completing phase (like EM or LD) cannot be used for OnlyU


  if (IsAnOrderedPhase(IndGenotype, FirstSNP, LastSNP);
  
  if ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[5]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[6]++;
      
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[7]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[8]++;

}
else
{
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[0]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MajorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[1]++;
      
   if ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MajorAllele[LastSNP])) 
	   comb[2]++;

   if  ((abs(*((IndGenotype->Right)+FirstSNP))==MinorAllele[FirstSNP]) && (abs(*((IndGenotype->Right)+LastSNP))==MinorAllele[LastSNP]))
	   comb[3]++;
}
} // end only U

/*___________________________________________________________ */
void genotype::CountPairwiseHapsNotOnlyU (frequencies comb, genotype::Genotype* IndGenotype, 
							SNPPos FirstSNP, SNPPos LastSNP, 
							bool SolvedGenericParent=false) 
{
if (IsHeterozygous(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))   
 {
  comb[4]=comb[4]+1;// HH 

  if ((PhaseMode==ResolveFromTU 
	  && (!IsUnresolved (IndGenotype, FirstSNP) && !IsUnresolved (IndGenotype, LastSNP)) 
	     ||  SolvedGenericParent)
	  || (PhaseMode==dHap && !IsUnresolved (IndGenotype, FirstSNP))
	  || (PhaseMode==IsPhased) 
	  || (PhaseMode==KeepLeftRight) 
	  || (PhaseMode==ToOrder))
	if (IsAnOrderedPhase(IndGenotype, FirstSNP, LastSNP))
	  {
	  comb[5]++;
	  comb[8]++;
   }
  else
	{
  	  comb[6]++;
	  comb[7]++;

	}
} // end double heterozygous
 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[0]=comb[0]+2;// 1 1 

 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
  comb[1]=comb[1]+2;// 1 2 

 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))  
  comb[3]=comb[3]+2;// 2 2 

 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
  comb[2]=comb[2]+2;// 2 1

     
 
 if (IsHomozygous1(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))
 {
       comb[0]++; // 1 1 
       comb[1]++; // 1 2
 }
 if (IsHomozygous2(IndGenotype, FirstSNP) && IsHeterozygous(IndGenotype, LastSNP))         
 {
       comb[2]++; // 2 1 
       comb[3]++; // 2 2
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous1(IndGenotype, LastSNP))         
 {
     comb[0]++;// 1 1 
     comb[2]++; // 2 1
 }
 if (IsHeterozygous(IndGenotype, FirstSNP) && IsHomozygous2(IndGenotype, LastSNP))         
 {
     comb[1]++; // 1 2 
     comb[3]++; // 2 2
 }
}// end not OnlyU
/*_____________________________________________________________*/

void genotype::CountPairwiseHaps (frequencies comb, genotype::Genotype* IndGenotype, 
							SNPPos FirstSNP, SNPPos LastSNP, 
							bool OnlyU=false, 
							bool SolvedGenericParent=false) 
//count known haplotypes
{
// if phase has been trivially solved (phase solved using families by procedure ResolveU/T) 
// each marked positions means that
// two phase are unknown: the one with the last hetero and the one with the next hetero
// If phase was solved using dHap or other like ResolveTrivialPhase, a marked position
// means that phase has not been solved between that position and the next heterozygotic one
if (OnlyU==true)
 CountPairwiseHapsOnlyU(comb, IndGenotype, FirstSNP, LastSNP, SolvedGenericParent);
else // not OnlyU: dHAP and NR must be in this option
 CountPairwiseHapsNotOnlyU(comb, IndGenotype, FirstSNP, LastSNP, SolvedGenericParent);

};  



};  // End of Namespace

#endif

/* End of file: genotype.h */




