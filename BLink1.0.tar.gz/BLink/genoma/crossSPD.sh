rm crosscomp
echo Phase checker 
../PhaseResolverAndChecker cross50.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross100.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross150.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross200.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross250.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross300.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross350.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross400.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross450.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross500.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross550.txt crosscomp 50 100 1 0
../PhaseResolverAndChecker cross600.txt crosscomp 50 100 1 0
exit 0
