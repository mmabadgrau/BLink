  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

/*
//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"

#include "../commonc++/Fachade.h"
#include "../commonc++/Sampling.h"
*/
#include "FachadeGenoma.h"

/*
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "GenomaSample.h"
*/
/* This program select individuals for IndType and also ramdomly reduce the sample size or read from a file individuals to be selected. Inthis last case, the text file for selection must contain individual IDs (code 2)*/

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> " << " <output file> "  << "<number of individuals> "  << " <selection file> ";
        exit(-1);
        }
     char filename[128], filename2[128], selectionFile[256];
        
	 strcpy(filename, argv[1]);

	 if (argc>=3)
   	 strcpy(filename2, argv[2]);
	 else ChangeExtension(filename, filename2, "output");
		
	 IndPos size=0;
	 if (argc==4)
   	 size= atoi(argv[3]);

  	 if (argc==5)
{
if (size!=0)
{
cout <<"Error, number of individuals to bne selected must be 0 when selection is done using a file";
end();
}
   	 strcpy(selectionFile, argv[4]);
}
		 

GenomaSample *sample, *sample2;

sample=new GenomaSample (filename, everybody, NotChanged);

intList *samplingList;
samplingList=new intList();

int sampleSize=sample->GenotypeSample::GetSize();

if (size!=0)
{
Sampling* sampling;
sampling=new Sampling(sampleSize, false);
for (SNPPos i=0;i<size;i++)
{
 samplingList->insertElement(sampling->Pos[i]);
// cout <<"\nval:" << sampling->Pos[i];
}
}
else
{
PhenotypeSample::NodePointer p;
bool found;
int c;
stringList* selection=new stringList(selectionFile);

for (int i=0; i<selection->GetSize();i++)
{
found=false;
c=0;
 p=sample->PhenotypeSample::GetFirst();
//cout <<"\nlooking for ind code " << selection->GetElement(i) <<" in " << sample->PhenotypeSample::GetSize() << " inds";
while (p!=NULL && !found)
{
//cout <<"code:" << sample->PhenotypeSample::GetElement(p).getCode2();
if (sample->PhenotypeSample::GetElement(p).getCode2()==atoi(selection->GetElement(i).c_str()))
{
 found=true;
 samplingList->insertElement(c);
}
//if (found) cout <<"found";
c++;
p=sample->PhenotypeSample::GetNext(p);
}
};
};
//delete sampling;

sample2=sample->copyElementsWithPositionsIn(samplingList, true);
sample2->WriteResults(filename2); 

delete samplingList, sample, sample2;
cout <<"Selected individuals have been recorded in file " << filename2;

char filepos[128], filepos2[128]; 

ChangeExtension(filename2, filepos2, "pou");
ChangeExtension(filename, filepos, "pou");

FileCopy(filepos, filepos2);

ChangeExtension(filename2, filepos2, "rs");
ChangeExtension(filename, filepos, "rs");

FileCopy(filepos, filepos2);

return 0;


}










