/* File: TriosPairwiseMeasure.h */


#ifndef __TriosPairwiseMeasure_h__
#define __TriosPairwiseMeasure_h__

//#include <string.h>
//#include <cstdio>

#include "../commonc++/list.h"
#include "../commonc++/basic.h"
#include "../commonc++/Sampling.h"

#include "Positions.h"
#include "Tables2x2.h"
#include "MonolociMeasure.h"
#include "TrioSample.h"
#include "math.h"

//using namespace stats;

namespace BIOS {


/************************/
/* SNP'S TriosPairwiseMeasure DEFINITION */
/************************/


/**
        @memo TriosPairwiseMeasure for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class TriosPairwiseMeasure: PairwiseMeasure<TrioSample> {


private:

    /** @name Implementation of class TriosPairwiseMeasure
        @memo Private part.
    */

	bool IsPartiallySolved;


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

    double GetnxyKnown(bool IsMajor1, bool IsMajor2);


	void CheckFrequency (double f, bool fa);


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on TriosPairwiseMeasure 
        @memo Operations on a TriosPairwiseMeasure 
    */
	TriosPairwiseMeasure(SNPPos SNP1, SNPPos SNP2, TrioSample * samp, BayesType  Bay, IndCategory  i, bool IsPartiallySol, float distance);

	~TriosPairwiseMeasure()
	{
			zap(line);

	};

	double GetTotalUnKnown () {return PairwiseMeasure<TrioSample>::GetTotalUnKnown();}

	double GetTotalKnown(){return PairwiseMeasure<TrioSample>::GetTotalKnown();};

	double GetTotalKnown(double nAB, double nAb, double naB, double nab){return PairwiseMeasure<TrioSample>::GetTotalKnown(nAB, nAb, naB, nab);};

	double GetfAB(){return PairwiseMeasure<TrioSample>::GetfAB();};

	double GetfA(){return PairwiseMeasure<TrioSample>::GetfA();};

	double GetfB(){return PairwiseMeasure<TrioSample>::GetfB();};

	double GetnAB(){return PairwiseMeasure<TrioSample>::GetnAB();};

	double GetnAb(){return PairwiseMeasure<TrioSample>::GetnAb();};

	double GetnaB(){return PairwiseMeasure<TrioSample>::GetnaB();};
	
	double Getnab(){return PairwiseMeasure<TrioSample>::Getnab();};


};  // End of class TriosPairwiseMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


/*_________________________________________________________________*/

TriosPairwiseMeasure::TriosPairwiseMeasure(SNPPos S1, SNPPos S2, TrioSample * samp, BayesType Bay, IndCategory i, bool IsPartiallySol=false, float distance=0):PairwiseMeasure<TrioSample>(samp)
{

	SNP1=S1;
	SNP2=S2;
	//cout <<"\nSNP1: " << SNP1 << ", SNP2:" << SNP2;
	Bayes=Bay; 
	ic=i; 
	IsPartiallySolved=IsPartiallySol;
	missing=false;
//	IndPos TotalInds=sample->GenotypeSample::GetSize();

//	sample->PhenotypeSample::SetMarked(Marked, ic);


	
	if (sample->GetTotalMissing(SNP1, ic)!=0 || sample->GetTotalMissing(SNP2, ic)!=0)
	{
	missing=true;
//	cout <<" differences in missing totals";
//	exit(0);
	}

	nAB=sample->GetHap(SNP1, SNP2, ic, true, true, IsPartiallySolved);
	nAb=sample->GetHap(SNP1, SNP2, ic, true, false, IsPartiallySolved);
	naB=sample->GetHap(SNP1, SNP2, ic, false, true, IsPartiallySolved);
	nab=sample->GetHap(SNP1, SNP2, ic, false, false, IsPartiallySolved);

	double nA=nAB+nAb+nHH;
	double nB=nAB+naB+nHH;

	double MLfA=nA/(nA+naB+nab+nHH);
	double MLfB=nB/(nB+nAb+nab+nHH);

	nAB=AddBayesHap(nAB, Bayes, distance, 0, MLfA, MLfB);
	nAb=AddBayesHap(nAb, Bayes, distance, 1, MLfA, MLfB);
	naB=AddBayesHap(naB, Bayes, distance, 2, MLfA, MLfB);
	nab=AddBayesHap(nab, Bayes, distance, 3, MLfA, MLfB);

	nHH=sample->GetUnsolvedDoubleHeterozygous(SNP1, SNP2, ic, IsPartiallySolved);
	

	nA=nAB+nAb+nHH;
	nB=nAB+naB+nHH;

	SetCommon();



	if ((nA/totalhaplotypes)<0.5)
	{
		change (nAb, nab);
		change (nAB, naB);
		nA=nAB+nAb+nHH;
	}

	if ((nB/totalhaplotypes)<0.5)
	{
		change (nAB, nAb);
		change (naB, nab);
		nB=nAB+naB+nHH;

	}
}





};  // End of Namespace

#endif

/* End of file: TriosPairwiseMeasure.h */




