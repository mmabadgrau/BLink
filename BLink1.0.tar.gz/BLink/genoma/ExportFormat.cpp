  /**
    * @file ExportFormat.cpp
    * @brief Program to export formats in genotype files
	* @example ExportFormat PHASE chrom1.red chrom1PHASE.inp 
	* convert a file called chrom1.red in our format to PHASE format. The target file will be
    * called chrom1PHASE.inp. 
    */


#include <iostream>
#include <cassert>
#include <fstream>


#include "../commonc++/Fachade.h"
#include "FachadeGenoma.h"



/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {



     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " PHASE/SNPHAP/HTYPER/ML/HAP/PLEM/MLC/MLHAP/MLCHAP " << " <source file> " 
		<< "<Only for PHASE,MLHAP and MLCHAP 0: NotChanged haps, 1: Major First, 3: Random; for ML and MLC: 0: MajorByFrequencies, 1: MajorByQuantity (ex: 2 larger than 4 so 2 is the major allele>"	<< " <target file> "  << endl;
        exit(-1);
        }
     char filename[128], filename2[128], filepos[128], Algorithm[20];

		 
     strcpy (Algorithm,argv[1]);
     FormatType Alg=GetFormatType (Algorithm);
	 strcpy(filename, argv[2]);

     AlleleOrderType AlleleOrderMod=(AlleleOrderType) atoi(argv[3]);

	 if (argc==5) strcpy(filename2, argv[4]);
	 else 
	 {
		 char ext[20];
		 sprintf(ext, "output%s", Algorithm);
		 ChangeExtension (filename, filename2, ext);
	 }


GenomaSample *Sample;


Positions* Pos;

ChangeExtension (filename, filepos, "pou");

Pos=new Positions (filepos);

// filename must have only genotypes

 Sample=new GenomaSample (&filename[0], everybody, AlleleOrderMod); 

 switch (Alg)
{
case PHASE:  //  PHASE
case PHASERECOMB:
Sample->ExportForPHASE(Pos, filename2);
break;
case SNPHAP: // SNPHAP
Sample->ExportForSNPHAP (filename2);
break;
case HTYPER: // HTYPER
case PLEM: // PLEM
Sample->ExportForHTYPER (filename2);
break;
case ML: // machine learning
Sample->GenotypeSample::ExportForML (filename2);
break;
case MLC: // machine learning
Sample->ExportForML (filename2);
break;
case MLHAP: // machine learning
Sample->GenotypeSample::ExportForMLHAP (filename2);
break;
case MLCHAP: // machine learning
Sample->ExportForMLHAP (filename2);
break;
case HAP: // HAP
Sample->ExportForHAP (filename2);
break;
}

delete Sample, Pos;
return 0;

}



