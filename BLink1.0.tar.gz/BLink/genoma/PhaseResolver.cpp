  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Genotype.h"
#include "PhaseResolver.h"
//#include "Tables2x2.h"


//using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;


/*****************/
/*          MAIN          */
/*****************/

using namespace SNP;


int main(int argc, char*argv[]) {

	char filename2[128], filename3[128], Estimator[128], filepos[128];

     if(argc<12)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <#SNPs>" << " <#individuals>" << " <ExistPhenotype={0,1}>" 
			<< " <IndCategory (0:only parents/1: only children /2:all)>" 
			<< "<ReduceSample (1: all, 2: take 1 of each 2, 3: take 1 of each 3 ...)>" 
		<<"<PhaseMode>(" << PrintPhaseTypes() <<")"
			//<< "<PhaseMode>(0=IsPhased/1=KeepUnordered/2=ToOrder/3=ResolvFromTU/4=dHap)" 
			<< "<Phenotype (0=non-affected/1=all/2=affected)>" 
			<< "<Only untransmitted (0=false/1=true), applied only if ic=0 (parents)>" 
			<< "<Bayesian correction (0=MLE/1=UniformBayes/2=ReducedUiformBayes/3=EquilibriumBayes)>" 
			<< "<Output Way (0=false/1=true)>" 
			<< "<slide size>" << "<slide overlap>" << "<max distance>" << "<MAF>" << endl;
        exit(-1);
        }
     char* filename;
         if ((filename=new char[128])==NULL)
		 throw NoMemory();
	 strcpy(filename, argv[1]);
     unsigned int TotalSNPs=atoi(argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int IsPhenotype=atoi(argv[4]);
     IndCategory ic=(IndCategory) atoi(argv[5]);
     short unsigned int ReduceSample=atoi(argv[6]);

		unsigned int PhaseMode=atoi(argv[7]);

	 	unsigned int SlideSize=1;
		unsigned int SlideOverlap=0;
		unsigned int MaxDistance=0;
		float MAP;


	 unsigned short int affected=atoi(argv[8]);
		
 unsigned short int OnlyU=0;

 if (atoi(argv[9])==1)
 
	 OnlyU=atoi(argv[9]);

 unsigned short int Bayes=atoi(argv[10]);

  bool OutputWay=false;

 if (atoi(argv[11])==1) OutputWay=true;

cout <<"Configuration: IsPhenotype=" << IsPhenotype << ", IndCategory: " << (int)ic << ", Method for phasing:" 
<< PhaseMode
<<", affected:" << affected <<", OnlyUntransmitted:" << OnlyU <<", Bayes correction:" << Bayes
<<" OutputWay:" << OutputWay <<"\n" ;

bool ComputeHaplotypes=false;

GenomaSample *gs;
Positions* Pos;
ChangeExtension (filename, filepos, "pou");

Pos=new Positions (filepos);
gs=new GenomaSample (filename);

if ((PhasedSample = new genoma(filename, TotalSNPs, Size, ExistPhenotype, ic,  
	ComputeHaplotypes, (PhaseType)PhaseMode, MAF, affected, OnlyU, Bayes, OutputWay, ReduceSample))==NULL)
 throw NoMemory();

ChangeExtension(filename2, filename, "sal");
PhasedSample->WriteResults(filename2);


ChangeExtension(filename2, filename, "hap");
PhasedSample->WriteHaplotypes(filename2);


ChangeExtension(filename2, filename, "SNPs");
PhasedSample->PrintSNPPositions(filename2);


   return 0;

}





