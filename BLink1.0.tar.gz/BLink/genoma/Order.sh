if [ $# -ne 2 ]
then
echo This macro needs two arguments: month and year
exit 0
fi
./OrderHapmap.sh /home/mabad/hapmap$1$2/Yoruba/ YRI $1 $2
./OrderHapmap.sh /home/mabad/hapmap$1$2/US/ CEU $1 $2
./OrderHapmap.sh /home/mabad/hapmap$1$2/China/ CHB $1 $2
./OrderHapmap.sh /home/mabad/hapmap$1$2/Japan/ JPT $1 $2
