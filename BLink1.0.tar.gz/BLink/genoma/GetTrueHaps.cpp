  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "PhaseResolver.h"

using namespace UTILS;


/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) 
{

if(argc<2)
{
 cerr << "Error: you have to especify the following information:" << endl;
 cerr  << argv[0] << " <input file> "  << " <Exist Phenotype> ";  
 exit(-1);
}
char filename[128], filename2[128], filepos[128], filename3[128];
bool ExistPhenotype=false;
        
strcpy(filename, argv[1]);

if (argc>=3)  ExistPhenotype=atoi(argv[2]);

if (argc==4)  strcpy(filename2, argv[3]);
else ChangeExtension(filename, filename2, "truehap\0");
 
TrioSample *PhasedSample;
Positions* Pos;
cout << "file:" << filename;

ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, filename3, "true.gou");
cout << "file:" << filepos;
Pos=new Positions (filepos);
PhasedSample=new TrioSample (filename, everybody, LeftRight, false);
PhasedSample->RemoveByCategory(parent);
PhasedSample->PrintHaplotypes(filename2);
PhasedSample->WriteResults(filename3);
return 0;
}








