  /**
    * @file genoma.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "hapmap.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

void PhaseResolver(char *filename, unsigned int TotalSNPs, unsigned int Size, bool ExistPhenotype)
{

char * filename2;
//strcpy(filename2, filename);
individual *Sample, *PhasedSample;
// phase will be resolved only for offspring
IndCategory ic=(IndCategory)1; 
// phenotypes are setup as all children if !ExistPhenotype holds for the sample at filename
if ((Sample = new individual(filename, TotalSNPs, Size, ExistPhenotype, ic))==NULL)
 throw NoMemory();
//Sample=new individual(TotalSNPs);
if ((PhasedSample = new individual(*Sample, ic))==NULL)
 throw NoMemory();

PhasedSample->ResolvePhase((IndCategory)1); 
filename2=strtok(filename, ".");

strncat(filename2, ".sal\0", 4);//
cout << "\nOutput file: " << filename2 <<"\n";

PhasedSample->WriteGenotypes(filename2);

}
}

/* _____________________________________________________*/

void PhaseResolver(char *filename, unsigned int TotalSNPs, unsigned int Size, bool ExistPhenotype)
{

char * filename2;
//strcpy(filename2, filename);
individual *Sample, *PhasedSample;
// phase will be resolved only for offspring
IndCategory ic=(IndCategory)1; 
// phenotypes are setup as all children if !ExistPhenotype holds for the sample at filename
if ((Sample = new individual(filename, TotalSNPs, Size, ExistPhenotype, ic))==NULL)
 throw NoMemory();
//Sample=new individual(TotalSNPs);
if ((PhasedSample = new individual(*Sample, ic))==NULL)
 throw NoMemory();

PhasedSample->ResolvePhase((IndCategory)1); 
filename2=strtok(filename, ".");

strncat(filename2, ".sal\0", 4);//
cout << "\nOutput file: " << filename2 <<"\n";

PhasedSample->WriteGenotypes(filename2);

}
}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc!=5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <#SNPs>" << " <#individuals>" << " <ExistPhenotype={0,1}>" << endl;
        exit(-1);
        }
     char* filename;
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
	 strcpy(filename, argv[1]);
     unsigned int TotalSNPs=atoi(argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int IsPhenotype=atoi(argv[4]);
	 bool ExistPhenotype;

	 if (IsPhenotype==1)
		 ExistPhenotype=true;
	 else
		 ExistPhenotype=false;

     try{ 
         HapMap.   		 
Id=genotypes_chr1C(1,:);
Id=TransformId(Id);
SNP1=genotypes_chr1C(2:size(genotypes_chr1C,1),:);
CROM1=TransformPairs(SNP1);
CROM1=AddIDs(CROM1, Id);
CROM1=RemoveDuplicates(CROM1);
CROM1=AddDescription(CROM1,data);

         PhaseResolver(filename, TotalSNPs, TotalIndividuals, ExistPhenotype);
	}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
 

   return 0;

}





