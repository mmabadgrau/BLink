echo Daly blocks
../ChangeFormat e PHASE crohncomplete.txt crohnB1PHASE.inp c 1 95 387 0 8
../ChangeFormat e PHASE crohncomplete.txt crohnB2PHASE.inp c 1 95 387 9 5
../ChangeFormat e PHASE crohncomplete.txt crohnB3PHASE.inp c 1 95 387 15 8
../ChangeFormat e PHASE crohncomplete.txt crohnB4PHASE.inp c 1 95 387 23 11
../ChangeFormat e PHASE crohncomplete.txt crohnB5PHASE.inp c 1 95 387 34 4
../ChangeFormat e PHASE crohncomplete.txt crohnB6PHASE.inp c 1 95 387 38 5
../ChangeFormat e PHASE crohncomplete.txt crohnB7PHASE.inp c 1 95 387 43 27
../ChangeFormat e PHASE crohncomplete.txt crohnB8PHASE.inp c 1 95 387 71 5
../ChangeFormat e PHASE crohncomplete.txt crohnB9PHASE.inp c 1 95 387 77 6
../ChangeFormat e PHASE crohncomplete.txt crohnB10PHASE.inp c 1 95 387 83 7
../ChangeFormat e PHASE crohncomplete.txt crohnB11PHASE.inp c 1 95 387 90 5
echo internal blocks
../ChangeFormat e PHASE crohncomplete.txt crohnB1IPHASE.inp c 1 95 387 2 4
../ChangeFormat e PHASE crohncomplete.txt crohnB2IPHASE.inp c 1 95 387 10 3
../ChangeFormat e PHASE crohncomplete.txt crohnB3IPHASE.inp c 1 95 387 17 4
../ChangeFormat e PHASE crohncomplete.txt crohnB4IPHASE.inp c 1 95 387 27 3
../ChangeFormat e PHASE crohncomplete.txt crohnB5IPHASE.inp c 1 95 387 35 2
../ChangeFormat e PHASE crohncomplete.txt crohnB6IPHASE.inp c 1 95 387 39 3
../ChangeFormat e PHASE crohncomplete.txt crohnB7IPHASE.inp c 1 95 387 54 5
../ChangeFormat e PHASE crohncomplete.txt crohnB8IPHASE.inp c 1 95 387 72 3
../ChangeFormat e PHASE crohncomplete.txt crohnB9IPHASE.inp c 1 95 387 78 4
../ChangeFormat e PHASE crohncomplete.txt crohnB10IPHASE.inp c 1 95 387 85 3
../ChangeFormat e PHASE crohncomplete.txt crohnB11IPHASE.inp c 1 95 387 91 3
echo original
../ReduceSample crohncomplete.red crohnB1.txt 95 129 8 129 1 0 0
../ReduceSample crohncomplete.red crohnB2.txt 95 129 5 129 1 0 9
../ReduceSample crohncomplete.red crohnB3.txt 95 129 8 129 1 0 15
../ReduceSample crohncomplete.red crohnB4.txt 95 129 11 129 1 0 23
../ReduceSample crohncomplete.red crohnB5.txt 95 129 4 129 1 0 34
../ReduceSample crohncomplete.red crohnB6.txt 95 129 5 129 1 0 38
../ReduceSample crohncomplete.red crohnB7.txt 95 129 27 129 1 0 43
../ReduceSample crohncomplete.red crohnB8.txt 95 129 5 129 1 0 71
../ReduceSample crohncomplete.red crohnB9.txt 95 129 6 129 1 0 77
../ReduceSample crohncomplete.red crohnB10.txt 95 129 7 129 1 0 83
../ReduceSample crohncomplete.red crohnB11.txt 95 129 5 129 1 0 90
echo original internal
../ReduceSample crohncomplete.red crohnB1I.txt 95 129 4 129 1 0 2
../ReduceSample crohncomplete.red crohnB2I.txt 95 129 3 129 1 0 10
../ReduceSample crohncomplete.red crohnB3I.txt 95 129 4 129 1 0 17
../ReduceSample crohncomplete.red crohnB4I.txt 95 129 3 129 1 0 27
../ReduceSample crohncomplete.red crohnB5I.txt 95 129 2 129 1 0 35
../ReduceSample crohncomplete.red crohnB6I.txt 95 129 3 129 1 0 39
../ReduceSample crohncomplete.red crohnB7I.txt 95 129 5 129 1 0 54
../ReduceSample crohncomplete.red crohnB8I.txt 95 129 3 129 1 0 72
../ReduceSample crohncomplete.red crohnB9I.txt 95 129 4 129 1 0 78
../ReduceSample crohncomplete.red crohnB10I.txt 95 129 3 129 1 0 85
../ReduceSample crohncomplete.red crohnB11I.txt 95 129 3 129 1 0 91

