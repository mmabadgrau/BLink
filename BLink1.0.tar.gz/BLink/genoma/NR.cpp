  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "PhaseResolver.h"

using namespace UTILS;


/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) 
{

if(argc<2)
{
 cerr << "Error: you have to especify the following information:" << endl;
 cerr  << argv[0] << " <input file> "   << " <output file> ";  
 exit(-1);
}
char filename[128], filename2[128];
bool ExistPhenotype=false;
        
strcpy(filename, argv[1]);

if (argc==3)  strcpy(filename2, argv[2]);
else ChangeExtension(filename, filename2, "hap\0");
 
PhaseResolver *PhasedSample;
Positions* Pos;
cout << "file:" << filename;

PhasedSample=new PhaseResolver (filename, false, MajorFirst, MLE, true);
PhasedSample->ResolvePhase(NR);
exit(0);
PhasedSample->PrintHaplotypes(filename2);
return 0;
}








