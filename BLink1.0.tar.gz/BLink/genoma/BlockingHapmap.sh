dircode="/home/mabad/genoma"
if [ $# -ne 5 ]
then
echo This macro needs five arguments: the first with the directory where the data files reside, the second with the name of the population -CEU, YRI, CHB, JPT-, the third and four with the name of month and the year respectively and the fifth is 1 for European or Asian and 0 for other populations
exit 0
stop
fi
cd $1
echo Order chromosomes 
chromosome="X 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1" 
# chromosome="2"
for a in $chromosome
do
echo $a 
outputfile=$1"chromosome"$a"_$2$3$4.bl"
$dircode/HapBlocking $outputfile 500000 $5 
echo HapBlocking has been generated
done
