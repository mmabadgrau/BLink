/* File: PhasedGenotypeForUnrelated::.h */

//#include <string>

//#include "Exceptions.h"
//#include "genoma.h"
#include "gamma.h"

#include "basic.h"
#include "SNP.h"
#include "Tables2x2.h"
#include "phenotype.h"
#include "positions.h"
#include "genotype.h"

#ifndef __PhaseSolverForUnrelated_h__
#define __PhaseSolverForUnrelated_h__

namespace SNP {

	class PhasedGenotypeForUnrelated: public genotype, public Table2x2  
	{


protected:
    
	void ResolvePhase (PhaseType PhaseMode);
	unsigned int AssignPhasedHAP (unsigned int FirstHetero, unsigned int LastHetero);
	void GetLongHaps(unsigned int * LongHaps, Genotype* IndGenotypeRef, int ExtremePos[4], unsigned int heteroPos);
	unsigned int AssignPhaseNR (unsigned int FirstHetero, unsigned int LastHetero, Genotype* IndGenotypeRef);
	void ReconstructHaplotypes(unsigned short int *MajorPhase, Genotype *IndGenotype);
	bool CheckLongHaplotypes(Genotype* IndGenotype, int &MaxPos, int *ExtremePos, int heteroPos);
	void Expand(Genotype * IndGenotype, int *ExtremePos, unsigned int & heteroPos, ModeDir & Dir);

public:


/**
         @memo From file constructor
         @param destino: genotype where will be copy
         @param origen: file with genotypes to copy
         @doc
           Make a copy of genotype
           Time complexity in time O(1).
        */
		  PhasedGenotypeForUnrelated (char* filename, positions * pos, PhaseType PhaseMode, unsigned short int ReduceSample);

 
	};
/*____________________________________________________________ */

PhasedGenotypeForUnrelated::PhasedGenotypeForUnrelated (char* filename,  positions * pos,  PhaseType PhaseMode=KeepLeftRight, unsigned short int ReduceSample=1):
 genotype (filename, pos, PhaseMode, ReduceSample)
{

switch (PhaseMode)
{
case dHap: OrderLeftRight(); ResolvePhase(dHap); break; 
case NR: OrderLeftRight(); ResolvePhase(NR); break; 
default: break;
}
 };

/*__________________________________________________________*/

unsigned int PhasedGenotypeForUnrelated::AssignPhasedHAP (unsigned int FirstHetero, unsigned int LastHetero)
{
frequencies Freqs;
unsigned int MajorPhase=1;
double total=0.0, denominatornew, numeratornew, oddratio, probs[4];

double* Frequencies=&Freqs[0];


if (haps==NULL)
{
GetHap(FirstHetero, LastHetero, Freqs);// AB, Ab, aB, ab and HH, only the first 5 positions are used
Frequencies=&Freqs[0];
}
else Frequencies=haps[FirstHetero][LastHetero-FirstHetero-1];


for (int i=0;i<4;i++)
 total=total+Frequencies[i];

//initialization assuming HWE

try
{
probs[0]=GetTotalFreqAllele(FirstHetero,true)*GetTotalFreqAllele(LastHetero,true);
probs[1]=GetTotalFreqAllele(FirstHetero,true)*GetTotalFreqAllele(LastHetero,false);
probs[2]=GetTotalFreqAllele(FirstHetero,false)*GetTotalFreqAllele(LastHetero,true);
probs[3]=GetTotalFreqAllele(FirstHetero,false)*GetTotalFreqAllele(LastHetero,false);



if (!IsOne(sum(probs, 4))) throw NonProb();

EstimateMLE (Frequencies, &probs[0], total, 1000); 

if (!IsOne(sum(probs, 4))) throw NonProb();

}
catch (NonProb np) {
        np.PrintMessage();
      }

numeratornew=(probs[0]*probs[3]);
denominatornew=(probs[1]*probs[2]);//-numeratornew;//+H4;

oddratio=numeratornew-denominatornew;
  if (oddratio < (double)0) MajorPhase=2;

return MajorPhase;



} 
/*__________________________________________________________*/
void PhasedGenotypeForUnrelated::GetLongHaps(unsigned int * LongHaps, Genotype* IndGenotypeRef, int ExtremePos[4], unsigned int heteroPos)
{
// It counts the number of haplotypes in the sample by using the array LongHaps
// Each value in the array is a haplotype
Genotype *IndGenotype;


if  ((IndGenotype=TheFirstGenotype)==NULL)
 throw NullValue();

for (int i=0;i<Size;i++) // number of individuals
{
 if (IndGenotype!=IndGenotypeRef)
 if (IndGenotype->Selected)
	if ((HaveTheSameHomoPos(IndGenotypeRef, IndGenotype, ExtremePos[0], ExtremePos[1]))
		&& 
		(HaveTheSameHomoPos(IndGenotypeRef, IndGenotype, ExtremePos[2], ExtremePos[3])))
	 CountLongHaps(LongHaps, IndGenotype, ExtremePos, heteroPos, IndGenotypeRef);

 IndGenotype=genotype::GetNext(IndGenotype);
}

}
/*__________________________________________________________*/

bool PhasedGenotypeForUnrelated::CheckLongHaplotypes(Genotype* IndGenotypeRef, int &MaxPos, int ExtremePos[4], int heteroPos)
{
bool found=false;
unsigned int *LongHaps;

if  ((LongHaps=new unsigned int[2^heteroPos])==NULL)
 throw NullValue();

GetLongHaps(LongHaps, IndGenotypeRef, ExtremePos, heteroPos);

bool NonZeroPairs=GetNumberofNonZeroHaplotypePairs(LongHaps, heteroPos);
if (NonZeroPairs!=0) MaxPos=GetMostFrequentHaplotypePair(LongHaps, heteroPos);

if (NonZeroPairs<=1) found=true;


if ((ExtremePos[0]==0) && (ExtremePos[3]==(TotalSNPs-1))) found=true; // extremes reached

delete LongHaps;
return found;
}
/*__________________________________________________________*/
void PhasedGenotypeForUnrelated::Expand (Genotype * IndGenotypeRef, int* ExtremePos, unsigned int & heteroPos, ModeDir & Dir)
{
bool HomoLeftLeft=(ExtremePos[0]>0) && (IsHomozygous(IndGenotypeRef, ExtremePos[0]-1));
bool HomoLeftRight=(ExtremePos[1]<ExtremePos[2]) && (IsHomozygous(IndGenotypeRef, ExtremePos[1]+1));
bool HomoRightLeft=(ExtremePos[2]>ExtremePos[1]) && (IsHomozygous(IndGenotypeRef, ExtremePos[2]-1));
bool HomoRightRight=(ExtremePos[3]<(TotalSNPs-1)) && (IsHomozygous(IndGenotypeRef, ExtremePos[3]+1));
bool SomeHomo=HomoLeftLeft || HomoRightRight || HomoLeftRight || HomoRightLeft;
bool AllHomo=HomoLeftLeft && HomoRightRight && HomoLeftRight && HomoRightLeft;

// it advances throw the direction with more homo positions


if (!SomeHomo) heteroPos++;

if ((Dir==LeftRight) && (HomoLeftRight==true || (!SomeHomo && (ExtremePos[1]<ExtremePos[2]))))
	ExtremePos[1]++;
else if ((Dir==RightLeft) && (HomoRightLeft==true || (!SomeHomo && (ExtremePos[2]>ExtremePos[1]))))
	ExtremePos[2]--;
else if ((Dir==RightRight) && (HomoRightRight==true || (!SomeHomo && (ExtremePos[3]<(TotalSNPs-1)))))
	ExtremePos[3]++;
else if ((Dir==LeftLeft) && (HomoLeftLeft==true || (!SomeHomo && (ExtremePos[0]>0))))
	ExtremePos[0]--;

else if (HomoLeftRight==true) ExtremePos[1]++;
else if (HomoRightLeft==true) ExtremePos[2]--;
else if (HomoRightRight==true) ExtremePos[3]++;
else ExtremePos[0]--;

}
/*__________________________________________________________*/

unsigned int PhasedGenotypeForUnrelated::AssignPhaseNR (unsigned int FirstHetero, unsigned int LastHetero, Genotype* IndGenotypeRef)
{
unsigned int MajorPhase=1;
ModeDir Dir=LeftRight;

bool found;
unsigned int heteroPos=2;
int ExtremePos[4], MaxPos;
ExtremePos[0]=FirstHetero; 
ExtremePos[1]=FirstHetero; 
ExtremePos[2]=LastHetero; 
ExtremePos[3]=LastHetero; 

found=CheckLongHaplotypes (IndGenotypeRef, MaxPos, ExtremePos, heteroPos);

while (!found) 
{
Expand(IndGenotypeRef, ExtremePos, heteroPos, Dir);
found=CheckLongHaplotypes (IndGenotypeRef, MaxPos, ExtremePos, heteroPos);
}

unsigned int PosLeftInHaps=FirstHetero-ExtremePos[0];
unsigned int PosRightInHaps=(ExtremePos[1]-ExtremePos[0])+1+(LastHetero-ExtremePos[2]);

if ((IsAZero(PosLeftInHaps, MaxPos) && (IsAZero(PosRightInHaps, MaxPos)))
	 ||
	(!IsAZero(PosLeftInHaps, MaxPos) && (!IsAZero(PosRightInHaps, MaxPos))))
	MajorPhase=1;
 else MajorPhase=2;

return MajorPhase;
} 

/*__________________________________________________________*/
void PhasedGenotypeForUnrelated::ReconstructHaplotypes(unsigned short int *MajorPhase, Genotype *IndGenotype)
{
int LastResolved;
unsigned int SNP1;
unsigned short int Phase;
  LastResolved=FindFirstHeterozygous(IndGenotype);
  SNP1=LastResolved+1;
  while (SNP1<genotype::TotalSNPs)
  {
   if (IsHeterozygous(IndGenotype, SNP1))
   {
   Phase=MajorPhase[SNP1];
   if (Phase==0)
   {
	   throw UnsolvedPhase();
	   exit(0);
   }
   if (((Phase==1) && (!IsAnOrderedPhase (IndGenotype, LastResolved, SNP1)))
	   || 
	   ((Phase==2) && (IsAnOrderedPhase (IndGenotype, LastResolved, SNP1))))
	   ChangeAlleles (IndGenotype, SNP1);
	LastResolved=SNP1;
   } // end for each heterozygous SNP
   SNP1++;
  } // end for each SNP
}
/*____________________________________________________________ */

void PhasedGenotypeForUnrelated::ResolvePhase (PhaseType PhaseMode)
{
OrderSNPs();
unsigned short int *MajorPhase;
int LastResolved;
unsigned int SNP;
cout << "Reconstructing haplotypes...\n";

Genotype* IndGenotype=TheFirstGenotype;

if ((MajorPhase=new unsigned short int [genotype::TotalSNPs])==NULL)
  throw NoMemory();

IndGenotype=TheFirstGenotype;
for (int i=0;i<Size;i++)
 {
  LastResolved=FindFirstHeterozygous(IndGenotype);
  for (int j=0;j<=LastResolved;j++)
   MajorPhase[j]=0;
  SNP=LastResolved+1;
  
  while (SNP<genotype::TotalSNPs)
  {
   if (IsHeterozygous(IndGenotype, SNP)) 
   {
   if (PhaseMode==dHap)
     MajorPhase[SNP]=AssignPhasedHAP (LastResolved, SNP);
   if (PhaseMode==NR)
     MajorPhase[SNP]=AssignPhaseNR (LastResolved, SNP, IndGenotype);
   LastResolved=SNP;
   } //end for each hetero SNP
   else MajorPhase[SNP]=0;
   SNP++;
  } // for each SNP
  
 ReconstructHaplotypes(MajorPhase, IndGenotype);
 IndGenotype=genotype::GetNext(IndGenotype);
} // end for each individual

delete MajorPhase;
cout << "Reconstruction has finished\n";
  }
 /*____________________________________________________________ */
/*
//do not do anything
  void PhasedGenotypeForUnrelated::ResolvePhaseAll ()
{
unsigned int MajorPhase;

// Resolve phase for every pair of consecutive SNP
OrderSNPs();


Genotype* IndGenotype=TheFirstGenotype;

 for (int SNP=0;SNP<genotype::TotalSNPs;SNP++)
    MajorPhase=AssignPhase (SNP, SNP+1, IndGenotype, SNP-1);
  }


*/
/*____________________________________________________________ */



};  // Fin del Namespace

#endif

/* Fin Fichero: PhasedGenotypeForUnrelated.h */
