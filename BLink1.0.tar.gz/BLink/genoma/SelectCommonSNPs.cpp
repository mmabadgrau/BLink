  /**
    * @file genoma.cpp
    * @brief Program for selecting SNP Pos
    * a file with the positions to be chosen must be in the 
	* same directory and with the same name than the input file and extension .posS
    */



#include "FachadeGenoma.h"



//using namespace UTILS;



namespace BIOS {



/* _____________________________________________________*/

void ReduceSample(char *filename, char *targetFile,  char *fileSelectedPos, bool physicalPositions)
{
char filePos[256];
GenomaSample *gs=new GenomaSample (filename, everybody, NotChanged);

if (physicalPositions) 
ChangeExtension(filename, filePos, "pou");
else ChangeExtension(filename, filePos, "rs");

stringList* selectedPositions=new stringList(fileSelectedPos);



stringList* sourcePositions=new stringList(filePos);

  intList*selectedFilePositions=sourcePositions->copyPositionsWithElementsIn(selectedPositions);
//cout << *selectedFilePositions;
//cout <<"\n\n" << *sourcePhysicalPositions;
zap(sourcePositions);
zap(selectedPositions);
gs->SNPSampling (selectedFilePositions);
gs->WriteResults (targetFile);

zap(gs);

char fileResultPos[256], fileResultRSPos[256]; 

ChangeExtension(targetFile, fileResultPos, "pou");
ChangeExtension(targetFile, fileResultRSPos, "rs");

if (!physicalPositions) 
ChangeExtension(filename, filePos, "pou");

Positions * Pos=new Positions(filePos);
Pos->SNPSampling(selectedFilePositions);

//cout << *Pos;

Pos->PrintPositions (fileResultPos);

Pos->PrintRSNumbers (fileResultRSPos);

zap(Pos);
zap(selectedFilePositions);


}
}

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<5)
     {
        cerr << "Error in SelectCommonSNPs: you have to specify the following information:" << endl;
        cerr  << argv[0] << " <current file> "   << " <target file> " << " <file with physical positions or rs numbers to be selected> " << "<type: 1 for physical positions (default), 0 for rs numbers>" << endl;
        exit(-1);
        }
     char filename[128], filename2[128], filename3[128];

	 strcpy(filename, argv[1]);
      strcpy(filename2, argv[2]);
 strcpy(filename3, argv[3]);
bool physicalPosition=true;

if (argc==5) physicalPosition=atoi(argv[4]);
    	
ReduceSample(filename, filename2, filename3, physicalPosition);

	   return 0;

}





