echo Use haploview with all chromosomes at hapmap and then convert the output blocks in order to be processed by Best
chromosome="2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 X"
chromosome="22"
for a in $chromosome
do
# cd /home/staff/sebas/hapmap
inputfile=("chromosome" $a "june2004.ped")
directory=("chromosome"$a"june2004")
mkdir directory
# java -d64 -Xmx8192m -Xms1024m -jar Haploview.jar -n -p $inputfile
cd $directory
outputfile=("chromosome"$a"june2004.ped.GABRIELblocks")
../ConvertForHT.out $outputfile $a
tar -cf * ("chromosome"$a".tar")
rm b*
echo -n "Chromosome "
echo -n $a
echo " has been processed"
done
