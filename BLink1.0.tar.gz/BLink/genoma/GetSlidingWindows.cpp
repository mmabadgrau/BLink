  /**
    * @file HapBlocking.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method)
    *
    */

//#include <cstdlib>//

#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"

using namespace UTILS;

namespace BIOS 
	 {
char* filename, *filename2;
IndCategory ic=parent;
BayesType BayesMode=MLE;
bool IsPartiallySolved=false;
double MAF=0.0;
float Width=0.0;
IndPos size=100;
SNPPos SlideSize=1700000;
SNPPos SlideOverlap=1600000;
SNPPos TotalSNPs; 

/*_____________________________________________________________________________________________________________*/

void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "\nYou have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  <<"<max width>"
			<< " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium/4:Bayes distance Uniform/5:Bayes distance symmetrical>" 
		<< " ic (father=0, mother=1, offspring=2, everybody=3, parent=4)" 
		<< "< Pairwise phase (0: standard phase/1: with partially solved)>" 
		<< "<slide size>" << "<slide overlap>" <<"<MAF>" << endl;
        exit(-1);
        }

        
	 if ((filename=new char[128])==NULL)
		 throw NoMemory();

	 strcpy(filename, argv[1]);

if (argc>=3) Width=atof(argv[2]);

if (argc>=4) BayesMode=(BayesType) atoi(argv[3]);

if (argc>=5) ic=(IndCategory) atoi(argv[4]);

if (argc>=6) IsPartiallySolved=atoi(argv[5]);

if (argc>=7) SlideSize=atoi(argv[6]);

if (argc>=8) SlideOverlap=atoi(argv[7]);

if (argc>=9) MAF=atof(argv[8]);


}

}
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
  
		 
double upperbound, lowerbound, MLDPrime;
TrioSample *Sample;
Positions * Pos;
Table2x2 T2x2;
Pair pair;
char filepos[128], filesw[128], ext[128];

sprintf(ext, "MAF%1.2lf.sw", MAF);
ChangeExtension (filename, filepos, "pou");
ChangeExtension (filename, filesw, ext);
Pos=new Positions (filepos);
Sample=new TrioSample (filename);
TotalSNPs=Sample->GetTotalSNPs();
if (Width==0.0 || Width>Pos->GetDistance(0, TotalSNPs-1)) 
 Width=Pos->GetDistance(0, TotalSNPs-1);
double fA, fB, fAB, DPrime, r2;
PairwiseMeasure<TrioSample> *PM;
SNPPos SlideGap=SlideSize-SlideOverlap;
SNPPos LastSNPInWindow, SNP=0, LastComparison, comparisons;
double pos, alpha=90, distance;
ofstream OutputFile; 

OpenOutput(filesw, &OutputFile);
char line[100];

OutputFile << "Initial SNP" << "\t" <<  "Initial Position" << "\t" <<  "number of comparisons" << "\t" << "DPrime\tr2\tDistDPrime\tlowerDPrime\tupperDPrime" <<"\n";
MonolociMeasure<TrioSample> MM = MonolociMeasure<TrioSample>(Sample, (BayesType) 0, ic);
Positions::NodePointer i=Pos->GetFirst(), j;
try {
bool EndReached=false;
printf("width:%7.2f\n", Width);
do
{
if (Pos->IsEndReached(i, SlideSize)) 
{
EndReached=true;
LastSNPInWindow=TotalSNPs-1;
}
else
{
LastSNPInWindow=SNP+Pos->GetTotalSNPs(i, SlideSize);
pos=Pos->GetElement(i).pos;
}
j=i;
comparisons=0;
if (SNP%1000==0)
cout << SNP+1 << "\n";

DPrime=0.0, lowerbound=0, upperbound=0, r2=0;
for (SNPPos SNP2=SNP; SNP2<=LastSNPInWindow;SNP2++) // until the end of the window
{
 if (Sample->GetTotalMissing(SNP2, ic)==0) 
 if (MM.GetTotalFreqAllele(SNP2, false)>MAF) 
 {  	
   LastComparison=SNP2+Pos->GetTotalSNPs(j, Width);
   if (LastSNPInWindow<LastComparison)LastComparison=LastSNPInWindow; 
   for (SNPPos SNP3=SNP2+1; SNP3<LastComparison;SNP3++) // until max distance allowed
   if (Sample->GetTotalMissing(SNP3, ic)==0) 
   if (MM.GetTotalFreqAllele(SNP3, false)>MAF) 
   {
//	  	cout <<"\nsnps:" << SNP2 << " and " << SNP3;
   distance=Pos->GetDistance(SNP2, SNP3);
	PM = new TriosPairwiseMeasure(SNP2, SNP3, Sample, BayesMode, ic, IsPartiallySolved, distance);
	
	if (PM->GetfA()<1 && PM->GetfB()<1) // to avoid different missing counters between both SNPs
	{
	fA=PM->GetfA();
    fB=PM->GetfB();
    fAB=PM->GetfAB();
   // MLDPrime=MLDPrime+PM->GetMaxDPrime();
  MLDPrime=MLDPrime+T2x2.GetMaxDPrime(fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());

	pair=T2x2.GetQuantilesDPrime(50-alpha/2, 50+alpha/2, fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
	lowerbound=lowerbound+pair.First;
	upperbound=upperbound+pair.Second;


//	if (T2x2.GetDPrime(fAB,fA,fB)>=0)
	{
	 DPrime=DPrime+T2x2.GetDPrime(fAB,fA,fB);
	 r2=r2+T2x2.GetR2(fAB,fA,fB);
	 comparisons++;
	}
	}
	
   } // end for each SNP3 with freq>MAF
 } // end if freq>MAF
j=Pos->GetNext(j);
} // end for each SNP2
OutputFile << SNP+1 << "\t" <<  pos	 << "\t" << comparisons << "\t";
if (comparisons>0)
sprintf(line, "%1.2lf\t%1.2lf\t%1.2lf\t%1.2lf\t%1.2lf\n", DPrime/comparisons, r2/comparisons, MLDPrime/comparisons, lowerbound/comparisons, upperbound/comparisons);
else sprintf(line, "-\n");
OutputFile << line;
SNP=SNP+Pos->GetTotalSNPs(i, SlideGap);
i=Pos->MoveToPos(i, SlideGap);
}
while ((SNP<(TotalSNPs-1)) && (EndReached==false));
}
catch (OutOfRange ora) {ora.PrintMessage(SNP);}	 
catch (NonSNP ns) {ns.PrintMessage(SNP);}
catch (NullValue null) {null.PrintMessage();}
OutputFile.close();
 cout << "\nInformation about sliding windows has been saved in file " << filesw <<"\n";
return 0;
};








