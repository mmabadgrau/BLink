

#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "SNP.h"
#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "TriosPairwiseMeasure.h"
#include "MonolociMeasure.h"
#include "TriosMonolociMeasure.h"


char line[1024];
/*______________________________________________________________*/
 

char* PrintHeading()
{
char* p=line;
strcpy(line, "First SNP,Position,Second SNP,Position,n(A),n(a),n(B),n(b),n(HH) (individuals),n(AB),n(Ab),n(aB),n(ab),f(A),f(B),f(AB),D,max D,DPrime,DPrimeLowerBound,DPrimeUpperBound,R2,Yules Q\n");
return p;
}

/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

char line[100];
if(argc<5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " << " <MAF> "  << " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium/4:Bayes distance Uniform/5:Bayes distance symmetrical>" 
		<< " ic (father=0, mother=1, offspring=2, everybody=3, parent=4)" << "< Pairwise phase (0: standard phase/1: with partially solved)>" <<"<alpha ci>" <<"<invariant sites (0: no (default), 1: yes)>"<< endl;
        exit(-1);
        }
  float alpha=90;
  char filename[256], filepos[256], filename2[256], filenameReduced[256], ext[128];;
  strcpy (filename, argv[1]);
  float MAF=atof(argv[2]);
  BayesType BayesMode=(BayesType) atoi(argv[3]);
  IndCategory ic= (IndCategory) atoi(argv[4]);
  bool IsPartiallySolved=atoi(argv[5]);
  if (argc>=7) alpha=atof(argv[6]);
  bool invariant=false;
if (argc>=8) invariant=atoi(argv[7]);
  SNPPos size=1000;
  unsigned int nHH;
  double upperbound, lowerbound;

  
  
if (MAF==0.0 && invariant)
strcpy(ext, "invariant\0");
else strcpy(ext, "\0");



if (BayesMode==MLE)
sprintf(ext, "%sMAF%d-MLE.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceUniform)
sprintf(ext, "%sMAF%d-BDistanceUniform.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceSymmetrical)
sprintf(ext, "%sMAF%d-BDistanceSymmetrical.pm", ext, (int)(MAF*100));
  
  
ChangeExtension (filename, filename2, ext);

try
{
  OutputFile.open (filename2, ofstream::out);
  if (!OutputFile) throw ErrorFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
TrioSample *ts;
//GenomaSample *gs;
Positions* Pos;
Table2x2 T2x2;
ChangeExtension (filename, filepos, "pou");
float distance;
struct Pair pair;
Pos=new Positions (filepos);
ts=new TrioSample (filename);

OutputFile << PrintHeading();
double fAB, fA, fB, DPrime, MaxDPrime;
SNPPos SNP2, TotalSNPs=ts->GetTotalSNPs(), total;

TriosPairwiseMeasure *PM;
TriosMonolociMeasure MM = TriosMonolociMeasure(ts, (BayesType)0, ic);

for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 if (ts->GetTotalMissing(SNP, ic)==0) 
  if (invariant || MM.GetTotalFreqAllele(SNP, false)>MAF) 
  {
 if (SNP%100==0)
 cout <<"\nsnp:" << SNP+1;
 for (SNPPos SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
  if (ts->GetTotalMissing(SNP2, ic)==0) 
   if (invariant || MM.GetTotalFreqAllele(SNP2, false)>MAF) 
 {
distance=Pos->GetDistance(SNP, SNP2);
if (distance<500000)
{
 PM = new TriosPairwiseMeasure(SNP, SNP2, ts, BayesMode, ic, IsPartiallySolved, distance);
 fA=PM->GetfA();
 fB=PM->GetfB();
 fAB=PM->GetfAB();
 DPrime=T2x2.GetDPrime(fAB, fA, fB);
 OutputFile 
	 << SNP+1 << ", " << Pos->PrintPosition(SNP)  << ", ";
 OutputFile
	 << SNP2+1 << ", " << Pos->PrintPosition(SNP2)  << ", " 
   	 << ts->GetTotalAllele(SNP, true, ic) << ", " 
   	 << ts->GetTotalAllele(SNP, false, ic) << ", " 
   	 << ts->GetTotalAllele(SNP2, true, ic) << ", " 
  	 << ts->GetTotalAllele(SNP2, false,  ic) << ", " 
	 << ts->GetUnsolvedDoubleHeterozygous(SNP, SNP2, ic, IsPartiallySolved) << ", "
	 << PM->GetnAB() <<", "
 	 << PM->GetnAb() <<", "
	 << PM->GetnaB() <<", "
	 << PM->Getnab() <<", "
	 << fA <<", "
 	 << fB <<", "
	 << fAB <<", "
	 << T2x2.GetD(fAB, fA, fB) <<", "
	 << T2x2.GetMaxD(fAB, fA, fB) <<", ";
	sprintf(line, "%1.2f, ", DPrime);
	OutputFile << line;
	pair=T2x2.GetQuantilesDPrime(50-alpha/2, 50+alpha/2, fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown(), BayesMode);
	lowerbound=pair.First;
	upperbound=pair.Second;
	sprintf(line, "%1.2lf, %1.2lf, ", lowerbound, upperbound);
	OutputFile << line; 
 sprintf(line, "%1.2f, %1.2f, %1.2f\n", T2x2.GetR2(fAB, fA, fB), T2x2.GetQ(fAB, fA, fB), T2x2.GetRho(fAB, fA, fB));
 OutputFile << line;
} //if in distance
  } // end for each SNP2 a real SNP
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise measures has been saved in file " << filename2 <<"\n";
 
 OutputFile.close();

   return 0;

};

