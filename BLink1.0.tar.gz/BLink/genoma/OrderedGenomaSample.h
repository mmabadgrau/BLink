
/* File: GenomaSample.h */

//#include <string>
//#include <math.h>
//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include <cstdio>//
//#include <cmath>//



#ifndef __GenomaSample_h__
#define __GenomaSample_h__

#include "Exceptions.h"

#include "basic.h"
#include "SNP.h"
#include "phenotype.h"
#include "positions.h"
#include "genotype.h"
#include "CoupleGenotype.h"
#include "OrderedGenotypeSample.h"
#include "PhenotypeSample.h"
      
        



namespace BIOS {


         class GenomaSample: public GenotypeSample, public PhenotypeSample
 {
	 
       //  public:


    /** @name Implementation of class GenomaSample
        @memo Private part.
    */




  private:

 
  unsigned long int GetTotalHomozygousType (SNPPos SNP, unsigned short int typ, IndCategory ic);



/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:


    /**
	 @memo Destructor
	 @doc
           Deallocate memory used by individual.
           Time complexity O(1).

      */
	  ~GenomaSample ();


	   /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
	  GenomaSample(positions* pos);

  /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

	
	  GenomaSample(GenomaSample& source, unsigned int *Sampling);

 

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		GenomaSample(char* filename, positions* pos, unsigned short int ReduceSample, bool CompleteMissing, AlleleOrderType AlleleOrderMode);

		void CheckInconsistenciesFromParents ();

		void CompleteMissingFromParents ();

		void WriteResults (char* filename, bool PrintPhenotypes=true);

		unsigned long int GetTotalType (unsigned long int SNP, IndCategory ic, GenotypeType type);

		unsigned long int GetTotalHomozygous1 (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalHomozygous2 (unsigned long int SNP, IndCategory ic);

		unsigned long int GetTotalHeterozygous (unsigned long int SNP, IndCategory ic);

		unsigned long int GenomaSample::GetTotalMissing (unsigned long int SNP, IndCategory ic);

		double GetTotalAllele (SNPPos SNP, bool IsMajor, IndCategory ic, unsigned short int Bayes);

		double GetTotalFreqAllele (SNPPos SNP, bool IsMajor, IndCategory ic, unsigned short int Bayes);

		void ComputeHaps (hprobs probs, SNPPos SNP1, SNPPos SNP2, LDType mode, bool Semi, unsigned short int Bayes);


};  // End of class GenomaSample




/*____________________________________________________________ */

GenomaSample::GenomaSample(positions* pos): 
PhenotypeSample(), GenotypeSample(pos)
//, positions (TotalSNPs)
{

};

/*____________________________________________________________ */
// copy individuals at positions in Samplong (they can be repeated)
GenomaSample::GenomaSample(GenomaSample& source, unsigned int *Sampling=NULL)
: 
PhenotypeSample(source), 
GenotypeSample(source, Sampling)
{
};
/*____________________________________________________________ */

GenomaSample::GenomaSample(char* filename, positions* pos, 
			    unsigned short int ReduceSample=1, bool CompleteMissing=false, AlleleOrderType AlleleOrderMode=MajorFirst): 
				PhenotypeSample(filename, pos->GetTotalSNPs(), ReduceSample), 
				GenotypeSample(filename, pos, ReduceSample, true)
{
// cout <<"gentot:" << genotype::TotalSNPs;



CheckInconsistenciesFromParents();


if (CompleteMissing) 
{
 CompleteMissingFromParents();

// after completing missing genotypes, major and minor will be computed again

cout << "Computing major and minor alleles from file " << filename << " ...\n";


delete MajorAllele;
delete MinorAllele;

MajorAllele=NULL;
MinorAllele=NULL;



try {
 SetMajorAllele ();
 SetMinorAllele (); 
}
  catch (NoMemory no) {
  no.PrintMessage();
  }


 cout << "Computation of major and minor alleles has finished\n";

}

switch (AlleleOrderMode)
{
case NotChanged: break;
case MajorFirst: OrderMajorFirst(); break;
};

};
/*____________________________________________________________ */

void GenomaSample::WriteResults (char* filename, bool PrintPhenotypes=true)
 {
  ofstream: OutputFile; 
  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  OrderedGenotypeSample::NodePointer IndGenotype=OrderedGenotypeSample::GetFirst();
  positions::NodePointer PPosition;
  Genotype* genotype;

  SNPPos TotalSNPs=GetTotalSNPs();
  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

while (IndPhenotype!=NULL && IndGenotype!=NULL)
  {
	if (PhenotypeSample::GetElement(IndPhenotype).IsSelected()) 	  
  {
   if (PrintPhenotypes)	PhenotypeSample::GetElement(IndPhenotype).PrintPhenotype();

    PPosition=pos->GetFirst();
    genotype=new Genotype(OrderedGenotypeSample::GetElement(IndGenotype));
    for (SNPPos i2=0; i2<TotalSNPs;i2++)
	{
	 if (pos->GetElement(PPosition).unrepeated==true) genotype->PrintGenotype(i2);
    
     PPosition=pos->GetNext(PPosition);
	}
      
	OutputFile << "\n";
	}
    IndGenotype=OrderedGenotypeSample::GetNext(IndGenotype);
    IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
  OutputFile.close();

cout << "\nInformation about phased genotype has been saved in file " << filename <<"\n";
 }


/*__________________________________________________________*/

unsigned long int GenomaSample::GetTotalType (unsigned long int SNP, IndCategory ic, GenotypeType type)
{
OrderedGenotypeSample::NodePointer IndGenotype=OrderedGenotypeSample::GetFirst();
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
Phenotype phenotype;
Genotype* genotype;

unsigned long int Total=0;
try
{
while (IndGenotype!=NULL)
{
	
if (IndPhenotype==NULL) 
    throw NullValue();

 phenotype=PhenotypeSample::GetElement(IndPhenotype);
 genotype=new Genotype(OrderedGenotypeSample::GetElement(IndGenotype));
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
 switch (type)
 {
 case missing: if (genotype->IsAMissingSNP (SNP)) Total++; break;
 case homozygous1: if (genotype->IsHomozygous1(SNP, MajorAllele)) Total++; break;
 case homozygous2: if (genotype->IsHomozygous2(SNP, MajorAllele)) Total++; break;
 case heterozygous: if (genotype->IsHeterozygous(SNP, MajorAllele)) Total++; break;
 }
 IndGenotype=OrderedGenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}

if (IndPhenotype!=NULL) 
    throw NullValue();
}

catch (NullValue nv) {
        nv.PrintMessage();
      }

return Total;
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHomozygous1 (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, homozygous1));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHomozygous2 (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, homozygous2));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalHeterozygous (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, heterozygous));
}
/*___________________________________________________________*/

unsigned long int GenomaSample::GetTotalMissing (unsigned long int SNP, IndCategory ic)
{
	return (GetTotalType (SNP, ic, missing));
}
/*__________________________________________________________*/

double GenomaSample::GetTotalAllele (unsigned long int SNP, bool IsMajor, IndCategory ic, unsigned short int Bayes=false)
{
OrderedGenotypeSample::NodePointer IndGenotype=OrderedGenotypeSample::GetFirst();
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
Phenotype phenotype;
Genotype* genotype;

CheckRangeSNP(SNP);

double Total=0.0;
try
{
while (IndGenotype!=NULL)
{
	
if (IndPhenotype==NULL) 
    throw NullValue();

 phenotype=PhenotypeSample::GetElement(IndPhenotype);
 genotype=new Genotype (OrderedGenotypeSample::GetElement(IndGenotype));
 if ((ic==offspring && IsAChild (IndPhenotype)) || (ic==parent && IsAParent (IndPhenotype)) 
	 || (ic==everybody) || (ic==father && IsAFather(IndPhenotype)) || (ic==mother && IsAMother(IndPhenotype)))
 switch (IsMajor)
 {
 case true: if (genotype->IsHomozygous1 (SNP, MajorAllele)) Total=Total+2; 
			if (genotype->IsHeterozygous(SNP, MajorAllele)) Total++; break;
 case false:if (genotype->IsHomozygous2(SNP, MajorAllele)) Total=Total+2;
			if (genotype->IsHeterozygous(SNP, MajorAllele)) Total++; break;
 }
 IndGenotype=OrderedGenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
}

if (IndPhenotype!=NULL) 
    throw NullValue();
}

catch (NullValue nv) {
        nv.PrintMessage();
      }



switch (Bayes)
{
case 0: break;
case 1: Total=Total+2; break;
case 2: Total=Total+0.5; break;
case 3: break;
}

return Total;
}
/*__________________________________________________________*/

double GenomaSample::GetTotalFreqAllele (unsigned long int SNP, bool IsMajor, IndCategory ic, unsigned short int Bayes=false)
{
return GetTotalAllele(SNP, IsMajor, ic, Bayes)/(double)(GetTotalAllele(SNP, IsMajor, ic, Bayes)+GetTotalAllele(SNP, !IsMajor, ic, Bayes));
}


/*____________________________________________________________ */

void GenomaSample::CheckInconsistenciesFromParents ()
{
SNPPos TotalSNPs=GetTotalSNPs();	
cout << "Checking inconsistencies from parents...\n";
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
OrderedGenotypeSample::NodePointer IndGenotype=OrderedGenotypeSample::GetFirst();
CoupleGenotype* couplegenotype;
Genotype * childgenotype, *FatherGenotype, *MotherGenotype;
Phenotype::PhenotypeS childphenotypeS;
IndPos Pos=0;
while (IndPhenotype!=NULL)
{
 if (IsAChild (IndPhenotype))
 {
  FatherGenotype=new Genotype(OrderedGenotypeSample::GetElement(OrderedGenotypeSample::GetNode(PhenotypeSample::GetPos(GetFather(IndPhenotype)))));
  MotherGenotype=new Genotype(OrderedGenotypeSample::GetElement(OrderedGenotypeSample::GetNode(PhenotypeSample::GetPos(GetMother(IndPhenotype)))));
  couplegenotype=new CoupleGenotype(*FatherGenotype, *MotherGenotype);
  childgenotype=new Genotype(OrderedGenotypeSample::GetElement(IndGenotype));
  childphenotypeS=PhenotypeSample::GetElement(IndPhenotype).GetPhenotype();
  for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
   if (((couplegenotype->IsHomozygous1Heterozygous (SNP, MajorAllele)) && (childgenotype->IsHomozygous2(SNP, MajorAllele))) ||
	  ((couplegenotype->IsHomozygous2Heterozygous(SNP, MajorAllele)) && (childgenotype->IsHomozygous1(SNP, MajorAllele))) ||
	  ((couplegenotype->IsHomozygous1Homozygous1 (SNP, MajorAllele)) 
	      && ((childgenotype->IsHomozygous2(SNP, MajorAllele)) || (childgenotype->IsHeterozygous(SNP, MajorAllele))  )) ||
	  ((couplegenotype->IsHomozygous2Homozygous2 (SNP, MajorAllele)) 
	      && ((childgenotype->IsHomozygous1(SNP, MajorAllele)) || (childgenotype->IsHeterozygous(SNP, MajorAllele))  )) ||
	  ((couplegenotype->IsHomozygous1Homozygous2 (SNP, MajorAllele)) 
	      && ((childgenotype->IsHomozygous1(SNP, MajorAllele)) || (childgenotype->IsHomozygous2(SNP, MajorAllele))  ))		  
		  )	  
   	
		  cout <<"\nInconsistence at ind " << Pos+1 << "(code " << childphenotypeS.Code <<", family code " << childphenotypeS.Pedigree << ")" << " pos " << SNP+1 << " val file: " 
            << childgenotype->GetLeftAllele(SNP) <<childgenotype->GetRightAllele(SNP) << " with father "
			<< FatherGenotype->GetLeftAllele(SNP) <<FatherGenotype->GetRightAllele(SNP) << " and mother " 
			<< MotherGenotype->GetLeftAllele(SNP) <<MotherGenotype->GetRightAllele(SNP) ; 

}
 IndGenotype=OrderedGenotypeSample::GetNext(IndGenotype);
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 Pos++;
}
cout <<"Inconsistencies have been checked from parents\n";
}
/*____________________________________________________________ */

void GenomaSample::CompleteMissingFromParents ()
{
SNPPos TotalSNPs=GetTotalSNPs();	
cout << "\nCompleting missing from parents...";
PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst();
OrderedGenotypeSample::NodePointer IndGenotype=OrderedGenotypeSample::GetFirst();

Genotype *FatherGenotype, *MotherGenotype, *ChildGenotype;
CoupleGenotype* couplegenotype;

while (IndPhenotype!=NULL)
{
 if (IsAChild (IndPhenotype))
 {
  FatherGenotype=new Genotype(OrderedGenotypeSample::GetElement(OrderedGenotypeSample::GetNode(PhenotypeSample::GetPos(GetFather(IndPhenotype)))));
  MotherGenotype=new Genotype(OrderedGenotypeSample::GetElement(OrderedGenotypeSample::GetNode(PhenotypeSample::GetPos(GetMother(IndPhenotype)))));
  couplegenotype=new CoupleGenotype(*FatherGenotype, *MotherGenotype);
  ChildGenotype=new Genotype(OrderedGenotypeSample::GetElement(IndGenotype));
  for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
   if (ChildGenotype->IsAMissingSNP(SNP))
  {
   if (couplegenotype->IsHomozygous1Homozygous1 (SNP, MajorAllele)) 
	   ChildGenotype->SetAlleles(MajorAllele[SNP], MajorAllele[SNP], SNP);

    if (couplegenotype->IsHomozygous2Homozygous2 (SNP, MajorAllele)) 
	   ChildGenotype->SetAlleles(MinorAllele[SNP], MinorAllele[SNP], SNP);

    if (couplegenotype->IsHomozygous1Homozygous2 (SNP, MinorAllele)) 
       ChildGenotype->SetAlleles(MajorAllele[SNP], MinorAllele[SNP], SNP);

  } // end for each missing SNP
 } // end for each child
 IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
 IndGenotype=OrderedGenotypeSample::GetNext(IndGenotype);

} // end for each individual
cout <<"\nMissing data have been completed from parents\n";
}



/*____________________________________________________________ */

GenomaSample::~GenomaSample ()
{
}

};  // Fin del Namespace

#endif

/* Fin Fichero: GenomaSample.h */
