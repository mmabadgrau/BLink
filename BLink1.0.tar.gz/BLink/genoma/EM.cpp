  /**
    * @file PhaseChecker.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "PhaseResolver.h"
#include "genoma.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;


//using namespace std;
//using namespace string;

namespace SNP
{

void ResolveEM2(char* filename, unsigned long int TotalSNPs, unsigned int Size, IndCategory ic)
{
 genoma *Sample;

	  Sample = new genoma(filename, TotalSNPs, Size, (bool)1, ic);
	  Sample->ResolvePhaseAll(ic);

}

}


/*****************/
/*          MAIN          */
/*****************/

using namespace SNP;


int main(int argc, char*argv[]) {

     if(argc!=5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> "  << " <#individuals>" << " <#SNPs>" << " <IndCategory>" << endl;
        exit(-1);
        }
     char* filename;
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filename, argv[1]);

		 char* filenameacc;

     unsigned int TotalIndividuals=atoi(argv[2]);
     unsigned int TotalSNPs=atoi(argv[3]);
     IndCategory ic=(IndCategory) atoi(argv[4]);


	 try{ 
		 ResolveEM2(filename, TotalSNPs, TotalIndividuals, ic);
	  	
		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (NullValue nv) {
		 nv.PrintMessage();}

 
	delete filename;

   return 0;

}





