/* File: GenotypeSample.h */


#ifndef __GenotypeSample_h__
#define __GenotypeSample_h__


#include "Diplotype.cpp"
#include "Genotype.cpp"
#include "Positions.cpp"

//using namespace UTILS;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


/*________________________________________________________________________________________*/

 
	class GenotypeSample: public Container<Genotype, ListOfPointers>  {


	protected:
    /** @name Implementation of class GenotypeSample
        @memo Private part.
    */


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
     bool ExistPhenotypes;

	 AlleleOrderType AlleleOrderMode;


	public:


     allele * MajorAllele, *MinorAllele;



/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      */

		//Genotype  ReadElement (ifstream * source, SNPPos size);

	
//		void  ReadGenotype (list<Diplotype::DiplotypeS>* DiplotypeList, char* line, SNPPos size);


				   /**
         @memo Compute the more frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the more frequent value
*/


/**
         @memo Compute the less frequent allele for each SNP.
         @param ic: 0: if phase has to be resolved only for parents, 1: only for children, 2 for everybody
		 @ return: pointer to a table of TotalSNPs alleles with the less frequent value
*/

		void SetAlleleType (bool IsMajor);


	protected:


		
		//Diplotype::Diplotype ReadDiplotype (ifstream * source, unsigned long int size);

	//	Diplotype ReadDiplotype (list<Diplotype>* ld, ifstream * source, bool ExistPhenotypes);

	//	virtual Genotype* ReadElement (ifstream * source, char* tokens);

		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

      /** @name Operations on GenotypeSample 
        @memo Operations on a GenotypeSample 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  

		  GenotypeSample(char * filename, bool ExistPhenotypes, AlleleOrderType AlleleOrderMode);

    

		        /**
         @memo Copy constructor
         @param destino: GenotypeSample where will be copy
         @param origen: GenotypeSample to copy
         @doc
           Make a copy of GenotypeSample
           Time complexity in time O(1).
        */
	
		//  GenotypeSample (GenotypeSample& Source, SNPPos TotalSNPs, unsigned int *Sampling);


		  GenotypeSample (GenotypeSample& source);

		  GenotypeSample();

		  ~GenotypeSample (){zaparr(MajorAllele); zaparr(MinorAllele);};

               GenotypeSample (Container<Genotype, ListOfPointers>& source, bool e, AlleleOrderType a);

		  void SNPSampling (list<SNPPos> *Sampling);

      /**
         @memo Is equal
         @param g: GenotypeSample to compare with.
	 @return
           Return true if all the GenotypeSample is the same, false otherwise.
         @doc Time complexity O(1).

      */

	  GenotypeSample& operator=(const GenotypeSample & Source);

      bool operator==(const GenotypeSample & g);
      /**
         @memo Is different
         @param g, position: GenotypeSample to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const GenotypeSample & g);

		
	  SNPPos GetTotalSNPs();
   
	  SNPPos GetTotalAllele (SNPPos SNP, bool IsMajor, const bool Marked[]);

	  SNPPos GetHap(SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, const bool Marked[]); 

	  SNPPos GetnAB(SNPPos SNP1, SNPPos SNP2, const bool Marked[]);

	  SNPPos GetnAb(SNPPos SNP1, SNPPos SNP2, const bool Marked[]);
	  
	  SNPPos GetnaB(SNPPos SNP1, SNPPos SNP2, const bool Marked[]);
	  
	  SNPPos Getnab(SNPPos SNP1, SNPPos SNP2, const bool Marked[]);

      allele getMajorAllele(SNPPos SNP, const bool Marked[]);
       
	  allele getMinorAllele(SNPPos SNP, const bool Marked[]);

	  SNPPos GetTotalType (SNPPos SNP, GenotypeType type, const bool Marked[]);

	  SNPPos GetTotalHomozygous1 (SNPPos SNP, const bool Marked[]);

	  SNPPos GetTotalHomozygous2 (SNPPos SNP, const bool Marked[]);

	  SNPPos GetTotalHeterozygous (SNPPos SNP, const bool Marked[]);

	  SNPPos GetTotalMissing (SNPPos SNP, const bool Marked[]);

	  SNPPos GetTotalNonMissing (SNPPos SNP, const bool Marked[]);
	  
	  SNPPos GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, const bool Marked[]);

      SNPPos GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, const bool Marked[]);

        SNPPos* getAlleleFrequencies(allele alleleType, const bool Marked[]=NULL);

	  /**
         @memo Obtain the number of SNPs.
         @return the number of SNPs
         @doc Return the number of SNPs. This value
         is in the variable TotalSNPs.
         Time complexity O(1)

      */
		void OrderSNPs (list<SNPPos> *Sampling);

		void OrderMajorFirst ();

		void OrderRandomly ();

		void CountAlleles (SNPPos SNP, unsigned int Basis[5], const bool Marked[]);

		void PrintHaplotypes (char* filename);

		void PrintGenotypes (char* filename);


		void SetMajorAllele(const bool Marked[]);

		allele* SetAllele(bool major, const bool Marked[]);

		void SetMinorAllele(const bool Marked[]);

		void RemoveInconsistentIndividuals(SNPPos HomoPos, NodePointer IndGenotypeRef);

		void ExportForHTYPER (char *filename);

                void ExportForML (char *filename);
      
		void ExportForMLHAP (char *filename);
                
		void ExportForSNPHAP (char *filename);
	
		void ExportForHAP (char *filename);

		void ExportForPHASE (Positions* Pos, char *filename);

		SNPPos GetLongPhasedHap(allele* Hap, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele, const bool Marked[]); 

		void ImportFormat (char *filename);

          GenotypeSample* copyElementsWithPositionsIn(intList* positions, bool inThis=true);


};  // End of class GenotypeSample

typedef GenotypeSample::NodePointer GenotypePointer;



}
// End of Namespace

#endif

/* End of file: GenotypeSample.h */




