#ifndef __SNP_h__
#define __SNP_h__




namespace BIOS {
	
	
	
	
	
	typedef int SNPPos;
	
	typedef int IndPos;
	
	
	
	typedef enum {
		MLE=0, 
			UBalpha=1, 
			MarginalBayes=2,
			equilibrium=3,
			BDistanceUniform=4,
			BDistanceSymmetrical=5,
			BDistanceMarginal=6
			
	} BayesType; 
	
	typedef enum {
		NotChanged=0, // phase is not known
			MajorFirst=1, // phase is not known
			LeftRight=2, // phase is known
			random=3
			
	} AlleleOrderType; 
	
	typedef enum {
		IsPhased=0, 
			KeepLeftRight=1, 
			ToOrder=2, 
			ResolveFromTU=3, 
			dHap=4, 
			ResolveFromPhasedChild=5, 
			ResolvePhaseFromFile=6,
			NR=7
	} PhaseType; 
	

	char vali[2];
	
	char* PrintPhaseTypes();
	
	/*
	@memo Definition of type allele
	@doc
	Used to declare alleles in SNPs. They can have one of the values 0,1,2,3,4,
	representing missing, adenine, cytosine, guanine, thymine respectively.
    */
	
	
	// adenine     A=1;
	// cytosine     C=2;
	// guanine    G=3;
	// thymine   T=4;
	
	typedef enum  {N=0, A=1, C=2, G=3, T=4, U=5, UT=-4, UG=-3, UC=-2, UA=-1} allele; // U: unphased, N:non known
	
	//typedef enum  {LeftLeft=0, LeftRight=1, RightLeft=2, RightRight} ModeDir; // U: unphased, N:non known
	
	typedef enum  {Left=0, Right=1, All=2} ModePhase; // U: unphased, N:non known
	
	typedef enum  {left=0, right=1} HaplotypeType; // U: unphased, N:non known
	
	//	typedef enum  {left=0, right=1, leftright=2, rightleft=4, all=5} ModePair; // U: unphased, N:non known
	
	typedef enum  {father=0, mother=1, offspring=2, everybody=3, parent=4} IndCategory;
	
	typedef enum  {missing=0, homozygous1=1, homozygous2=2, heterozygous=3} GenotypeType;
	
	typedef enum {Known=0, Complete=1, Inferred=2} LDType ; // LD from known haplotypes, max and min respectively
	
	// project: onlt some SNPs, select: only some individuals or all
	typedef enum  {Project=0, Select=1, None=3} RedType; 
	
	typedef double frequencies[9];
	
	typedef double sfrequencies[5];
	
    typedef double hprobs[4];
	
        typedef enum {DHAP=0, PHASE=1, SNPHAP=2, HTYPER=3, PLEM=4, PHASERECOMB=5, NR1=6, ML=7, MS=8, COSI=9, HAP=10, MLC=11, MAKEPED=12, MLHAP=13, MLCHAP=14} FormatType; // 
	
	typedef enum {Missing=0, ABAB=1, ABAb=2, ABaB=3, ABab=4, AbAb=5, AbaB=6, Abab=7, aBaB=8, aBab=9, abab=10, Unphased=11} GenotypeCode ; // 
	
	
	
	bool IsACorrectAllele (char value);
	
	allele ConvertAllele (char* value);
	
	
	char* UnconvertAllele (allele a);
	
	
	double AddBayesAllele(double Total, BayesType Bayes, float distance=0, float alpha=4);
	
	
	double AddBayesHap(double Total, BayesType Bayes, float distance=0, unsigned short int hap=0, double MLfA=0.5, double MLfB=0.5, float alpha=4);
	
	
	FormatType GetFormatType (char* Algorithm);
	
	
} // end namespace

#endif

/* End of file: genotype.h */
