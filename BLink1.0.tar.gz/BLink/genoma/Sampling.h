/* File: Sampling.h */


#ifndef __Sampling_h__
#define __Sampling_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"


namespace stats {


/************************/
/* Sampling STATISTIC*/
/************************/


/**
        @memo Sampling

	@doc
        Definition:
        An array Pos of Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Sampling  {


protected:
    /** @name Implementation of class Sampling
        @memo Private part.
    */


  
   unsigned long int Size;






/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:

  unsigned long int  * Pos;

Sampling(unsigned long int size, bool repetition);
~Sampling();


};  // End of class Sampling



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////



///////////////////
//// public ////////
///////////////////


/**********************************/
Sampling::Sampling(unsigned long int size, bool repetition)
{
Size=size;
bool *Chosen;


try {
if ((Pos=new unsigned long int[size])==NULL)
      throw NoMemory();


if (repetition==true)
for (unsigned long int  i=0; i<size;i++)
 Pos[i]=rand() % (size);     //
else // without repetition
{
int pos;
if ((Chosen=new bool[size])==NULL)
    throw NoMemory();
for (unsigned long int  i=0;i<size;i++)
	Chosen[i]=false;

unsigned long int cont2, posNotChosen;

for (int i=0; i<size;i++)
  {//
   cont2=0;//
   pos=rand() % (size-i);     //
   posNotChosen=0;
   while (Chosen[posNotChosen]==true)
    posNotChosen++;
   Pos[i]=posNotChosen;
   Chosen[posNotChosen]=true;
  }//
} // end without repetition 
  }
catch (NoMemory no) {
  no.PrintMessage();
  }
if (Chosen!=NULL)
delete Chosen;
}
/**********************************/

Sampling::~Sampling()
{
//	if (SamplingValue!=NULL)
//	delete SamplingValue;
delete Pos;
}


};  // End of Namespace

#endif

/* End of file: Sampling.h */




