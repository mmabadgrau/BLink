echo only untransmitted haplotypes 
./PhaseResolver data/crohn.txt 102 387 1 0 3 1 1 1700000 1600000 50000 0
0
mv data/crohn.dp data/crohnU.dp
mv data/crohn.hap data/crohnParents.hap
echo only transmitted haplotypes 
./PhaseResolver data/crohn.txt 102 387 1 1 3 1 0 1700000 1600000 50000 0
mv data/crohn.dp data/crohnT.dp
mv data/crohn.hap data/crohnChildren.hap
