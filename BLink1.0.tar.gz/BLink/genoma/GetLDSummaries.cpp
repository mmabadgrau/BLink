


#include "../commonc++/Fachade.h"
#include "FachadeGenoma.h"


/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

AlleleOrderType AlleleOrderMode;
float alphaBayes; 

char line[100];
if(argc<10 || argc>19)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " <<" <Trios (1: yes, 0: no)>"  <<"<max MaximumDistance>" 
			<< " <Type of summary (0: pairwise, 1: LD decay, 2: Sliding Windows>" << " <MAF> "  << " <Bayes Type (0:MLE/1: uniform Bayes/3:Equilibrium Bayes/4:Bayes distance Uniform/5:Bayes distance symmetrical>" 
		<< "<alpha Bayes (disregarded for MLE)>" << " <ic (father=0, mother=1, offspring=2, everybody=3, parent=4)>" <<" <0: all pairs (default), 1:only consecutives> "
		<< "< Phase (0: (trios: partially solved, unrelated: not changed) /1: (trios: standard phase, unrelated: leftright (known phase))> <Result(1: basic, default, 0: complete)>";
		cerr << " <first position (default is 0)> <last position (default is last in the file)> <pairwise: alpha ci (default: 90), LD decay and SW: slide size (default 20000)>"
		<< " < LD decay and SW: slide overlap (default 10000), diregarded for pairwise>" << " <invariant sites (0: no (default), 1: yes)>" << " <Output file (default, no option)>" << " <Selection file (default, no selection file)>"<< endl;

		
		
         exit(-1);
        }
  float alpha=90;
  SNPPos SlideSize=20000;
  SNPPos SlideOverlap=10000;
  double firstPosition=0, lastPosition=0;
  bool invariant=false;
  char filename[256], filepos[256], filename2[256]="\0", *fileSel=NULL, ext[256];
  strcpy (filename, argv[1]);
  bool trios=atoi(argv[2]); 
  float MaximumDistance=atof(argv[3]);
  int type=atoi(argv[4]);
  float MAF=atof(argv[5]);
  BayesType BayesMode=(BayesType) atoi(argv[6]);
  alphaBayes=atof(argv[7]);
   IndCategory ic= (IndCategory) atoi(argv[8]);
   bool onlyConsecutives=atoi(argv[9]);
  bool Phase=atoi(argv[10]);
  bool basic=atoi(argv[11]);
  if (argc>=13)
	  firstPosition=atof(argv[12]);


  if (argc>=14)
	  lastPosition=atof(argv[13]);
  if (argc>=15) 
  if (type==0) alpha=atof(argv[14]);
  else SlideSize=atoi(argv[14]);

   
  if (argc>=16)
  SlideOverlap=atoi(argv[15]);

    if (argc>=17)
   invariant=atoi(argv[16]);
   

 if (argc>=18) 
   strcpy(filename2, argv[17]);
  
 if (argc==19)
    strcpy(fileSel, argv[18]);

if (SlideSize<SlideOverlap) 
{ 
	cout <<"SlideOverlap cannot be greater than slide size.\n";
	exit(0);
}
if (firstPosition>lastPosition) change(firstPosition, lastPosition);


if (strcmp(filename2, "\0")==0)
{
strcpy(filename2, GetFilePath(filename));
//cout <<"path is" << GetFilePath(filename);
strcat(filename2, GetFilename(filename));
//cout <<"file is " << GetFilename(filename);
if (MAF==0.0 && invariant)
strcat(filename2, "Invariant\0");
switch(BayesMode)
{
case MLE:
sprintf(filename2, "%sMAF%d-MLE", filename2, (int)(MAF*100)); break;
case BDistanceUniform:
sprintf(filename2, "%sMAF%d-BDistanceUniform%f", filename2, (int)(MAF*100), alphaBayes); break;
case BDistanceSymmetrical:
sprintf(filename2, "%sMAF%d-BDistanceSymmetrical%f", filename2, (int)(MAF*100), alphaBayes); break;
case BDistanceMarginal:
sprintf(filename2, "%sMAF%d-BDistanceMarginal%f", filename2, (int)(MAF*100), alphaBayes); break;
}
if (firstPosition>0)
sprintf(filename2, "%sFirstPos%0.1f-LastPos%0.1f", filename2, (float)firstPosition, (float)lastPosition); 


switch(ic)
{
case father:
strcat(filename2, "OnlyFathers"); break;
case mother:
strcat(filename2, "OnlyMothers");  break;
case offspring:
strcat(filename2, "OnlyChildren");  break;
case parent:
strcat(filename2, "OnlyParents");  break;
case everybody:
strcat(filename2, "Everybody"); break;
}

if (onlyConsecutives) strcat(filename2, "OnlyConsecSNPs");

//if (invariant) strcat(filename2, "invariant");

if (type==0 && argc>14) 
{
strcat(filename2, "alpha");
strcat(filename2, argv[14]);// alpha
}


switch (type)
{
case 0: strcpy(ext, ".pm\0"); break;
case 1: strcpy(ext, ".dec\0"); break;
case 2: strcpy(ext, ".sw\0"); break;
}

strcat(filename2, ext);
}
  
if (trios)
{
PairwiseMeasuresResults<TrioSample> *PM=NULL;
AlleleOrderMode=MajorFirst;
PM=new PairwiseMeasuresResults<TrioSample>(filename, MAF, BayesMode, alphaBayes, onlyConsecutives, ic, Phase, AlleleOrderMode, alpha, invariant, firstPosition, lastPosition, fileSel);
switch(type)
{
case 0: PM->PrintClassicPairwisesMeasures(filename2, false, MaximumDistance, basic); break;
case 1: PM->printLDDecay(filename2, MaximumDistance, SlideSize, SlideOverlap, false); break;
case 2: PM->printSlidingWindows(filename2, MaximumDistance, SlideSize, SlideOverlap, false); break;
}
zap(PM);
}
else
{
PairwiseMeasuresResults<GenomaSample> * PM=NULL;
AlleleOrderMode=LeftRight;
PM=new PairwiseMeasuresResults<GenomaSample>(filename, MAF, BayesMode, alphaBayes, onlyConsecutives, ic, Phase, AlleleOrderMode, alpha, invariant, firstPosition, lastPosition, fileSel);
switch(type)
{
case 0: PM->PrintClassicPairwisesMeasures(filename2, false, MaximumDistance, basic); break;
case 1: PM->printLDDecay(filename2, MaximumDistance, SlideSize, SlideOverlap, false); break;
case 2: PM->printSlidingWindows(filename2, MaximumDistance, SlideSize, SlideOverlap, false); break;
}
zap(PM);
}





return 0;
};

 


