if [ $# -ne 3 ]
then
echo This macro needs three arguments: macro, month and year
exit 0
fi
./$1.sh /home/mabad/hapmap$2$3/Yoruba/ YRI $2 $3 #0
./$1.sh /home/mabad/hapmap$2$3/US/ CEU $2 $3 #1
./$1.sh /home/mabad/hapmap$2$3/China/ CHB $2 $3 #1
./$1.sh /home/mabad/hapmap$2$3/Japan/ JPT $2 $3 #1
