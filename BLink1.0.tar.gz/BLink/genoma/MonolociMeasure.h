/* File: MonolociMeasure.h */


#ifndef __MonolociMeasure_h__
#define __MonolociMeasure_h__



#include "GenotypeSample.cpp"



namespace BIOS {


/************************/
/* SNP'S MonolociMeasure DEFINITION */
/************************/


/**
        @memo MonolociMeasure for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
template <class T> class MonolociMeasure {


protected:

    /** @name Implementation of class MonolociMeasure
        @memo Private part.
    */

	  BayesType Bayes;

	  IndCategory ic;

	  T * sample;

	  float alpha;

	  bool*Marked;



/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on MonolociMeasure 
        @memo Operations on a MonolociMeasure 
		  */
		  inline MonolociMeasure(T * samp, const IndCategory & i=everybody, bool* Marked, const BayesType & Bay=MLE, const float alpha=0)
		  {
// Marked is used for consistency when only genotypes are chosen
			  sample=samp; Bayes=Bay; ic=i; this->alpha=alpha;//
			  IndPos TotalInds=sample->GenotypeSample::GetSize();
			  this->Marked=Marked;			 
		  }
		  inline MonolociMeasure(T * samp, const IndCategory & i=everybody, const BayesType & Bay=MLE, const float alpha=0)
		  {
                          this->Marked=NULL;
			  sample=samp; Bayes=Bay; ic=i; this->alpha=alpha;//
			  IndPos TotalInds=sample->GenotypeSample::GetSize();
			  this->Marked=Marked;			 
		  }
		  //cout <<"\ntam:" <<sample->PhenotypeSample::GetSize();};
		  
		  
		  double GetTotalFreqAllele(const SNPPos & SNP1, const bool IsMajor, int distance);
		  double GetTotalAllele(const SNPPos & SNP1, const bool IsMajor, int distance);
		  double GetTotalMissing(const SNPPos & SNP1);
		 
		  
		  ~MonolociMeasure(){};
		  
};  // End of class MonolociMeasure



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////
/*____________________________________________________________ */

template<class T> double MonolociMeasure<T>::GetTotalAllele(const SNPPos & SNP, const bool IsMajor=true, int distance=0)
{
double total=sample->GenotypeSample::GetTotalAllele(SNP, IsMajor, Marked);
total=AddBayesAllele(total, Bayes, distance, alpha);
			 
	return total;
}

/*____________________________________________________________ */

template<class T> double MonolociMeasure<T>::GetTotalFreqAllele(const SNPPos & SNP, const bool IsMajor=true, int distance=0)
{
	double total=GetTotalAllele(SNP, IsMajor);
	double total2=sample->GenotypeSample::GetTotalAllele(SNP, !IsMajor, Marked);
	total2=AddBayesAllele(total2, Bayes, distance, alpha);
		
 if ((total+total2)>0)
 return total/(total+total2);
 else return 0;
}

/*____________________________________________________________ */

template<class T> double MonolociMeasure<T>::GetTotalMissing(const SNPPos & SNP)
{
	return sample->GenotypeSample::GetTotalMissing(SNP, Marked);
	
}


};  // End of Namespace

#endif

/* End of file: MonolociMeasure.h */




