  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */
//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//


#include "Tables2x2.h"

using namespace BIOS;



int main(int argc, char*argv[]) {

     if(argc<9)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <n(AB)> " << " <n(Ab)>" << " <n(aB)>" << " <n(ab)>" << " < HH individuals >" << " <fA>" << " <fB>"  
			 <<"<alpha(ci)>" << endl;
        exit(-1);
        }
    
	 
	 double nAB=atof(argv[1]);
	 double nAb=atof(argv[2]); 
	 double naB=atof(argv[3]); 
	 double nab=atof(argv[4]);
	 double nHH=atof(argv[5]);
	 double fA=atof(argv[6]);
	 double fB=atof(argv[7]);
     double alpha=atof(argv[8]);


	 Table2x2 T2x2;

     struct Pair pair=T2x2.GetQuantilesDPrime (50-alpha/2, 50+alpha/2, fA, fB, nAB, nAb, naB, nab, nHH, true);
	
 cout <<"\nLower:" << pair.First << ", upper:" << pair.Second;



   return 0;

}





