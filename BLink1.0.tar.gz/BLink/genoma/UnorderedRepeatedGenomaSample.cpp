
/* File: UnorderedRepeatedGenomaSample.cpp */


#ifndef __UnorderedRepeatedGenomaSample_cpp__
#define __UnorderedRepeatedGenomaSample_cpp__



#include "UnorderedRepeatedGenomaSample.h"
     
        



namespace BIOS {



/*____________________________________________________________ */

UnorderedRepeatedGenomaSample::UnorderedRepeatedGenomaSample(char* filename, bool  ExistPhen): 
				PhenotypeSample(filename), 
				UnorderedRepeatedGenotypeSample(filename, ExistPhen)

{
};
/*____________________________________________________________ */

void UnorderedRepeatedGenomaSample::PrintOrderedRepeatedGenoma (char* filename, bool PrintPhenotypes)
 {

		ofstream OutputFile;

  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
  Genotype* genotype;

  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

while (IndPhenotype!=NULL && IndGenotype!=NULL)
  {
   if (PrintPhenotypes)	OutputFile << PhenotypeSample::GetElement(IndPhenotype).PrintPhenotype();

	OutputFile << UnorderedRepeatedGenotypeSample::GetElement(IndGenotype)->print();    
	OutputFile << "\n";
    IndGenotype=GenotypeSample::GetNext(IndGenotype);
    IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
  OutputFile.close();

cout << "\nInformation about ordered genotype has been saved in file " << filename <<"\n";
 }




};  // Fin del Namespace

#endif

/* Fin Fichero: UnorderedRepeatedGenomaSample.h */
