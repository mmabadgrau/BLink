  /**
    * @file genoma.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "genoma.h"
#include "PhaseChecker.h"

using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }


/* _____________________________________________________*/

void ChangeIds(char *filename, char* filename2, unsigned int TotalSNPs, unsigned int Size)
{

//strcpy(filename2, filename);
individual *Sample;
// phase will be resolved only for offspring



if ((Sample = new individual(filename, TotalSNPs, Size, true, (IndCategory)2))==NULL)
 throw NoMemory();


/*
	 strcpy (filename2, filename);
	 strtok(filename2, ".");
	 strcat (filename2, ".red\0");
*/
Sample->ChangeIds(filename2); 


cout << "\nOutput file: " << filename2 <<"\n";

//delete filename2;

}

}



/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc!=5)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <orig file> " << " <target file> " << " <#SNPs>" << " <#individuals>"  << endl;
        exit(-1);
        }
     char* filename, *filename2;
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
	 if ((filename2=new char[64])==NULL)
		 throw NoMemory();
	 strcpy(filename, argv[1]);
	 strcpy(filename2, argv[2]);

     unsigned int TotalSNPs=atoi(argv[3]);
     unsigned int TotalIndividuals=atoi(argv[4]);


	 try{ 

	
      //   TotalSNPs=HapMapProcessing (filename, filephenotypes, filename2, TotalIndividuals);
		// GenomaProcessing (filename2, TotalSNPs, TotalIndividuals);
		// GenomaProcessing (filename2, 22603, TotalIndividuals);
       ChangeIds (filename, filename2, TotalSNPs, TotalIndividuals);

		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}

	 delete filename, delete filename2;
 
   return 0;

}





