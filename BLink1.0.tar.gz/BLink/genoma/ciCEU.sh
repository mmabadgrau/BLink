./CIHapmap.sh /home/mabad/hapmapJune2005/US/ CEU June 2005

