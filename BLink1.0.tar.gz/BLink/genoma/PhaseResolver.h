/* File: PhaseResolver.h */

//#include <string>

#include "Exceptions.h"
#include "GenotypeSample.h"
#include "Tables2x2.h"
#include "PairwiseMeasure.h"
#include "block.h"


#ifndef __PhaseResolver_h__
#define __PhaseResolver_h__

namespace BIOS {

class PhaseResolver: public GenotypeSample
{
private:
	bool EM;
	bool UseBlocks;
	block *listBlocks;
	BayesType BayesMode;
	char filename[128];
//	bool IsSolved (Genotype* IndGenotype, unsigned int FirstSNP, unsigned int LastSNP);
	//bool IsLD (unsigned int *Frequencies);
	short int AssignPhase (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	unsigned int AssignPhaseNR (SNPPos FirstHetero, SNPPos LastHetero, NodePointer IndGenotypeRef);
	void GetLongHaps(double * LongHaps, Genotype* IndGenotypeRef, unsigned int FirstPos, unsigned int LastPos, unsigned int heteroPos);
	bool AreThereTooManyIndividuals (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	bool AreThereTooLittleIndividuals (SNPPos FirstHetero, SNPPos LastHetero, double distance);
//	short int AssignPhase (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	double GetDPrime (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	double GetD (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	double GetfA (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	double GetfB (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	double GetfAB (SNPPos FirstHetero, SNPPos LastHetero, double distance);
	void GetHaps(IndPos * Haps, SNPPos FirstHetero, SNPPos LastHetero, SNPPos HomoPos[], SNPPos TotalHomoPos, allele* MajorAllele, NodePointer IndGenotypeRef);
	unsigned int GetNumberofNonZeroHaplotypePairs(unsigned int *Haps, SNPPos TotalHeteroPos);
	int GetMostFrequentHaplotypePair(unsigned int *Haps, SNPPos TotalHeteroPos);
	//void AddHomoPos(SNPPos *HomoPos, SNPPos Borders[4], Genotype* GenotypeRef);
	SNPPos GetHomoPos(SNPPos Borders[4], Genotype* GenotypeRef);
	short int AssignPhaseLongHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef, SNPPos FirstFirstHetero, SNPPos LastLastHetero);
	short int AssignPhaseDecreasingHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef);

public:
	PhaseResolver(char * filenam, bool ExistPhenotype, AlleleOrderType AlleleOrderMode, BayesType BayesMod, bool Em, bool UseBl=false): GenotypeSample(filenam, ExistPhenotype, AlleleOrderMode)
	{
	BayesMode=BayesMod;
	Em=Em; 
	strcpy (filename, filenam);
	UseBlocks=UseBl;
	char fileblocks[128];
	ChangeExtension(filename, fileblocks, "bl\0");
    if (UseBlocks) 
	{
		listBlocks=new block(fileblocks);
		if (listBlocks->GetFirst()==NULL) UseBlocks=false;
	}
	 else listBlocks=NULL;
	};

	~PhaseResolver(){if (UseBlocks) delete listBlocks;};
	void ResolvePhase (PhaseType PhaseMode, bool UseMarkers);
//	void SetMarked (bool Marked[], IndCategory ic);
	void ResolvePhaseIncreasingDistances (bool UseMarkers);
	void ResolvePhaseDecreasingDistances (bool UseMarkers);

};

/*_________________________________________________________________________*/
/*
bool PhaseResolver::IsSolved (Genotype* genotype, unsigned int FirstSNP, unsigned int LastSNP)
 {
	SNPPos TotalSNPs=GetTotalSNPs();
   unsigned int TotalHeterozygous=0, LastHeterozygous, CurrentHeterozygous, distance=LastSNP-FirstSNP;
   for (int i=0;i<TotalSNPs;i++)
   {
	if ((i<=FirstSNP) && (genotype->IsHeterozygous(i)))
		LastHeterozygous=i;
	if ((i>FirstSNP) && (i<LastSNP) && (genotype->IsHeterozygous(i)))
	{
	 TotalHeterozygous++;
	 CurrentHeterozygous=i;
	}
   }
   if ((TotalHeterozygous==1) && ((CurrentHeterozygous-LastHeterozygous)>=distance))
   return false;
   else return true;
  }

*/
/*__________________________________________________________*/
/*
bool PhaseResolver::IsLD (unsigned int *Frequencies)
{
	unsigned int n=0;
	double chi2, pvalue, Expected[4];
	
	for (int i=0;i<4;i++)
	 n=n+Frequencies[i];

	Expected[0]=(((double)Frequencies[0]+Frequencies[2])*(Frequencies[0]+Frequencies[1]))/n;
	Expected[1]=(((double)Frequencies[1]+Frequencies[0])*(Frequencies[1]+Frequencies[3]))/n;
	Expected[2]=(((double)Frequencies[2]+Frequencies[0])*(Frequencies[2]+Frequencies[3]))/n;
	Expected[3]=(((double)Frequencies[3]+Frequencies[1])*(Frequencies[3]+Frequencies[2]))/n;

	chi2=((pow(((double)Frequencies[0]-Expected[0]),2))/Expected[0])+((pow(((double)Frequencies[1]-Expected[1]),2))/Expected[1])+
		((pow(((double)Frequencies[2]-Expected[2]),2))/Expected[2])+((pow(((double)Frequencies[3]-Expected[3]),2))/Expected[3]);

    pvalue=(1-gammai(0.5, (double)chi2/2));

	if (pvalue<0.05) return true;
	else return false;
//	return true;

}
*/
/*____________________________________________________________ */
/*
void PhaseResolver::SetMarked (bool Marked[], IndCategory ic)
{
IndPos TotalInds=GetSize();
InitializeList(Marked, TotalInds, true);
}
/*__________________________________________________________*/

bool PhaseResolver::AreThereTooManyIndividuals (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
if (GetfA(FirstHetero, LastHetero, distance)==0  || GetfB(FirstHetero, LastHetero, distance)==0) return true;
return fabs(GetDPrime(FirstHetero, LastHetero, distance))!=1;  
} 
/*__________________________________________________________*/

bool PhaseResolver::AreThereTooLittleIndividuals (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
return GetfA(FirstHetero, LastHetero, distance)==0  || GetfB(FirstHetero, LastHetero, distance)==0;  
} 
/*__________________________________________________________*/

short int PhaseResolver::AssignPhaseDecreasingHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef)
{
SNPPos TotalPos=LastHetero-FirstHetero+1;
allele Hap[TotalPos];
SNPPos Pos[TotalPos]; 

IndPos TotalIndividuals=GetSize(), ind;
bool Marked[TotalIndividuals];

IndPos nAB=0, nAb=0, naB=0, nab=0;
int i, a=0;
for (i=FirstHetero;i<=LastHetero;i++)
{
   Hap[a]=GenotypeRef->GetDiplotype(i).GetLeftAllele();
   Pos[a]=i;
   a++;
 }
Genotype *g;
ind=0;
NodePointer IndGenotype=GetFirst();
while (IndGenotype!=NULL)
{
	g=GetElement(IndGenotype);
	Marked[ind]=false;
	i=FirstHetero;
	while (i<=LastHetero && g->GetDiplotype(i).IsHomozygous(MajorAllele[i]))
	 i++;
	if (i==(LastHetero+1))
		Marked[ind]=true;
	IndGenotype=GetNext(IndGenotype);
	ind++;
}

if (ind>0)
{
Diplotype D=GenotypeRef->GetDiplotype(FirstHetero);
D.OrderMajorFirst(MajorAllele[FirstHetero]);
Diplotype D2=GenotypeRef->GetDiplotype(LastHetero);
D2.OrderMajorFirst(MajorAllele[LastHetero]);


Hap[0]=D.GetLeftAllele();
Hap[TotalPos-1]=D2.GetLeftAllele();
nAB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[0]=D.GetLeftAllele();
Hap[TotalPos-1]=D2.GetRightAllele();
nAb=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[0]=D.GetRightAllele();
Hap[TotalPos-1]=D2.GetLeftAllele();
naB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[0]=D.GetRightAllele();
Hap[TotalPos-1]=D2.GetRightAllele();
nab=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
}
if ((nAB*nab)==0 && (nAb*naB)==0)
 return AssignPhase(FirstHetero, LastHetero, (double)0);
else

if (nAB*nab>=nAb*naB) return 1; else return 2; 
} 
/*__________________________________________________________*/

short int PhaseResolver::AssignPhaseLongHaps (SNPPos FirstHetero, SNPPos LastHetero, allele* MajorAllele, Genotype* GenotypeRef, SNPPos FirstFirstHetero, SNPPos LastLastHetero)
{
SNPPos TotalSNPs=GetTotalSNPs();
SNPPos TotalPos=0, p, F, L;

//if (LastLastHetero>=TotalSNPs)
//cout <<"EEEEEEEEEEEEEE";
//TotalPos=LastLastHetero-FirstFirstHetero+1;
for (p=FirstFirstHetero;p<=LastLastHetero;p++)
if (GenotypeRef->GetDiplotype(p).IsHomozygous(MajorAllele[p]))
 TotalPos++;
TotalPos=TotalPos+2; 

allele Hap[TotalPos];
SNPPos Pos[TotalPos]; 

IndPos TotalIndividuals=GetSize(), ind;
bool Marked[TotalIndividuals];


NodePointer IndGenotype=GetFirst();
Genotype * genotype;
SNPPos Total=0, i=0;
bool phased=false;
IndPos nAB=0, nAb=0, naB=0, nab=0;

for (p=FirstFirstHetero;p<=LastLastHetero;p++)
 if (GenotypeRef->GetDiplotype(p).IsHomozygous(MajorAllele[p]) || p==FirstHetero || p==LastHetero)
 {
 if (p==FirstHetero) F=i;
 else if (p==LastHetero) L=i;
 else
 Hap[i]=GenotypeRef->GetDiplotype(p).GetLeftAllele();
 Pos[i]=p;
 i++;
 }

Genotype *g;
ind=0;

while (IndGenotype!=NULL)
{
	g=GetElement(IndGenotype);
	p=FirstFirstHetero;
	Marked[ind]=true;

    if (g->GetDiplotype(FirstHetero).IsHeterozygous(MajorAllele[FirstHetero]) && g->GetDiplotype(LastHetero).IsHeterozygous(MajorAllele[LastHetero]))
    {
	i=0;
	while (i<TotalPos && (g->GetDiplotype(Pos[i]).IsHomozygous(MajorAllele[Pos[i]]) || Pos[i]==FirstHetero || Pos[i]==LastHetero))
	 i++;
	}
	//cout <<"\nLastHetero:" << LastLastHetero;
	//cout <<"p" << p;
	if (i==(TotalPos+1))
		Marked[ind]=false;
	IndGenotype=GetNext(IndGenotype);
	ind++;
}


Diplotype D=GenotypeRef->GetDiplotype(FirstHetero);
D.OrderMajorFirst(MajorAllele[FirstHetero]);
Diplotype D2=GenotypeRef->GetDiplotype(LastHetero);
D2.OrderMajorFirst(MajorAllele[LastHetero]);


Hap[F]=D.GetLeftAllele();
Hap[L]=D2.GetLeftAllele();
nAB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetLeftAllele();
Hap[L]=D2.GetRightAllele();
nAb=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetRightAllele();
Hap[L]=D2.GetLeftAllele();
naB=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);
Hap[F]=D.GetRightAllele();
Hap[L]=D2.GetRightAllele();
nab=GetLongPhasedHap(Hap, Pos, TotalPos, MajorAllele, Marked);

if ((nAB*nab)==0 && (nAb*naB)==0)
 return AssignPhase(FirstHetero, LastHetero, (double)0);
else

if (nAB*nab>=nAb*naB) return 1; else return 2; 
} 
/*__________________________________________________________*/

short int PhaseResolver::AssignPhase (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
/*
if (GetfA(FirstHetero, LastHetero, distance)==0 || GetfB(FirstHetero, LastHetero, distance)==0) 
{
	cout <<"error in AssignPhase";
	exit(0);
	return 1;
}
*/
if (GetD(FirstHetero, LastHetero, distance)>=(double)0) return 1; else return 2; // if some position is not a SNP, return 1
} 
/*__________________________________________________________*/

double PhaseResolver::GetDPrime (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
Table2x2 T2x2;
double fA=GetfA(FirstHetero, LastHetero, distance);
double fB=GetfB(FirstHetero, LastHetero, distance);
if (GetfA(FirstHetero, LastHetero, distance)==0  || GetfB(FirstHetero, LastHetero, distance)==0){cout <<"error in getprime"; exit(0);};
double fAB=GetfAB(FirstHetero, LastHetero, distance);
return T2x2.GetDPrime(fAB, fA, fB);
} 
/*__________________________________________________________*/

double PhaseResolver::GetD (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
Table2x2 T2x2;
double fA=GetfA(FirstHetero, LastHetero, distance);
double fB=GetfB(FirstHetero, LastHetero, distance);
/*
if (GetfA(FirstHetero, LastHetero, distance)==0  || GetfB(FirstHetero, LastHetero, distance)==0) 
{
	cout <<"error";
	exit(0);
	return 0.0;
}
*/
double fAB=GetfAB(FirstHetero, LastHetero, distance);
return T2x2.GetD(fAB, fA, fB);
} 
/*__________________________________________________________*/

double PhaseResolver::GetfA (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
PairwiseMeasure<PhaseResolver> *PM;
PM = new PairwiseMeasure<PhaseResolver>(FirstHetero, LastHetero, this, BayesMode, (IndCategory)everybody, distance);
return PM->GetfA();
} 
/*__________________________________________________________*/

double PhaseResolver::GetfB (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
PairwiseMeasure<PhaseResolver> *PM;
PM = new PairwiseMeasure<PhaseResolver>(FirstHetero, LastHetero, this, BayesMode, (IndCategory)everybody, distance);
return PM->GetfB();
} 
/*__________________________________________________________*/

double PhaseResolver::GetfAB (SNPPos FirstHetero, SNPPos LastHetero, double distance=0)
{
PairwiseMeasure<PhaseResolver> *PM;
PM = new PairwiseMeasure<PhaseResolver>(FirstHetero, LastHetero, this, BayesMode, (IndCategory)everybody, distance);
if (EM) return PM->GetfAB();
else return PM->GetfABNoEM();
} 
/*__________________________________________________________*/

void PhaseResolver::GetHaps(IndPos * Haps, SNPPos FirstHetero, SNPPos LastHetero, SNPPos HomoPos[], SNPPos TotalHomoPos, allele* MajorAllele, NodePointer IndGenotypeRef)
{
// There are 2^heteropos different haplotypes
// This procedure obtains the frequencies for each haplotype 
NodePointer IndGenotype=GetFirst();
Genotype *genotype, *genotyperef;
genotyperef=GetElement(IndGenotypeRef);
SNPPos HeteroPos[2];
HeteroPos[0]=FirstHetero;
HeteroPos[1]=LastHetero;

while (IndGenotype!=NULL)
{
if (IndGenotypeRef!=IndGenotype)
{
genotype=GetElement(IndGenotype);
if (genotype->HaveTheSameHomoPos(*genotyperef, HomoPos, TotalHomoPos, MajorAllele))
genotype->CountHaps(Haps, HeteroPos, 2, MajorAllele);
}
IndGenotype=GetNext(IndGenotype);
}
}

/*_____________________________________________________________*/

unsigned int PhaseResolver::GetNumberofNonZeroHaplotypePairs(unsigned int *Haps, SNPPos TotalHeteroPos)
{
unsigned int LeftHap, RightHap, haplotypePairs=(unsigned int) pow(2,(TotalHeteroPos-1));
unsigned int NonZeroPairs=haplotypePairs;
for (int i=0;i<haplotypePairs;i++)
{
	LeftHap=i;
	RightHap=(unsigned int) pow(2,TotalHeteroPos)-1-i;
	if ((Haps[LeftHap]==0) || (Haps[RightHap]==0))
	 NonZeroPairs--;
}
return NonZeroPairs;
}
/*_____________________________________________________________*/

int PhaseResolver::GetMostFrequentHaplotypePair(unsigned int *Haps, SNPPos TotalHeteroPos)
{
unsigned int haplotypePairs=(unsigned int)pow(2,(TotalHeteroPos-1));
unsigned int NonZeroPairs=haplotypePairs;
unsigned long int MaxFreq=0;
int MaxPos=-1, LeftHap, RightHap;
for (int i=0;i<haplotypePairs;i++)
{
	LeftHap=i;
	RightHap=(unsigned int) pow(2,TotalHeteroPos)-1-i;
	if ((Haps[LeftHap]*Haps[RightHap])>MaxFreq) 
 {
	 MaxFreq=Haps[LeftHap]*Haps[RightHap];
	 MaxPos=i;
}
}
return MaxPos;
}
/*_____________________________________________________________*/
/*
void PhaseResolver::AddHomoPos(SNPPos *HomoPos, SNPPos Borders[4], Genotype* GenotypeRef)
{
// Update Borders and add homo position to HomoPos
if ((Borders[0]>0) 
	&& ((IsHomozygous(IndGenotypeRef, FirstPos-1))
	|| (!((LastPos<(TotalSNPs-1)) && (IsHomozygous(IndGenotypeRef, LastPos+1))) && (LastTrend==0))))
{
FirstPos--;
LastTrend=0; //left
}
else
if (LastPos<(genotype::TotalSNPs-1)) 
{
LastPos++;
LastTrend=1; //right
}

heteroPosPrevious=heteroPos;


if (((LastTrend==0) && (IsHeterozygous(IndGenotypeRef, FirstPos))) 
	||
	((LastTrend==1) && (IsHeterozygous(IndGenotypeRef, LastPos))))
	 heteroPos++;
}
/*_____________________________________________________________*/

SNPPos PhaseResolver::GetHomoPos(SNPPos Borders[4], Genotype* GenotypeRef)
{
SNPPos TotalSNPs=GetTotalSNPs();

bool IsOdd=false;
while ((Borders[1]+1)!=Borders[2])
{
 if (IsOdd)
 {
 Borders[1]++;
 if (GenotypeRef->GetDiplotype(Borders[1]).IsHomozygous(MajorAllele[Borders[1]]))
   return Borders[1];
 IsOdd=false;
 }
else
 {
 Borders[2]--;
 if (GenotypeRef->GetDiplotype(Borders[2]).IsHomozygous(MajorAllele[Borders[2]]))
   return Borders[2];
 IsOdd=true;
 }
}

while ((Borders[0]-1)!=0)
{
 Borders[0]--;
 if (GenotypeRef->GetDiplotype(Borders[0]).IsHomozygous(MajorAllele[Borders[0]]))
   return Borders[0];
}

while ((Borders[3]+1)!=(TotalSNPs-1))
{
 Borders[3]++;
 if (GenotypeRef->GetDiplotype(Borders[3]).IsHomozygous(MajorAllele[Borders[3]]))
   return Borders[3];
}

return TotalSNPs;

}

/*__________________________________________________________*/

unsigned int PhaseResolver::AssignPhaseNR (SNPPos FirstHetero, SNPPos LastHetero, NodePointer IndGenotypeRef)
{
// Algorithm NR (Nearest Relative)
// Solve the phase for a genotype in the same way as it is solved in its closer relative.

PhaseResolver* Sample2;
Sample2=new PhaseResolver(*this);	
short unsigned int Phase=1;

SNPPos TotalSNPs=GetTotalSNPs(), HomoPos;
bool TooManyIndividuals=false, border=false;
Genotype* GenotypeRef=GetElement(IndGenotypeRef);
SNPPos Borders[4];
Borders[0]=FirstHetero;Borders[1]=FirstHetero;
Borders[2]=LastHetero;Borders[3]=LastHetero;
do
{
if (!Sample2->AreThereTooLittleIndividuals(FirstHetero, LastHetero))
Phase=Sample2->AssignPhase (FirstHetero, LastHetero);
if (Borders[0]==0 && Borders[3]==TotalSNPs-1 && Borders[1]==Borders[2]) border=true;
else 
{
HomoPos=GetHomoPos(Borders, GenotypeRef);
if (HomoPos<TotalSNPs) Sample2->RemoveInconsistentIndividuals(HomoPos, IndGenotypeRef);
TooManyIndividuals=Sample2->AreThereTooManyIndividuals(FirstHetero, LastHetero);
}
}
while (!TooManyIndividuals && !border);

return Phase;
} 

/*____________________________________________________________ */

void PhaseResolver::ResolvePhase (PhaseType PhaseMode, bool UseMarkers=false)
{
char filepos[128];

ChangeExtension (filename, filepos, "pou");

unsigned short int MajorPhase;
SNPPos LastResolved, TotalSNPs=GetTotalSNPs(), SNP;
cout << "\nReconstructing haplotypes...";
double distance;
Positions * Pos;
Pos=new Positions (filepos);

NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* G;

unsigned short int Phase=0;
bool IsAnOrderedPhase;
while (IndGenotype!=NULL)
{
  G=GetElement(IndGenotype);
  LastResolved=G->GetFirstHeterozygous(MajorAllele);
  SNP=LastResolved+1;
  while (SNP<TotalSNPs)
  {
   if (G->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) 
   {
    distance=Pos->GetDistance(LastResolved, SNP);
   if (PhaseMode==dHap) Phase=AssignPhase (LastResolved, SNP, distance);
   if (PhaseMode==NR) Phase=AssignPhaseNR (LastResolved, SNP, IndGenotype);
   IsAnOrderedPhase=G->IsMajorMajor(MajorAllele[LastResolved], MajorAllele[SNP], G->GetDiplotype(LastResolved), G->GetDiplotype(SNP));
   if ((UseMarkers && G->IsMarked(SNP)) || !UseMarkers) 
   if ((Phase==1 && !IsAnOrderedPhase) || (Phase==2 && IsAnOrderedPhase)) 
  //if (!IsAnOrderedPhase)
    G->ChangeAlleles(SNP);
   LastResolved=SNP;
   } //end for each hetero SNP
   SNP++;
  } // for each SNP
 IndGenotype=GetNext(IndGenotype);
} // end for each individual
cout << "\nReconstruction has finished";
}
/*____________________________________________________________ */

void PhaseResolver::ResolvePhaseIncreasingDistances (bool UseMarkers=false)
{
char filepos[128];

ChangeExtension (filename, filepos, "pou");

unsigned short int MajorPhase;
SNPPos LastResolved, TotalSNPs=GetTotalSNPs(), SNP, NextHet, LastLastResolved;
cout << "\nReconstructing haplotypes...";
double distance;
Positions * Pos;
Pos=new Positions (filepos);
NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* G;
Block bl;
bool simpleDHAP;
unsigned short int Phase=0;
bool IsAnOrderedPhase;
block::NodePointer pB;
for (SNPPos gap=0;gap<(TotalSNPs-1);gap++)
{
IndGenotype=GenotypeSample::GetFirst();
while (IndGenotype!=NULL)
{
  LastLastResolved=TotalSNPs;
  G=GetElement(IndGenotype);
  LastResolved=G->GetFirstHeterozygous(MajorAllele);
  SNP=LastResolved+1;
  
  while (SNP<TotalSNPs)
  {
 
   if (G->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) 
   {
    distance=Pos->GetDistance(LastResolved, SNP);
	if ((SNP-LastResolved-1)==gap)
	{
       NextHet=SNP+1;
	   while (NextHet<TotalSNPs && G->GetDiplotype(NextHet).IsHomozygous(MajorAllele[NextHet]))
		   NextHet++;
	   NextHet--;
	  if (LastLastResolved==TotalSNPs) 
	   LastLastResolved=LastResolved;
	
	simpleDHAP=false;
	
   	if (UseBlocks)	
	{
    pB=listBlocks->GetFirst();
	//exit(0);
	if (pB!=NULL) bl=listBlocks->GetElement(pB);
    while (pB!=NULL && bl.IniPos>LastResolved)
    {
	pB=listBlocks->GetNext(pB);
    if (pB!=NULL) bl=listBlocks->GetElement(pB);
    }
    if (bl.IniPos<=LastResolved && bl.LastPos>=SNP)
	{
	LastLastResolved=bl.IniPos;
	NextHet=bl.LastPos;
	}
	else simpleDHAP=true;
	}
//if all
	//	LastLastResolved=0;
	//	NextHet=TotalSNPs-1;
	// if basic incremental
	//LastLastResolved=LastResolved;
	//NextHet=SNP;
	if (simpleDHAP) AssignPhase (LastResolved, SNP, distance); 
	else Phase=AssignPhaseLongHaps (LastResolved, SNP, MajorAllele, G, LastLastResolved, NextHet);
	   IsAnOrderedPhase=G->IsMajorMajor(MajorAllele[LastResolved], MajorAllele[SNP], G->GetDiplotype(LastResolved), G->GetDiplotype(SNP));
   if ((UseMarkers && G->IsMarked(SNP)) || !UseMarkers) 
   if ((Phase==1 && !IsAnOrderedPhase) || (Phase==2 && IsAnOrderedPhase)) 
   {
    G->ChangeAlleles(SNP);
   // update phases
	
   for (SNPPos SNP2=(SNP+1);SNP2<(TotalSNPs-1);SNP2++)
   if (G->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2])) 
    G->ChangeAlleles(SNP2);
	   
   }//if changed
	}//for this gap
	LastLastResolved=LastResolved;
   LastResolved=SNP;
   } //end for each hetero SNP
   SNP++;
  } // for each SNP
  
 IndGenotype=GetNext(IndGenotype);
} // end for each individual
} // end for each gap


cout << "\nReconstruction has finished";
}
/*____________________________________________________________ */

void PhaseResolver::ResolvePhaseDecreasingDistances (bool UseMarkers=false)
{
char filepos[128];

ChangeExtension (filename, filepos, "pou");

unsigned short int MajorPhase;
SNPPos LastResolved, TotalSNPs=GetTotalSNPs(), SNP, NextHet, LastLastResolved;
cout << "\nReconstructing haplotypes...";
double distance;
Positions * Pos;
Pos=new Positions (filepos);
NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* G;
Block bl;
bool simpleDHAP;
unsigned short int Phase=1;
bool IsAnOrderedPhase;
block::NodePointer pB;
for (SNPPos gap=TotalSNPs-2;gap>0;gap--)
{
IndGenotype=GenotypeSample::GetFirst();
while (IndGenotype!=NULL)
{
  G=GetElement(IndGenotype);
  LastResolved=G->GetFirstHeterozygous(MajorAllele);
  SNP=LastResolved+1;
  
  while (SNP<TotalSNPs)
  {
 
   if (G->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) 
   {
    distance=Pos->GetDistance(LastResolved, SNP);
	if ((SNP-LastResolved-1)==gap)
	{
	Phase=AssignPhaseDecreasingHaps (LastResolved, SNP, MajorAllele, G);
        IsAnOrderedPhase=G->IsMajorMajor(MajorAllele[LastResolved], MajorAllele[SNP], G->GetDiplotype(LastResolved), G->GetDiplotype(SNP));
   if ((UseMarkers && G->IsMarked(SNP)) || !UseMarkers) 
   if ((Phase==1 && !IsAnOrderedPhase) || (Phase==2 && IsAnOrderedPhase)) 
   {
    G->ChangeAlleles(SNP);
   // update phases
	
   for (SNPPos SNP2=(SNP+1);SNP2<(TotalSNPs-1);SNP2++)
   if (G->GetDiplotype(SNP2).IsHeterozygous(MajorAllele[SNP2])) 
    G->ChangeAlleles(SNP2);
	   
   }//if changed
	}//for this gap
   LastResolved=SNP;
   } //end for each hetero SNP
   SNP++;
  } // for each SNP
  
 IndGenotype=GetNext(IndGenotype);
} // end for each individual
} // end for each gap


cout << "\nReconstruction has finished";
}
/*____________________________________________________________ */



};  // Fin del Namespace

#endif

/* Fin Fichero: PhaseResolver.h */
