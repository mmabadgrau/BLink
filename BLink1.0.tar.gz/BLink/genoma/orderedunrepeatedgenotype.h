/* File: Genotype.h */


#ifndef __OrderedUnrepeatedGenotype_h__
#define __OrderedUnrepeatedGenotype_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "orderedunrepeatedpositions.h"




using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class OrderedUnrepeatedGenotype {


protected:
    /** @name Implementation of class Genotype
        @memo Private part.
    */
	   typedef struct GenotypeS {

      /**
      @memo A pointer to the list of left alleles
      @doc  Each left allele contains a value {0,1,2,3,4}
      */
      allele *Left;

      /**
      @memo A pointer to the list of right alleles
      @doc Each right allele contains a value {0,1,2,3,4}
      */
      allele *Right;

   };  // end structure genotype


      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
   GenotypeS genotype;

   orderedunrepeatedpositions* pos;

   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

		void CheckRangeSNP(SNPPos SNP);



		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on Genotype 
        @memo Operations on a Genotype 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  OrderedUnrepeatedGenotype();


      /**
         @memo Copy constructor
         @param destino: Genotype where will be copy
         @param origen: Genotype to copy
         @doc
           Make a copy of Genotype
           Time complexity in time O(1).
        */
		  OrderedUnrepeatedGenotype (const OrderedUnrepeatedGenotype& Source);


		        /**
         @memo Copy constructor
         @param destino: Genotype where will be copy
         @param origen: Genotype to copy
         @doc
           Make a copy of Genotype
           Time complexity in time O(1).
        */
	
		  //Genotype (Genotype& Source, unsigned int *Sampling);



      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
      ~OrderedUnrepeatedGenotype ();

      /**
         @memo Assignation
         @param g Genotype to copy.
         @return Reference to the receptor Genotype.
	 @doc
           Copy the Genotype in the receptor Genotype.
           Time complexity O(1).

      */
      OrderedUnrepeatedGenotype& operator=(const OrderedUnrepeatedGenotype& g);




      /**
         @memo Is equal
         @param g: Genotype to compare with.
	 @return
           Return true if all the Genotype is the same, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator==(const OrderedUnrepeatedGenotype & g);
      /**
         @memo Is different
         @param g, position: Genotype to compare with.
	 @return
           Return true if the SNP is different, false otherwise.
         @doc Time complexity O(1).

      */
      bool operator!=(const OrderedUnrepeatedGenotype & g);

	  SNPPos GetTotalSNPs();
   
      void OrderSNPs ();

      void OrderMajorFirst (allele * MajorAllele);

	  allele GetLeftAllele (SNPPos position);

  	  allele GetRightAllele (SNPPos position);

	  bool IsEqual(OrderedUnrepeatedGenotype g, SNPPos position);

	  
      /**
         @memo Check if the genotype is non missing.
         @param g: pointer to the genotype to check.
         @return bool
         @doc Return a false if one or both alleles in the genotype are missing,
         return a true if both are non missing. Complexity O(1).

      */
        bool IsANonMissingSNP (SNPPos position);   


      /**
         @memo Check if the genotype is heterozygous
         @param g: pointer to the genotype to check.
         @return bool 
         @doc Return a false if the genotype snp is not heterozygous
         (it can be missing, homozygous wild type or homozygous mutant).
         return a true if the genotype snp is heterozygous.
         Complexity O(1).

      */
        bool IsHeterozygous (SNPPos position, allele *MajorAllele);             
      
		/**
         @memo Check if the genotype is homozygous for wild-type allele
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous wild-type
         (it can be missing, homozygous mutant or heterozygous).
         return a true if the genotype snp is homozygous wild-type.
         Complexity O(1).

      */
        bool IsHomozygous1 (SNPPos position, allele *MajorAllele);             

/**
         @memo Check if the genotype is homozygous for mutant allele
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous wild-type
         (it can be missing, homozygous mutant or heterozygous).
         return a true if the genotype snp is homozygous wild-type.
         Complexity O(1).

      */
        bool IsHomozygous2 (SNPPos position, allele *MajorAllele);             


/**
         @memo Check if the genotype is homozygous 
         @param position: pointer to the genotype to check,
         allele to check homozygosity.
         @return bool 
         @doc Return a false if the genotype snp is not homozygous 
         (it can be missing, or heterozygous).
         return a true if the genotype snp is homozygous.
         Complexity O(1).

      */
        bool IsHomozygous (SNPPos position, allele * MajorAllele);             


		void ChangeAlleles (SNPPos SNP);


		bool HaveTheSameHomoPos(OrderedUnrepeatedGenotype IndGenotype, SNPPos FirstPos, SNPPos LastPos, allele * MajorAllele);
 
 	  /**
         @memo Increase the counter of the total number of known haplotypes between two positions.
         @param comb: pointer to a 5-integer array: 1: 11, 2:12, 3: 21, 4: 22
         @param IndGenotype: individual whose haplotype is going to be checked
         @param FirstSNP, LastSNP: the two loci
     */
     
		void CountPairwiseHaps (frequencies comb, SNPPos FirstSNP, SNPPos LastSNP, allele *MajorAllele);

		bool IsAMissingSNP (SNPPos position);

		void SetAlleles (allele LeftValue, allele RightValue, SNPPos SNP);

		void PrintGenotype(SNPPos SNP);

		void PrintCompleteGenotype();


};  // End of class Genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


OrderedUnrepeatedGenotype::OrderedUnrepeatedGenotype()
{
 // this->TheFirstGenotype=NULL;
  pos=NULL;
  genotype.Left=NULL;
  genotype.Right=NULL;
}

/*____________________________________________________________ */


OrderedUnrepeatedGenotype::OrderedUnrepeatedGenotype (const OrderedUnrepeatedGenotype & source)
{
pos=source.pos;

SNPPos TotalSNPs=GetTotalSNPs();
 
try
{
if ((genotype.Left=new allele[TotalSNPs])==NULL)
   throw NoMemory();
if ((genotype.Right=new allele[TotalSNPs])==NULL)
   throw NoMemory();

for (int i=0;i<TotalSNPs;i++)
{
genotype.Left[i]=source.genotype.Left[i];
genotype.Right[i]=source.genotype.Right[i];
}
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}               
}

/*____________________________________________________________ */

OrderedUnrepeatedGenotype::~OrderedUnrepeatedGenotype ()
{
 if (genotype.Left != NULL)
  delete genotype.Left;
 if (genotype.Right != NULL)
  delete genotype.Right;

}
/*____________________________________________________________ */

SNPPos OrderedUnrepeatedGenotype::GetTotalSNPs()
{
return	pos->GetTotalSNPs();
}


/*____________________________________________________________ */

void OrderedUnrepeatedGenotype::OrderMajorFirst(allele * MajorAllele)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

     SNPPos TotalSNPs=pos->GetTotalSNPs();


      for (SNPPos i=0; i<TotalSNPs;i++)
	  {
      if (IsHeterozygous(i, MajorAllele) && genotype.Left[i]!=MajorAllele[i])
 	   change (genotype.Left[i], genotype.Right[i]);
	 }

  cout <<"Sorting Left/Right has finished\n";
}

/*____________________________________________________________ */



bool OrderedUnrepeatedGenotype::IsHeterozygous (const SNPPos position, allele * MajorAllele)
{
CheckRangeSNP(position);

bool Heterozygous=false;
allele LeftValue=genotype.Left[position];
allele RightValue=genotype.Right[position];

if (IsANonMissingSNP(position))
if ((LeftValue==MajorAllele[position] && RightValue!=MajorAllele[position]) ||
(LeftValue!=MajorAllele[position] && RightValue==MajorAllele[position]))
 Heterozygous = true;
return Heterozygous;
}

/*___________________________________________________*/


bool OrderedUnrepeatedGenotype::IsHomozygous1 (SNPPos position, allele * MajorAllele)
{
CheckRangeSNP(position);
allele LeftValue=genotype.Left[position];
allele RightValue=genotype.Right[position];

return IsANonMissingSNP(position) && LeftValue==MajorAllele[position] && RightValue==MajorAllele[position];
}

/*___________________________________________________*/


bool OrderedUnrepeatedGenotype::IsHomozygous2 (SNPPos position, allele * MajorAllele)
{
CheckRangeSNP(position);
allele LeftValue=genotype.Left[position];
allele RightValue=genotype.Right[position];

return IsANonMissingSNP(position) && LeftValue!=MajorAllele[position] && RightValue!=MajorAllele[position];
};

/*___________________________________________________*/


bool OrderedUnrepeatedGenotype::IsHomozygous (SNPPos position, allele * MajorAllele)
{
return (IsHomozygous1(position, MajorAllele)) ||  (IsHomozygous2(position, MajorAllele));
};



/*___________________________________________________*/

bool OrderedUnrepeatedGenotype::IsEqual(OrderedUnrepeatedGenotype g, SNPPos position)
{
CheckRangeSNP(position);
g.CheckRangeSNP(position);

return  genotype.Left[position]==g.genotype.Left[position] && 
genotype.Right[position]==g.genotype.Right[position];

}

/*____________________________________________________________ */
           
bool OrderedUnrepeatedGenotype::IsANonMissingSNP (SNPPos position)
{
CheckRangeSNP(position);
return genotype.Left[position]!=0 && genotype.Right[position]!=0;
}
/*____________________________________________________________ */
           
bool OrderedUnrepeatedGenotype::IsAMissingSNP (SNPPos position)
{
return !IsANonMissingSNP(position);
}

/*___________________________________________________________ */

void OrderedUnrepeatedGenotype::ChangeAlleles (SNPPos SNP)
{
CheckRangeSNP(SNP);
switch (genotype.Left[SNP],genotype.Right[SNP]);
}


/*__________________________________________________________*/
void OrderedUnrepeatedGenotype::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}
/*__________________________________________________________*/

allele OrderedUnrepeatedGenotype::GetLeftAllele (SNPPos position)
{
	return genotype.Left[position];
}
/*__________________________________________________________*/

allele OrderedUnrepeatedGenotype::GetRightAllele (SNPPos position)
{
	return genotype.Right[position];
}


/*_____________________________________________________________*/

bool OrderedUnrepeatedGenotype::HaveTheSameHomoPos(OrderedUnrepeatedGenotype IndGenotype, SNPPos FirstPos, SNPPos LastPos, allele * MajorAllele)
{
CheckRangeSNP(FirstPos);
CheckRangeSNP(LastPos);
IndGenotype.CheckRangeSNP(FirstPos);
IndGenotype.CheckRangeSNP(LastPos);

bool same=true;
SNPPos pos=FirstPos;
while ((same) && (pos<=LastPos))
{
 if ((IsHomozygous1(pos, MajorAllele) && !(IndGenotype.IsHomozygous1(pos, MajorAllele)))      
	 ||
	(IsHomozygous2(pos, MajorAllele) && !(IndGenotype.IsHomozygous2(pos, MajorAllele)))) 
same=false;
pos++;
}
return same;
}
/*_____________________________________________________________*/

void OrderedUnrepeatedGenotype::CountPairwiseHaps (frequencies comb, SNPPos FirstSNP, SNPPos LastSNP, allele * MajorAllele)
{
// 0: 11
// 1: 12 
// 2: 21
// 3: 22 
// 4: HH // individuals HH
if (IsHomozygous1(FirstSNP, MajorAllele) && IsHomozygous1(LastSNP, MajorAllele))
 comb[0]+2;
if (IsHomozygous2(FirstSNP, MajorAllele) && IsHomozygous2(LastSNP, MajorAllele))
 comb[3]+2;
if (IsHomozygous1(FirstSNP, MajorAllele) && IsHomozygous2(LastSNP, MajorAllele))
 comb[1]+2;
if (IsHomozygous2(FirstSNP, MajorAllele) && IsHomozygous1(LastSNP, MajorAllele))
 comb[2]+2;
if (IsHomozygous1(FirstSNP, MajorAllele) && IsHomozygous1(LastSNP, MajorAllele))
 comb[0]+2;

if (IsHomozygous1(FirstSNP, MajorAllele) && IsHeterozygous(LastSNP, MajorAllele))
{
 comb[0]++;
 comb[1]++;
}
if (IsHomozygous2(FirstSNP, MajorAllele) && IsHeterozygous(LastSNP, MajorAllele))
{
 comb[2]++;
 comb[3]++;
}
if (IsHeterozygous(FirstSNP, MajorAllele) && IsHomozygous1(LastSNP, MajorAllele))
{
 comb[0]++;
 comb[2]++;
}
if (IsHeterozygous(FirstSNP, MajorAllele) && IsHomozygous2(LastSNP, MajorAllele))
{
 comb[1]++;
 comb[3]++;
}
if (IsHeterozygous(FirstSNP, MajorAllele) && IsHeterozygous(LastSNP, MajorAllele))
comb[4]++;
}
/*_____________________________________________________________*/

void OrderedUnrepeatedGenotype::SetAlleles (allele LeftValue, allele RightValue, SNPPos SNP)
{
 genotype.Left[SNP]=LeftValue;

 genotype.Right[SNP]=RightValue;
}
/*____________________________________________________________ */

OrderedUnrepeatedGenotype & OrderedUnrepeatedGenotype::operator=(const OrderedUnrepeatedGenotype & Source)
{
pos=Source.pos;
	
SNPPos TotalSNPs=GetTotalSNPs();
 
try
{
if (genotype.Left!=NULL)
 if ((genotype.Left=new allele[TotalSNPs])==NULL)
   throw NoMemory();

if (genotype.Left!=NULL)
 if ((genotype.Right=new allele[TotalSNPs])==NULL)
   throw NoMemory();

for (int i=0;i<TotalSNPs;i++)
{
genotype.Left[i]=Source.genotype.Left[i];
genotype.Right[i]=Source.genotype.Right[i];
}
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}               
}

/*____________________________________________________________ */

void OrderedUnrepeatedGenotype::PrintGenotype(SNPPos SNP)
{

      OutputFile << genotype.Left[SNP] << ' ';
      OutputFile << genotype.Right[SNP] << ' ';


}
/*____________________________________________________________ */

void OrderedUnrepeatedGenotype::PrintCompleteGenotype()
{
SNPPos TotalSNPs=pos->GetTotalSNPs();

for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
{
      PrintGenotype(SNP);
}

}
};  // End of Namespace

#endif

/* End of file: Genotype.h */




