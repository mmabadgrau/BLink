echo Change to a subdirectory of the genoma fold
echo Convert to ped format
# chromosome="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
 chromosome="22"
# chromosome="5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 X"
for a in $chromosome
do
# echo $a 
inputfile=("genotypes_chr"$a"_txt_gz.txt")
outputfile=("chromosome"$a"july2004.txt")
 originalfile=("genotypes_chr"$a".txt.gz")
 mv $originalfile $inputfile
../hapmap $inputfile 90 $outputfile
echo Converted to dhap format
#
inputfile=$outputfile
outputfile=("chromosome"$a"july2004.ped")
outputfile2=("chromosome"$a"OnlyChildrenjuly2004.ped")
posfile=("chromosome"$a"july2004.poo")
l=`wc $posfile -l`
l2="c"
index=`expr index "$l" "$l2"`
pos=1
index2=$index-3
b=${l:pos:index2}
../ChangeFormat e MAKEPED $inputfile $outputfile c 1 $b 90 2
../ChangeFormat e MAKEPED $inputfile $outputfile2 c 1 $b 90 1 
echo Converted to ped format
inputfile=("chromosome"$a"july2004.poo")
outputfile=("chromosome"$a"july2004.info")
outputfile2=("chromosome"$a"OnlyChildrenjuly2004.info")
../../proyecto/ChangeFormat $inputfile $outputfile $b 1 -2 0 "MARKER "  
cp $outputfile $outputfile2
 echo -n "Converted file " 
echo -n $inputfile
echo -n " in " 
 echo $outputfile
done
