
#ifndef __Excep__
#define __Excep__
#include<sstream>
#include <sys/stat.h>  
#include <iostream>
#include <cassert>
#include <fstream>
#include <string>
#include <iostream>
#include <cmath>
#include <stdio.h>//


using namespace std;




class MultiAllelic {
public:
        void PrintMessage(unsigned long int pos) {
                cout << "\nThere is a Multiallelic SNP at position " << pos<<".\n";
		exit(1);
	}
		        void PrintMessage() {
                cout << "\nThere is a Multiallelic SNP.\n";
		exit(1);
	}

};
class MonoAllelic {
public:
        void PrintMessage(unsigned long int pos) {
                cout << "\nThere is a Monoallelic SNP at position " << pos<<".\n";
		exit(1);
	}
		        void PrintMessage() {
                cout << "\nThere is a Monoallelic SNP.\n";
		exit(1);
	}

};

class Inconsistent {
public:
        void PrintMessage(unsigned long int pos) {
                cout << "\nThere is an inconsistent SNP at position " << pos<<".\n";
		exit(1);
	}
		        void PrintMessage() {
                cout << "\nThere is an inconsistent SNP \n";
		exit(1);
	}

};

class OutOfRange {
public:
        void PrintMessage(unsigned int value) {
                cout << "Some metric for SNP " << value << " is out of range.\n";
		exit(1);
		}
		 void PrintMessage() {
                cout << "Some metric is out of range.\n";
		exit(1);
		}
		 void PrintMessage(char * message) {
                cout << "Some metric is out of range at " << message <<".\n";
		exit(1);
		}
};
class UnorderedPos {
public:
        void PrintMessage() {
                cout << " Positions are not ordered.\n";
		exit(1);
	}
};




class IncorrectParameters {
public:
        void PrintMessage() {
                cout << "\nEspecified number of individuals y/or number of SNPs do not match with those in the file.\n";
		exit(1);
	}
};


class IncorrectAlgorithm {
string cad;
public:

IncorrectAlgorithm (char* cad) {this->cad=string(cad);}
        void PrintMessage() {

         cout << "Error, algorithm " << cad << " is not allowed";
	exit(1);
	}
};


class IncorrectWay {
public:
        void PrintMessage() {

         cout << "Error, way must be e (for Export) or i (for import)";
	exit(1);
	}
};



class NonHetero {
public:
        void PrintMessage(unsigned int position, int ind=-1) {

         cout << "Error, the position " << position << " is not heterozygotic";
		 if (ind>=0) cout << " for individual " << ind;
	exit(1);
	}
};


class NonExist {
public:
        void PrintMessage(unsigned int position) {

         cout << "Error, the position " << position << " does not exist\n";
	exit(1);
	}
};


class OverflowedSNP {
public:
        void PrintMessage(unsigned long int SNP) {

         cout << "Error, the SNP number " << SNP << " overpass the total number of SNPs\n";
	exit(1);
	}
		void PrintMessage(unsigned long int SNP, char* message) {

         cout << "Error, the SNP number " << SNP << " overpass the total number of SNPs at " << message <<"\n";
	exit(1);
	}
};
class NonFound {
public:
        void PrintMessage() {

         cout << "Error, individual has not been found\n";
	exit(1);
	}
};


class UnsolvedPhase {
public:
        void PrintMessage() {

         cout << "Error, phase non solved\n";
	exit(1);
	}
};



#endif
