/* File: OrderedUnrepeatedGenoma.h */


#ifndef __OrderedUnrepeatedGenoma_h__
#define __OrderedUnrepeatedGenoma_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "positions.h"

using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo OrderedUnrepeatedGenoma for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
class OrderedUnrepeatedGenoma {


protected:

    /** @name Implementation of class OrderedUnrepeatedGenoma
        @memo Private part.
    */
      /**
      @memo A pointer to the list of left alleles
      @doc  Each left allele contains a value {0,1,2,3,4}
      */

	  typedef list<Diplotype> *DL;
	  
	  DL DiplotypeList;

         

      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

      void CheckRangeSNP(SNPPos SNP);

      void OrderSNPs ();

  	  void PrintOrderedUnrepeatedGenoma(SNPPos SNP);

  	  void PrintCompleteOrderedUnrepeatedGenoma();




		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on OrderedUnrepeatedGenoma 
        @memo Operations on a OrderedUnrepeatedGenoma 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  OrderedUnrepeatedGenoma();


      /**
         @memo Copy constructor
         @param destino: OrderedUnrepeatedGenoma where will be copy
         @param origen: OrderedUnrepeatedGenoma to copy
         @doc
           Make a copy of OrderedUnrepeatedGenoma
           Time complexity in time O(1).
        */
		  OrderedUnrepeatedGenoma (const OrderedUnrepeatedGenoma& Source);



		        /**
         @memo Copy constructor
         @param destino: OrderedUnrepeatedGenoma where will be copy
         @param origen: OrderedUnrepeatedGenoma to copy
         @doc
           Make a copy of OrderedUnrepeatedGenoma
           Time complexity in time O(1).
        */
	
		  //OrderedUnrepeatedGenoma (OrderedUnrepeatedGenoma& Source, unsigned int *Sampling);



      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
      ~OrderedUnrepeatedGenoma ();

   
	  SNPPos GetTotalSNPs();
   

	  void PrintOrderedOrderedUnrepeatedGenoma();
 
	  void SetOrderedUnrepeatedGenoma (const LD & DiplotypeListSource);

};  // End of class OrderedUnrepeatedGenoma



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


OrderedUnrepeatedGenoma::OrderedUnrepeatedGenoma(): genotype(), phenotype()
{
}

/*____________________________________________________________ */


OrderedUnrepeatedGenoma::OrderedUnrepeatedGenoma (const OrderedUnrepeatedGenoma & source):genotype(source), phenotype(source)
{


}

/*____________________________________________________________ */

OrderedUnrepeatedGenoma::~OrderedUnrepeatedGenoma ()
{
 if (DiplotypeList != NULL)
  delete DiplotypeList;

}


/*____________________________________________________________ */

void OrderedUnrepeatedGenoma::PrintCompleteOrderedUnrepeatedGenoma()
{
list<Diplotype>::NodePointer p=DiplotypeList->GetFirst();
while (p!=NULL)
{
	DiplotypeList->PrintDiplotype();
    p=DiplotypeList->GetNext(p);
}
}
/*____________________________________________________________ */

void OrderedUnrepeatedGenoma::PrintOrderedOrderedUnrepeatedGenoma()
{
  OrderSNPs();

  PrintCompleteOrderedUnrepeatedGenoma();
}
/*___________________________________________________*/

SNPPos OrderedUnrepeatedGenoma::GetHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, TrioGenotype Trio)      
{
	PairGenotype PG;
	if IsAnOffspring(): PG=PairGenotype(Trio.FatherGenotype, Trio.MotherGenotype); 
	if IsAFather():  PG=PairGenotype(Trio.ChildGenotype, Trio.MotherGenotype);
	if IsAMother():	PG=PairGenotype(Trio.ChildGenotype, Trio.FatherGenotype); 
    
 
	SNPPos Total=OrderedUnrepeatedGenotype::GetHap(SNP1, SNP2, IsMajor, IsMajor);
	
	if (Total==0) Total=GetInferredHap(SNP1, SNP2, IsMajor, IsMajor, PG);

	if (Total==0) Total=GetPartiallySolved(SNP1, SNP2, IsMajor, IsMajor, Trio);
	
	return Total;
};
/*___________________________________________________*/

bool OrderedUnrepeatedGenoma::CanBeInferred (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele, PairGenotype PG)      
{
// Karnaugh map: 1111/1010/1100/1000  Rows and columns labels: OO, OH, HO, HH
Trio T=(this, PG.GetFirst(), PG.GetSecond());
if (IsKnown(SNP1,SNP2)==false && T.IsComplete(SNP1, SNP2)==true && T.IsHetero(SNP1, SNP2)==false)

if ((PG.FirstGenotype.IsHomozygousHomozygous(SNP1, SNP2, MajorAllele) || PG.SecondGenotype.IsHomozygousHomozygous(SNP1, SNP2, MajorAllele))
|| 	(PG.FirstGenotype.IsHomozygous(SNP1, MajorAllele) && PG.SecondGenotype.IsHeterozygous(SNP2, MajorAllele)) 
||  (PG.FirstGenotype.IsHeterozygous(SNP2, MajorAllele) && PG.SecondGenotype.IsHomozygous(SNP1, MajorAllele))) 
return true;
else return false;
}
/*___________________________________________________*/

void TrioGenotype::GetLeftRight (SNPPos SNP1, SNPPos SNP2, genotype::Diplotype & First, Diplotype & Second)      
{
if (PG->FirstGenotype.IsHomozygous(SNP1) && TargetGenotype.GetLeftAllele(SNP1)!=PG->FirstGenotype.GetLeftAllele(SNP1))
{
	First.Left=TargetGenotype.GetRightAllele(SNP1);
	First.Right=TargetGenotype.GetLeftAllele(SNP1);
}
else
if (PG->SecondGenotype.IsHomozygous(SNP1) && TargetGenotype.GetRightAllele(SNP1)!=PG->FirstGenotype.GetLeftAllele(SNP1))
{
	First.Left=TargetGenotype.GetRightAllele(SNP1);
	First.Right=TargetGenotype.GetLeftAllele(SNP1);
}
}
/*___________________________________________________*/

SNPPos TrioGenotype::GetInferredHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, PairGenotype PG)      
{
Diplotype First=Diplotype(0,0), Second=Diplotype(0,0);

if (CanBeInferred(SNP1,SNP2)) 
{
	GetLeftRigh(SNP1, SNP2, First, Second);
	return (GetKnownHap(First, Second, IsMajor1, IsMajor2));
}
return 0;
}
/*___________________________________________________*/

SNPPos TrioGenotype::GetPartiallySolved (SNPPos SNP1, SNPPos SNP2, TrioGenotype Trio)      
{
if (Trio.FatherGenotype.IsHeterozygousHeterozygous(SNP1, SNP2, MajorAllele) 
&& Trio.MotherGenotype.IsHeterozygousHeterozygous(SNP1, SNP2, MajorAllele)
&& Trio.ChildGenotype.IsHomozygousHeterozygous(SNP1, SNP2, MajorAllele)) 

if (IsAFather())
if ((IsMajor1 && IsMajor2) || (!IsMajor1 && !IsMajor2))
return 1;

if (IsAMother())
if ((IsMajor1 && !IsMajor2) || (!IsMajor1 && IsMajor2))
return 1;

return 0;
}

};  // End of Namespace

#endif

/* End of file: OrderedUnrepeatedGenoma.h */




