  /**
    * @file HapBlockingFromIndividualSample.cpp
    * @brief Program to compute block by using Confidence Intervals (Gabriel method). It computes CI as part of the method, opposite to HapBlocking.cpp, which uses files with already computed CI.
    *
    */

#include "../commonc++/Fachade.h"
#include "Tables2x2.h"
#include "SNP.cpp"

#include "PairwiseMeasuresResults.h"
//#include "sample.h"
#include "blockCI.h"



namespace BIOS 
	 {

float Width=500000;

SNPPos TotalSNPs;

char filename[256], filename2[256], filepos[256];
PhaseType PhaseMode=ResolveFromTU;
IndCategory ic=everybody;
BayesType bayesMode=MLE;
double MAF=0, alphaBayes=0, alpha=90;
bool EurOrAs=true;
SNPPos SNPRange;

/*****************/
void ReadData(int argc, char*argv[])
{
if(argc<2)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <input file> "  << " <output file> " << "<phase type (0: (trios: standard phase, unrelated: not changed) /1: (trios: partially solved, unrelated: leftright (known phase))>" << "<ind category (father=0, mother=1, offspring=2, everybody=3, parent=4)>" << "<Bayes type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium/4:Bayes distance Uniform/5:Bayes distance symmetrical)>" << "<alphaBayes Bayes>" << "<MAF>" << "<Eur or asiatic (default: 1 -true-)>" << "<max width (0: default=500kb, -1: only consecutives)>" << "<alpha (default:90)>";  
        exit(-1);
        }
        

	 strcpy(filename, argv[1]);

	 if (argc>=3)
   	 strcpy(filename2, argv[2]);
	 else
	ChangeExtension (filename, filename2, "bl");
	 
 
if (argc>=4) PhaseMode=(PhaseType) atoi(argv[3]);

if (argc>=5) ic=(IndCategory) atoi(argv[4]);

if (argc>=6) bayesMode=(BayesType)atoi(argv[5]);

if (argc>=7) alphaBayes=atof(argv[6]);

if (argc>=8) MAF=atof(argv[7]);

if (argc>=9) EurOrAs=atof(argv[8]);

if (argc>=10) Width=atof(argv[9]);

if (Width==0) Width=500000;

if (argc>=11) alpha=atof(argv[10]);


}


} //end namespace
/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

ReadData(argc, argv);
     
		 

GenomaSample *Sample;
Positions * Pos;
BlockList * blocks;
Table2x2 T2x2;
double fA, fB, fAB;
PairwiseMeasure<GenomaSample>* PM;
float distance;
int cont;
ChangeExtension (filename, filepos, "pou");
Pos=new Positions (filepos);
Sample=new GenomaSample (filename);
TotalSNPs=Pos->VirtualPositions::GetTotalSNPs();
if (TotalSNPs!=Sample->GetTotalSNPs())
{
cout <<"Error, there are " << TotalSNPs << " positions but " << Sample->GetTotalSNPs() << " SNPs";
end();
}


SNPPos lastSNP=Pos->GetTotalSNPs(0, Width);

DiagonalTable<float>* UpperBound, *LowerBound;

UpperBound=new DiagonalTable<float>(TotalSNPs);
LowerBound=new DiagonalTable<float>(TotalSNPs);
LowerBound->initialize(2);
UpperBound->initialize(2);

MonolociMeasure<GenomaSample> MM = MonolociMeasure<GenomaSample>(Sample, ic, bayesMode);
	bool ListUsedSNPs[TotalSNPs];
	for (SNPPos SNP=0;SNP<TotalSNPs;SNP++) 
 	 ListUsedSNPs[SNP]=false;
IndPos total=0, top;
Pair<double> pair;


for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
 for (SNPPos SNP2=SNP+1; SNP2<(SNP+Pos->GetTotalSNPs(SNP, Width)); SNP2++)
  if (SNP2<TotalSNPs)
  if (MM.GetTotalFreqAllele(SNP, false)>=MAF && MM.GetTotalFreqAllele(SNP2, false)>=MAF)
 //  if (MM.GetTotalMissing(SNP)!=0 && MM.GetTotalMissing(SNP2)!=0) 
   {

distance=(float)Pos->GetDistance(SNP, SNP2);

	PM = new PairwiseMeasure<GenomaSample>(SNP, SNP2, Sample, ic, bayesMode, alphaBayes, distance, false);// false means not OnlyKnown
	fAB=PM->GetfAB();
        fA=PM->GetfA();
        fB=PM->GetfB();

	pair=T2x2.GetQuantilesDPrime(alpha, fA, fB, fAB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown(), bayesMode);
	UpperBound->setValue(SNP, SNP2, pair.Second);
	LowerBound->setValue(SNP, SNP2, pair.First);
	ListUsedSNPs[SNP]=true;
	ListUsedSNPs[SNP2]=true;

   }
//end();
//cout << *UpperBound;
blockCI *blockCI1;



 if ((blockCI1 = new blockCI(Pos, UpperBound, LowerBound, TotalSNPs, Width, EurOrAs, &(ListUsedSNPs[0])))==NULL)
 throw NoMemory();

blockCI1->WriteBlocks(filename2);

cout << blockCI1->GetSize() << " blocks have been obtained\n";

//zap(UpperBound);
//zap(LowerBound);
return 0;


}









