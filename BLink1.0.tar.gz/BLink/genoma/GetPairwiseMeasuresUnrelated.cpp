/**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */

//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//

#include "SNP.h"

#include "Tables2x2.h"
#include "../commonc++/list.h"
#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Genoma.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "GenomaSample.h"
#include "PairwiseMeasure.h"



char line[3000];
/*______________________________________________________________*/
 

char* PrintHeading()
{
char* p=line;
strcpy(line, "First SNP,Position,Second SNP,Position,n(A),n(a),n(B),n(b),n(HH) (individuals),n(AB),n(Ab),n(aB),n(ab),f(A),f(B),f(AB),D,max D,DPrime,DPrimeLowerBound,DPrimeUpperBound,R2,Yules Q, Rho\n");
return p;
}

/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " << " <MAF> "  << " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium/4:Bayes distance Uniform/5:Bayes distance symmetrical>" 
		<< "< phase (0: not changed/2: leftright(known phase))>" <<"<invariant sites (0: no (default), 1: yes)>" << "<Selection file>" << endl;
        exit(-1);
        }
    
  char filename[256], filepos[256], filename2[256], filenameReduced[256], fileSel[128], filepos2[128], filepos3[128], filename3[128], ext[128];
  strcpy (filename, argv[1]);
  float MAF=atof(argv[2]);
  BayesType BayesMode=(BayesType) atoi(argv[3]);
  IndCategory ic= everybody;
  AlleleOrderType AlleleOrderMode=(AlleleOrderType) atoi(argv[4]);


bool Selection=false;
bool invariant=false;

if (argc>=6) invariant=atoi(argv[5]);

if (argc==7) 
{
	strcpy(fileSel, argv[6]);
	Selection=true;
}



  SNPPos size=1000;
  unsigned int nHH;
  double upperbound, lowerbound, alpha=90;




 
  
if (MAF==0.0 && invariant)
strcpy(ext, "invariant\0");
else strcpy(ext, "\0");



if (BayesMode==MLE)
sprintf(ext, "%sMAF%d-MLE.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceUniform)
sprintf(ext, "%sMAF%d-BDistanceUniform.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceSymmetrical)
sprintf(ext, "%sMAF%d-BDistanceSymmetrical.pm", ext, (int)(MAF*100));
  
  
ChangeExtension (filename, filename2, ext);





try
{
  OutputFile.open (filename2, ofstream::out);
  if (!OutputFile) throw ErrorFile();
}
catch (ErrorFile NoFile) {NoFile.PrintMessage();}
GenomaSample *ts, *ts2;
//GenomaSample *gs;
Positions* Pos;
Table2x2 T2x2;
double distance;
ChangeExtension (filename, filepos, "pou");
Pair pair;
Pos=new Positions (filepos);

ts=new GenomaSample (filename, AlleleOrderMode);

if (Selection) ts2=new GenomaSample (fileSel, AlleleOrderMode);


//ChangeExtension (filename, filenameReduced, "red");
//ts->WriteResults(filenameReduced, true, ic, (SNPPos)0, (SNPPos)100);//last number is the SNP to be printed
OutputFile << "file source:" << filename <<", Bayes type:" << BayesMode << ", IndCategory:" << ic <<", Phase mode:" << AlleleOrderMode <<"\n";
OutputFile << PrintHeading();
double fAB, fA, fB, DPrime, MaxDPrime;
SNPPos SNP2, TotalSNPs=ts->GetTotalSNPs(), total;
PairwiseMeasure<GenomaSample> *PM;
MonolociMeasure<GenomaSample> MM = MonolociMeasure<GenomaSample>(ts, (BayesType)0, ic);
MonolociMeasure<GenomaSample> MM2 = MonolociMeasure<GenomaSample>(ts2, (BayesType)0, ic);

for (SNPPos SNP=0; SNP<(TotalSNPs-1);SNP++)
//for (SNPPos SNP=100; SNP<101;SNP++)
 if (ts->GetTotalMissing(SNP, ic)==0) 
 if (MM.GetTotalFreqAllele(SNP, false)>MAF)
	 if (!Selection || (MM2.GetTotalFreqAllele(SNP, false)>MAF && MM2.GetTotalFreqAllele(SNP, true)>MAF)) 
 {
 //if (SNP%100==0)
 cout <<"\nsnp:" << SNP+1;

 for (SNPPos SNP2=SNP+1; SNP2<TotalSNPs;SNP2++)
  if (ts->GetTotalMissing(SNP2, ic)==0) 
  if (MM.GetTotalFreqAllele(SNP2, false)>MAF)
 	 if (!Selection || (MM2.GetTotalFreqAllele(SNP2, false)>MAF && MM2.GetTotalFreqAllele(SNP2, true)>MAF)) 
 {
 distance=Pos->GetDistance(SNP, SNP2);
 PM = new PairwiseMeasure<GenomaSample>(SNP, SNP2, ts, BayesMode, ic, distance);


 fA=PM->GetfA();
 fB=PM->GetfB();
 fAB=PM->GetfAB();
 DPrime=T2x2.GetDPrime(fAB, fA, fB);
 OutputFile 
	 << SNP+1 << ", " << Pos->PrintPosition(SNP)  << ", ";
 OutputFile
	 << SNP2+1 << ", " << Pos->PrintPosition(SNP2)  << ", " 
   	 << ts->GetTotalAllele(SNP, true, ic) << ", " 
   	 << ts->GetTotalAllele(SNP, false, ic) << ", " 
   	 << ts->GetTotalAllele(SNP2, true, ic) << ", " 
  	 << ts->GetTotalAllele(SNP2, false,  ic) << ", ";
  OutputFile << ts->GetUnsolvedDoubleHeterozygous(SNP, SNP2, ic) << ", ";
  OutputFile
	 << PM->GetnAB() <<", "
 	 << PM->GetnAb() <<", "
	 << PM->GetnaB() <<", "
	 << PM->Getnab() <<", "
	 << fA <<", "
 	 << fB <<", "
	 << fAB <<", "
	 << T2x2.GetD(fAB, fA, fB) <<", "
	 << T2x2.GetMaxD(fAB, fA, fB) <<", ";
 
 sprintf(line, "%1.2f, ", DPrime);
 OutputFile << line;
 
 sprintf(line, "%1.8f, ", T2x2.GetR2(fAB, fA, fB));
 OutputFile << line;

 MaxDPrime=T2x2.GetMaxDPrime(fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
 pair=T2x2.GetQuantilesDPrime(50-alpha/2, 50+alpha/2, fA, fB, PM->GetnAB(), PM->GetnAb(), PM->GetnaB(), PM->Getnab(), PM->GetTotalUnKnown());
 lowerbound=pair.First;
 upperbound=pair.Second;
 sprintf(line, "%1.2f, %1.2f, %1.2f,", MaxDPrime, lowerbound, upperbound);

 OutputFile << line;
 sprintf(line, "%1.2f, %1.2f, %1.2f\n", T2x2.GetR2(fAB, fA, fB), T2x2.GetQ(fAB, fA, fB), T2x2.GetRho(fAB, fA, fB));
 OutputFile << line;




 delete PM;
  } // end for each SNP2 a real SNP
 } // end for each SNP a real SNP

 cout << "\nInformation about pairwise measures has been saved in file " << filename2 <<"\n";
 
 OutputFile.close();

 delete Pos, ts;

 if (Selection) delete ts2;


};
