/* File: GenotypeSample.cpp */


#ifndef __GenotypeSample_cpp__
#define __GenotypeSample_cpp__

#include "SNP.cpp"
#include "GenotypeSample.h"


//using namespace UTILS;

namespace BIOS {




/*___________________________________________________________ */

Diplotype ReadDiplotype (list<Diplotype>* ld, ifstream * source, bool ExistPhenotypes=true)
//Diplotype::Diplotype GenotypeSample::ReadDiplotype (ifstream * source, unsigned long int size)

{
	char line[100], c1, c2;
	Diplotype::Diplotype Dip;
	char *genotypebuf; 
	genotypebuf=CaptureLine(source);
	char *cad, cadena[2], cadena2[2];
	cad = strtok (genotypebuf," \t");
        if (ExistPhenotypes==true)
 	 for (int phen=0;phen<7;phen++)
          cad = strtok (NULL," \t");

try
{
    while (cad!=NULL && ((strlen(cad)==2 && cad[0]=='-' && IsACorrectAllele(cad[1])) || IsACorrectAllele(cad[0])))
    {

	if (strlen(cad)==1 || (strlen(cad)==2 && cad[0]=='-'))
	{
	strcpy(cadena, "\0");
	sscanf (cad, "%s", cadena);
	Dip.SetLeftAllele(ConvertAllele(cadena));
	cad = strtok (NULL," \t");
    if (cad==NULL) 
	{
		sprintf(line, "ReadDiplotype::ReadElement, last value was: \"%s\"", cad);
//		cout <<"\nsi";
		throw NullValue();
	}
//		cout <<"Cad:\"" << cad <<"\"";

	sscanf (cad, "%s", cadena);
	Dip.SetRightAllele(ConvertAllele(cadena));
	//cout << Dip.PrintDiplotype();
    }
	else // if (strlen(cad)==2)

	{
	sscanf (cad, "%c%c", &c1, &c2);
    if (!IsACorrectAllele(c2)) 
	{   
		sprintf(line, "list<Diplotype>::ReadElement, value: \"%c\"", c2);
		throw NonSNP();
	}
	Dip.SetLeftAllele(ConvertAllele(&c1));
	Dip.SetRightAllele(ConvertAllele(&c2));
    }
	ld->insertElement(Dip);
	cad = strtok (NULL," \t");
//	cout << Dip.PrintDiplotype();
	}// end while
//cout <<"\n";
}
 catch (NullValue nv) { nv.PrintMessage(line);}   
 catch (NonSNP ns) { ns.PrintMessage(line);}   
delete genotypebuf;
}

/*________________________________________________________________________________________*/

template<> Genotype* list<Genotype*>::ReadElement (ifstream * source, char* tokens){
	

	list<Diplotype> *DiplotypeList;
	DiplotypeList=new list<Diplotype::Diplotype>();
	ReadDiplotype(DiplotypeList, source);
	
	SNPPos cont=0, TotalSNPs=DiplotypeList->GetSize();
	Genotype* targetGenotype; 
	targetGenotype= new Genotype(TotalSNPs);
	
	list<Diplotype::Diplotype>::NodePointer p=DiplotypeList->GetFirst();
	
	while (p!=NULL)
	{
		targetGenotype->SetDiplotype(DiplotypeList->GetElement(p), cont);
		p=DiplotypeList->GetNext(p);
		cont++;
	};
zap(DiplotypeList);
//cout <<targetGenotype->print();
//end();
return targetGenotype;
 };



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


//////////// privates /////////////



///////////////////
//// public ////////
///////////////////

//Diplotype list<Diplotype>::ReadElement (ifstream * source, unsigned long int size){	};

/*________________________________________________________________________________________*/

//template<> Genotype* list<Genotype*>::ReadElement (ifstream * source, char* tokens){
	/*
 Genotype* GenotypeSample::ReadElement (ifstream * source, char* tokens){
	 return Container<Genotype, ListOfPointers>::ReadElement(source, tokens);
 };

/*____________________________________________________________ */

GenotypeSample::GenotypeSample():Container<Genotype, ListOfPointers>()
{
MajorAllele=NULL;
MinorAllele=NULL;

}
 
/*____________________________________________________________ */

GenotypeSample::GenotypeSample (GenotypeSample& source):Container<Genotype, ListOfPointers>(source)
{
ExistPhenotypes=source.ExistPhenotypes;
AlleleOrderMode=source.AlleleOrderMode;
MajorAllele=NULL;
MinorAllele=NULL;
}
/*____________________________________________________________ */

GenotypeSample::GenotypeSample (Container<Genotype, ListOfPointers>& source, bool e, AlleleOrderType a):Container<Genotype, ListOfPointers>(source)
{
ExistPhenotypes=e;
AlleleOrderMode=a;
MajorAllele=NULL;
MinorAllele=NULL;
}

/*____________________________________________________________ */

GenotypeSample* GenotypeSample::copyElementsWithPositionsIn(intList* positions, bool inThis)
{
Container<Genotype, ListOfPointers> *res=this->Container<Genotype, ListOfPointers>::copyElementsWithPositionsIn(positions, inThis);

GenotypeSample* result= new  GenotypeSample(*res, this->ExistPhenotypes, this->AlleleOrderMode);

zap(res);

return result;
}

/*____________________________________________________________ */

GenotypeSample::GenotypeSample (char * filename,  bool  ExistPhen=true, AlleleOrderType AlleleOrderMod=MajorFirst):Container<Genotype, ListOfPointers>(filename)
{

MajorAllele=NULL;
MinorAllele=NULL;


AlleleOrderMode=AlleleOrderMod;
ExistPhenotypes=ExistPhen;

SetMinorAllele (NULL);

SetMajorAllele (NULL);

switch (AlleleOrderMode)
{
case NotChanged: 
case LeftRight: break;
case MajorFirst: OrderMajorFirst(); break;
case random: OrderRandomly(); break;
};

}
/*____________________________________________________________ */

GenotypeSample& GenotypeSample::operator=(const GenotypeSample & Source)
{

   if (&Source!=NULL)
    {
    
      if (this!=&Source)
      {

        if (this->GetFirst()!=NULL)
           destroy(this->GetFirst());
  
        copy (Source.List);

   
   ExistPhenotypes=Source.ExistPhenotypes;
  SetMajorAllele (NULL);
  SetMinorAllele (NULL);
  }
}

  return *this;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetTotalSNPs ()
{
return GetElement(GetFirst())->GetTotalSNPs();
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetTotalAllele (SNPPos SNP, bool IsMajor, const bool Marked[])
{
NodePointer IndGenotype=GetFirst();
Genotype *genotype;

SNPPos Total=0, cont=0;
while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 genotype=IndGenotype->element;
// if (genotype->GetDiplotype(SNP).IsANonMissingSNP())
 switch (IsMajor)
 {
 case true: if (genotype->GetDiplotype(SNP).IsHomozygous1 (MajorAllele[SNP])) Total=Total+2; 
			if (genotype->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) Total++; break;
 case false:if (genotype->GetDiplotype(SNP).IsHomozygous2(MajorAllele[SNP])) Total=Total+2;
			if (genotype->GetDiplotype(SNP).IsHeterozygous(MajorAllele[SNP])) Total++; break;
 }
 }
 IndGenotype=GetNext(IndGenotype);
 cont++;
}

return Total;
}
/*____________________________________________________________ */

allele GenotypeSample::getMajorAllele (SNPPos SNP, const bool Marked[])
{


if (MajorAllele==NULL) SetMajorAllele(Marked);


//cout <<MajorAllele[SNP] <<"-";
return MajorAllele[SNP];
}
/*____________________________________________________________ */

allele GenotypeSample::getMinorAllele (SNPPos SNP, const bool Marked[])
{


if (MinorAllele==NULL) SetMinorAllele(Marked);

//cout <<MinorAllele[SNP] <<"\n";
return MinorAllele[SNP];
}

/*____________________________________________________________ */

SNPPos GenotypeSample::GetHap(SNPPos SNP1, SNPPos SNP2, bool IsMajor1=true, bool IsMajor2=true, const bool Marked[]=NULL) 
{
NodePointer IndGenotype=GetFirst();
Genotype * genotype;
SNPPos Total=0, cont=0;
bool phased=false;

while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 genotype=IndGenotype->element;
 Total=Total+genotype->GetHap(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele, AlleleOrderMode);     
 }
 cont++;
 IndGenotype=GetNext(IndGenotype);
}

return Total;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetUnsolvedDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, const bool Marked[]=NULL)
{
SNPPos Total=0, cont=0;
NodePointer IndGenotype=GetFirst();
Genotype *G;

while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 G=IndGenotype->element;
 if (G->IsHeterozygousHeterozygous (FirstSNP, LastSNP, MajorAllele)) 
  if (G->CanBeSolved (FirstSNP, LastSNP, MajorAllele)==false)     
   Total=Total+1; 
 }
 IndGenotype=GetNext(IndGenotype);
 cont++;
}
 
return Total;
}
/*____________________________________________________________ */


    int* GenotypeSample::getAlleleFrequencies(allele alleleType, const bool Marked[])
{
SNPPos totalSNPs=GetTotalSNPs();
int * result=Initialize(totalSNPs, 0);
for (SNPPos i=0;i<totalSNPs;i++)
if (alleleType==N) // NA
result[i]=GetTotalType (i, missing, Marked)*2;
else if (MajorAllele[i]==alleleType)
 result[i]=GetTotalAllele(i, true, Marked);
else if (MinorAllele[i]=alleleType)
 result[i]=GetTotalAllele(i, false, Marked);
return result;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetLongPhasedHap(allele* Hap, const SNPPos Pos[], SNPPos TotalPos, allele * MajorAllele, const bool Marked[]=NULL) 
{
NodePointer IndGenotype=GetFirst();
Genotype * genotype;
SNPPos Total=0, cont=0;
bool phased=false;

if (Marked==NULL)
cout <<"null";

while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 genotype=IndGenotype->element;
 Total=Total+genotype->CountPhasedHap(Hap, Pos, TotalPos, MajorAllele);     
 }
 cont++;
 IndGenotype=GetNext(IndGenotype);
}

return Total;
}
/*____________________________________________________________ */

SNPPos GenotypeSample::GetnAB(SNPPos SNP1, SNPPos SNP2, const bool Marked[]=NULL)
{
return GetHap(SNP1, SNP2, true, true, Marked);
};  
/*____________________________________________________________ */

SNPPos GenotypeSample::GetnAb(SNPPos SNP1, SNPPos SNP2, const bool Marked[]=NULL)
{
return GetHap(SNP1, SNP2, true, false, Marked);
};  
/*____________________________________________________________ */

SNPPos GenotypeSample::GetnaB(SNPPos SNP1, SNPPos SNP2, const bool Marked[]=NULL)
{
return GetHap(SNP1, SNP2, false, true, Marked);
};  
/*____________________________________________________________ */

SNPPos GenotypeSample::Getnab(SNPPos SNP1, SNPPos SNP2, const bool Marked[]=NULL)
{
return GetHap(SNP1, SNP2, false, false, Marked);
};  
/*____________________________________________________________ */

void GenotypeSample::OrderMajorFirst ()
{
try
{

if (MajorAllele==NULL)
throw NullValue();

  NodePointer IndGenotype=GetFirst();
  Genotype *g;
  while (IndGenotype!=NULL)
  {
	  g=IndGenotype->element;
//cout << g->print() <<"\n";
	  g->OrderMajorFirst(MajorAllele);
	  IndGenotype=GetNext(IndGenotype);
  }
}
catch (NullValue nv)
{ nv.PrintMessage(" in GenotypeSample::OrderMajorFirst, MajorAllele is NULL");
}
}
/*____________________________________________________________ */

void GenotypeSample::OrderRandomly ()
{
  srand(24226616);
  NodePointer IndGenotype=GetFirst();
  Genotype *g;
  while (IndGenotype!=NULL)
  {
	  g=IndGenotype->element;
	  g->OrderRandomly(MajorAllele);
	  //ReplaceNode(IndGenotype, g);
	  IndGenotype=GetNext(IndGenotype);
  }
 //   cout <<"Sorting randomly has finished\n";

}

/*____________________________________________________________ */

void GenotypeSample::PrintHaplotypes (char* filename)
 {

  GenotypeSample::NodePointer IndGenotype=GetFirst();
  Genotype *genotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 

  SNPPos TotalSNPs=GetTotalSNPs();

while (IndGenotype!=NULL)
  {
   genotype=IndGenotype->element;
   OutputFile << genotype->print(left);     
   OutputFile << "\n";
   OutputFile << genotype->print(right);     
   OutputFile << "\n";
   IndGenotype=GetNext(IndGenotype);
  }
  OutputFile.close();

cout << "\nInformation about haplotypes has been saved in file " << filename <<"\n";
 }

/*____________________________________________________________ */

void GenotypeSample::PrintGenotypes (char* filename)
 {

  GenotypeSample::NodePointer IndGenotype=GetFirst();
  Genotype *genotype;
  ofstream OutputFile;
  OpenOutput(filename, &OutputFile); 

  SNPPos TotalSNPs=GetTotalSNPs();

while (IndGenotype!=NULL)
  {
   genotype=IndGenotype->element;
   OutputFile << genotype->print();     
   OutputFile << "\n";
   IndGenotype=GetNext(IndGenotype);
  }
  OutputFile.close();

cout << "\nInformation about genotypes has been saved in file " << filename <<"\n";
 }
/*__________________________________________________________*/

SNPPos GenotypeSample::GetTotalType (SNPPos SNP, GenotypeType type, const bool Marked[]=NULL)
{
GenotypeSample::NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype* genotype;
Diplotype Dip;
IndPos Total=0, cont=0;
while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 genotype=IndGenotype->element;
 Dip=genotype->GetDiplotype(SNP);
 switch (type)
 {
 case missing: if (Dip.IsAMissingSNP ()) Total++; break;
 case homozygous1: if (Dip.IsHomozygous1(MajorAllele[SNP])) Total++; break;
 case homozygous2: if (Dip.IsHomozygous2(MajorAllele[SNP])) Total++; break;
 case heterozygous: if (Dip.IsHeterozygous(MajorAllele[SNP])) Total++; break;
 }
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 cont++;
}
return Total;
}
/*___________________________________________________________*/

SNPPos GenotypeSample::GetTotalHomozygous1 (SNPPos SNP, const bool Marked[]=NULL)
{
	return (GetTotalType (SNP, homozygous1, Marked));
}
/*___________________________________________________________*/

SNPPos GenotypeSample::GetTotalHomozygous2 (SNPPos SNP, const bool Marked[]=NULL)
{
	return (GetTotalType (SNP, homozygous2, Marked));
}
/*___________________________________________________________*/

SNPPos GenotypeSample::GetTotalHeterozygous (SNPPos SNP, const bool Marked[]=NULL)
{
	return (GetTotalType (SNP, heterozygous, Marked));
}
/*___________________________________________________________*/

SNPPos GenotypeSample::GetTotalMissing (SNPPos SNP, const bool Marked[]=NULL)
{
	return (GetTotalType (SNP, missing, Marked));
}
/*___________________________________________________________*/

SNPPos GenotypeSample::GetTotalNonMissing (SNPPos SNP, const bool Marked[]=NULL)
{
	return GetTotalHomozygous1 (SNP, Marked)+GetTotalHomozygous2(SNP, Marked)+GetTotalHeterozygous(SNP, Marked);
}

/*____________________________________________________________ */

SNPPos GenotypeSample::GetDoubleHeterozygous (SNPPos FirstSNP, SNPPos LastSNP, const bool Marked[]=NULL)
{
SNPPos Total=0, cont=0;
NodePointer IndGenotype=GenotypeSample::GetFirst();
Genotype * G;
while (IndGenotype!=NULL)
{
 if (Marked==NULL || Marked[cont]==true)
 {
 G=IndGenotype->element;
 if (G->IsHeterozygousHeterozygous (FirstSNP, LastSNP, MajorAllele)) Total=Total+1; 
 }
 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 cont++;
 }
return Total;
}


/*____________________________________________________________ */

void GenotypeSample::CountAlleles (SNPPos SNP, unsigned int Basis[5], const bool Marked[]=NULL)
{
NodePointer IndGenotype=GenotypeSample::GetFirst();
IndPos cont=0;
InitializeList(Basis, (unsigned int)5, (unsigned int)0);

Genotype * genotype;

while (IndGenotype!=NULL)
{

if (Marked==NULL || Marked[cont]==true)
{
 genotype=GetElement(IndGenotype);

Basis[(int)genotype->GetLeftAllele(SNP)]++; 
Basis[(int)genotype->GetRightAllele(SNP)]++; 

 }

 IndGenotype=GenotypeSample::GetNext(IndGenotype);
 cont++;
}
unsigned int TotalUsed=0;
for (int c2=1;c2<=4;c2++)
 if (Basis[c2]>0) TotalUsed++;    
try
{
 if (TotalUsed>2)
 throw MultiAllelic();
}
catch (MultiAllelic ma) {ma.PrintMessage(SNP);}
}


/*____________________________________________________________ */

void GenotypeSample::SetMajorAllele(const bool Marked[]=NULL)
{
if (MajorAllele==NULL) 
MajorAllele=SetAllele(true, Marked);
} 
/*____________________________________________________________ */

void GenotypeSample::SetMinorAllele(const bool Marked[]=NULL)
{
if (MinorAllele==NULL) 
MinorAllele=SetAllele(false, Marked);
} 
/*____________________________________________________________ */

allele* GenotypeSample::SetAllele(bool major, const bool Marked[]=NULL)
{

if (major==true) zaparr(MajorAllele);
else zaparr(MinorAllele);

allele* alleleTable;

//cout <<"Computing major alleles...\n";
unsigned int TotalUsed;
unsigned int Basis[5], ChosenPos, ChosenVal;
// Basis first positions is for missing allele, 1 - 4 positions are for A, G, C, T respectively

SNPPos TotalSNPs=GetTotalSNPs();
try
{
if ((alleleTable=new allele[TotalSNPs])==NULL)
      throw NoMemory();
}

catch (NoMemory NM ) {NM.PrintMessage();}

for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
{
CountAlleles(SNP, Basis, Marked);
//cout <<"\nVals:";
//for (int i=0;i<5;i++)
//cout << Basis[i] <<"-";
//if (SNP>10) exit(0);

ChosenPos=GetMaxPos(&(Basis[1]),4)+1;
if (major==false)
{
Basis[ChosenPos]=0;
ChosenPos=GetMaxPos(&(Basis[1]),4)+1;
}
alleleTable[SNP]=(allele)ChosenPos;
}

return alleleTable;
} 

/*___________________________________________________________*/

void GenotypeSample::RemoveInconsistentIndividuals(SNPPos HomoPos, NodePointer IndGenotypeRef)
{
SNPPos Total=0, cont=0;
NodePointer IndGenotype=GetFirst();
Genotype *G, *GRef;
Diplotype D, DRef;
allele majorAllele=MajorAllele[HomoPos];
while (IndGenotype!=NULL)
{
 GRef=IndGenotype->element;
 G=IndGenotypeRef->element;
 D=G->GetDiplotype(HomoPos);
 DRef=GRef->GetDiplotype(HomoPos);
 if ((D.IsHomozygous1(majorAllele) && DRef.IsHomozygous2(majorAllele)) 
	 || (D.IsHomozygous2(majorAllele) && DRef.IsHomozygous1(majorAllele))) 
 removeNode(IndGenotype);
 IndGenotype=GetNext(IndGenotype);
}
};
/*_______________________________________________________________*/

void GenotypeSample::ExportForPHASE (Positions* Pos, char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();
ofstream OutputFile; 
//cout <<"Exporting to PHASE\n";

OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();


OutputFile << GetSize() << "\n";

OutputFile << TotalSNPs << "\n";

OutputFile << "P" << ' ';


for (SNPPos i=0; i<TotalSNPs;i++)

{
  OutputFile << Pos->GetPosition(i);
  if (i==(TotalSNPs-1))	OutputFile << "\n";
  else OutputFile << ' ';
}
for (SNPPos i=0; i<TotalSNPs;i++)
 OutputFile << "S";

OutputFile << "\n";

NodePointer IndGenotype=GetFirst();

unsigned short int *random=NULL;

Genotype* g;
Diplotype D;
if ((random=new unsigned short int[TotalSNPs])==NULL)
     throw NoMemory();

IndPos Ind=0;

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	
 OutputFile << "#" << Ind << "\n";
 for (SNPPos i=0; i<TotalSNPs;i++)
 {
 D=g->GetDiplotype(i);
 random[i]=rand() % (2);

 if (D.IsAMissingSNP())
  OutputFile << "?";
  else 
    OutputFile << D.GetLeftAllele();
    if (i==(TotalSNPs-1))
     OutputFile << "\n";
  else OutputFile << " ";
 }
 for (SNPPos i=0; i<TotalSNPs;i++)
 {
 D=g->GetDiplotype(i);
 if (D.IsAMissingSNP())  OutputFile << "?";
 else  OutputFile << D.GetRightAllele();
  
 if (i==(TotalSNPs-1))
	  OutputFile << "\n";
  else OutputFile << " ";
 }

  IndGenotype=IndGenotype->Next;
  Ind++;
}

OutputFile.close();
zaparr(random);
}
/*____________________________________________________________ */

void GenotypeSample::ExportForHTYPER (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

ofstream OutputFile; 

//cout <<"Exporting to HTYPER, file " << filename << "\n";

OpenOutput(filename, &OutputFile);

NodePointer IndGenotype=GetFirst();
Genotype* g;
Diplotype D;

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	

 for (SNPPos i=0; i<TotalSNPs;i++)
  {
  D=g->GetDiplotype(i);
  if (D.IsAMissingSNP()) OutputFile << "3";
  if (D.IsHeterozygous (MajorAllele[i])) OutputFile << "0";
  if (D.IsHomozygous1 (MajorAllele[i]))  OutputFile << "1";
  if (D.IsHomozygous2 (MajorAllele[i]))  OutputFile << "2";
  }
  OutputFile << "\n";
  IndGenotype=GetNext(IndGenotype);
}

OutputFile.close();
}
/*____________________________________________________________ */

void GenotypeSample::ExportForML (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

ofstream OutputFile; 

//cout <<"Exporting to ML, file " << filename << "\n";

OpenOutput(filename, &OutputFile);

NodePointer IndGenotype=GetFirst();
Genotype* g;
Diplotype D;

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	

 for (SNPPos i=0; i<TotalSNPs;i++)
  {
  D=g->GetDiplotype(i);
  if (D.IsHeterozygous (MajorAllele[i])) OutputFile << "0";
  if (D.IsAMissingSNP()) OutputFile << "?";
  if (D.IsHomozygous1 (MajorAllele[i]))  
  if (AlleleOrderMode==NotChanged || MajorAllele[i]<MinorAllele[i]) OutputFile << "1";
  else OutputFile <<"2";
  if (D.IsHomozygous2 (MajorAllele[i])) 
  if (AlleleOrderMode==NotChanged || MajorAllele[i]<MinorAllele[i]) OutputFile << "2";
  else OutputFile <<"1";
  if (i<(TotalSNPs-1)) OutputFile << ",";
  }
  OutputFile << "\n";
  IndGenotype=GetNext(IndGenotype);
}

OutputFile.close();

char filename2[256];
ChangeExtension(filename, filename2, "mas");
OpenOutput(filename2, &OutputFile);
for (SNPPos i=0;i<TotalSNPs;i++)
OutputFile << "0 SNP" << i <<": 0, 1, 2 //\n";
OutputFile.close();
}
/*____________________________________________________________ */

void GenotypeSample::ExportForMLHAP (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

ofstream OutputFile; 

//cout <<"Exporting to ML, file " << filename << "\n";

OpenOutput(filename, &OutputFile);

NodePointer IndGenotype=GetFirst();
Genotype* g;
Diplotype D;

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	

 for (SNPPos i=0; i<TotalSNPs;i++)
  {
  D=g->GetDiplotype(i);
  if (D.IsAMissingSNP()) OutputFile << "?";
  if (D.IsHeterozygous (MajorAllele[i]) && D.GetLeftAllele()==MajorAllele[i]) OutputFile << "12";
  if (D.IsHeterozygous (MajorAllele[i]) && D.GetLeftAllele()!=MajorAllele[i]) OutputFile << "21";
  if (D.IsHomozygous1 (MajorAllele[i]))  OutputFile << "11";
  if (D.IsHomozygous2 (MajorAllele[i]))  OutputFile << "22";
  if (i<(TotalSNPs-1)) OutputFile << ",";
  }
  OutputFile << "\n";
  IndGenotype=GetNext(IndGenotype);
}

OutputFile.close();

char filename2[256];
ChangeExtension(filename, filename2, "mas");
OpenOutput(filename2, &OutputFile);
for (SNPPos i=0;i<TotalSNPs;i++)
OutputFile << "0 SNP" << i <<": 12, 21, 11, 22 //\n";
OutputFile.close();
}


/*____________________________________________________________ */

void GenotypeSample::ExportForSNPHAP (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

//cout <<"Exporting to SNPHAP\n";
ofstream OutputFile;


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

Genotype* g;
Diplotype D;

NodePointer IndGenotype=GetFirst();

unsigned int last=TotalSNPs-1;


IndPos Ind=1;

char a[2];

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	
 OutputFile << Ind << " ";
 for (SNPPos i=0; i<TotalSNPs;i++)
 {
 D=g->GetDiplotype(i);
 if (D.IsAMissingSNP()) OutputFile << "? ?";
 else 
 {
strcpy (a, UnconvertAllele(D.GetLeftAllele()));
OutputFile << a <<" ";
strcpy (a, UnconvertAllele(D.GetRightAllele()));
OutputFile << a ;
}
 if (i==(TotalSNPs-1))
	  OutputFile << "\n";
  else OutputFile << " ";
 }
  IndGenotype=IndGenotype->Next;
 Ind++;
}

OutputFile.close();
}
/*____________________________________________________________ */

void GenotypeSample::ExportForHAP (char *filename)
{
SNPPos TotalSNPs=GetTotalSNPs();

//cout <<"Exporting to SNPHAP\n";
ofstream OutputFile;


OutputFile.open (filename, ifstream::out);
if (!OutputFile)
	throw ErrorFile();

Genotype* g;
Diplotype D;

NodePointer IndGenotype=GetFirst();

unsigned int last=TotalSNPs-1;


IndPos Ind=1;
char *a;

while (IndGenotype!=NULL)
{
 g=GetElement(IndGenotype);	
 OutputFile << Ind << " ";
 for (SNPPos i=0; i<TotalSNPs;i++)
 {
 D=g->GetDiplotype(i);
 if (D.IsAMissingSNP()) OutputFile << "S S";
 else 
 {
strcpy (a, UnconvertAllele(D.GetLeftAllele()));
OutputFile << a <<" ";
strcpy (a, UnconvertAllele(D.GetRightAllele()));
OutputFile << a ;
}
 if (i==(TotalSNPs-1))
	  OutputFile << "\n";
  else OutputFile << " ";
 }
  IndGenotype=IndGenotype->Next;
 Ind++;
}

OutputFile.close();
}

/*____________________________________________________________ */

void GenotypeSample::SNPSampling (list<SNPPos> *Sampling)
{

    Genotype *genotype, *genotype2;
	NodePointer p=GetFirst(), pOld, pNext;
	while (p!=NULL)
	{
         genotype=GetElement(p);
	 genotype2=new Genotype(*genotype, Sampling);
	 pOld=p;
	 p=GetNext(p);
	 removeNode(pOld);
         pNext=p;
	 insertElementAtPointer(genotype2, p);
	 p=pNext;

	}

}

/*________________________________________________________________________________________________*/

void GenotypeSample::ImportFormat (char *filename)
{
if (GetSize()>0)
{
cout <<"Importing must be done when there is not any individuals in this object";
exit(0);
}
AlleleOrderMode=NotChanged;
ExistPhenotypes=false;

ifstream InputFile; 
SNPPos TotalSNPs, TotalSNPsOld, i=0;
SNPPos size=GetLineLength(filename)+1;


InputFile.open (filename, ifstream::in);
if (!InputFile || InputFile.peek()==EOF)
	throw ErrorFile();


    char *genotypebuf=NULL, *cad;
    if ((genotypebuf=new char[size])==NULL)
     throw NoMemory();
 
Genotype* targetGenotype=NULL; 
while (InputFile.peek()!=EOF)
{
InputFile.getline (genotypebuf, size, '\n');
TotalSNPs=strlen(genotypebuf);

if (i>0 && TotalSNPs!=TotalSNPsOld)
{
cout <<"\nError in input file. The individual " << i <<" has " << TotalSNPs+1 <<" SNPs, while the others before had " << TotalSNPsOld+1 << " SNPs.";
exit(0);
}
Diplotype* diplotype;
targetGenotype= new Genotype(TotalSNPs);
for (int d=0;d<TotalSNPs;d++)
{
 switch (genotypebuf[d])
 {
 case '0': diplotype= new Diplotype((allele)1,(allele)2); break;
 case '1': diplotype= new Diplotype((allele)1,(allele)1); break;
 case '2': diplotype= new Diplotype((allele)2,(allele)2); break;
 case '3': diplotype= new Diplotype((allele)0,(allele)0); break;
 case '4': diplotype= new Diplotype((allele)1,(allele)0); break;
 case '5': diplotype= new Diplotype((allele)2,(allele)0); break;
default: cout <<"\nError, value " << genotypebuf[d] << " is not allowed."; exit(0); break;
 }

targetGenotype->SetDiplotype(*diplotype, d);

};
insertElement(targetGenotype);

i++;
TotalSNPsOld=TotalSNPs;
}
InputFile.close();
zaparr(genotypebuf);


try
{
if ((MajorAllele=new allele[TotalSNPs])==NULL)
      throw NoMemory();
}
catch (NoMemory NM ) {NM.PrintMessage();}

for (SNPPos SNP=0;SNP<TotalSNPs;SNP++)
 MajorAllele[SNP]=(allele)1;


}
}
// End of Namespace

#endif

/* End of file: GenotypeSample.h */




