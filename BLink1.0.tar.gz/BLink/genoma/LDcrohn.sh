echo Exist phenotype
echo only parents
echo LD computed from families
echo affected and unaffected
# echo only untransmitted haplotypes
echo  no Bayesian correction
echo sliding size 1700000
echo overlapping 1600000
echo maximum distance 50000
echo MAF greater or equal to $2 
./PhaseResolver data/crohn.txt 102 387 1 2 3 2 $1 0 1700000 1600000 50000 $2 
