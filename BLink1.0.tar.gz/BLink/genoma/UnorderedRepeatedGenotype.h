/* File: UnorderedRepeatedGenotype.h */


#ifndef __UnorderedRepeatedGenotype_h__
#define __UnorderedRepeatedGenotype_h__

//#include <string.h>
//#include <cstdio>

#include "list.h"

#include "UnorderedRepeatedPositions.h"

using namespace TAD;

namespace BIOS {


/************************/
/* SNP'S UnorderedRepeatedGenotype DEFINITION */
/************************/


/**
        @memo UnorderedRepeatedGenotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class UnorderedRepeatedGenotype: public list<Diplotype> {


protected:

    /** @name Implementation of class UnorderedRepeatedGenotype
        @memo Private part.
    */
      /**
      @memo A pointer to the list of left alleles
      @doc  Each left allele contains a value {0,1,2,3,4}
      */

	   typedef list<Diplotype> *DL;
	  
	  DL DiplotypeList;

   

      /**
      @memo Declaration of type gender
      @doc It can have one of {1,2} values. 1 for male, 2 for female.
      */

	  
   /** @name Number of individuals (sample size)
        @doc Is the total number of individuals in the sample.
    */
   
/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */

      void CheckRangeSNP(SNPPos SNP);

	  void OrderSNPs(UnorderedRepeatedPositions *pos);

  	  void PrintCompleteGenotype();




		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



      /** @name Operations on UnorderedRepeatedGenotype 
        @memo Operations on a UnorderedRepeatedGenotype 
    */

      /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */
		  UnorderedRepeatedGenotype();


      /**
         @memo Copy constructor
         @param destino: UnorderedRepeatedGenotype where will be copy
         @param origen: UnorderedRepeatedGenotype to copy
         @doc
           Make a copy of UnorderedRepeatedGenotype
           Time complexity in time O(1).
        */
		  UnorderedRepeatedGenotype (const UnorderedRepeatedGenotype& Source);



		        /**
         @memo Copy constructor
         @param destino: UnorderedRepeatedGenotype where will be copy
         @param origen: UnorderedRepeatedGenotype to copy
         @doc
           Make a copy of UnorderedRepeatedGenotype
           Time complexity in time O(1).
        */
	
		  //UnorderedRepeatedGenotype (UnorderedRepeatedGenotype& Source, unsigned int *Sampling);



      /**
	 @memo Destructor
	 @doc
           Deallocate memory used by snps.
           Time complexity O(1).

      */
      ~UnorderedRepeatedGenotype ();

   
	  SNPPos GetTotalSNPs();
   

	  void PrintRepeatedGenotype(UnorderedRepeatedPositions *pos);

	  void SetUnorderedRepeatedGenotype (const DL & DiplotypeListSource);

};  // End of class UnorderedRepeatedGenotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


UnorderedRepeatedGenotype::UnorderedRepeatedGenotype()
{
  DiplotypeList=NULL;
}

/*____________________________________________________________ */


UnorderedRepeatedGenotype::UnorderedRepeatedGenotype (const UnorderedRepeatedGenotype & source)
{


try
{
if ((DiplotypeList=new list<Diplotype>(*source.DiplotypeList))==NULL)
   throw NoMemory();
}
catch (NoMemory wm) 
{
 wm.PrintMessage();
}          

}

/*____________________________________________________________ */

UnorderedRepeatedGenotype::~UnorderedRepeatedGenotype ()
{
 if (DiplotypeList != NULL)
  delete DiplotypeList;

}
/*____________________________________________________________ */

SNPPos UnorderedRepeatedGenotype::GetTotalSNPs()
{
return	DiplotypeList->GetSize();
}

/*____________________________________________________________ */

void UnorderedRepeatedGenotype::OrderSNPs(UnorderedRepeatedPositions *pos)
{
	SNPPos TotalSNPs=GetTotalSNPs(), NewPosList[TotalSNPs], *p=NewPosList, i; 


	 list<PosS>::NodePointer IndPosition=pos->GetFirst();
	 i=0;
     while (IndPosition!=NULL)
	 {
	  NewPosList[i]=(pos->GetElement(IndPosition)).filepos;
	  i++;
	 }

     DiplotypeList->Order(p);
	

  cout <<"Sorting has finished\n";
}


/*__________________________________________________________*/
void UnorderedRepeatedGenotype::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}

/*____________________________________________________________ */

void UnorderedRepeatedGenotype::PrintCompleteGenotype()
{
list<Diplotype>::NodePointer p=GetFirst();
while (p!=NULL)
{
	GetElement(p).PrintDiplotype();
    p=GetNext(p);
}
}
/*____________________________________________________________ */

void UnorderedRepeatedGenotype::PrintRepeatedGenotype(UnorderedRepeatedPositions *pos)
{
  OrderSNPs(pos);

  PrintCompleteGenotype();
}


};  // End of Namespace

#endif

/* End of file: UnorderedRepeatedGenotype.h */




