/* File: genotype.h */


#ifndef __orderedgenotype_h__
#define __genotype_h__

//#include <string.h>
//#include <cstdio>

//#include "Exceptions.h"


namespace SNP {


/************************/
/* SNP'S GENOTYPE DEFINITION */
/************************/


/**
        @memo Genotype for SNPs

	@doc
        Definition:
        A unordered pair of SNPs values for an individual and a genetic position.
        One has been transmitted from the father, one for the mother. Who transmits
        each one of them does not matter.

        Memory space: O(1). 

        @author Maria M. Abad
	@version 1.0
*/


 
	class haplotype: public genotype  {


protected:
    /** @name Implementation of class genotype
        @memo Private part.
    */



/**
   @memo Pointer to the array of snps. It's NULL if snps has not been assigned yet.
*/


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */
      /**
         @memo Destroy the vector of SNP genotypes for an individual
	 @doc
           release memory for this vector.

      
		/* PUBLIC FUNCTIONS (INTERFACE) */

      public:



		  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */

		void Write (char* filename, RedType R=None, long int FirstSNP=-1, unsigned int RegionSize=0);
	
	  /**
         @memo Write the genotypes in a new file.
         @param OutputFile: file where Genotypes will be written.
         @doc Write genotypes that can have been modified
         Time complexity O(Size*TotalSNPs)

      */
	  


};  // End of class genotype



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////




/*____________________________________________________*/

bool genotype::IsTheSamePhase (const Genotype* IndGenotype1, 
							   const Genotype* IndGenotype2, 
							   SNPPos SNP1, 
							   SNPPos SNP2, 
							   ModePhase Mode)    
{
// if Mode=Left, compare the phase of IndGenotype1 with the phase between left of IndGenotype2 and its complementary
// if Mode=Right, compare the phase of IndGenotype1 with the phase between right of IndGenotype2 and its complementary
// if Mode=All, compare the phase of IndGenotype1 with the phase of IndGenotype2

	
	bool same=false;

switch (Mode)
{
case Left:
 if   ( (  (allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))  ) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
  if   ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Left)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Left)+SNP2))) )
 same=true;
break;
case Right:
 if  ( ((allele)abs(*((IndGenotype1->Left)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;
 if  ( ((allele)abs(*((IndGenotype1->Right)+SNP1))==(allele)abs(*((IndGenotype2->Right)+SNP1))) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==(allele)abs(*((IndGenotype2->Right)+SNP2)) ))
 same=true;

break;
}
return same;
}

/*____________________________________________________*/

bool genotype::IsAnOrderedPhase (const Genotype* IndGenotype1, 
							    SNPPos SNP1, 
							    SNPPos SNP2)    
{
	
	bool ordered=false;
//	if (SNP1==1)
//	{
//cout <<"\nfirstizq:" << (allele)abs(*((IndGenotype1->Left)+SNP1)) <<"firstder:" << (allele)abs(*((IndGenotype1->Right)+SNP1)) << ", mayor first: " << GetMajorAllele(SNP1);
//cout <<"lastizq:" << (allele)abs(*((IndGenotype1->Left)+SNP2)) <<"lastder:" << (allele)abs(*((IndGenotype1->Right)+SNP2)) << ", mayor first: " << GetMajorAllele(SNP2);
//	}
if (  
	((allele)abs(*((IndGenotype1->Left)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Left)+SNP2))==GetMajorAllele(SNP2)) 
		  ) 
 ordered=true;
else
 if (  ((allele)abs(*((IndGenotype1->Right)+SNP1))==GetMajorAllele(SNP1)) 
		  && ((allele)abs(*((IndGenotype1->Right)+SNP2))==GetMajorAllele(SNP2))  ) 
 ordered=true;

return ordered;
}



 /*____________________________________________________________ */

void genotype::Write (char* filename, long int FirstSNP=-1, unsigned int RegionSize=0)
 {


  ofstream OutputFile; 
  Genotype *IndGenotype=TheFirstGenotype;
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
  for (int i=0; i<Size;i++)
  {
    for (SNPPos i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
	 OutputFile << *((IndGenotype->Left)+i2) << ' ';
	}
	OutputFile << "\n";
	for (SNPPos i2=0; i2<genotype::TotalSNPs;i2++)
	{
	if ((FirstSNP==-1) || ((i2>=FirstSNP) && (i2<(FirstSNP+RegionSize))))
     OutputFile << *((IndGenotype->Right)+i2) << ' ';
	}
	OutputFile << "\n";
  IndGenotype=genotype::GetNext(IndGenotype);
  }
 OutputFile.close();
cout << "Information about haplotypes has been saved in file " << filename <<"\n";
 }



/*_____________________________________________________________*/
unsigned int genotype::GetNumberofNonZeroHaplotypePairs(unsigned int *LongHaps, SNPPos heteroPos)
{
unsigned int LeftHap, RightHap, haplotypePairs=(unsigned int) pow(2,(heteroPos-1));
unsigned int NonZeroPairs=haplotypePairs;
for (int i=0;i<haplotypePairs;i++)
{
	LeftHap=i;
	RightHap=(unsigned int) pow(2,heteroPos)-1-i;
	if ((LongHaps[LeftHap]==0) || (LongHaps[RightHap]==0))
	 NonZeroPairs--;
}
return NonZeroPairs;
}
/*_____________________________________________________________*/
int genotype::GetMostFrequentHaplotypePair(unsigned int *LongHaps, SNPPos heteroPos)
{
unsigned int haplotypePairs=(unsigned int)pow(2,(heteroPos-1));
unsigned int NonZeroPairs=haplotypePairs;
unsigned long int MaxFreq=0;
int MaxPos=-1, LeftHap, RightHap;
for (int i=0;i<haplotypePairs;i++)
{
	LeftHap=i;
	RightHap=(unsigned int) pow(2,heteroPos)-1-i;
	if ((LongHaps[LeftHap]*LongHaps[RightHap])>MaxFreq) 
 {
	 MaxFreq=LongHaps[LeftHap]*LongHaps[RightHap];
	 MaxPos=i;
}
}
return MaxPos;
}
/*_____________________________________________________________*/

void genotype::CountLongHaps (unsigned int* LongHaps, Genotype* genotyperef, 
							int ExtremePos[4], SNPPos TotalHeteros) 
//Used by the NR algorithm
//If IndGenotype is homo at all hetero positions of IndGenotypeRef except 1, the haplotype is counted.
//The haplotype is refered with its code "pos" (log2 of the number of haplotypes)
{
unsigned int pos1=0, pos2=0, cont=0;
bool KnownHap=true;
bool FoundHetero=false;
unsigned int i=ExtremePos[0];

while ((KnownHap==true) && (i<=ExtremePos[3]))
{
if (IsHeterozygous(IndGenotype, i) && FoundHetero==true) KnownHap=false;
if (IsHeterozygous(IndGenotype, i) && FoundHetero==false) 
{
	FoundHetero=true;
	//pos1=pos1*2+1;
	pos2=pos2+(unsigned int) pow(2,cont);
}
if (IsHomozygous2(IndGenotype, i))
{
	pos1=pos1+(unsigned int)pow(2,cont);
	pos2=pos2+(unsigned int)pow(2,cont);
}
cont++;
i++;
while ((i>ExtremePos[1]) && (i<ExtremePos[2]) && KnownHap==true)
i++;
}
if (KnownHap==true) 
{
	LongHaps[pos1]=LongHaps[pos1]++;
	LongHaps[pos2]=LongHaps[pos2]++;
}
};  



};  // End of Namespace

#endif

/* End of file: genotype.h */




