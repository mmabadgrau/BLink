/* File: GenomaList.h */


#ifndef __GenomaList_h__
#define __GenomaList_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

#include "../commonc++/ExceptionsBasic.h"
#include "../commonc++/basic.h"
#include "../commonc++/list.h"

//#include "Diplotype.h"


  /**
      @memo Declaration of a list (FIFO)
      @doc
      */

//using namespace UTILS;

namespace BIOS {

	template <class T> class list: public UTILS::list<T> 
{
	  virtual T ReadElement (ifstream * is, unsigned long int size);

};

     
} // end namespace
#endif

/* Fin Fichero: list.h */
