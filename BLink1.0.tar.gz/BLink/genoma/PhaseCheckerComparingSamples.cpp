  /**
    * @file PhaseChecker.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "Haplotype.h"
//#include "PhaseResolver.h"



   
namespace BIOS
{
/*_________________________________________________________________________*/

SNPPos GetTotalSNPs(char* filename)
{
unsigned long int length=GetLineLength (filename), TotalSNPs=0; 
ifstream InputFile;
OpenInput(filename, &InputFile);
char line[length];
CaptureLine (&InputFile, line, length);
for (int i=0;i<length;i++)
 if (line[i]>='0' && line[i]<='4') TotalSNPs++;

InputFile.close();
return TotalSNPs;
}
/*_________________________________________________________________________*/

allele GetHap(ifstream* InputFile)
{
char cc[3], c;
allele a;
int pos=1;
InputFile->get(c);
strncpy(cc,&c,1);
if (c=='-') 
 { 
   InputFile->get(c);
   strncat(cc, &c, 1);
   pos=2;
 }
cc[pos]='\0';
return ConvertAllele(cc);
}

/*__________________________________________________________________________*/

void GetHaplotypes (char* filename, char* filenametrue, allele** HapLeft, allele**HapRight, allele**TrueHapLeft, allele**TrueHapRight, FormatType alg, SNPPos TotalIndividuals, SNPPos TotalSNPs)
{

ofstream OutputFile;
ifstream InputFile, InputFile2;
bool exist=true;

OpenInput(filename, &InputFile);
OpenInput( filenametrue, &InputFile2);

Haplotype *H, *TrueH;
char c;
IndPos IndError=0;
SNPPos SwitchError=0, StError=0, Unknown=0, Unsolved=0;


for (IndPos i=0;i<TotalIndividuals; i++)
{
 for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
 {
 HapLeft[i][SNP]=GetHap(&InputFile);
 TrueHapLeft[i][SNP]=GetHap(&InputFile2);
}
 NextLine(&InputFile);
 NextLine(&InputFile2);
 for (SNPPos SNP=0; SNP<TotalSNPs;SNP++)
 {
 HapRight[i][SNP]=GetHap(&InputFile);
 TrueHapRight[i][SNP]=GetHap(&InputFile2);
 }
 NextLine(&InputFile);
 NextLine(&InputFile2);
 }// end for each individual
InputFile.close();
InputFile2.close();
}
/*__________________________________________________________________________*/

void ChangeAlleles (allele **HapLeft, allele **HapRight, allele **TrueHapLeft, allele **TrueHapRight, SNPPos TotalIndividuals, SNPPos TotalSNPs)
{
IndPos val[5];
allele Major[TotalSNPs], Minor[TotalSNPs];
 
for (SNPPos SNP=0;SNP<TotalSNPs; SNP++)
{
for (int j=0;j<5;j++) val[j]=0;
  for (IndPos i=0;i<TotalIndividuals; i++)
 {
    val[abs((int)TrueHapLeft[i][SNP])]++;
    val[abs((int)TrueHapRight[i][SNP])]++;
}

Major[SNP]=(allele)(GetMaxPos(val+1,4)+1);
for (int j=1;j<5;j++) if (val[j]==0) val[j]=maxint;
Minor[SNP]=(allele)(GetMinPos(val+1,4)+1);
if (Minor[SNP]==Major[SNP]) 
{
val[Major[SNP]]=maxint;
Minor[SNP]=(allele)(GetMinPos(val+1,4)+1);
}
}
for (SNPPos SNP=0;SNP<TotalSNPs; SNP++)
 for (IndPos i=0;i<TotalIndividuals; i++)
 {
if (TrueHapLeft[i][SNP]!=0 && TrueHapRight[i][SNP]!=0) 
{
  if (HapLeft[i][SNP]==0) 
	  HapLeft[i][SNP]=Major[SNP]; else HapLeft[i][SNP]=Minor[SNP];
  if (HapRight[i][SNP]==0) 
	  HapRight[i][SNP]=Major[SNP]; else HapRight[i][SNP]=Minor[SNP];
}
else
{
HapLeft[i][SNP]=(allele)0;
HapRight[i][SNP]=(allele)0;
TrueHapLeft[i][SNP]=(allele)0;
TrueHapRight[i][SNP]=(allele)0;
}
  }

}
/*_________________________________________________________________________*/

void ComputeAccuracy(char* filename, char* filenametrue, char* fileaccuracy, FormatType alg)
{
ofstream OutputFile;
ifstream InputFile, InputFile2;
bool exist=false;
SNPPos TotalSNPs=GetTotalSNPs(filenametrue);
SNPPos TotalIndividuals=GetTotalLines(filenametrue)/2;

allele **HapLeft, **HapRight, **TrueHapLeft, **TrueHapRight;

HapLeft=new allele*[TotalIndividuals];
HapRight=new allele*[TotalIndividuals];
TrueHapLeft=new allele*[TotalIndividuals];
TrueHapRight=new allele*[TotalIndividuals];

for (IndPos i=0;i<TotalIndividuals;i++)
{
	HapLeft[i]=new allele [TotalSNPs];
	HapRight[i]=new allele [TotalSNPs];
	TrueHapLeft[i]=new allele [TotalSNPs];
	TrueHapRight[i]=new allele [TotalSNPs];
}

GetHaplotypes(filename, filenametrue, HapLeft, HapRight, TrueHapRight, TrueHapLeft, (FormatType)0, TotalIndividuals, TotalSNPs);

if (alg==PLEM || alg==HTYPER) ChangeAlleles(HapLeft, HapRight, TrueHapRight, TrueHapLeft, TotalIndividuals, TotalSNPs);

if (ExistFile(fileaccuracy)==true) exist=true;

OpenOutputAdd(fileaccuracy, &OutputFile);

if (!exist) 
OutputFile << "dataset\tTotalSNPs\tTotalIndividuals\tIndividualAcc\tTotal Het \tTotal Missing\tTotal Het Known\tTotal Het Solved\tTotal Switch Correct\tSwitch Accuracy\tTotal Known\tTotal Absolute Switch Accuracy\n";
Haplotype *H, *TrueH;
char c;
IndPos IndError=0;
SNPPos SwitchError=0, StError=0, Unknown=0, Unsolved=0, Homo=0;


for (IndPos i=0;i<TotalIndividuals; i++)
{
 H=new Haplotype (HapLeft[i], HapRight[i], TotalSNPs);
 TrueH=new Haplotype(TrueHapLeft[i], TrueHapRight[i], TotalSNPs);
 if (*H!=*TrueH) IndError++;
 SwitchError=SwitchError+H->GetSwitchErrors(TrueH);
 StError=StError+H->GetStErrors(TrueH);
 Unknown=Unknown+H->GetUnknown(TrueH);
 Unsolved=Unsolved+H->GetUnsolved(TrueH); 
 Homo=Homo+H->GetHomozygous(TrueH);
}// end for each individual
OutputFile << filename << "\t" << TotalSNPs << "\t" << TotalIndividuals << "\t" << (TotalIndividuals-IndError)/(float)TotalIndividuals << "\t"
<< TotalIndividuals*TotalSNPs-Unknown-Homo <<  "\t" << Unknown <<  "\t"
<< TotalIndividuals*(TotalSNPs-1)-Unknown-Homo << "\t" << TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo << "\t"
<< TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-SwitchError << "\t" << (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-SwitchError)/(double) (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo) << "\t"
//<< TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-StError << "\t" << (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo-StError)/(double) (TotalIndividuals*(TotalSNPs-1)-Unknown-Unsolved-Homo) << "\t" 
<< TotalIndividuals*TotalSNPs-Unknown-Unsolved 
<< "\t" << (TotalIndividuals*TotalSNPs-Unknown-Unsolved-SwitchError)/(double) (TotalIndividuals*TotalSNPs-Unknown-Unsolved) << "\n";

OutputFile.close();
//delete haps

}
} // end namespace



/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;



int main(int argc, char*argv[]) {

     if (argc<3) 
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <ficheroacc> " << " <phase algorithm>" << endl;
        exit(-1);
        }
char filename[128], filenametrue[128], filenameacc[128], filenametrue2[128];
        
strcpy(filename, argv[1]);

strcpy(filenameacc, argv[2]);

FormatType alg=(FormatType)0; // DHAP

if (argc>3)
alg=(FormatType) atoi(argv[3]);

ChangeExtension (filename, filenametrue2, "truehaps");

sprintf (filenametrue, "../%s", filenametrue2);

ComputeAccuracy(filename, filenametrue, filenameacc, alg);
 
return 0;
}







