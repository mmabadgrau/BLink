rm(list=ls())
#############################################################
################## Function GetErrorProb ####################
#############################################################
# It checks if a value can be a probability
GetErrorProb<-function (prob) 
{
ifelse ((prob<0 || prob >1), FALSE, TRUE)
}


#######################################################
################## Function GetnAB ####################
#######################################################
# It computes sample absolute frequency of haplotype AB, given haplotypes for the
# sample in VectorHaplotypes.

GetnAB<-function(VectorHaplotypes, UnknownPhaseInds, Method, BayesType) 
{
 nAB<-VectorHaplotypes[1] #AB
 if (Method==Bayes && BayesType==Uniform)
  nAB<-nAB+alpha/4
nAB
}
#######################################################
################## Function GetnA #####################
#######################################################
# It computes major allele absolute frequency nA from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetnA<-function(VectorHaplotype, UnknownPhaseInds, Method, BayesType) 
{
nA<-VectorHaplotype[1]+VectorHaplotype[2]+UnknownPhaseInds
if (Method==Bayes && BayesType==Uniform)
nA<-nA+alpha/2
nA
}
#######################################################
################## Function GetfA #####################
#######################################################
# It computes major allele frequency fA from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetfA<-function(VectorHaplotype, UnknownPhaseInds, Method=MLE, BayesType=MLE) 
{
numerator<-GetnA(VectorHaplotype, UnknownPhaseInds, Method, BayesType)
denominator<-sum(VectorHaplotype) + UnknownPhaseInds*2
if (Method==Bayes) 
 denominator<-denominator+alpha
numerator/denominator
}
#######################################################
################## Function GetnB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetnB<-function(VectorHaplotype, UnknownPhaseInds, Method, BayesType) 
{
nB<-VectorHaplotype[1]+VectorHaplotype[3]+UnknownPhaseInds
if (Method==Bayes && BayesType==Uniform)
nB<-nB+alpha/2
nB
}
#######################################################
################## Function GetTotalHaplotypes ########
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetTotalHaplotypes<-function(VectorHaplotype, TotalUnknownPhaseInds, Method, BayesType) 
{
TotalHaplotypes<-sum(VectorHaplotype)+TotalUnknownPhaseInds*2
if (Method==Bayes && BayesType==Uniform)
TotalHaplotypes<-TotalHaplotypes+alpha
TotalHaplotypes
}
#######################################################
################## Function GetfB #####################
#######################################################
# It computes major allele frequency fB from a sample with the 10 values of
# haplotype frequencies at VectorHaplotype


GetfB<-function(VectorHaplotype, Method=MLE, BayesType=MLE) 
{
numerator<-GetnB(VectorHaplotype, Method, BayesType)
denominator<-sum(VectorHaplotype)
if (Method==Bayes) 
 denominator<-denominator+alpha
numerator/denominator
}

#############################################################
################## Function SetDPrimeDist #####################
#############################################################
# It computes the ML estimator of DPrime  

SetDPrimeDist<-function(VectorHaplotypes, UnknownPhaseInds, Method, BayesType) 
{
DPrimeVector<-c(0.01*0:100)
frequency<-c(1:101)*0
NormalizedFrequencyDPrime<-c(1:101)
total<-GetTotalHaplotypes(VectorHaplotypes, UnknownPhaseInds, Method, BayesType)
nA=GetnA(VectorHaplotypes, UnknownPhaseInds, Method, BayesType)
nB=GetnB(VectorHaplotypes, UnknownPhaseInds, Method, BayesType)
nAB<-GetnAB(VectorHaplotypes, UnknownPhaseInds, Method, BayesType)
nAb<-nA-nAB
naB<-nB-nAB
nab<-total-nAB-nAb-naB
#write (nab,"")
fA=nA/total
fB=nB/total

for (i in 1:length(DPrimeVector))
 for (sign in 1:2)
  if (DPrimeVector[i]>0 || sign==1)
  {
   if (sign==2) DMax<-min(fA*(1-fB), (1-fA)*fB)
   else DMax<--min(fA*fB, (1-fA)*(1-fB))

   D=DPrimeVector[i]*DMax
   fAB=D+fA*fB
   if ((fA-fAB)<zero) fAb=0
   else fAb=fA-fAB
   if ((fB-fAB)<zero) faB=0
   else faB=fB-fAB
   if (abs(1-(fAB+fAb+faB))<=zero) 
   fab=0
   else fab=1-fAB-fAb-faB

   #freq<--Inf
   #if (fAB>0) freq<-nAB*log(fAB)
   #if (fAb>0) freq<-freq+nAb*log(fAb)
   #if (faB>0) freq<-freq+naB*log(faB)
   #if (fab>0) freq<-freq+nab*log(fab)
   #if ((2*fAB*fab+2*fAb*faB)>0) freq<-freq+UnknownPhaseInds*log(2*fAB*fab+2*fAb*faB)

freq<-(fAB^nAB)*(fAb^nAb)*(faB^naB)*(fab^nab)*((2*fAB*fab+2*fAb*faB)^UnknownPhaseInds)

if (sign==1) frequency[i]<-freq
else frequency[i]<-frequency[i]+freq
}

NormalizedFrequencyDPrime<-frequency/(sum(frequency))
NormalizedFrequencyDPrime
}

######################################################
################## Function GetHaplotypes ############
#######################################################
# 1: n(AB/AB), 
# 2: n(AB/Ab),
# 3: n(AB/aB), 
# 4: n(AB/ab), 
# 5: n(Ab/Ab), 
# 6: n(Ab/aB), 
# 7: n(Ab/ab), 
# 8: n(aB/aB), 
# 9: n(aB/ab) and
# 10: n(ab/ab).
# 11: nUnknown

GetHaplotypes<-function(data)
{
 VectorHaplotype<-c(1:4)*0
 for (i in 1:length(data))
 {
  if (data[i]==1) VectorHaplotype[1]=VectorHaplotype[1]+2 #AB/AB
  if (data[i]==5) VectorHaplotype[2]=VectorHaplotype[2]+2 #Ab/Ab
  if (data[i]==8) VectorHaplotype[3]=VectorHaplotype[3]+2 #aB/aB
  if (data[i]==10) VectorHaplotype[4]=VectorHaplotype[4]+2 #ab/ab
  if (data[i]==2) # AB/Ab
  {
   VectorHaplotype[1]=VectorHaplotype[1]+1 
   VectorHaplotype[2]=VectorHaplotype[2]+1 
  }
  if (data[i]==3) # AB/aB
  {
   VectorHaplotype[1]=VectorHaplotype[1]+1 
   VectorHaplotype[3]=VectorHaplotype[3]+1 
  }  
  if (data[i]==4) # AB/ab
  {
   VectorHaplotype[1]=VectorHaplotype[1]+1 
   VectorHaplotype[4]=VectorHaplotype[4]+1 
  }  
  if (data[i]==6) # Ab/aB
  {
   VectorHaplotype[2]=VectorHaplotype[2]+1 
   VectorHaplotype[3]=VectorHaplotype[3]+1 
  }  
  if (data[i]==7) # Ab/ab
  {
   VectorHaplotype[2]=VectorHaplotype[2]+1 
   VectorHaplotype[4]=VectorHaplotype[4]+1 
  }  
  if (data[i]==9) # aB/ab
  {
   VectorHaplotype[3]=VectorHaplotype[3]+1 
   VectorHaplotype[4]=VectorHaplotype[4]+1 
  }
  }
 VectorHaplotype
}
#######################################################
################## Function GetUnknownPhaseInds #######
#######################################################
# 1: n(AB/AB), 
# 2: n(AB/Ab),
# 3: n(AB/aB), 
# 4: n(AB/ab), 
# 5: n(Ab/Ab), 
# 6: n(Ab/aB), 
# 7: n(Ab/ab), 
# 8: n(aB/aB), 
# 9: n(aB/ab) and
# 10: n(ab/ab).
# 11: nUnknown

GetUnknownPhaseInds<-function(data)
{
 u<-0
 for (i in 1:length(data))
  if (data[i]==11) u=u+1 
u
}
#######################################################
################## Function GetQuantile ###############
#######################################################
GetQuantile<-function(CumulativeFrequencyDPrime, Quantile)
{
DPrimeVector<-c(0.01*0:100)
Find<-0
Value<-0
i<-1
while (Find==0 && i<=length(DPrimeVector))
{
if (CumulativeFrequencyDPrime[i]>=Quantile)
{
Find<-1
Value<-DPrimeVector[i]
}
i<-i+1
}
Value
}
#######################################################
################## Function GetMaxDPrime ###############
#######################################################
GetMaxDPrime<-function(NormalizedFrequencyDPrime)
{
DPrimeVector<-c(0.01*0:100)
Max<-1
MaxFreq<-0
for (i in 1:length(DPrimeVector))
{
 if (NormalizedFrequencyDPrime[i]>MaxFreq)
 {
 MaxFreq<-NormalizedFrequencyDPrime[i]
 Max<-i
 }
 }
DPrimeVector[Max]
}
###############################################################################################
######################################### Main program ########################################
###############################################################################################
ML<-1
Bayes<-2
Uniform<-1
alpha<-1
BayesType<-Uniform
Method<-Bayes
zero<-1e-10
DPrimeVector<-c(0.01*0:100)

NormalizedFrequencyDPrime<-c(1:101)

#filename="/home/mabad/R/SNP10DPrime.CI"
filename="c://genoma/SNP3DPrime.CI"

#data=read.table("/home/mabad/genoma/chrom22rSNP3.red", header=TRUE)
data=read.table("c://genoma/chrom22rSNP3.red", header=TRUE)
TotalSNPs=length(data[1,])
inds=length(data[,1])

cat (", nAB, nAb, naB, nab, nHH, DPrime, Lower, Upper\n", file=filename, append=FALSE)


for (i in 1:TotalSNPs)
{
write (paste("SNP", i),"")
VectorHaplotypes<-GetHaplotypes(data[[i]])
UnknownPhaseInds<-GetUnknownPhaseInds(data[[i]])
NormalizedFrequencyDPrime<-SetDPrimeDist(VectorHaplotypes, UnknownPhaseInds, Method, BayesType)
DPrime<-GetMaxDPrime(NormalizedFrequencyDPrime)
CumulativeFrequencyDPrime<-cumsum(NormalizedFrequencyDPrime)
lower<-GetQuantile(CumulativeFrequencyDPrime, 0.025)
upper<-GetQuantile(CumulativeFrequencyDPrime, 0.975)
cat (paste(i, VectorHaplotypes[1], VectorHaplotypes[2], VectorHaplotypes[3], VectorHaplotypes[4], UnknownPhaseInds, DPrime, lower, upper, "\n", sep=",") , file=filename,append=TRUE)
}


