/* File: Genoma.cpp */


#ifndef __Genoma_cpp__
#define __Genoma_cpp__


#include "Genoma.h"


namespace BIOS {




/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////


Genoma::Genoma()
{
line=NULL;
PG=NULL;
}

/*____________________________________________________________ */

Genoma::Genoma (Genoma * source)
{
line=NULL;
genotype=source->genotype;
PG=new PairGenotype(source->PG);
ic=source->ic;
}

/*____________________________________________________________ */

Genoma::Genoma (Trio & T, IndCategory i)
{
line=NULL;
ic=i;
if (ic!=offspring && ic!=mother && ic!=father)
{ cout <<"Error in Genoma::Genoma\n" << (int)ic;
	exit(0);
}

switch (ic)
{
case offspring:
	genotype=T.GetChildGenotype()->element;
	PG=new PairGenotype(T.GetFatherGenotype()->element, T.GetMotherGenotype()->element); 
	break;
case father:
	genotype=T.GetFatherGenotype()->element;
	PG=new PairGenotype(T.GetChildGenotype()->element, T.GetMotherGenotype()->element);
	break;
case mother:
	genotype=T.GetMotherGenotype()->element;
	PG=new PairGenotype(T.GetChildGenotype()->element, T.GetFatherGenotype()->element); 
}
}
/*____________________________________________________________ */

Genoma::~Genoma ()
{
zap(line);
zap(PG);
}



/*___________________________________________________*/

SNPPos Genoma::GetHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele, bool IsPartiallySolved=false)      
{

IndPos Total=GetInferredHap(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele);

if (Total==0 && ic!=offspring)	

Total=GetPartiallySolved(SNP1, SNP2, IsMajor1, IsMajor2, MajorAllele, IsPartiallySolved);
	

return Total;
};


/*___________________________________________________*/

bool Genoma::CanBeInferred (SNPPos SNP1, SNPPos SNP2, allele* MajorAllele)      
{
// Karnaugh map: 1111/1010/1100/1000  Rows and columns labels: OO, OH, HO, HH
if (genotype->IsPhaseKnown(SNP1,SNP2, MajorAllele)==false)

if  (genotype->GetDiplotype(SNP1).IsANonMissingSNP() 
	 && genotype->GetDiplotype(SNP2).IsANonMissingSNP() 	
	 && PG->GetFirstGenotype()->GetDiplotype(SNP1).IsANonMissingSNP() 
	 && PG->GetFirstGenotype()->GetDiplotype(SNP2).IsANonMissingSNP() 	
	 && PG->GetSecondGenotype()->GetDiplotype(SNP1).IsANonMissingSNP() 
	 && PG->GetSecondGenotype()->GetDiplotype(SNP2).IsANonMissingSNP()) 	


if  (genotype->GetDiplotype(SNP1).IsHomozygous(MajorAllele[SNP1])
	|| genotype->GetDiplotype(SNP2).IsHomozygous(MajorAllele[SNP2])
	|| PG->GetFirstGenotype()->GetDiplotype(SNP1).IsHomozygous(MajorAllele[SNP1])
	|| PG->GetFirstGenotype()->GetDiplotype(SNP2).IsHomozygous(MajorAllele[SNP2])
	|| PG->GetSecondGenotype()->GetDiplotype(SNP1).IsHomozygous(MajorAllele[SNP1])
	|| PG->GetSecondGenotype()->GetDiplotype(SNP2).IsHomozygous(MajorAllele[SNP2]) )

if ((PG->GetFirstGenotype()->IsHomozygousHomozygous(SNP1, SNP2, MajorAllele) || PG->GetSecondGenotype()->IsHomozygousHomozygous(SNP1, SNP2, MajorAllele))
|| 	(PG->GetFirstGenotype()->GetDiplotype(SNP1).IsHomozygous(MajorAllele[SNP1]) && PG->GetSecondGenotype()->GetDiplotype(SNP2).IsHomozygous(MajorAllele[SNP2])) 
||  (PG->GetFirstGenotype()->GetDiplotype(SNP2).IsHomozygous(MajorAllele[SNP2]) && PG->GetSecondGenotype()->GetDiplotype(SNP1).IsHomozygous(MajorAllele[SNP1]))) 

return true;


return false;

}
/*___________________________________________________*/

bool Genoma::CanBeInferred (SNPPos SNP, allele MajorAllele)      
{
if (genotype->GetDiplotype(SNP).IsHeterozygous(MajorAllele))
if  (PG->GetFirstGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele)
	|| PG->GetSecondGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele))
return true;


return false;

}
/*___________________________________________________*/

void Genoma::SetLeftRight (SNPPos SNP, allele MajorAllele, Diplotype & Dip)      
{
if (PG->GetFirstGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele))
{
if (genotype->GetLeftAllele(SNP)!=PG->GetFirstGenotype()->GetLeftAllele(SNP))
 Dip.ChangeAlleles();
}
else
if (PG->GetSecondGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele) && genotype->GetRightAllele(SNP)!=PG->GetSecondGenotype()->GetLeftAllele(SNP))
 Dip.ChangeAlleles();
}
/*___________________________________________________*/

bool Genoma::MustBeChanged (SNPPos SNP, allele MajorAllele)      
{
if (PG->GetFirstGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele))
{
if (genotype->GetLeftAllele(SNP)!=PG->GetFirstGenotype()->GetLeftAllele(SNP))
 return true;
}
else
if (PG->GetSecondGenotype()->GetDiplotype(SNP).IsHomozygous(MajorAllele) && genotype->GetRightAllele(SNP)!=PG->GetSecondGenotype()->GetLeftAllele(SNP))
 return true;

return false;
}
/*___________________________________________________*/

SNPPos Genoma::GetInferredHap (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele* MajorAllele)      
{
if (CanBeInferred(SNP1,SNP2, MajorAllele)) 
{
	Diplotype D1=genotype->GetDiplotype(SNP1), D2=genotype->GetDiplotype(SNP2);
	SetLeftRight(SNP1, MajorAllele[SNP1], D1);
	SetLeftRight(SNP2, MajorAllele[SNP2], D2);


if (((IsMajor1 && IsMajor2) || (!IsMajor1 && !IsMajor2)) && genotype->IsMajorMajor(MajorAllele[SNP1], MajorAllele[SNP2], D1, D2))
 return 1;
if (((IsMajor1 && !IsMajor2) || (!IsMajor1 && IsMajor2)) && !genotype->IsMajorMajor(MajorAllele[SNP1], MajorAllele[SNP2], D1, D2))
 return 1;
	
}
return 0;
}
/*___________________________________________________*/

SNPPos Genoma::GetPartiallySolved (SNPPos SNP1, SNPPos SNP2, bool IsMajor1, bool IsMajor2, allele * MajorAllele, bool IsPartiallySolved)      
{
if (CanBePartiallySolved (SNP1, SNP2, MajorAllele, IsPartiallySolved))
if (ic==father)
{
if ((IsMajor1 && IsMajor2) || (!IsMajor1 && !IsMajor2))
return 1;
}
else
{
if (ic==mother)
if ((IsMajor1 && !IsMajor2) || (!IsMajor1 && IsMajor2))
return 1;
}
return 0;
}
/*___________________________________________________*/

bool Genoma::CanBePartiallySolved (SNPPos SNP1, SNPPos SNP2, allele * MajorAllele, bool IsPartiallySolved)      
{
return (ic==father || ic==mother) 
&& IsPartiallySolved 
&& genotype->IsHeterozygousHeterozygous(SNP1, SNP2, MajorAllele) 
&& PG->GetSecondGenotype()->IsHeterozygousHeterozygous(SNP1, SNP2, MajorAllele) // couple
&& PG->GetFirstGenotype()->IsHomozygousHeterozygous(SNP1, SNP2, MajorAllele) // child
&& (ic==father || ic==mother);
}
/*____________________________________________________________ */

void Genoma::ChangeAlleles(SNPPos SNP)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

 genotype->ChangeAlleles(SNP);

}
/*____________________________________________________________ */

void Genoma::MarkAlleles(SNPPos SNP)
{
	// for those heterozygous positions, rewrite first MajorAllele, second Minor Allele.
	// NOT implemented: if only one allele is missing, write it in the second positions

 genotype->MarkAlleles(SNP);

}
/*__________________________________________________________*/

Diplotype Genoma::GetDiplotype(SNPPos SNP)
{
return genotype->GetDiplotype(SNP);
}
/*__________________________________________________________*/

GenotypeCode Genoma::GetGenotypeCode(SNPPos SNP1, SNPPos SNP2, allele* MajorAllele)
{
IndPos nAB, nAb, naB, nab;
Diplotype D1=GetDiplotype(SNP1), D2=GetDiplotype(SNP2);
if (D1.IsAMissingSNP() || D2.IsAMissingSNP())
return Missing;

if (genotype->IsPhaseKnown(SNP1,SNP2, MajorAllele) || CanBeInferred (SNP1, SNP2, MajorAllele))
{
if (genotype->IsPhaseKnown(SNP1,SNP2, MajorAllele))
{
 nAB=genotype->GetHap (SNP1, SNP2, true, true, MajorAllele, NotChanged);  
 nAb=genotype->GetHap (SNP1, SNP2, true, false, MajorAllele, NotChanged); 
 naB=genotype->GetHap (SNP1, SNP2, false, true, MajorAllele, NotChanged);  
 nab=genotype->GetHap (SNP1, SNP2, false, false, MajorAllele, NotChanged);  
}
else if (CanBeInferred (SNP1, SNP2, MajorAllele))
{
 nAB=GetHap (SNP1, SNP2, true, true, MajorAllele, NotChanged);  
 nAb=GetHap (SNP1, SNP2, true, false, MajorAllele, NotChanged); 
 naB=GetHap (SNP1, SNP2, false, true, MajorAllele, NotChanged);  
 nab=GetHap (SNP1, SNP2, false, false, MajorAllele, NotChanged);  
}
if (nAB==2) return ABAB;
if (nAb==2) return AbAb;
if (naB==2) return aBaB;
if (nab==2) return abab;
if (nAB==1 && nAb==1) return ABAb;
if (nAB==1 && naB==1) return ABaB;
if (nAB==1 && nab==1) return ABab;
if (nAb==1 && naB==1) return AbaB;
if (nAb==1 && nab==1) return Abab;
if (naB==1 && nab==1) return aBab;
}
return Unphased;


}
/*__________________________________________________________*/

char* Genoma::PrintGenotypeCode(SNPPos SNP, SNPPos SNP2, allele* MajorAllele)
{
	SNPPos TotalSNPs=genotype->GetTotalSNPs();
	if ((line=new char [TotalSNPs*6])==NULL)
	throw NoMemory();

	strcpy(line, "\0");

   sprintf(line, "%d ", (int)GetGenotypeCode(SNP, SNP2, MajorAllele));

   return line;
}
};  // End of Namespace

#endif

/* End of file: Genoma.h */




