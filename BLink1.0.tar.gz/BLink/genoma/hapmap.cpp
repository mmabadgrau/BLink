  /**
    * @file genoma.cpp
    * @brief Program to convert hapmap format to linkage pedigree format
	* @example hapmap genotypes_chr1_txt_gz.txt 90 chrom1.gen will convert the hapmap-format file genotypes_chr1_txt to a file called chrom1.gen
	* there are 90 individuals in the file
    *
    */

/* File: hapmap.cpp */

#ifndef __hapmap_cpp__
#define __hapmap_cpp__



#include "hapmap.h"




namespace BIOS {



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

void hapmap::destroy(hapmap::position * Position, hapmap::InverseGenotype *IG, hapmap::dup *DUP)
{
 assert (Position != NULL);
 assert (IG != NULL);
 assert (DUP != NULL);
 destroy (Position->Next, IG->Next, DUP->Next);
 delete Position;
 delete IG;
 delete DUP;
};


/*___________________________________________________________ */

void hapmap::ReadInfo (ifstream* origen, InverseGenotype *target, position *targetpos, unsigned int TotalSize)
{

	dup *DupPointer; 

	unsigned int cont2, LastNew;

	char *genotypebuf, *cad, al1, al2;
    if ((genotypebuf=new char[TotalSize*4+500])==NULL)
     throw NoMemory();
 //   if ((cad=new char[TotalSize*4+500])==NULL)
 //    throw NoMemory();

	
        do

	{
    if ((target->Left=new allele[TotalSize])==NULL)
      throw NoMemory();
    if ((target->Right=new allele[TotalSize])==NULL)
      throw NoMemory();

	//   genotypebuf2=genotypebuf;
 
        origen-> getline (genotypebuf, TotalSize*4+500, '\n');

	// read rs
	cad = strtok (genotypebuf,", \t");
        targetpos->rsNumber = string(cad);

	// read SNP alleles
	cad = strtok (NULL,", \t");

	// read chrom
	cad = strtok (NULL,", \t");

	// read position
	cad = strtok (NULL,", \t");
//      cout << atoi(cad) <<"\n";
//      sscanf (cad, "%s", cadena);


    targetpos->pos = atoi(cad);

        // read strand, genome_buider, center, protLSID, assayLSID, panelLSID, QC_code
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");
	cad = strtok (NULL,", \t");

//	cout << "cad" << cad;
   
	cont2=0, LastNew=0;

    DupPointer=TheFirstDup;
 
    for (int cont=0;cont<Sizedup;cont++)
    {
//    cout <<"cont: " << cont;
	cad = strtok (NULL,", \t");
//      cout << cad << "\n";


        sscanf (cad, "%c%c", &al1, &al2);
//  al1='A';
//  al2='A';
  
	if (!(DupPointer->IsDup)) // if non duplicated
    {
    *((target->Left)+cont2)= (allele) ConvertAllele (&al1);
    *((target->Right)+cont2)= (allele) ConvertAllele (&al2); 
	LastNew=cont2;
	cont2++;
    }
 
        else
    {
    if  (*((target->Left)+LastNew)==(allele)0)
	{
	 *((target->Left)+LastNew)= (allele) ConvertAllele (&al1);
	}
    if  (*((target->Right)+LastNew)==(allele)0)
	{
	 *((target->Right)+LastNew)= (allele) ConvertAllele (&al2);
	}
     }
  
	DupPointer=DupPointer->Next;


        } //end for


    Size=cont2; 	

    TotalSNPs++;

//	if (TotalSNPs==52400)//58220
//		exit(0);


	if ((origen->peek()!=EOF) && (origen->peek()!='\n'))
	{

        
	if ((target->Next=new InverseGenotype)==NULL)
     throw NoMemory();
	target->Next->Previous=target;
	if ((targetpos->Next=new position)==NULL)
     throw NoMemory();
	targetpos->Next->Previous=targetpos;
	

	target=target->Next;
	targetpos=targetpos->Next;
        
	}

	else
	{
		target->Next=NULL;
		targetpos->Next=NULL;
	}


}
        while ((origen->peek()!=EOF) && (origen->peek()!='\n'));

    target->Next=NULL;
    targetpos->Next=NULL;

	assert (genotypebuf!=NULL);
    delete genotypebuf;





}


/*___________________________________________________________ */

void hapmap::GetIDs (char * IDs)
{
	dup * DupPointer;
	Sizedup=0;
	Size=0;
	char *cad, car1, car2, cadena[10];
	unsigned int ID;

	// red t-rs

	cad = strtok (IDs,", \t");

   
        // read t-SNPalleles, t-chrom, t-pos, t-strand, tgenomebuider, t-center, t-protLSID, t-assayLSID, t-panelLSID, QC_code

    for (int i=0;i<10;i++)
	 cad = strtok (NULL,", \t");
   
	// read ID
	unsigned int cont=0;

    if ((TheFirstDup=new dup)==NULL)
     throw NoMemory();
    DupPointer=TheFirstDup;

    cad = strtok (NULL,", \t");
  
    while (cad!=NULL)
    {  

	sscanf (cad, "%c%c%s", &car1, &car2, &cadena[0]);

	ID= atoi(cadena);

	if ((DupPointer==TheFirstDup) || (DupPointer->Previous->ID!=ID))
	{
	 DupPointer->ID=ID;
	 DupPointer->IsDup=false;
	 Size++;
	}
	else DupPointer->IsDup=true;

    if ((DupPointer->Next=new dup)==NULL)
     throw NoMemory();
	DupPointer->Next->Previous=DupPointer;
	DupPointer=DupPointer->Next;
	Sizedup++;
	cad = strtok (NULL,", \t");
	}

}



/*____________________________________________________________ */

void hapmap::GetInfo(ifstream *InputFile, unsigned int TotalSize)
{

Size=0;
cout << "\nReading genotypes ...";
	



try {
if ((this->TheFirstInverseGenotype=new InverseGenotype)==NULL)
      throw NoMemory();
if ((this->TheFirstPosition=new position)==NULL)
      throw NoMemory();



ReadInfo (InputFile, this->TheFirstInverseGenotype, this->TheFirstPosition, TotalSize);

  }
catch (NoMemory no) {
  no.PrintMessage();
  }



if (TotalSize != Size)
{
 cerr << "There are " << Size <<" phenotypes in the file but you have especified that the number is " << TotalSize;
 exit(0);
}
};

///////////////////
//// public ////////
///////////////////


/*____________________________________________________________ */

hapmap::hapmap()
{
};


/*____________________________________________________________ */

hapmap::hapmap(char* filename, unsigned int TotalSize)
{
// 
Size=0;
TotalSNPs=0;
//TotalSNPs=TotalSNPsI;
char *IDs;




if ((IDs=new char[1400])==NULL)
 throw NoMemory();


cout << "\nReading positions ...";
	
Size=TotalSize;

ifstream InputFile; 
try
{
 InputFile.open (filename, ifstream::in);
 if (InputFile.peek()==EOF)
  throw EmptyFile();
}
catch (ErrorFile NoFile) {
	NoFile.PrintMessage();}
catch (EmptyFile EFile) {
        EFile.PrintMessage(filename);
   }
// read first line (IDs)


	InputFile.getline (IDs, 1400, '\n');

	GetIDs(IDs);

	delete(IDs);


try {
if ((this->TheFirstPosition=new position)==NULL)
      throw NoMemory();

	GetInfo (&InputFile, TotalSize);
  }
catch (NoMemory no) {
  no.PrintMessage();
  }
InputFile.close();
	

}


/*____________________________________________________________ */




void hapmap::ConvertFormat (char* filePhenotypes, char* filename)
{
 // the new file will include phenotypes and (reverse?) genotypes
  ofstream OutputFile; 
  ifstream InputFile;
  InverseGenotype * GenotypePointer;

  try
  {
  InputFile.open (filePhenotypes, ifstream::in);
  if (!InputFile)
	throw ErrorFile();
  OutputFile.open (filename, ifstream::out);
  if (!OutputFile)
	  throw ErrorFile();
  }
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

char *line, cadena[5], *cad;
if ((line=new char[40])==NULL)
 throw NoMemory();

for (int i=0; i<Size;i++)
{
 InputFile.getline (line, 40, '\n');

 // pedigree
 cad = strtok (line,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';

 // ind code
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';
	  
 // father code
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';

 // mother code
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';

 // gender
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';	
 
 // affectation
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';	


  //  code2
 cad = strtok (NULL,", \t");
 sscanf (cad, "%s", &cadena[0]);
 OutputFile << cadena << ' ';

 GenotypePointer=TheFirstInverseGenotype;


 for (int SNP=0; SNP<TotalSNPs; SNP++)
 {
  OutputFile << *((GenotypePointer->Left)+i) << ' ';
  OutputFile << *((GenotypePointer->Right)+i) << ' ';
  GenotypePointer=GenotypePointer->Next;
 }
OutputFile << "\n";
}

InputFile.close();
OutputFile.close();

}

/*____________________________________________________________ */

void hapmap::PrintPositions (char* filename)
 {
  ofstream OutputFile; 
  position *IndPosition=TheFirstPosition; 
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
for (int i=0; i<TotalSNPs;i++)
  {
    OutputFile << IndPosition->pos << '\n';
    IndPosition=IndPosition->Next;
	}
  
 OutputFile.close();

 }
/*____________________________________________________________ */

void hapmap::PrintRSNumbers (char* filename)
 {
  ofstream OutputFile; 
  position *IndPosition=TheFirstPosition; 
  try
{
  OutputFile.open (filename, ifstream::out);
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }
for (int i=0; i<TotalSNPs;i++)
  {
    OutputFile << IndPosition->rsNumber << '\n';
    IndPosition=IndPosition->Next;
	}
  
 OutputFile.close();

 }
/*___________________________________________________*/

hapmap::~hapmap ()
{
	hapmap::destroy(TheFirstPosition, TheFirstInverseGenotype, TheFirstDup);
}

/*__________________________________________________________________________________*/

void hapmap::ProcessHapmap (char* filephenotype, char* filename)
{

   
ConvertFormat(filephenotype, filename);

char *filename2; 

 if ((filename2=new char[256])==NULL)
		 throw NoMemory();
char filename3[256];
	// strcpy (filename2, filename);
	// strtok(filename2, ".");
	// strcat (filename2, ".pos\0");
    ChangeExtension(filename, filename2, "pos");

         ChangeExtension(filename2, filename3, "rs");

	 PrintPositions(filename2);
 PrintRSNumbers(filename3);

	 delete filename2;
}


/*____________________________________________________________ */

unsigned int hapmap::GetTotalSNPs()
{
  return TotalSNPs;
}

/* _____________________________________________________*/

unsigned int HapMapProcessing(char *filename, char* filephenotypes, char*filename2, unsigned int Size)
{


hapmap *HapMap;

if ((HapMap = new hapmap(filename, Size))==NULL)
 throw NoMemory();

HapMap->ProcessHapmap(filephenotypes, filename2);
cout << "\nOutput file: " << filename2 <<"\n";
cout << "\nNumber of SNPs: " << HapMap->GetTotalSNPs() <<"\n";
return HapMap->GetTotalSNPs();
}

}


/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<3)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << "<population acronym (YRI for Yoruba/CHB for China/JPT for Japan/CEU for US)>" << " <targetfilename(opt)>" << endl;
        exit(-1);
        }
     char* filename, *filename2, filephenotypes[256];
	 unsigned int TotalSNPs;
	 if ((filename=new char[256])==NULL)
		 throw NoMemory();
	 if ((filename2=new char[256])==NULL)
		 throw NoMemory();
	
		 strcpy(filename, argv[1]);
         strcpy(filephenotypes, GetFilePath(filename));
         strcat(filephenotypes, "pedigree");
	 strcat(filephenotypes, argv[2]);
	 strcat(filephenotypes, ".txt");

	 	if (argc==4)	 
		 strcpy(filename2, argv[3]);
		else
		{
		 strcpy (filename2, filename);
		 strtok(filename2, ".");
		 strncat(filename2, ".gen\0", 4);
}


     unsigned int TotalIndividuals=GetTotalLines(filephenotypes);

	 try{ 

	      TotalSNPs=HapMapProcessing (filename, filephenotypes, filename2, TotalIndividuals);
		 cout <<"There are " << TotalSNPs << " SNPs in the sample\n";
	
		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
 
	delete filename, filename2;

   return 0;

}


#endif

/* Fin Fichero: hapmap.cpp */


