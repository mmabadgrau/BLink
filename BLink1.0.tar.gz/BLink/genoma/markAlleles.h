/*____________________________________________________________ */

unsigned int genotype::ConvertAllele (char value)
{
unsigned int val;
try
{
	if ((value=='N') || (value=='?')) val=0;
	else if (value=='A') val=1;
	else if (value=='C') val=2;	
	else if (value=='G') val=3;	
	else if (value=='T') val=4;	
	else 
	{
		throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(value);
      }

	return (val);
}

/*____________________________________________________________ */

char genotype::UnconvertAllele (short int number)
{
char c;
try
{
	switch (number)
	{
		case 0: c='?'; break;
		case 1: c='A'; break;
		case 2: c='C'; break;
		case 3: c='G'; break;
		case 4: c='T'; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(number);
      }
return(c);
}

/*____________________________________________________________ */

allele genotype::MarkAllele (allele number)
{
allele a;
try
{
	switch (number)
	{
		case N: a=N; break;
		case A: a=UA; break;
		case C: a=UC; break;
		case G: a=UG; break;
		case T: a=UT; break;
		case U: a=U; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
return(a);
}
/*____________________________________________________________ */

void genotype::MarkAlleles (Genotype* IndGenotype, SNPPos SNP,  ModePhase TypePhase=All)
{

switch (TypePhase)
{
case Left: *((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP)); break;
case Right: *((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP)); break;
case All: 
	*((IndGenotype->Left)+SNP)=MarkAllele(*((IndGenotype->Left)+SNP)); 
	*((IndGenotype->Right)+SNP)=MarkAllele(*((IndGenotype->Right)+SNP)); break;
}


}
/*____________________________________________________________ */

void genotype::UnmarkAlleles (Genotype* IndGenotype, SNPPos SNP,  ModePhase TypePhase=All)
{

switch (TypePhase)
{
case Left: *((IndGenotype->Left)+SNP)=UnmarkAllele(*((IndGenotype->Left)+SNP)); break;
case Right: *((IndGenotype->Right)+SNP)=UnmarkAllele(*((IndGenotype->Right)+SNP)); break;
case All: 
	*((IndGenotype->Left)+SNP)=UnmarkAllele(*((IndGenotype->Left)+SNP)); 
	*((IndGenotype->Right)+SNP)=UnmarkAllele(*((IndGenotype->Right)+SNP)); break;
}


}
/*____________________________________________________________ */

allele genotype::UnmarkAllele (allele number)
{
 allele a;
try
{
	switch (number)
	{
		case N: return a=N; break;
		case UA: return a=A; break;
		case UC: return a=C; break;
		case UG: return a=G; break;
		case UT: return a=T; break;
		case U: return a=U; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
	return a;
}
/*__________________________________________________________*/

bool genotype::IsMarked (allele number)
{
bool b;
try
{
	switch (number)
	{
		case N: 
		case A: 
		case C: 
		case G: 
		case T: 
		case U: b=false; break;
		case UA: 
		case UC: 
		case UG: 
		case UT: b=true; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage((short int)(number));
      }
return (b);
}

/*____________________________________________________________ */

unsigned int genotype::ConvertAllele (char value)
{
unsigned int val;
try
{
	if ((value=='N') || (value=='?')) val=0;
	else if (value=='A') val=1;
	else if (value=='C') val=2;	
	else if (value=='G') val=3;	
	else if (value=='T') val=4;	
	else 
	{
		throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(value);
      }

	return (val);
}

/*____________________________________________________________ */

char genotype::UnconvertAllele (short int number)
{
char c;
try
{
	switch (number)
	{
		case 0: c='?'; break;
		case 1: c='A'; break;
		case 2: c='C'; break;
		case 3: c='G'; break;
		case 4: c='T'; break;
		default: throw NonSNP();
	}
}
	catch (NonSNP NS) {
        NS.PrintMessage(number);
      }
return(c);
}
