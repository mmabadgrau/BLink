  /**
    * @file PhaseResolver.cpp
    * @brief Program to resolve phase
    *
    */
//#include <cstdlib>//
#include <fstream>

//#include <individual.h>
#include <string>
#include <iostream>
//#include <cassert>
#include <stdio.h>//
#include <math.h>//


#include "Tables2x2.h"

using namespace BIOS;



int main(int argc, char*argv[]) {

     if(argc<6)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <n(AB)> " << " <n(Ab)>" << " <n(aB)>" << " <n(ab)>" 
			<< " < HH individuals >"  << endl;
        exit(-1);
        }
    
	 
	 unsigned long int nAB=atoi(argv[1]);
	 unsigned long int nAb=atoi(argv[2]); 
	 unsigned long int naB=atoi(argv[3]); 
	 unsigned long int nab=atoi(argv[4]);
	 unsigned long int nHH=atoi(argv[5]);

     double total= nAB+nAb+naB+nab;

	 double fA=(nAB+nAb+nHH)/(total+2*nHH), fB=(nAB+naB+nHH)/(total+2*nHH);

 	 srand(24226616);

	 Table2x2 T2x2;

     double fAB=T2x2.EstimateMLE (fA*fB, nHH, nAB, total, fA, fB, 1000);
	 double fAb=fA-fAB;
	 double faB=fB-fAB;
	 double fab=1-fAB-fAb-faB;
     

cout <<"\nf(AB)" << fAB;
cout <<"\nf(Ab)" << fAb;
cout <<"\nf(aB)" << faB;
cout <<"\nf(ab)" << fab;
cout <<"\nf(A)" << fA;
cout <<"\nf(B)" << fB;

cout << "\nDprime:" << T2x2.GetDPrime(fAB, fA, fB) <<"\n";



   return 0;

}





