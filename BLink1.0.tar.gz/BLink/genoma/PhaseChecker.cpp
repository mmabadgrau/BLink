  /**
    * @file PhaseChecker.cpp
    * @brief Program for different geneomics computations
    *
    */


#include <iostream>
#include <cassert>
#include <fstream>

#include "PhaseChecker.h"
#include "hapmap.h"
#include "PhaseResolver.h"


using namespace SNP;

     //typedef enum typefile {phase=0, TDT=1};

//	 typefile tf;

	 IndCategory ic;

//using namespace std;
//using namespace string;

namespace Phase {

/* _____________________________________________________*/

//Programa_Pruebas::Programa_Pruebas(string nombre){
//   origen=nombre;
//   }

/* _____________________________________________________*/

//Programa_Pruebas::~Programa_Pruebas(){
//   }

/* _____________________________________________________*/

unsigned int HapMapProcessing(char *filename, char* filephenotypes, char*filename2, unsigned int Size)
{


hapmap *HapMap;
if ((HapMap = new hapmap(filename, Size))==NULL)
 throw NoMemory();


HapMap->ProcessHapmap(filephenotypes, filename2);
cout << "\nOutput file: " << filename2 <<"\n";
cout << "\nNumber of SNPs: " << HapMap->GetTotalSNPs() <<"\n";
return HapMap->GetTotalSNPs();

}

/* _____________________________________________________*/

void GenomaProcessing(char *filename, char* filenameacc, unsigned int TotalSNPs, unsigned int Size, bool Distance)
{
	

char * filename2, *filename3, *filename4, *filepos;

if ((filename2=new char[64])==NULL)
 throw NoMemory();
if ((filename3=new char[64])==NULL)
 throw NoMemory();
if ((filename4=new char[64])==NULL)
 throw NoMemory();
//strcpy(filename2, filename);
genoma *Sample, *Sample2, *SampleTrivial;
// phase will be resolved only for offspring
IndCategory ic=(IndCategory)1; 
bool OnlyChildren=false;
// phenotypes are setup as all children if !ExistPhenotype holds for the sample at filename


//to show distances versus errors (Paola)

 if ((filepos=new char[64])==NULL)
		 throw NoMemory();

	 strcpy (filepos, filename);
	 strtok(filepos, ".");
	 strcat (filepos, ".pos\0");

cout <<"Uploading file " << filename <<"...\n";


if ((Sample = new genoma(filename, filepos, TotalSNPs, Size, true, ic, OnlyChildren))==NULL)
 throw NoMemory();



if ((Sample2 = new genoma(filename, filepos, TotalSNPs, Size, true, ic, OnlyChildren))==NULL)
 throw NoMemory();

//Sample->OrderPositions();


//if ((Sample = new genoma(filename, TotalSNPs, Size, true, ic))==NULL)
// throw NoMemory();



//strcpy (filename4, filename);
//filename3=strtok(filename4, ".");
//strncat(filename4, ".red\0", 4);//

//Sample->WriteResults(filename3);
//exit(0);

//Sample->ResolvePhase((IndCategory)1); 



cout << "heteros:" << Sample->GetHeterozygousGenotypes();


//if ((SampleTrivial = new genoma(filename, TotalSNPs, Size, true, ic))==NULL)
//throw NoMemory();



//if ((SampleTrivial = new genoma(filename4, filepos, TotalSNPs, Size, true, ic))==NULL)
// throw NoMemory();
if ((SampleTrivial = new genoma(*Sample, ic))==NULL)
 throw NoMemory();


cout << "heteros base:" << Sample->GetHeterozygousGenotypes();

cout << "heteros trivial:" << SampleTrivial->GetHeterozygousGenotypes();

 Sample->CheckInconsistencies(*SampleTrivial);


SampleTrivial->ResolveTrivialPhase();


cout << "heteros trivial:" << SampleTrivial->GetHeterozygousGenotypes();

SampleTrivial->TestSPD((IndCategory)1, true, filename);

//Sample->PhaseAccuracy(*SampleTrivial, filename, filenameacc, NULL, Distance);


Sample->PhaseAccuracy(*SampleTrivial, filenameacc, filename, NULL, 0); 
Sample2->PhaseAccuracy(*SampleTrivial, filenameacc, filename, NULL, 1); 

strcpy (filename2, filename);
filename2=strtok(filename2, ".");
strncat(filename2, ".sal\0", 4);//

strcpy (filename3, filename);
filename3=strtok(filename3, ".");
strncat(filename3, ".tri\0", 4);//

Sample->WriteResults(filename2);


SampleTrivial->WriteResults(filename3);

}

}






/*****************/
/*          MAIN          */
/*****************/

using namespace Phase;


int main(int argc, char*argv[]) {

     if(argc!=6)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <fichero> " << " <ficheroacc> " << " <#individuals>" << " <#SNPs>" << " <distance>" << endl;
        exit(-1);
        }
     char* filename;
	 bool Distance;
	 if ((filename=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filename, argv[1]);

		 char* filenameacc;
	 if ((filenameacc=new char[64])==NULL)
		 throw NoMemory();
		 strcpy(filenameacc, argv[2]);
     unsigned int TotalIndividuals=atoi(argv[3]);
     unsigned int TotalSNPs=atoi(argv[4]);
     unsigned short int distance=atoi(argv[5]);
	 if (distance==0) Distance=false; 
	 else  if (distance==1) Distance=true;
	 else cerr <<"Error, distances must be a boolean \n";

	 try{ 

		GenomaProcessing (filename, filenameacc, TotalSNPs, TotalIndividuals, Distance);

		}

	 catch (BadFile bf) {
		 bf.PrintMessage();}
	 catch (NoMemory nm) {
		 nm.PrintMessage();}
	 catch (NullValue nv) {
		 nv.PrintMessage();}

	delete filename;

   return 0;

};


