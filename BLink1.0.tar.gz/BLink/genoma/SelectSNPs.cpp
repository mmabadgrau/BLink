  /**
    * @file genoma.cpp
    * @brief Program for selecting SNP Pos
    * a file with the positions to be chosen must be in the 
	* same directory and with the same name than the input file and extension .posS
    */

#include "FachadeGenoma.h"


//using namespace UTILS;



namespace BIOS {



/* _____________________________________________________*/

void ReduceSample(char *filename, char *filename2, unsigned int density, SNPPos ini=0, SNPPos end=0)
{

GenomaSample *Sample;
if ((Sample = new GenomaSample(filename, everybody, NotChanged))==NULL)
 throw NoMemory();

list<SNPPos> *Sampling;
Sampling=new list<SNPPos>();
//SNPPos size;
if (end==0)
end=Sample->GetTotalSNPs();
//else
//size=end-ini+1;

for (SNPPos i=ini;i<=end;i++)
if (i%density==0)
 Sampling->insertElement(i);



Sample->SNPSampling (Sampling);
//cout <<"filename:" << filename <<",filename2:" << filename2;
//exit(0);
Sample->WriteResults (filename2);

delete Sample;

char filepos[128], filepos2[128]; 
ChangeExtension(filename2, filepos2, "pou");
ChangeExtension(filename, filepos, "pou");
Positions * Pos, *Pos2;
Pos=new Positions (filepos);

Pos->SNPSampling(Sampling);
Pos->PrintPositions (filepos2);

delete Pos, Pos2, Sampling;


}

}

/*****************/
/*          MAIN          */
/*****************/

using namespace BIOS;


int main(int argc, char*argv[]) {

     if(argc<4)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <current file> "  << " <new file> " << "<density>"   << "<inipos>"  << "<endpos>" << endl;
        exit(-1);
        }
     char filename[128], filename2[128];

	 strcpy(filename, argv[1]);
	 strcpy(filename2, argv[2]);

     unsigned int density=atoi(argv[3]);
	SNPPos ini=0, end=0;
    if (argc>4) ini=atoi(argv[4]);

    if (argc>5) end=atoi(argv[5]);

	
        ReduceSample (filename, filename2, density, ini, end);

	   return 0;

}





