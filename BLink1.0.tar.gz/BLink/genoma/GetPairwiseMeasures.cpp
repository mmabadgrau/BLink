

#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>//
#include <math.h>//
#include "../commonc++/Fachade.h"
#include "SNP.h"
#include "Tables2x2.cpp"

#include "Positions.h"
#include "Diplotype.h"
#include "Genotype.h"
#include "Phenotype.h"
#include "PhenotypeSample.h"
#include "GenotypeSample.h"
#include "Trio.h"
#include "Genoma.h"
#include "GenomaSample.h"
#include "TrioSample.h"
#include "PairwiseMeasure.h"
#include "MonolociMeasure.h"
#include "MonolociMeasuresResults.h"
#include "PairwiseMeasuresResults.h"



/*______________________________________________________________________________*/

using namespace BIOS;

int main(int argc, char*argv[]) 
{

AlleleOrderType AlleleOrderMode;
float alphaBayes; 

char line[100];
if(argc<7)
     {
        cerr << "Error: you have to especify the following information:" << endl;
        cerr  << argv[0] << " <gou file> " <<" <Trios (1: yes, 0: no)>" << " <MAF> "  << " <distance (0: default=500kb, -1: only consecutives> " << " <Bayes Type (0:MLE/1:alpha4/2:alpha1/3:Equilibrium/4:Bayes distance Uniform/5:Bayes distance symmetrical>" 
		<< "<alpha Bayes>" << " <ic (father=0, mother=1, offspring=2, everybody=3, parent=4)>" 
		<< "< Phase (0: (trios: standard phase, unrelated: not changed) /1: (trios: partially solved, unrelated: leftright (known phase))>" 
		<<"<alpha ci>" <<"<invariant sites (0: no (default), 1: yes)>" << "<Selection file>"<< endl;

         exit(-1);
        }
  float alpha=90;
  char filename[256], filepos[256], filename2[256], *fileSel=NULL, ext[256];
  strcpy (filename, argv[1]);
  bool trios=atoi(argv[2]); 
  float MAF=atof(argv[3]);
  double distance=atof(argv[4]);
  BayesType BayesMode=(BayesType) atoi(argv[5]);
  alphaBayes=atof(argv[6]);
   IndCategory ic= (IndCategory) atoi(argv[7]);
  bool Phase=atoi(argv[8]);
  if (argc>=10) alpha=atof(argv[9]);
  bool invariant=false;
  if (argc>=11) invariant=atoi(argv[10]);
  if (argc>=12) strcpy(fileSel, argv[11]);


if (MAF==0.0 && invariant)
strcpy(ext, "invariant\0");
else strcpy(ext, "\0");

bool onlyConsecutives=false;

if (distance==-1)
{
sprintf(ext, "%sOnlyConsecPos", ext);
onlyConsecutives=true;
}
else if (distance!=0)
sprintf(ext, "%sOnlyForDistancesShortestThan%d", distance);
else distance=500000;

if (BayesMode==MLE)
sprintf(ext, "%sMAF%d-MLE.pm", ext, (int)(MAF*100));
else
if (BayesMode==BDistanceUniform)
sprintf(ext, "%sMAF%d-BDistanceUniform%f.pm", ext, (int)(MAF*100), alphaBayes);
else
if (BayesMode==BDistanceSymmetrical)
sprintf(ext, "%sMAF%d-BDistanceSymmetrical%f.pm", ext, (int)(MAF*100), alphaBayes);
else
if (BayesMode==BDistanceMarginal)
sprintf(ext, "%sMAF%d-BDistanceMarginal%f.pm", ext, (int)(MAF*100), alphaBayes);



ChangeExtension (filename, filename2, ext);

if (trios)
{
PairwiseMeasuresResults<TrioSample> *PM=NULL;
AlleleOrderMode=MajorFirst;
PM=new PairwiseMeasuresResults<TrioSample>(filename, MAF, BayesMode, alphaBayes, onlyConsecutives, ic, Phase, AlleleOrderMode, alpha, invariant, 0, 0, fileSel);
PM->PrintClassicPairwisesMeasures(filename2, false, distance);
zap(PM);
//exit(0);
}
else
{
PairwiseMeasuresResults<GenomaSample> * PM=NULL;
AlleleOrderMode=LeftRight;
PM=new PairwiseMeasuresResults<GenomaSample>(filename, MAF, BayesMode, alphaBayes, onlyConsecutives, ic, Phase, AlleleOrderMode, alpha, invariant, 0, 0, fileSel);
PM->PrintClassicPairwisesMeasures(filename2, false, distance);
zap(PM);
}



return 0;
};

 


