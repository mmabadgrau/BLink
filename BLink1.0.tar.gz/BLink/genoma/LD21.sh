echo Exist phenotype
echo only parents
echo LD computed from families
echo affected and unaffected
echo transmitted and untransmitted haplotypes
echo Bayesian correction $2 
echo PrintWay
echo sliding size 1700000
echo overlapping 1600000
echo maximum distance 50000
echo MAF greater or equal to $1 
./PhaseResolver data/genotypes_chr21.gen 16511 90 1 0 3 1 0 $2 0 1700000 1600000 50000 $1 
