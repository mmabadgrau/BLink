
/* File: RepeatedGenomaSample.cpp */



#ifndef __RepeatedGenomaSample_cpp__
#define __RepeatedGenomaSample_cpp__


#include "RepeatedGenomaSample.h"
      
        



namespace BIOS {




/*____________________________________________________________ */

RepeatedGenomaSample::RepeatedGenomaSample(char* filename, bool  ExistPhen): 
				PhenotypeSample(filename), 
				RepeatedGenotypeSample(filename, ExistPhen)
{
// cout <<"gentot:" << genotype::TotalSNPs;
};
/*____________________________________________________________ */

void RepeatedGenomaSample::PrintOrderedUnrepeatedGenoma (char* filename, bool PrintPhenotypes)
 {

  PhenotypeSample::NodePointer IndPhenotype=PhenotypeSample::GetFirst(); 
  RepeatedGenotypeSample::NodePointer IndOrderedGenotype=RepeatedGenotypeSample::GetFirst();
  Genotype* genotype;
		ofstream OutputFile;

  try
{
	  OutputFile.open (filename, ifstream::out);
	  if (!OutputFile)
	   throw ErrorFile();
}
catch (ErrorFile NoFile) {
        NoFile.PrintMessage();
      }

while (IndPhenotype!=NULL && IndOrderedGenotype!=NULL)
  {
   if (PrintPhenotypes)	OutputFile << PhenotypeSample::GetElement(IndPhenotype).PrintPhenotype();

	OutputFile << RepeatedGenotypeSample::GetElement(IndOrderedGenotype)->print();    
	OutputFile << "\n";
    IndOrderedGenotype=RepeatedGenotypeSample::GetNext(IndOrderedGenotype);
    IndPhenotype=PhenotypeSample::GetNext(IndPhenotype);
  }
  OutputFile.close();

cout << "\nInformation about ordered genotype has been saved in file " << filename <<"\n";
 }




};  // Fin del Namespace

#endif

/* Fin Fichero: RepeatedGenomaSample.h */
