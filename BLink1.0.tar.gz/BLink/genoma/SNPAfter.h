#ifndef __SNPAfter_h__
#define __SNPAfter_h__

//#include <string.h>
//#include <cstdio>

#include "Exceptions.h"
#include "SNP.h"
#include "Positions.h"


//using namespace UTILS;


namespace BIOS {




/* _____________________________________________________*/

SNPPos GetTotalSNPs(char* filepos)
{
Positions * Pos;
Pos=new Positions (filepos);
return Pos->GetSize();
}

} // end namespace

#endif

/* End of file: SNPAfter.h */
